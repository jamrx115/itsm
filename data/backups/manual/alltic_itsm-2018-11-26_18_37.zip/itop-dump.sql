-- MySQL dump 10.13  Distrib 5.6.41, for Linux (x86_64)
--
-- Host: localhost    Database: alltic_itsm
-- ------------------------------------------------------
-- Server version	5.6.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `applicationsolution`
--

DROP TABLE IF EXISTS `applicationsolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `applicationsolution` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` enum('active','inactive') COLLATE utf8_unicode_ci DEFAULT 'active',
  `redundancy` varchar(20) COLLATE utf8_unicode_ci DEFAULT 'disabled',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applicationsolution`
--

LOCK TABLES `applicationsolution` WRITE;
/*!40000 ALTER TABLE `applicationsolution` DISABLE KEYS */;
INSERT INTO `applicationsolution` VALUES (32,'active','disabled'),(33,'active','disabled');
/*!40000 ALTER TABLE `applicationsolution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attachment`
--

DROP TABLE IF EXISTS `attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attachment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `expire` datetime DEFAULT NULL,
  `temp_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `item_class` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `item_id` int(11) DEFAULT '0',
  `item_org_id` int(11) DEFAULT '0',
  `contents_data` longblob,
  `contents_mimetype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contents_filename` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `temp_id` (`temp_id`),
  KEY `item_class_item_id` (`item_class`,`item_id`),
  KEY `item_org_id` (`item_org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attachment`
--

LOCK TABLES `attachment` WRITE;
/*!40000 ALTER TABLE `attachment` DISABLE KEYS */;
/*!40000 ALTER TABLE `attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `brand`
--

DROP TABLE IF EXISTS `brand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `brand` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brand`
--

LOCK TABLES `brand` WRITE;
/*!40000 ALTER TABLE `brand` DISABLE KEYS */;
/*!40000 ALTER TABLE `brand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `businessprocess`
--

DROP TABLE IF EXISTS `businessprocess`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `businessprocess` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` enum('active','inactive') COLLATE utf8_unicode_ci DEFAULT 'active',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `businessprocess`
--

LOCK TABLES `businessprocess` WRITE;
/*!40000 ALTER TABLE `businessprocess` DISABLE KEYS */;
/*!40000 ALTER TABLE `businessprocess` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `change`
--

DROP TABLE IF EXISTS `change`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `change` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` enum('approved','assigned','closed','implemented','monitored','new','notapproved','plannedscheduled','rejected','validated') COLLATE utf8_unicode_ci DEFAULT 'new',
  `reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `requestor_id` int(11) DEFAULT '0',
  `creation_date` datetime DEFAULT NULL,
  `impact` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `supervisor_group_id` int(11) DEFAULT '0',
  `supervisor_id` int(11) DEFAULT '0',
  `manager_group_id` int(11) DEFAULT '0',
  `manager_id` int(11) DEFAULT '0',
  `outage` enum('no','yes') COLLATE utf8_unicode_ci DEFAULT 'no',
  `fallback` text COLLATE utf8_unicode_ci,
  `parent_id` int(11) DEFAULT '0',
  `external_id_cambios` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `servicefamily_key` int(11) DEFAULT '0',
  `service_key` int(11) DEFAULT '0',
  `servicesubcategory_key` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `requestor_id` (`requestor_id`),
  KEY `supervisor_group_id` (`supervisor_group_id`),
  KEY `supervisor_id` (`supervisor_id`),
  KEY `manager_group_id` (`manager_group_id`),
  KEY `manager_id` (`manager_id`),
  KEY `parent_id` (`parent_id`),
  KEY `servicefamily_key` (`servicefamily_key`),
  KEY `service_key` (`service_key`),
  KEY `servicesubcategory_key` (`servicesubcategory_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `change`
--

LOCK TABLES `change` WRITE;
/*!40000 ALTER TABLE `change` DISABLE KEYS */;
/*!40000 ALTER TABLE `change` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `change_approved`
--

DROP TABLE IF EXISTS `change_approved`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `change_approved` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `approval_date` datetime DEFAULT NULL,
  `approval_comment` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `change_approved`
--

LOCK TABLES `change_approved` WRITE;
/*!40000 ALTER TABLE `change_approved` DISABLE KEYS */;
/*!40000 ALTER TABLE `change_approved` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `change_emergency`
--

DROP TABLE IF EXISTS `change_emergency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `change_emergency` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `change_emergency`
--

LOCK TABLES `change_emergency` WRITE;
/*!40000 ALTER TABLE `change_emergency` DISABLE KEYS */;
/*!40000 ALTER TABLE `change_emergency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `change_normal`
--

DROP TABLE IF EXISTS `change_normal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `change_normal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `change_normal`
--

LOCK TABLES `change_normal` WRITE;
/*!40000 ALTER TABLE `change_normal` DISABLE KEYS */;
/*!40000 ALTER TABLE `change_normal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `change_routine`
--

DROP TABLE IF EXISTS `change_routine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `change_routine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_cambio` enum('New Feature','Patch to Fix') COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `change_routine`
--

LOCK TABLES `change_routine` WRITE;
/*!40000 ALTER TABLE `change_routine` DISABLE KEYS */;
/*!40000 ALTER TABLE `change_routine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `connectableci`
--

DROP TABLE IF EXISTS `connectableci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `connectableci` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `connectableci`
--

LOCK TABLES `connectableci` WRITE;
/*!40000 ALTER TABLE `connectableci` DISABLE KEYS */;
/*!40000 ALTER TABLE `connectableci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `status` enum('active','inactive') COLLATE utf8_unicode_ci DEFAULT 'active',
  `org_id` int(11) DEFAULT '0',
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `notify` enum('no','yes') COLLATE utf8_unicode_ci DEFAULT 'yes',
  `function` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `finalclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Contact',
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `finalclass` (`finalclass`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact`
--

LOCK TABLES `contact` WRITE;
/*!40000 ALTER TABLE `contact` DISABLE KEYS */;
INSERT INTO `contact` VALUES (2,'Leal Ochoa','active',2,'mleal@alltic.co','3799683','yes','Director Operativo','Person'),(3,'Barona García','active',4,'ibarona@alltic.co','3799683','yes','Coordinador de calidad','Person'),(4,'Lozano Galindo','active',4,'jlozano@alltic.co','3799683','yes','Analista de sistemas','Person'),(5,'Vitta Jessurum','active',2,'jcvitta@alltic.co','3799683','yes','C.E.O','Person'),(6,'Castaño Henao','active',4,'jcastano@alltic.co','3799683','yes','Analista de sistemas','Person'),(7,'Martinez Velasco','active',3,'jmartinez@alltic.co','3799683','yes','Coordinador de proyectos','Person'),(8,'Villareal Hernandez','active',2,'pavillareal@alltic.co','3799683','yes','Auxiliar Administrativo','Person'),(9,'Aparicio Garcia','active',3,'caparicio@alltic.co','3799683','yes','Analista de negocio','Person'),(10,'Trejos Perez','active',4,'vtrejos@alltic.co','3799683','yes','Analista de sistemas','Person'),(11,'Cuellar Zambrano','active',4,'hzambrano@alltic.co','3799683','yes','Analista de sistemas','Person'),(12,'Patiño Gomez','active',4,'mpatino@alltic.co','3799683','yes','Analista de sistemas','Person'),(13,'Rengifo Muñoz','active',3,'orengifo@alltic.co','3799683','yes','Analista de sistemas','Person'),(14,'Hernandez Abahonza','active',3,'chernandez@alltic.co','3799683','yes','Desarrollador Jr','Person'),(15,'Granda Escobar','active',4,'mgranda@alltic.co','3799683','yes','Analista de sistemas','Person'),(16,'Lopez Suarez','active',4,'alopez@alltic.co','3799683','yes','Analista de sistemas','Person'),(17,'Gomez Buitrón','active',3,'agomez@alltic.co','3799683','yes','Coordinador de calidad','Person');
/*!40000 ALTER TABLE `contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacttype`
--

DROP TABLE IF EXISTS `contacttype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacttype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacttype`
--

LOCK TABLES `contacttype` WRITE;
/*!40000 ALTER TABLE `contacttype` DISABLE KEYS */;
/*!40000 ALTER TABLE `contacttype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract`
--

DROP TABLE IF EXISTS `contract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contract` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `org_id` int(11) DEFAULT '0',
  `description` text COLLATE utf8_unicode_ci,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `cost` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `cost_currency` enum('dollars','euros') COLLATE utf8_unicode_ci DEFAULT NULL,
  `contracttype_id` int(11) DEFAULT '0',
  `billing_frequency` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `cost_unit` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `provider_id` int(11) DEFAULT '0',
  `status` enum('implementation','obsolete','production') COLLATE utf8_unicode_ci DEFAULT NULL,
  `finalclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Contract',
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `contracttype_id` (`contracttype_id`),
  KEY `provider_id` (`provider_id`),
  KEY `finalclass` (`finalclass`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract`
--

LOCK TABLES `contract` WRITE;
/*!40000 ALTER TABLE `contract` DISABLE KEYS */;
INSERT INTO `contract` VALUES (1,'Atencion Alltic Interno',3,'','2018-11-27',NULL,'','dollars',0,'','',1,'production','CustomerContract');
/*!40000 ALTER TABLE `contract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contracttype`
--

DROP TABLE IF EXISTS `contracttype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contracttype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contracttype`
--

LOCK TABLES `contracttype` WRITE;
/*!40000 ALTER TABLE `contracttype` DISABLE KEYS */;
/*!40000 ALTER TABLE `contracttype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coverage_windows`
--

DROP TABLE IF EXISTS `coverage_windows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coverage_windows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` text COLLATE utf8_unicode_ci,
  `monday_start` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `monday_end` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `tuesday_start` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `tuesday_end` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `wendnesday_start` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `wednesday_end` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `thursday_start` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `thursday_end` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `friday_start` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `friday_end` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `saturday_start` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `saturday_end` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `sunday_start` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `sunday_end` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coverage_windows`
--

LOCK TABLES `coverage_windows` WRITE;
/*!40000 ALTER TABLE `coverage_windows` DISABLE KEYS */;
INSERT INTO `coverage_windows` VALUES (1,'Horario de atencion Alltic ITSM','Horario de disponibilidad en que los recursos atenderan las peticiones que sean registradas en Itop de Alltic ITMS','08:00','18:00','08:00','18:00','08:00','18:00','08:00','18:00','08:00','18:00','08:00','12:00','00:00','00:00');
/*!40000 ALTER TABLE `coverage_windows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customercontract`
--

DROP TABLE IF EXISTS `customercontract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customercontract` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customercontract`
--

LOCK TABLES `customercontract` WRITE;
/*!40000 ALTER TABLE `customercontract` DISABLE KEYS */;
INSERT INTO `customercontract` VALUES (1);
/*!40000 ALTER TABLE `customercontract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `databaseschema`
--

DROP TABLE IF EXISTS `databaseschema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `databaseschema` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dbserver_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `dbserver_id` (`dbserver_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `databaseschema`
--

LOCK TABLES `databaseschema` WRITE;
/*!40000 ALTER TABLE `databaseschema` DISABLE KEYS */;
INSERT INTO `databaseschema` VALUES (20,19),(21,19),(23,22),(24,22),(25,22),(26,22);
/*!40000 ALTER TABLE `databaseschema` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datacenterdevice`
--

DROP TABLE IF EXISTS `datacenterdevice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datacenterdevice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nb_u` int(11) DEFAULT NULL,
  `managementip` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `redundancy` varchar(20) COLLATE utf8_unicode_ci DEFAULT '1',
  `rack_id` int(11) DEFAULT '0',
  `enclosure_id` int(11) DEFAULT '0',
  `powera_id` int(11) DEFAULT '0',
  `powerB_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rack_id` (`rack_id`),
  KEY `enclosure_id` (`enclosure_id`),
  KEY `powera_id` (`powera_id`),
  KEY `powerB_id` (`powerB_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datacenterdevice`
--

LOCK TABLES `datacenterdevice` WRITE;
/*!40000 ALTER TABLE `datacenterdevice` DISABLE KEYS */;
/*!40000 ALTER TABLE `datacenterdevice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbserver`
--

DROP TABLE IF EXISTS `dbserver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbserver` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbserver`
--

LOCK TABLES `dbserver` WRITE;
/*!40000 ALTER TABLE `dbserver` DISABLE KEYS */;
INSERT INTO `dbserver` VALUES (19),(22);
/*!40000 ALTER TABLE `dbserver` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deliverymodel`
--

DROP TABLE IF EXISTS `deliverymodel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deliverymodel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `org_id` int(11) DEFAULT '0',
  `description` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deliverymodel`
--

LOCK TABLES `deliverymodel` WRITE;
/*!40000 ALTER TABLE `deliverymodel` DISABLE KEYS */;
INSERT INTO `deliverymodel` VALUES (1,'Modelo de entrega Alltic Interno',1,'');
/*!40000 ALTER TABLE `deliverymodel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document`
--

DROP TABLE IF EXISTS `document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `document` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `org_id` int(11) DEFAULT '0',
  `documenttype_id` int(11) DEFAULT '0',
  `version` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` text COLLATE utf8_unicode_ci,
  `status` enum('draft','obsolete','published') COLLATE utf8_unicode_ci DEFAULT NULL,
  `finalclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Document',
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `documenttype_id` (`documenttype_id`),
  KEY `finalclass` (`finalclass`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document`
--

LOCK TABLES `document` WRITE;
/*!40000 ALTER TABLE `document` DISABLE KEYS */;
INSERT INTO `document` VALUES (2,'AT-Documentacion Sistema de indicadores Alltic',1,0,'V1','','published','DocumentWeb');
/*!40000 ALTER TABLE `document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documentfile`
--

DROP TABLE IF EXISTS `documentfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documentfile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_data` longblob,
  `file_mimetype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_filename` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documentfile`
--

LOCK TABLES `documentfile` WRITE;
/*!40000 ALTER TABLE `documentfile` DISABLE KEYS */;
/*!40000 ALTER TABLE `documentfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documentnote`
--

DROP TABLE IF EXISTS `documentnote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documentnote` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documentnote`
--

LOCK TABLES `documentnote` WRITE;
/*!40000 ALTER TABLE `documentnote` DISABLE KEYS */;
/*!40000 ALTER TABLE `documentnote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documenttype`
--

DROP TABLE IF EXISTS `documenttype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documenttype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documenttype`
--

LOCK TABLES `documenttype` WRITE;
/*!40000 ALTER TABLE `documenttype` DISABLE KEYS */;
INSERT INTO `documenttype` VALUES (5);
/*!40000 ALTER TABLE `documenttype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documentweb`
--

DROP TABLE IF EXISTS `documentweb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documentweb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(2048) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documentweb`
--

LOCK TABLES `documentweb` WRITE;
/*!40000 ALTER TABLE `documentweb` DISABLE KEYS */;
INSERT INTO `documentweb` VALUES (2,'https://readycloud.netgear.com/client/dllink.html');
/*!40000 ALTER TABLE `documentweb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enclosure`
--

DROP TABLE IF EXISTS `enclosure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enclosure` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rack_id` int(11) DEFAULT '0',
  `nb_u` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rack_id` (`rack_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enclosure`
--

LOCK TABLES `enclosure` WRITE;
/*!40000 ALTER TABLE `enclosure` DISABLE KEYS */;
/*!40000 ALTER TABLE `enclosure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faq`
--

DROP TABLE IF EXISTS `faq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `summary` text COLLATE utf8_unicode_ci,
  `description` longtext COLLATE utf8_unicode_ci,
  `category_id` int(11) DEFAULT '0',
  `error_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `key_words` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faq`
--

LOCK TABLES `faq` WRITE;
/*!40000 ALTER TABLE `faq` DISABLE KEYS */;
/*!40000 ALTER TABLE `faq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faqcategory`
--

DROP TABLE IF EXISTS `faqcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faqcategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nam` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faqcategory`
--

LOCK TABLES `faqcategory` WRITE;
/*!40000 ALTER TABLE `faqcategory` DISABLE KEYS */;
/*!40000 ALTER TABLE `faqcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `farm`
--

DROP TABLE IF EXISTS `farm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `farm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `redundancy` varchar(20) COLLATE utf8_unicode_ci DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `farm`
--

LOCK TABLES `farm` WRITE;
/*!40000 ALTER TABLE `farm` DISABLE KEYS */;
INSERT INTO `farm` VALUES (11,'1');
/*!40000 ALTER TABLE `farm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fiberchannelinterface`
--

DROP TABLE IF EXISTS `fiberchannelinterface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fiberchannelinterface` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `speed` decimal(6,2) DEFAULT NULL,
  `topology` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `wwn` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `datacenterdevice_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `datacenterdevice_id` (`datacenterdevice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fiberchannelinterface`
--

LOCK TABLES `fiberchannelinterface` WRITE;
/*!40000 ALTER TABLE `fiberchannelinterface` DISABLE KEYS */;
/*!40000 ALTER TABLE `fiberchannelinterface` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `functionalci`
--

DROP TABLE IF EXISTS `functionalci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `functionalci` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` text COLLATE utf8_unicode_ci,
  `org_id` int(11) DEFAULT '0',
  `business_criticity` enum('high','low','medium') COLLATE utf8_unicode_ci DEFAULT 'low',
  `move2production` date DEFAULT NULL,
  `finalclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'FunctionalCI',
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `finalclass` (`finalclass`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `functionalci`
--

LOCK TABLES `functionalci` WRITE;
/*!40000 ALTER TABLE `functionalci` DISABLE KEYS */;
INSERT INTO `functionalci` VALUES (11,'Virtualización Alltic','',1,'high','2017-11-01','Farm'),(12,'AT-Godaddy','',1,'high','2017-11-01','Hypervisor'),(13,'AT-AWS','',1,'high','2017-11-01','Hypervisor'),(14,'AT-VPS','',1,'low','2017-11-01','VirtualMachine'),(15,'AT-SQLSERVER','',1,'low','2017-11-01','VirtualMachine'),(16,'AT-REPORTING','',1,'low',NULL,'VirtualMachine'),(17,'IIS','',1,'medium',NULL,'WebServer'),(18,'AT-Indicator Systema','',1,'low',NULL,'WebApplication'),(19,'AT-SQLSERVER','',1,'medium',NULL,'DBServer'),(20,'AT-BD-ALLTIC','',1,'medium',NULL,'DatabaseSchema'),(21,'AT-BD-REPORTING','',1,'medium',NULL,'DatabaseSchema'),(22,'AT-MYSQL-SERVER','',1,'high',NULL,'DBServer'),(23,'AT-BD-ITOP','',1,'high',NULL,'DatabaseSchema'),(24,'AT-BD-TESTLINK','',1,'low',NULL,'DatabaseSchema'),(25,'AT-BD-MANTIS','',1,'high',NULL,'DatabaseSchema'),(26,'AT-BD-TIMETRACKER','',1,'high',NULL,'DatabaseSchema'),(27,'AT-APACHE','',1,'high',NULL,'WebServer'),(28,'AT-APP-ITOP-HUGHES','',1,'high',NULL,'WebApplication'),(29,'AT-APP-MANTIS','',1,'medium',NULL,'WebApplication'),(30,'AT-APP-TESTLINK','',1,'high',NULL,'WebApplication'),(31,'AT-APP-TIMETRACKER','',1,'medium',NULL,'WebApplication'),(32,'AT-SOLUCIÓN APLICATIVA-ITOP','',1,'low',NULL,'ApplicationSolution'),(33,'AT-SISTEMA-INDICADORES','',1,'medium',NULL,'ApplicationSolution'),(34,'ODBC MYSQL','',1,'low',NULL,'OtherSoftware');
/*!40000 ALTER TABLE `functionalci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group`
--

DROP TABLE IF EXISTS `group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `status` enum('implementation','obsolete','production') COLLATE utf8_unicode_ci DEFAULT 'implementation',
  `org_id` int(11) DEFAULT '0',
  `description` text COLLATE utf8_unicode_ci,
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `parent_id` int(11) DEFAULT '0',
  `parent_id_left` int(11) DEFAULT '0',
  `parent_id_right` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `parent_id` (`parent_id`),
  KEY `parent_id_left` (`parent_id_left`),
  KEY `parent_id_right` (`parent_id_right`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group`
--

LOCK TABLES `group` WRITE;
/*!40000 ALTER TABLE `group` DISABLE KEYS */;
/*!40000 ALTER TABLE `group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `holiday_calendar`
--

DROP TABLE IF EXISTS `holiday_calendar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `holiday_calendar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `holiday_calendar`
--

LOCK TABLES `holiday_calendar` WRITE;
/*!40000 ALTER TABLE `holiday_calendar` DISABLE KEYS */;
INSERT INTO `holiday_calendar` VALUES (1,'Calendario Alltic ITSM');
/*!40000 ALTER TABLE `holiday_calendar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `holidays`
--

DROP TABLE IF EXISTS `holidays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `holidays` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `date` date DEFAULT NULL,
  `calendar_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `calendar_id` (`calendar_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `holidays`
--

LOCK TABLES `holidays` WRITE;
/*!40000 ALTER TABLE `holidays` DISABLE KEYS */;
INSERT INTO `holidays` VALUES (1,'Navidad','2018-12-25',1),(2,'Inmaculada concepción','2018-12-08',0),(3,'Año nuevo','2019-01-01',1),(4,'Día de los Reyes Magos','2019-01-07',1),(5,'Dia de San José','2019-03-25',0),(6,'Jueves Santo','2019-04-18',0),(7,'Viernes Santo','2019-04-19',0),(8,'Día del trabajo','2019-05-01',0),(9,'Día de la ascensión','2019-06-03',1),(10,'Corpus Christi','2019-06-24',1),(11,'San Pedro y San Pablo','2019-07-01',0),(12,'Dia de la Independencia','2019-07-20',1),(13,'Batalla de Boyaca','2019-08-07',1),(14,'Día de la Asunción','2019-08-19',1),(15,'Día de la raza','2019-10-14',1),(16,'Dia de todos los santos','2019-11-04',0),(17,'Independencia de Cartagena','2019-11-11',0),(18,'Inmaculada Concepción','2019-12-08',0),(19,'Navidad','2019-12-25',0);
/*!40000 ALTER TABLE `holidays` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hypervisor`
--

DROP TABLE IF EXISTS `hypervisor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hypervisor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `farm_id` int(11) DEFAULT '0',
  `server_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `farm_id` (`farm_id`),
  KEY `server_id` (`server_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hypervisor`
--

LOCK TABLES `hypervisor` WRITE;
/*!40000 ALTER TABLE `hypervisor` DISABLE KEYS */;
INSERT INTO `hypervisor` VALUES (12,0,0),(13,0,0);
/*!40000 ALTER TABLE `hypervisor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inline_image`
--

DROP TABLE IF EXISTS `inline_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inline_image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `expire` datetime DEFAULT NULL,
  `temp_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `item_class` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `item_id` int(11) DEFAULT '0',
  `item_org_id` int(11) DEFAULT '0',
  `contents_data` longblob,
  `contents_mimetype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contents_filename` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `secret` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `temp_id` (`temp_id`),
  KEY `item_class_item_id` (`item_class`,`item_id`),
  KEY `item_org_id` (`item_org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inline_image`
--

LOCK TABLES `inline_image` WRITE;
/*!40000 ALTER TABLE `inline_image` DISABLE KEYS */;
/*!40000 ALTER TABLE `inline_image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `iosversion`
--

DROP TABLE IF EXISTS `iosversion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `iosversion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `brand_id` (`brand_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iosversion`
--

LOCK TABLES `iosversion` WRITE;
/*!40000 ALTER TABLE `iosversion` DISABLE KEYS */;
/*!40000 ALTER TABLE `iosversion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipinterface`
--

DROP TABLE IF EXISTS `ipinterface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipinterface` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipaddress` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `macaddress` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `comment` text COLLATE utf8_unicode_ci,
  `ipgateway` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `ipmask` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `speed` decimal(12,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipinterface`
--

LOCK TABLES `ipinterface` WRITE;
/*!40000 ALTER TABLE `ipinterface` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipinterface` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipphone`
--

DROP TABLE IF EXISTS `ipphone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipphone` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipphone`
--

LOCK TABLES `ipphone` WRITE;
/*!40000 ALTER TABLE `ipphone` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipphone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `knownerror`
--

DROP TABLE IF EXISTS `knownerror`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `knownerror` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `cust_id` int(11) DEFAULT '0',
  `problem_id` int(11) DEFAULT '0',
  `symptom` text COLLATE utf8_unicode_ci,
  `rootcause` text COLLATE utf8_unicode_ci,
  `workaround` text COLLATE utf8_unicode_ci,
  `solution` text COLLATE utf8_unicode_ci,
  `error_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `domain` enum('Application','Desktop','Network','Server') COLLATE utf8_unicode_ci DEFAULT 'Application',
  `vendor` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `model` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `version` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cust_id` (`cust_id`),
  KEY `problem_id` (`problem_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knownerror`
--

LOCK TABLES `knownerror` WRITE;
/*!40000 ALTER TABLE `knownerror` DISABLE KEYS */;
/*!40000 ALTER TABLE `knownerror` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `licence`
--

DROP TABLE IF EXISTS `licence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `licence` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `org_id` int(11) DEFAULT '0',
  `usage_limit` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` text COLLATE utf8_unicode_ci,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `licence_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `perpetual` enum('no','yes') COLLATE utf8_unicode_ci DEFAULT 'no',
  `finalclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Licence',
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `finalclass` (`finalclass`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `licence`
--

LOCK TABLES `licence` WRITE;
/*!40000 ALTER TABLE `licence` DISABLE KEYS */;
INSERT INTO `licence` VALUES (1,'Open source',1,'','Licencia open source GNU',NULL,NULL,'','yes','OSLicence'),(2,'Action Pack',1,'2','Licencia adquirida con el contrato de licenciamiento actin pack de 2017','2017-11-15',NULL,'','yes','OSLicence');
/*!40000 ALTER TABLE `licence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkapplicationsolutiontobusinessprocess`
--

DROP TABLE IF EXISTS `lnkapplicationsolutiontobusinessprocess`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkapplicationsolutiontobusinessprocess` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `businessprocess_id` int(11) DEFAULT '0',
  `applicationsolution_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `businessprocess_id` (`businessprocess_id`),
  KEY `applicationsolution_id` (`applicationsolution_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkapplicationsolutiontobusinessprocess`
--

LOCK TABLES `lnkapplicationsolutiontobusinessprocess` WRITE;
/*!40000 ALTER TABLE `lnkapplicationsolutiontobusinessprocess` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkapplicationsolutiontobusinessprocess` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkapplicationsolutiontofunctionalci`
--

DROP TABLE IF EXISTS `lnkapplicationsolutiontofunctionalci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkapplicationsolutiontofunctionalci` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `applicationsolution_id` int(11) DEFAULT '0',
  `functionalci_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `applicationsolution_id` (`applicationsolution_id`),
  KEY `functionalci_id` (`functionalci_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkapplicationsolutiontofunctionalci`
--

LOCK TABLES `lnkapplicationsolutiontofunctionalci` WRITE;
/*!40000 ALTER TABLE `lnkapplicationsolutiontofunctionalci` DISABLE KEYS */;
INSERT INTO `lnkapplicationsolutiontofunctionalci` VALUES (4,32,28),(5,32,23),(8,33,15),(10,33,17),(15,33,32);
/*!40000 ALTER TABLE `lnkapplicationsolutiontofunctionalci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkconnectablecitonetworkdevice`
--

DROP TABLE IF EXISTS `lnkconnectablecitonetworkdevice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkconnectablecitonetworkdevice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkdevice_id` int(11) DEFAULT '0',
  `connectableci_id` int(11) DEFAULT '0',
  `network_port` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `device_port` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `type` enum('downlink','uplink') COLLATE utf8_unicode_ci DEFAULT 'downlink',
  PRIMARY KEY (`id`),
  KEY `networkdevice_id` (`networkdevice_id`),
  KEY `connectableci_id` (`connectableci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkconnectablecitonetworkdevice`
--

LOCK TABLES `lnkconnectablecitonetworkdevice` WRITE;
/*!40000 ALTER TABLE `lnkconnectablecitonetworkdevice` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkconnectablecitonetworkdevice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcontacttocontract`
--

DROP TABLE IF EXISTS `lnkcontacttocontract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkcontacttocontract` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contract_id` int(11) DEFAULT '0',
  `contact_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `contract_id` (`contract_id`),
  KEY `contact_id` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcontacttocontract`
--

LOCK TABLES `lnkcontacttocontract` WRITE;
/*!40000 ALTER TABLE `lnkcontacttocontract` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkcontacttocontract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcontacttofunctionalci`
--

DROP TABLE IF EXISTS `lnkcontacttofunctionalci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkcontacttofunctionalci` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `functionalci_id` int(11) DEFAULT '0',
  `contact_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `functionalci_id` (`functionalci_id`),
  KEY `contact_id` (`contact_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcontacttofunctionalci`
--

LOCK TABLES `lnkcontacttofunctionalci` WRITE;
/*!40000 ALTER TABLE `lnkcontacttofunctionalci` DISABLE KEYS */;
INSERT INTO `lnkcontacttofunctionalci` VALUES (2,18,7),(3,22,7),(4,32,7);
/*!40000 ALTER TABLE `lnkcontacttofunctionalci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcontacttoservice`
--

DROP TABLE IF EXISTS `lnkcontacttoservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkcontacttoservice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_id` int(11) DEFAULT '0',
  `contact_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  KEY `contact_id` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcontacttoservice`
--

LOCK TABLES `lnkcontacttoservice` WRITE;
/*!40000 ALTER TABLE `lnkcontacttoservice` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkcontacttoservice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcontacttoticket`
--

DROP TABLE IF EXISTS `lnkcontacttoticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkcontacttoticket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) DEFAULT '0',
  `contact_id` int(11) DEFAULT '0',
  `role` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `impact_code` enum('computed','do_not_notify','manual') COLLATE utf8_unicode_ci DEFAULT 'manual',
  PRIMARY KEY (`id`),
  KEY `ticket_id` (`ticket_id`),
  KEY `contact_id` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcontacttoticket`
--

LOCK TABLES `lnkcontacttoticket` WRITE;
/*!40000 ALTER TABLE `lnkcontacttoticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkcontacttoticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcontracttodocument`
--

DROP TABLE IF EXISTS `lnkcontracttodocument`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkcontracttodocument` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contract_id` int(11) DEFAULT '0',
  `document_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `contract_id` (`contract_id`),
  KEY `document_id` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcontracttodocument`
--

LOCK TABLES `lnkcontracttodocument` WRITE;
/*!40000 ALTER TABLE `lnkcontracttodocument` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkcontracttodocument` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcustomercontracttofunctionalci`
--

DROP TABLE IF EXISTS `lnkcustomercontracttofunctionalci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkcustomercontracttofunctionalci` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customercontract_id` int(11) DEFAULT '0',
  `functionalci_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `customercontract_id` (`customercontract_id`),
  KEY `functionalci_id` (`functionalci_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcustomercontracttofunctionalci`
--

LOCK TABLES `lnkcustomercontracttofunctionalci` WRITE;
/*!40000 ALTER TABLE `lnkcustomercontracttofunctionalci` DISABLE KEYS */;
INSERT INTO `lnkcustomercontracttofunctionalci` VALUES (1,1,27),(2,1,28),(3,1,29),(4,1,30),(5,1,31),(6,1,13),(7,1,20),(8,1,23),(9,1,25),(10,1,21),(11,1,24),(12,1,26),(13,1,12),(14,1,18),(15,1,22),(16,1,16),(17,1,33),(18,1,32),(19,1,15),(20,1,19),(21,1,14),(22,1,17),(23,1,34),(24,1,11);
/*!40000 ALTER TABLE `lnkcustomercontracttofunctionalci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcustomercontracttoprovidercontract`
--

DROP TABLE IF EXISTS `lnkcustomercontracttoprovidercontract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkcustomercontracttoprovidercontract` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customercontract_id` int(11) DEFAULT '0',
  `providercontract_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `customercontract_id` (`customercontract_id`),
  KEY `providercontract_id` (`providercontract_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcustomercontracttoprovidercontract`
--

LOCK TABLES `lnkcustomercontracttoprovidercontract` WRITE;
/*!40000 ALTER TABLE `lnkcustomercontracttoprovidercontract` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkcustomercontracttoprovidercontract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcustomercontracttoservice`
--

DROP TABLE IF EXISTS `lnkcustomercontracttoservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkcustomercontracttoservice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customercontract_id` int(11) DEFAULT '0',
  `service_id` int(11) DEFAULT '0',
  `sla_id` int(11) DEFAULT '0',
  `coveragewindow_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `customercontract_id` (`customercontract_id`),
  KEY `service_id` (`service_id`),
  KEY `sla_id` (`sla_id`),
  KEY `coveragewindow_id` (`coveragewindow_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcustomercontracttoservice`
--

LOCK TABLES `lnkcustomercontracttoservice` WRITE;
/*!40000 ALTER TABLE `lnkcustomercontracttoservice` DISABLE KEYS */;
INSERT INTO `lnkcustomercontracttoservice` VALUES (1,1,1,1,1),(2,1,2,1,1);
/*!40000 ALTER TABLE `lnkcustomercontracttoservice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdatacenterdevicetosan`
--

DROP TABLE IF EXISTS `lnkdatacenterdevicetosan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkdatacenterdevicetosan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `san_id` int(11) DEFAULT '0',
  `datacenterdevice_id` int(11) DEFAULT '0',
  `san_port` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `datacenterdevice_port` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `san_id` (`san_id`),
  KEY `datacenterdevice_id` (`datacenterdevice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdatacenterdevicetosan`
--

LOCK TABLES `lnkdatacenterdevicetosan` WRITE;
/*!40000 ALTER TABLE `lnkdatacenterdevicetosan` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdatacenterdevicetosan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdeliverymodeltocontact`
--

DROP TABLE IF EXISTS `lnkdeliverymodeltocontact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkdeliverymodeltocontact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `deliverymodel_id` int(11) DEFAULT '0',
  `contact_id` int(11) DEFAULT '0',
  `role_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `deliverymodel_id` (`deliverymodel_id`),
  KEY `contact_id` (`contact_id`),
  KEY `role_id` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdeliverymodeltocontact`
--

LOCK TABLES `lnkdeliverymodeltocontact` WRITE;
/*!40000 ALTER TABLE `lnkdeliverymodeltocontact` DISABLE KEYS */;
INSERT INTO `lnkdeliverymodeltocontact` VALUES (1,1,7,0),(2,1,9,0);
/*!40000 ALTER TABLE `lnkdeliverymodeltocontact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdocumenttoerror`
--

DROP TABLE IF EXISTS `lnkdocumenttoerror`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkdocumenttoerror` (
  `link_id` int(11) NOT NULL AUTO_INCREMENT,
  `document_id` int(11) DEFAULT '0',
  `error_id` int(11) DEFAULT '0',
  `link_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `document_id` (`document_id`),
  KEY `error_id` (`error_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdocumenttoerror`
--

LOCK TABLES `lnkdocumenttoerror` WRITE;
/*!40000 ALTER TABLE `lnkdocumenttoerror` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdocumenttoerror` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdocumenttofunctionalci`
--

DROP TABLE IF EXISTS `lnkdocumenttofunctionalci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkdocumenttofunctionalci` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `functionalci_id` int(11) DEFAULT '0',
  `document_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `functionalci_id` (`functionalci_id`),
  KEY `document_id` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdocumenttofunctionalci`
--

LOCK TABLES `lnkdocumenttofunctionalci` WRITE;
/*!40000 ALTER TABLE `lnkdocumenttofunctionalci` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdocumenttofunctionalci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdocumenttolicence`
--

DROP TABLE IF EXISTS `lnkdocumenttolicence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkdocumenttolicence` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `licence_id` int(11) DEFAULT '0',
  `document_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `licence_id` (`licence_id`),
  KEY `document_id` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdocumenttolicence`
--

LOCK TABLES `lnkdocumenttolicence` WRITE;
/*!40000 ALTER TABLE `lnkdocumenttolicence` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdocumenttolicence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdocumenttopatch`
--

DROP TABLE IF EXISTS `lnkdocumenttopatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkdocumenttopatch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patch_id` int(11) DEFAULT '0',
  `document_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `patch_id` (`patch_id`),
  KEY `document_id` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdocumenttopatch`
--

LOCK TABLES `lnkdocumenttopatch` WRITE;
/*!40000 ALTER TABLE `lnkdocumenttopatch` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdocumenttopatch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdocumenttoservice`
--

DROP TABLE IF EXISTS `lnkdocumenttoservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkdocumenttoservice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_id` int(11) DEFAULT '0',
  `document_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  KEY `document_id` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdocumenttoservice`
--

LOCK TABLES `lnkdocumenttoservice` WRITE;
/*!40000 ALTER TABLE `lnkdocumenttoservice` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdocumenttoservice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdocumenttosoftware`
--

DROP TABLE IF EXISTS `lnkdocumenttosoftware`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkdocumenttosoftware` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `software_id` int(11) DEFAULT '0',
  `document_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `software_id` (`software_id`),
  KEY `document_id` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdocumenttosoftware`
--

LOCK TABLES `lnkdocumenttosoftware` WRITE;
/*!40000 ALTER TABLE `lnkdocumenttosoftware` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdocumenttosoftware` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkerrortofunctionalci`
--

DROP TABLE IF EXISTS `lnkerrortofunctionalci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkerrortofunctionalci` (
  `link_id` int(11) NOT NULL AUTO_INCREMENT,
  `functionalci_id` int(11) DEFAULT '0',
  `error_id` int(11) DEFAULT '0',
  `dummy` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `functionalci_id` (`functionalci_id`),
  KEY `error_id` (`error_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkerrortofunctionalci`
--

LOCK TABLES `lnkerrortofunctionalci` WRITE;
/*!40000 ALTER TABLE `lnkerrortofunctionalci` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkerrortofunctionalci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkfunctionalcitoospatch`
--

DROP TABLE IF EXISTS `lnkfunctionalcitoospatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkfunctionalcitoospatch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ospatch_id` int(11) DEFAULT '0',
  `functionalci_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ospatch_id` (`ospatch_id`),
  KEY `functionalci_id` (`functionalci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkfunctionalcitoospatch`
--

LOCK TABLES `lnkfunctionalcitoospatch` WRITE;
/*!40000 ALTER TABLE `lnkfunctionalcitoospatch` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkfunctionalcitoospatch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkfunctionalcitoprovidercontract`
--

DROP TABLE IF EXISTS `lnkfunctionalcitoprovidercontract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkfunctionalcitoprovidercontract` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `providercontract_id` int(11) DEFAULT '0',
  `functionalci_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `providercontract_id` (`providercontract_id`),
  KEY `functionalci_id` (`functionalci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkfunctionalcitoprovidercontract`
--

LOCK TABLES `lnkfunctionalcitoprovidercontract` WRITE;
/*!40000 ALTER TABLE `lnkfunctionalcitoprovidercontract` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkfunctionalcitoprovidercontract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkfunctionalcitoservice`
--

DROP TABLE IF EXISTS `lnkfunctionalcitoservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkfunctionalcitoservice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_id` int(11) DEFAULT '0',
  `functionalci_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  KEY `functionalci_id` (`functionalci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkfunctionalcitoservice`
--

LOCK TABLES `lnkfunctionalcitoservice` WRITE;
/*!40000 ALTER TABLE `lnkfunctionalcitoservice` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkfunctionalcitoservice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkfunctionalcitoticket`
--

DROP TABLE IF EXISTS `lnkfunctionalcitoticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkfunctionalcitoticket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) DEFAULT '0',
  `functionalci_id` int(11) DEFAULT '0',
  `impact` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `impact_code` enum('computed','manual','not_impacted') COLLATE utf8_unicode_ci DEFAULT 'manual',
  PRIMARY KEY (`id`),
  KEY `ticket_id` (`ticket_id`),
  KEY `functionalci_id` (`functionalci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkfunctionalcitoticket`
--

LOCK TABLES `lnkfunctionalcitoticket` WRITE;
/*!40000 ALTER TABLE `lnkfunctionalcitoticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkfunctionalcitoticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkgrouptoci`
--

DROP TABLE IF EXISTS `lnkgrouptoci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkgrouptoci` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) DEFAULT '0',
  `ci_id` int(11) DEFAULT '0',
  `reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`),
  KEY `ci_id` (`ci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkgrouptoci`
--

LOCK TABLES `lnkgrouptoci` WRITE;
/*!40000 ALTER TABLE `lnkgrouptoci` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkgrouptoci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkpersontoteam`
--

DROP TABLE IF EXISTS `lnkpersontoteam`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkpersontoteam` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `team_id` int(11) DEFAULT '0',
  `person_id` int(11) DEFAULT '0',
  `role_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `team_id` (`team_id`),
  KEY `person_id` (`person_id`),
  KEY `role_id` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkpersontoteam`
--

LOCK TABLES `lnkpersontoteam` WRITE;
/*!40000 ALTER TABLE `lnkpersontoteam` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkpersontoteam` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkphysicalinterfacetovlan`
--

DROP TABLE IF EXISTS `lnkphysicalinterfacetovlan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkphysicalinterfacetovlan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `physicalinterface_id` int(11) DEFAULT '0',
  `vlan_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `physicalinterface_id` (`physicalinterface_id`),
  KEY `vlan_id` (`vlan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkphysicalinterfacetovlan`
--

LOCK TABLES `lnkphysicalinterfacetovlan` WRITE;
/*!40000 ALTER TABLE `lnkphysicalinterfacetovlan` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkphysicalinterfacetovlan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkprovidercontracttoservice`
--

DROP TABLE IF EXISTS `lnkprovidercontracttoservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkprovidercontracttoservice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_id` int(11) DEFAULT '0',
  `providercontract_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  KEY `providercontract_id` (`providercontract_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkprovidercontracttoservice`
--

LOCK TABLES `lnkprovidercontracttoservice` WRITE;
/*!40000 ALTER TABLE `lnkprovidercontracttoservice` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkprovidercontracttoservice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkservertovolume`
--

DROP TABLE IF EXISTS `lnkservertovolume`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkservertovolume` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `volume_id` int(11) DEFAULT '0',
  `server_id` int(11) DEFAULT '0',
  `size_used` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `volume_id` (`volume_id`),
  KEY `server_id` (`server_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkservertovolume`
--

LOCK TABLES `lnkservertovolume` WRITE;
/*!40000 ALTER TABLE `lnkservertovolume` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkservertovolume` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkslatoslt`
--

DROP TABLE IF EXISTS `lnkslatoslt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkslatoslt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sla_id` int(11) DEFAULT '0',
  `slt_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sla_id` (`sla_id`),
  KEY `slt_id` (`slt_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkslatoslt`
--

LOCK TABLES `lnkslatoslt` WRITE;
/*!40000 ALTER TABLE `lnkslatoslt` DISABLE KEYS */;
INSERT INTO `lnkslatoslt` VALUES (1,1,2),(2,1,9),(3,1,13),(4,1,8),(5,1,1),(6,1,11),(7,1,15),(8,1,5),(9,1,3),(10,1,10),(11,1,14),(12,1,6),(13,1,4),(14,1,12),(15,1,16),(16,1,7);
/*!40000 ALTER TABLE `lnkslatoslt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnksoftwareinstancetosoftwarepatch`
--

DROP TABLE IF EXISTS `lnksoftwareinstancetosoftwarepatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnksoftwareinstancetosoftwarepatch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `softwarepatch_id` int(11) DEFAULT '0',
  `softwareinstance_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `softwarepatch_id` (`softwarepatch_id`),
  KEY `softwareinstance_id` (`softwareinstance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnksoftwareinstancetosoftwarepatch`
--

LOCK TABLES `lnksoftwareinstancetosoftwarepatch` WRITE;
/*!40000 ALTER TABLE `lnksoftwareinstancetosoftwarepatch` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnksoftwareinstancetosoftwarepatch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnksubnettovlan`
--

DROP TABLE IF EXISTS `lnksubnettovlan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnksubnettovlan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subnet_id` int(11) DEFAULT '0',
  `vlan_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `subnet_id` (`subnet_id`),
  KEY `vlan_id` (`vlan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnksubnettovlan`
--

LOCK TABLES `lnksubnettovlan` WRITE;
/*!40000 ALTER TABLE `lnksubnettovlan` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnksubnettovlan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkvirtualdevicetovolume`
--

DROP TABLE IF EXISTS `lnkvirtualdevicetovolume`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkvirtualdevicetovolume` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `volume_id` int(11) DEFAULT '0',
  `virtualdevice_id` int(11) DEFAULT '0',
  `size_used` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `volume_id` (`volume_id`),
  KEY `virtualdevice_id` (`virtualdevice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkvirtualdevicetovolume`
--

LOCK TABLES `lnkvirtualdevicetovolume` WRITE;
/*!40000 ALTER TABLE `lnkvirtualdevicetovolume` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkvirtualdevicetovolume` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `location` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `status` enum('active','inactive') COLLATE utf8_unicode_ci DEFAULT 'active',
  `org_id` int(11) DEFAULT '0',
  `address` text COLLATE utf8_unicode_ci,
  `postal_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `city` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location`
--

LOCK TABLES `location` WRITE;
/*!40000 ALTER TABLE `location` DISABLE KEYS */;
/*!40000 ALTER TABLE `location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logicalinterface`
--

DROP TABLE IF EXISTS `logicalinterface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logicalinterface` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `virtualmachine_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `virtualmachine_id` (`virtualmachine_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logicalinterface`
--

LOCK TABLES `logicalinterface` WRITE;
/*!40000 ALTER TABLE `logicalinterface` DISABLE KEYS */;
/*!40000 ALTER TABLE `logicalinterface` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logicalvolume`
--

DROP TABLE IF EXISTS `logicalvolume`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logicalvolume` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `lun_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` text COLLATE utf8_unicode_ci,
  `raid_level` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `size` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `storagesystem_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `storagesystem_id` (`storagesystem_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logicalvolume`
--

LOCK TABLES `logicalvolume` WRITE;
/*!40000 ALTER TABLE `logicalvolume` DISABLE KEYS */;
/*!40000 ALTER TABLE `logicalvolume` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `middleware`
--

DROP TABLE IF EXISTS `middleware`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `middleware` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `middleware`
--

LOCK TABLES `middleware` WRITE;
/*!40000 ALTER TABLE `middleware` DISABLE KEYS */;
/*!40000 ALTER TABLE `middleware` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `middlewareinstance`
--

DROP TABLE IF EXISTS `middlewareinstance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `middlewareinstance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `middleware_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `middleware_id` (`middleware_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `middlewareinstance`
--

LOCK TABLES `middlewareinstance` WRITE;
/*!40000 ALTER TABLE `middlewareinstance` DISABLE KEYS */;
/*!40000 ALTER TABLE `middlewareinstance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mobilephone`
--

DROP TABLE IF EXISTS `mobilephone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mobilephone` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `imei` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `hw_pin` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mobilephone`
--

LOCK TABLES `mobilephone` WRITE;
/*!40000 ALTER TABLE `mobilephone` DISABLE KEYS */;
/*!40000 ALTER TABLE `mobilephone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model`
--

DROP TABLE IF EXISTS `model`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand_id` int(11) DEFAULT '0',
  `type` enum('DiskArray','Enclosure','IPPhone','MobilePhone','NAS','NetworkDevice','PC','PDU','Peripheral','Phone','PowerSource','Printer','Rack','SANSwitch','Server','StorageSystem','Tablet','TapeLibrary') COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `brand_id` (`brand_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model`
--

LOCK TABLES `model` WRITE;
/*!40000 ALTER TABLE `model` DISABLE KEYS */;
/*!40000 ALTER TABLE `model` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nas`
--

DROP TABLE IF EXISTS `nas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nas`
--

LOCK TABLES `nas` WRITE;
/*!40000 ALTER TABLE `nas` DISABLE KEYS */;
/*!40000 ALTER TABLE `nas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nasfilesystem`
--

DROP TABLE IF EXISTS `nasfilesystem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nasfilesystem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` text COLLATE utf8_unicode_ci,
  `raid_level` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `size` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `nas_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `nas_id` (`nas_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nasfilesystem`
--

LOCK TABLES `nasfilesystem` WRITE;
/*!40000 ALTER TABLE `nasfilesystem` DISABLE KEYS */;
/*!40000 ALTER TABLE `nasfilesystem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `networkdevice`
--

DROP TABLE IF EXISTS `networkdevice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `networkdevice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkdevicetype_id` int(11) DEFAULT '0',
  `iosversion_id` int(11) DEFAULT '0',
  `ram` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `networkdevicetype_id` (`networkdevicetype_id`),
  KEY `iosversion_id` (`iosversion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `networkdevice`
--

LOCK TABLES `networkdevice` WRITE;
/*!40000 ALTER TABLE `networkdevice` DISABLE KEYS */;
/*!40000 ALTER TABLE `networkdevice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `networkdevicetype`
--

DROP TABLE IF EXISTS `networkdevicetype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `networkdevicetype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `networkdevicetype`
--

LOCK TABLES `networkdevicetype` WRITE;
/*!40000 ALTER TABLE `networkdevicetype` DISABLE KEYS */;
/*!40000 ALTER TABLE `networkdevicetype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `networkinterface`
--

DROP TABLE IF EXISTS `networkinterface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `networkinterface` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `finalclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'NetworkInterface',
  PRIMARY KEY (`id`),
  KEY `finalclass` (`finalclass`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `networkinterface`
--

LOCK TABLES `networkinterface` WRITE;
/*!40000 ALTER TABLE `networkinterface` DISABLE KEYS */;
/*!40000 ALTER TABLE `networkinterface` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organization`
--

DROP TABLE IF EXISTS `organization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organization` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `status` enum('active','inactive') COLLATE utf8_unicode_ci DEFAULT 'active',
  `parent_id` int(11) DEFAULT '0',
  `parent_id_left` int(11) DEFAULT '0',
  `parent_id_right` int(11) DEFAULT '0',
  `deliverymodel_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  KEY `parent_id_left` (`parent_id_left`),
  KEY `parent_id_right` (`parent_id_right`),
  KEY `deliverymodel_id` (`deliverymodel_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organization`
--

LOCK TABLES `organization` WRITE;
/*!40000 ALTER TABLE `organization` DISABLE KEYS */;
INSERT INTO `organization` VALUES (1,'Alltic','AT-O001','active',0,1,10,0),(2,'Administrativo','AT-O002','active',1,2,3,1),(3,'Servicio','AT-O003','active',1,4,5,1),(4,'Soporte','AT-O004','active',1,6,7,1),(5,'Clientes','AT-O005','active',1,8,9,0);
/*!40000 ALTER TABLE `organization` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `osfamily`
--

DROP TABLE IF EXISTS `osfamily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `osfamily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `osfamily`
--

LOCK TABLES `osfamily` WRITE;
/*!40000 ALTER TABLE `osfamily` DISABLE KEYS */;
INSERT INTO `osfamily` VALUES (1),(3);
/*!40000 ALTER TABLE `osfamily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oslicence`
--

DROP TABLE IF EXISTS `oslicence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oslicence` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `osversion_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `osversion_id` (`osversion_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oslicence`
--

LOCK TABLES `oslicence` WRITE;
/*!40000 ALTER TABLE `oslicence` DISABLE KEYS */;
INSERT INTO `oslicence` VALUES (1,2),(2,4);
/*!40000 ALTER TABLE `oslicence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospatch`
--

DROP TABLE IF EXISTS `ospatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ospatch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `osversion_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `osversion_id` (`osversion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospatch`
--

LOCK TABLES `ospatch` WRITE;
/*!40000 ALTER TABLE `ospatch` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospatch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `osversion`
--

DROP TABLE IF EXISTS `osversion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `osversion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `osfamily_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `osfamily_id` (`osfamily_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `osversion`
--

LOCK TABLES `osversion` WRITE;
/*!40000 ALTER TABLE `osversion` DISABLE KEYS */;
INSERT INTO `osversion` VALUES (2,1),(4,3);
/*!40000 ALTER TABLE `osversion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `othersoftware`
--

DROP TABLE IF EXISTS `othersoftware`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `othersoftware` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `othersoftware`
--

LOCK TABLES `othersoftware` WRITE;
/*!40000 ALTER TABLE `othersoftware` DISABLE KEYS */;
INSERT INTO `othersoftware` VALUES (34);
/*!40000 ALTER TABLE `othersoftware` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patch`
--

DROP TABLE IF EXISTS `patch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` text COLLATE utf8_unicode_ci,
  `finalclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Patch',
  PRIMARY KEY (`id`),
  KEY `finalclass` (`finalclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patch`
--

LOCK TABLES `patch` WRITE;
/*!40000 ALTER TABLE `patch` DISABLE KEYS */;
/*!40000 ALTER TABLE `patch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pc`
--

DROP TABLE IF EXISTS `pc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `osfamily_id` int(11) DEFAULT '0',
  `osversion_id` int(11) DEFAULT '0',
  `cpu` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `ram` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `type` enum('desktop','laptop') COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `osfamily_id` (`osfamily_id`),
  KEY `osversion_id` (`osversion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pc`
--

LOCK TABLES `pc` WRITE;
/*!40000 ALTER TABLE `pc` DISABLE KEYS */;
/*!40000 ALTER TABLE `pc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pcsoftware`
--

DROP TABLE IF EXISTS `pcsoftware`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pcsoftware` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pcsoftware`
--

LOCK TABLES `pcsoftware` WRITE;
/*!40000 ALTER TABLE `pcsoftware` DISABLE KEYS */;
/*!40000 ALTER TABLE `pcsoftware` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pdu`
--

DROP TABLE IF EXISTS `pdu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pdu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rack_id` int(11) DEFAULT '0',
  `powerstart_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rack_id` (`rack_id`),
  KEY `powerstart_id` (`powerstart_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pdu`
--

LOCK TABLES `pdu` WRITE;
/*!40000 ALTER TABLE `pdu` DISABLE KEYS */;
/*!40000 ALTER TABLE `pdu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `peripheral`
--

DROP TABLE IF EXISTS `peripheral`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `peripheral` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `peripheral`
--

LOCK TABLES `peripheral` WRITE;
/*!40000 ALTER TABLE `peripheral` DISABLE KEYS */;
/*!40000 ALTER TABLE `peripheral` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `person`
--

DROP TABLE IF EXISTS `person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `person` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `picture_data` longblob,
  `picture_mimetype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture_filename` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `employee_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `mobile_phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `location_id` int(11) DEFAULT '0',
  `manager_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `location_id` (`location_id`),
  KEY `manager_id` (`manager_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `person`
--

LOCK TABLES `person` WRITE;
/*!40000 ALTER TABLE `person` DISABLE KEYS */;
INSERT INTO `person` VALUES (2,'','','','Mary','AT-C003','',0,0),(3,'','','','Ivan Dario','AT-C001','',0,2),(4,'','','','Johan Andres','AT-C002','',0,3),(5,'','','','Juan Carlos Alberto','AT-C004','',0,0),(6,'','','','Jonathan','AT-C005','',0,3),(7,'','','','Jaime Alberto','AT-C006','3103101854',0,2),(8,'','','','Paula Andrea','AT-C007','3178836888',0,2),(9,'','','','Carlos Adolfo','AT-C008','',0,2),(10,'','','','Erika Vanessa','AT-C009','',0,3),(11,'','','','Heidy Yaneth','AT-C010','',0,3),(12,'','','','Erick Mateo','AT-C011','',0,3),(13,'','','','Oscar Ivan','AT-C012','',0,7),(14,'','','','Diana Carolina','AT-C013','',0,7),(15,'','','','Maria del mar','AT-C014','',0,3),(16,'','','','Mayra Alejandra','AT-C015','3162588605',0,3),(17,'','','','Adriana Victoria','AT-C016','',0,2);
/*!40000 ALTER TABLE `person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phone`
--

DROP TABLE IF EXISTS `phone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phone` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phone`
--

LOCK TABLES `phone` WRITE;
/*!40000 ALTER TABLE `phone` DISABLE KEYS */;
/*!40000 ALTER TABLE `phone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `physicaldevice`
--

DROP TABLE IF EXISTS `physicaldevice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `physicaldevice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `serialnumber` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `location_id` int(11) DEFAULT '0',
  `status` enum('implementation','obsolete','production','stock') COLLATE utf8_unicode_ci DEFAULT 'production',
  `brand_id` int(11) DEFAULT '0',
  `model_id` int(11) DEFAULT '0',
  `asset_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `purchase_date` date DEFAULT NULL,
  `end_of_warranty` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `location_id` (`location_id`),
  KEY `brand_id` (`brand_id`),
  KEY `model_id` (`model_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `physicaldevice`
--

LOCK TABLES `physicaldevice` WRITE;
/*!40000 ALTER TABLE `physicaldevice` DISABLE KEYS */;
/*!40000 ALTER TABLE `physicaldevice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `physicalinterface`
--

DROP TABLE IF EXISTS `physicalinterface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `physicalinterface` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `connectableci_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `connectableci_id` (`connectableci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `physicalinterface`
--

LOCK TABLES `physicalinterface` WRITE;
/*!40000 ALTER TABLE `physicalinterface` DISABLE KEYS */;
/*!40000 ALTER TABLE `physicalinterface` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `powerconnection`
--

DROP TABLE IF EXISTS `powerconnection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `powerconnection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `powerconnection`
--

LOCK TABLES `powerconnection` WRITE;
/*!40000 ALTER TABLE `powerconnection` DISABLE KEYS */;
/*!40000 ALTER TABLE `powerconnection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `powersource`
--

DROP TABLE IF EXISTS `powersource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `powersource` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `powersource`
--

LOCK TABLES `powersource` WRITE;
/*!40000 ALTER TABLE `powersource` DISABLE KEYS */;
/*!40000 ALTER TABLE `powersource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `printer`
--

DROP TABLE IF EXISTS `printer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `printer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `printer`
--

LOCK TABLES `printer` WRITE;
/*!40000 ALTER TABLE `printer` DISABLE KEYS */;
/*!40000 ALTER TABLE `printer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_action`
--

DROP TABLE IF EXISTS `priv_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_action` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `status` enum('test','enabled','disabled') COLLATE utf8_unicode_ci DEFAULT 'test',
  `realclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Action',
  PRIMARY KEY (`id`),
  KEY `realclass` (`realclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_action`
--

LOCK TABLES `priv_action` WRITE;
/*!40000 ALTER TABLE `priv_action` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_action_email`
--

DROP TABLE IF EXISTS `priv_action_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_action_email` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `test_recipient` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `from` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `reply_to` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `to` text COLLATE utf8_unicode_ci,
  `cc` text COLLATE utf8_unicode_ci,
  `bcc` text COLLATE utf8_unicode_ci,
  `subject` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `body` text COLLATE utf8_unicode_ci,
  `importance` enum('high','low','normal') COLLATE utf8_unicode_ci DEFAULT 'normal',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_action_email`
--

LOCK TABLES `priv_action_email` WRITE;
/*!40000 ALTER TABLE `priv_action_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_action_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_action_notification`
--

DROP TABLE IF EXISTS `priv_action_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_action_notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_action_notification`
--

LOCK TABLES `priv_action_notification` WRITE;
/*!40000 ALTER TABLE `priv_action_notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_action_notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_app_dashboards`
--

DROP TABLE IF EXISTS `priv_app_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_app_dashboards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `menu_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `contents` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_app_dashboards`
--

LOCK TABLES `priv_app_dashboards` WRITE;
/*!40000 ALTER TABLE `priv_app_dashboards` DISABLE KEYS */;
INSERT INTO `priv_app_dashboards` VALUES (1,1,'Service:Overview','<?xml version=\"1.0\"?>\n<dashboard xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n  <layout>DashboardLayoutTwoCols</layout>\n  <title>UI:ServiceMgmtMenuOverview:Title</title>\n  <auto_reload>\n    <enabled>false</enabled>\n    <interval>300</interval>\n  </auto_reload>\n  <cells>\n    <cell id=\"0\">\n      <rank>0</rank>\n      <dashlets>\n        <dashlet id=\"1\" xsi:type=\"DashletObjectList\">\n          <rank>0</rank>\n          <title>UI-ServiceManagementOverview-CustomerContractToRenew</title>\n          <query>SELECT CustomerContract AS c </query>\n          <menu>false</menu>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"1\">\n      <rank>1</rank>\n      <dashlets>\n        <dashlet id=\"2\" xsi:type=\"DashletObjectList\">\n          <rank>0</rank>\n          <title>UI-ServiceManagementOverview-ProviderContractToRenew</title>\n          <query>SELECT ProviderContract AS c WHERE c.end_date &lt; DATE_ADD(NOW(), INTERVAL 30 DAY)</query>\n          <menu>false</menu>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"2\">\n      <rank>2</rank>\n      <dashlets>\n        <dashlet id=\"0\" xsi:type=\"DashletEmptyCell\">\n          <rank>0</rank>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"3\">\n      <rank>3</rank>\n      <dashlets>\n        <dashlet id=\"0\" xsi:type=\"DashletEmptyCell\">\n          <rank>0</rank>\n        </dashlet>\n      </dashlets>\n    </cell>\n  </cells>\n</dashboard>\n'),(2,1,'WelcomeMenuPage','<?xml version=\"1.0\"?>\n<dashboard xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n  <layout>DashboardLayoutOneCol</layout>\n  <title/>\n  <auto_reload>\n    <enabled>false</enabled>\n    <interval>300</interval>\n  </auto_reload>\n  <cells>\n    <cell id=\"0\">\n      <rank>0</rank>\n      <dashlets>\n        <dashlet id=\"1\" xsi:type=\"DashletHeaderStatic\">\n          <rank>0</rank>\n          <title>Menu:ConfigManagementCI</title>\n          <icon>itop-welcome-itil/images/database.png</icon>\n        </dashlet>\n        <dashlet id=\"2\" xsi:type=\"DashletBadge\">\n          <rank>1</rank>\n          <class>BusinessProcess</class>\n        </dashlet>\n        <dashlet id=\"3\" xsi:type=\"DashletBadge\">\n          <rank>2</rank>\n          <class>ApplicationSolution</class>\n        </dashlet>\n        <dashlet id=\"4\" xsi:type=\"DashletBadge\">\n          <rank>3</rank>\n          <class>Contact</class>\n        </dashlet>\n        <dashlet id=\"5\" xsi:type=\"DashletBadge\">\n          <rank>4</rank>\n          <class>Location</class>\n        </dashlet>\n        <dashlet id=\"6\" xsi:type=\"DashletBadge\">\n          <rank>5</rank>\n          <class>Contract</class>\n        </dashlet>\n        <dashlet id=\"7\" xsi:type=\"DashletBadge\">\n          <rank>6</rank>\n          <class>Server</class>\n        </dashlet>\n        <dashlet id=\"8\" xsi:type=\"DashletBadge\">\n          <rank>7</rank>\n          <class>Organization</class>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"1\">\n      <rank>1</rank>\n      <dashlets>\n        <dashlet id=\"11\" xsi:type=\"DashletHeaderDynamic\">\n          <rank>0</rank>\n          <title>Menu:RequestManagement</title>\n          <icon>itop-welcome-itil/images/user-request-deadline.png</icon>\n          <subtitle>Menu:UserRequest:OpenRequests</subtitle>\n          <query>SELECT UserRequest WHERE status != \"closed\"</query>\n          <group_by>status</group_by>\n          <values>assigned,escalated_tto,escalated_ttr,new,resolved</values>\n        </dashlet>\n        <dashlet id=\"12\" xsi:type=\"DashletObjectList\">\n          <rank>1</rank>\n          <title>UI:WelcomeMenu:MyCalls</title>\n          <query>SELECT UserRequest AS i WHERE i.agent_id = :current_contact_id AND status NOT IN (\"closed\", \"resolved\")</query>\n          <menu>true</menu>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"2\">\n      <rank>2</rank>\n      <dashlets>\n        <dashlet id=\"0\" xsi:type=\"DashletEmptyCell\">\n          <rank>0</rank>\n        </dashlet>\n      </dashlets>\n    </cell>\n  </cells>\n</dashboard>\n');
/*!40000 ALTER TABLE `priv_app_dashboards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_app_preferences`
--

DROP TABLE IF EXISTS `priv_app_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_app_preferences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT '0',
  `preferences` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_app_preferences`
--

LOCK TABLES `priv_app_preferences` WRITE;
/*!40000 ALTER TABLE `priv_app_preferences` DISABLE KEYS */;
INSERT INTO `priv_app_preferences` VALUES (1,1,'a:3:{s:13:\"welcome_popup\";s:1:\"0\";s:9:\"menu_pane\";s:4:\"open\";s:9:\"menu_size\";s:3:\"305\";}');
/*!40000 ALTER TABLE `priv_app_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_async_send_email`
--

DROP TABLE IF EXISTS `priv_async_send_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_async_send_email` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` int(11) DEFAULT '1',
  `to` text COLLATE utf8_unicode_ci,
  `subject` text COLLATE utf8_unicode_ci,
  `message` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_async_send_email`
--

LOCK TABLES `priv_async_send_email` WRITE;
/*!40000 ALTER TABLE `priv_async_send_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_async_send_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_async_task`
--

DROP TABLE IF EXISTS `priv_async_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_async_task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` enum('error','idle','planned','running') COLLATE utf8_unicode_ci DEFAULT 'planned',
  `created` datetime DEFAULT NULL,
  `started` datetime DEFAULT NULL,
  `planned` datetime DEFAULT NULL,
  `event_id` int(11) DEFAULT '0',
  `remaining_retries` int(11) DEFAULT '0',
  `last_error_code` int(11) DEFAULT '0',
  `last_error` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `last_attempt` datetime DEFAULT NULL,
  `realclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'AsyncTask',
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  KEY `realclass` (`realclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_async_task`
--

LOCK TABLES `priv_async_task` WRITE;
/*!40000 ALTER TABLE `priv_async_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_async_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_auditcategory`
--

DROP TABLE IF EXISTS `priv_auditcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_auditcategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `definition_set` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_auditcategory`
--

LOCK TABLES `priv_auditcategory` WRITE;
/*!40000 ALTER TABLE `priv_auditcategory` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_auditcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_auditrule`
--

DROP TABLE IF EXISTS `priv_auditrule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_auditrule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `query` text COLLATE utf8_unicode_ci,
  `valid_flag` enum('false','true') COLLATE utf8_unicode_ci DEFAULT 'true',
  `category_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_auditrule`
--

LOCK TABLES `priv_auditrule` WRITE;
/*!40000 ALTER TABLE `priv_auditrule` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_auditrule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_backgroundtask`
--

DROP TABLE IF EXISTS `priv_backgroundtask`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_backgroundtask` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `first_run_date` datetime DEFAULT NULL,
  `latest_run_date` datetime DEFAULT NULL,
  `next_run_date` datetime DEFAULT NULL,
  `total_exec_count` int(11) DEFAULT '0',
  `latest_run_duration` decimal(8,3) DEFAULT '0.000',
  `min_run_duration` decimal(8,3) DEFAULT '0.000',
  `max_run_duration` decimal(8,3) DEFAULT '0.000',
  `average_run_duration` decimal(8,3) DEFAULT '0.000',
  `running` tinyint(1) DEFAULT '0',
  `status` enum('active','paused') COLLATE utf8_unicode_ci DEFAULT 'active',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_backgroundtask`
--

LOCK TABLES `priv_backgroundtask` WRITE;
/*!40000 ALTER TABLE `priv_backgroundtask` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_backgroundtask` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_bulk_export_result`
--

DROP TABLE IF EXISTS `priv_bulk_export_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_bulk_export_result` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created` datetime DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  `chunk_size` int(11) DEFAULT '0',
  `format` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `temp_file_path` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `search` longtext COLLATE utf8_unicode_ci,
  `status_info` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_bulk_export_result`
--

LOCK TABLES `priv_bulk_export_result` WRITE;
/*!40000 ALTER TABLE `priv_bulk_export_result` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_bulk_export_result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_change`
--

DROP TABLE IF EXISTS `priv_change`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_change` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime DEFAULT NULL,
  `userinfo` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `origin` enum('csv-import.php','csv-interactive','custom-extension','email-processing','interactive','synchro-data-source','webservice-rest','webservice-soap') COLLATE utf8_unicode_ci DEFAULT 'interactive',
  PRIMARY KEY (`id`),
  KEY `origin` (`origin`)
) ENGINE=InnoDB AUTO_INCREMENT=192 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_change`
--

LOCK TABLES `priv_change` WRITE;
/*!40000 ALTER TABLE `priv_change` DISABLE KEYS */;
INSERT INTO `priv_change` VALUES (1,'2018-11-19 15:35:02','','interactive'),(2,'2018-11-19 15:35:13','Initialization','interactive'),(3,'2018-11-19 15:35:15','','interactive'),(4,'2018-11-19 10:52:30','My first name My last name','interactive'),(5,'2018-11-19 10:57:43','My first name My last name','interactive'),(6,'2018-11-19 10:58:11','My first name My last name','interactive'),(7,'2018-11-19 10:58:38','My first name My last name','interactive'),(8,'2018-11-19 12:22:57','My first name My last name','interactive'),(9,'2018-11-19 12:23:29','My first name My last name','interactive'),(10,'2018-11-19 12:23:39','My first name My last name','interactive'),(11,'2018-11-19 12:24:20','My first name My last name','interactive'),(12,'2018-11-19 12:24:42','My first name My last name','interactive'),(13,'2018-11-19 12:25:33','My first name My last name','interactive'),(14,'2018-11-19 12:25:50','My first name My last name','interactive'),(15,'2018-11-20 12:07:13','My first name My last name (CSV)','csv-interactive'),(16,'2018-11-20 14:44:35','My first name My last name (CSV)','csv-interactive'),(17,'2018-11-20 14:46:13','My first name My last name','interactive'),(18,'2018-11-20 14:50:44','admin','interactive'),(19,'2018-11-20 14:52:20','admin','interactive'),(20,'2018-11-20 14:52:36','admin','interactive'),(21,'2018-11-20 15:00:24','admin','interactive'),(22,'2018-11-20 15:02:47','admin','interactive'),(23,'2018-11-20 15:04:45','admin','interactive'),(24,'2018-11-20 15:06:19','admin','interactive'),(25,'2018-11-20 15:07:52','admin','interactive'),(26,'2018-11-20 15:26:01','admin','interactive'),(27,'2018-11-20 15:27:09','admin','interactive'),(28,'2018-11-20 15:28:40','admin','interactive'),(29,'2018-11-20 15:30:11','admin','interactive'),(30,'2018-11-20 15:31:37','admin','interactive'),(31,'2018-11-20 15:32:51','admin','interactive'),(32,'2018-11-20 15:34:10','admin','interactive'),(33,'2018-11-20 15:35:22','admin','interactive'),(34,'2018-11-20 15:36:58','admin','interactive'),(35,'2018-11-20 15:38:10','admin','interactive'),(36,'2018-11-20 15:38:41','admin','interactive'),(37,'2018-11-20 15:39:35','admin','interactive'),(38,'2018-11-20 15:40:06','admin','interactive'),(39,'2018-11-20 15:40:32','admin','interactive'),(40,'2018-11-20 15:40:58','admin','interactive'),(41,'2018-11-20 15:41:29','admin','interactive'),(42,'2018-11-20 15:42:01','admin','interactive'),(43,'2018-11-20 15:42:27','admin','interactive'),(44,'2018-11-20 15:42:57','admin','interactive'),(45,'2018-11-20 15:43:33','admin','interactive'),(46,'2018-11-20 15:44:40','admin','interactive'),(47,'2018-11-20 15:45:15','admin','interactive'),(48,'2018-11-20 15:46:00','admin','interactive'),(49,'2018-11-20 15:46:41','admin','interactive'),(50,'2018-11-20 15:47:51','admin','interactive'),(51,'2018-11-20 15:48:41','admin','interactive'),(52,'2018-11-20 15:49:15','admin','interactive'),(53,'2018-11-21 15:33:06','admin','interactive'),(54,'2018-11-21 15:33:36','admin','interactive'),(55,'2018-11-21 15:35:17','admin','interactive'),(56,'2018-11-21 15:35:43','admin','interactive'),(57,'2018-11-21 15:36:07','admin','interactive'),(58,'2018-11-21 15:59:42','admin','interactive'),(59,'2018-11-21 16:02:36','admin','interactive'),(60,'2018-11-21 16:03:23','admin','interactive'),(61,'2018-11-21 16:06:25','admin','interactive'),(62,'2018-11-21 16:07:29','admin','interactive'),(63,'2018-11-21 16:08:02','admin','interactive'),(64,'2018-11-21 16:08:33','admin','interactive'),(65,'2018-11-21 16:09:15','admin','interactive'),(66,'2018-11-21 16:09:36','admin','interactive'),(67,'2018-11-21 16:10:01','admin','interactive'),(68,'2018-11-21 16:10:50','admin','interactive'),(69,'2018-11-21 16:11:28','admin','interactive'),(70,'2018-11-21 16:11:52','admin','interactive'),(71,'2018-11-21 16:12:56','admin','interactive'),(72,'2018-11-21 16:13:22','admin','interactive'),(73,'2018-11-21 16:13:56','admin','interactive'),(74,'2018-11-21 16:14:36','admin','interactive'),(75,'2018-11-21 16:15:02','admin','interactive'),(76,'2018-11-21 16:15:30','admin','interactive'),(77,'2018-11-21 16:16:03','admin','interactive'),(78,'2018-11-21 16:16:35','admin','interactive'),(79,'2018-11-21 16:17:12','admin','interactive'),(80,'2018-11-21 16:38:01','admin','interactive'),(81,'2018-11-21 16:38:44','admin','interactive'),(82,'2018-11-21 16:39:10','admin','interactive'),(83,'2018-11-21 16:39:26','admin','interactive'),(84,'2018-11-21 16:39:43','admin','interactive'),(85,'2018-11-21 16:39:59','admin','interactive'),(86,'2018-11-21 16:41:34','admin','interactive'),(87,'2018-11-21 16:41:49','admin','interactive'),(88,'2018-11-21 16:42:05','admin','interactive'),(89,'2018-11-22 07:33:18','admin','interactive'),(90,'2018-11-22 08:46:46','admin','interactive'),(91,'2018-11-22 08:48:06','admin','interactive'),(92,'2018-11-22 08:49:19','admin','interactive'),(93,'2018-11-22 08:49:54','admin','interactive'),(94,'2018-11-22 08:55:25','admin','interactive'),(95,'2018-11-22 08:56:07','admin','interactive'),(96,'2018-11-22 09:46:57','admin','interactive'),(97,'2018-11-22 09:48:00','admin','interactive'),(98,'2018-11-22 09:48:12','admin','interactive'),(99,'2018-11-22 09:58:55','admin','interactive'),(100,'2018-11-22 10:00:42','admin','interactive'),(101,'2018-11-22 10:01:11','admin','interactive'),(102,'2018-11-22 10:02:05','admin','interactive'),(103,'2018-11-22 10:07:16','admin','interactive'),(104,'2018-11-22 10:08:16','admin','interactive'),(105,'2018-11-22 10:08:50','admin','interactive'),(106,'2018-11-22 10:09:21','admin','interactive'),(107,'2018-11-22 10:09:54','admin','interactive'),(108,'2018-11-22 10:10:46','admin','interactive'),(109,'2018-11-22 10:11:53','admin','interactive'),(110,'2018-11-22 10:12:28','admin','interactive'),(111,'2018-11-22 10:13:01','admin','interactive'),(112,'2018-11-22 10:14:00','admin','interactive'),(113,'2018-11-22 10:16:15','admin','interactive'),(114,'2018-11-22 10:20:13','admin','interactive'),(115,'2018-11-22 10:21:10','admin','interactive'),(116,'2018-11-22 10:22:20','admin','interactive'),(117,'2018-11-22 10:23:17','admin','interactive'),(118,'2018-11-22 10:25:56','admin','interactive'),(119,'2018-11-22 10:28:53','admin','interactive'),(120,'2018-11-22 10:29:27','admin','interactive'),(121,'2018-11-22 10:31:09','admin','interactive'),(122,'2018-11-22 10:32:05','admin','interactive'),(123,'2018-11-22 10:33:41','admin','interactive'),(124,'2018-11-22 10:35:16','admin','interactive'),(125,'2018-11-22 10:36:40','admin','interactive'),(126,'2018-11-22 10:37:25','admin','interactive'),(127,'2018-11-22 10:38:05','admin','interactive'),(128,'2018-11-26 14:45:02','admin','interactive'),(129,'2018-11-26 14:45:56','admin','interactive'),(130,'2018-11-26 14:46:16','admin','interactive'),(131,'2018-11-26 14:47:56','admin','interactive'),(132,'2018-11-26 14:52:32','admin','interactive'),(133,'2018-11-26 14:53:54','admin','interactive'),(134,'2018-11-26 14:54:17','admin','interactive'),(135,'2018-11-26 14:54:29','admin','interactive'),(136,'2018-11-26 14:58:42','admin','interactive'),(137,'2018-11-26 15:01:09','admin','interactive'),(138,'2018-11-26 15:02:00','admin','interactive'),(139,'2018-11-26 15:02:36','admin','interactive'),(140,'2018-11-26 15:03:16','admin','interactive'),(141,'2018-11-26 15:04:29','admin','interactive'),(142,'2018-11-26 15:04:57','admin','interactive'),(143,'2018-11-26 15:06:18','admin','interactive'),(144,'2018-11-26 15:06:36','admin','interactive'),(145,'2018-11-26 15:08:58','admin','interactive'),(146,'2018-11-26 15:12:29','admin','interactive'),(147,'2018-11-26 15:21:36','admin','interactive'),(148,'2018-11-26 15:21:48','admin','interactive'),(149,'2018-11-26 15:22:48','admin','interactive'),(150,'2018-11-26 15:23:18','admin','interactive'),(151,'2018-11-26 15:29:35','admin','interactive'),(152,'2018-11-26 15:37:34','admin','interactive'),(153,'2018-11-26 16:39:21','admin','interactive'),(154,'2018-11-26 16:55:15','admin','interactive'),(155,'2018-11-26 16:56:02','admin','interactive'),(156,'2018-11-26 16:56:27','admin','interactive'),(157,'2018-11-26 16:57:34','admin','interactive'),(158,'2018-11-26 16:59:11','admin','interactive'),(159,'2018-11-26 17:01:01','admin','interactive'),(160,'2018-11-26 17:02:43','admin','interactive'),(161,'2018-11-26 17:02:49','admin','interactive'),(162,'2018-11-26 17:03:03','admin','interactive'),(163,'2018-11-26 17:05:01','admin','interactive'),(164,'2018-11-26 17:05:11','admin','interactive'),(165,'2018-11-26 17:06:26','admin','interactive'),(166,'2018-11-26 17:07:05','admin','interactive'),(167,'2018-11-26 17:09:08','admin','interactive'),(168,'2018-11-26 17:10:43','admin','interactive'),(169,'2018-11-26 17:10:58','admin','interactive'),(170,'2018-11-26 17:12:36','admin','interactive'),(171,'2018-11-26 17:18:14','admin','interactive'),(172,'2018-11-26 17:18:22','admin','interactive'),(173,'2018-11-26 17:21:44','admin','interactive'),(174,'2018-11-26 17:25:04','admin','interactive'),(175,'2018-11-26 17:26:15','admin','interactive'),(176,'2018-11-26 17:28:38','admin','interactive'),(177,'2018-11-26 17:32:54','admin','interactive'),(178,'2018-11-26 17:33:49','admin','interactive'),(179,'2018-11-26 17:35:50','admin','interactive'),(180,'2018-11-26 17:39:17','admin','interactive'),(181,'2018-11-26 17:40:00','admin','interactive'),(182,'2018-11-26 17:40:16','admin','interactive'),(183,'2018-11-26 17:41:41','admin','interactive'),(184,'2018-11-26 17:44:08','admin','interactive'),(185,'2018-11-26 17:47:22','admin','interactive'),(186,'2018-11-26 17:48:40','admin','interactive'),(187,'2018-11-26 17:53:58','admin','interactive'),(188,'2018-11-26 18:02:16','admin','interactive'),(189,'2018-11-26 18:03:43','admin','interactive'),(190,'2018-11-26 18:07:58','admin','interactive'),(191,'2018-11-26 18:18:35','admin','interactive');
/*!40000 ALTER TABLE `priv_change` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop`
--

DROP TABLE IF EXISTS `priv_changeop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changeid` int(11) DEFAULT '0',
  `objclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `objkey` int(11) DEFAULT '0',
  `optype` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'CMDBChangeOp',
  PRIMARY KEY (`id`),
  KEY `changeid` (`changeid`),
  KEY `optype` (`optype`),
  KEY `objclass_objkey` (`objclass`,`objkey`)
) ENGINE=InnoDB AUTO_INCREMENT=461 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop`
--

LOCK TABLES `priv_changeop` WRITE;
/*!40000 ALTER TABLE `priv_changeop` DISABLE KEYS */;
INSERT INTO `priv_changeop` VALUES (1,1,'URP_Profiles',1,'CMDBChangeOpCreate'),(2,1,'URP_Profiles',3,'CMDBChangeOpCreate'),(3,1,'URP_Profiles',4,'CMDBChangeOpCreate'),(4,1,'URP_Profiles',5,'CMDBChangeOpCreate'),(5,1,'URP_Profiles',6,'CMDBChangeOpCreate'),(6,1,'URP_Profiles',7,'CMDBChangeOpCreate'),(7,1,'URP_Profiles',8,'CMDBChangeOpCreate'),(8,1,'URP_Profiles',9,'CMDBChangeOpCreate'),(9,1,'URP_Profiles',10,'CMDBChangeOpCreate'),(10,1,'URP_Profiles',11,'CMDBChangeOpCreate'),(11,1,'URP_Profiles',2,'CMDBChangeOpCreate'),(12,1,'URP_Profiles',12,'CMDBChangeOpCreate'),(13,1,'Organization',1,'CMDBChangeOpCreate'),(16,1,'URP_Profiles',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(17,1,'URP_UserProfile',1,'CMDBChangeOpCreate'),(18,1,'UserLocal',1,'CMDBChangeOpCreate'),(19,3,'ModuleInstallation',1,'CMDBChangeOpCreate'),(20,3,'ModuleInstallation',2,'CMDBChangeOpCreate'),(21,3,'ModuleInstallation',3,'CMDBChangeOpCreate'),(22,3,'ModuleInstallation',4,'CMDBChangeOpCreate'),(23,3,'ModuleInstallation',5,'CMDBChangeOpCreate'),(24,3,'ModuleInstallation',6,'CMDBChangeOpCreate'),(25,3,'ModuleInstallation',7,'CMDBChangeOpCreate'),(26,3,'ModuleInstallation',8,'CMDBChangeOpCreate'),(27,3,'ModuleInstallation',9,'CMDBChangeOpCreate'),(28,3,'ModuleInstallation',10,'CMDBChangeOpCreate'),(29,3,'ModuleInstallation',11,'CMDBChangeOpCreate'),(30,3,'ModuleInstallation',12,'CMDBChangeOpCreate'),(31,3,'ModuleInstallation',13,'CMDBChangeOpCreate'),(32,3,'ModuleInstallation',14,'CMDBChangeOpCreate'),(33,3,'ModuleInstallation',15,'CMDBChangeOpCreate'),(34,3,'ModuleInstallation',16,'CMDBChangeOpCreate'),(35,3,'ModuleInstallation',17,'CMDBChangeOpCreate'),(36,3,'ModuleInstallation',18,'CMDBChangeOpCreate'),(37,3,'ModuleInstallation',19,'CMDBChangeOpCreate'),(38,3,'ModuleInstallation',20,'CMDBChangeOpCreate'),(39,3,'ModuleInstallation',21,'CMDBChangeOpCreate'),(40,3,'ModuleInstallation',22,'CMDBChangeOpCreate'),(41,3,'ModuleInstallation',23,'CMDBChangeOpCreate'),(42,3,'ModuleInstallation',24,'CMDBChangeOpCreate'),(43,3,'ModuleInstallation',25,'CMDBChangeOpCreate'),(44,3,'ModuleInstallation',26,'CMDBChangeOpCreate'),(45,3,'ModuleInstallation',27,'CMDBChangeOpCreate'),(46,3,'ModuleInstallation',28,'CMDBChangeOpCreate'),(47,4,'Organization',1,'CMDBChangeOpSetAttributeScalar'),(48,4,'Organization',1,'CMDBChangeOpSetAttributeScalar'),(49,5,'Organization',2,'CMDBChangeOpCreate'),(50,6,'Organization',3,'CMDBChangeOpCreate'),(51,7,'Organization',4,'CMDBChangeOpCreate'),(53,9,'OSFamily',1,'CMDBChangeOpCreate'),(54,10,'OSVersion',2,'CMDBChangeOpCreate'),(55,11,'OSLicence',1,'CMDBChangeOpCreate'),(57,13,'FunctionalCI',2,'CMDBChangeOpDelete'),(58,14,'FunctionalCI',1,'CMDBChangeOpDelete'),(59,17,'Contact',1,'CMDBChangeOpDelete'),(60,17,'UserLocal',1,'CMDBChangeOpSetAttributeScalar'),(61,18,'Person',2,'CMDBChangeOpCreate'),(62,19,'Person',3,'CMDBChangeOpCreate'),(63,20,'Person',2,'CMDBChangeOpSetAttributeScalar'),(64,21,'Person',4,'CMDBChangeOpCreate'),(65,22,'Person',5,'CMDBChangeOpCreate'),(66,23,'Person',6,'CMDBChangeOpCreate'),(67,24,'Person',7,'CMDBChangeOpCreate'),(68,25,'Person',8,'CMDBChangeOpCreate'),(69,26,'Person',9,'CMDBChangeOpCreate'),(70,27,'Person',10,'CMDBChangeOpCreate'),(71,28,'Person',11,'CMDBChangeOpCreate'),(72,29,'Person',12,'CMDBChangeOpCreate'),(73,30,'Person',13,'CMDBChangeOpCreate'),(74,31,'Person',14,'CMDBChangeOpCreate'),(75,32,'Person',15,'CMDBChangeOpCreate'),(76,33,'Person',16,'CMDBChangeOpCreate'),(77,34,'Person',17,'CMDBChangeOpCreate'),(78,35,'Person',2,'CMDBChangeOpSetAttributeScalar'),(79,36,'Person',17,'CMDBChangeOpSetAttributeScalar'),(80,37,'Person',9,'CMDBChangeOpSetAttributeScalar'),(81,38,'Person',14,'CMDBChangeOpSetAttributeScalar'),(82,39,'Person',12,'CMDBChangeOpSetAttributeScalar'),(83,40,'Person',10,'CMDBChangeOpSetAttributeScalar'),(84,41,'Person',11,'CMDBChangeOpSetAttributeScalar'),(85,42,'Person',3,'CMDBChangeOpSetAttributeScalar'),(86,43,'Person',7,'CMDBChangeOpSetAttributeScalar'),(87,44,'Person',4,'CMDBChangeOpSetAttributeScalar'),(88,45,'Person',6,'CMDBChangeOpSetAttributeScalar'),(89,46,'Person',5,'CMDBChangeOpSetAttributeScalar'),(90,47,'Person',15,'CMDBChangeOpSetAttributeScalar'),(91,48,'Person',2,'CMDBChangeOpSetAttributeScalar'),(92,49,'Person',16,'CMDBChangeOpSetAttributeScalar'),(93,50,'Person',16,'CMDBChangeOpSetAttributeScalar'),(94,51,'Person',13,'CMDBChangeOpSetAttributeScalar'),(95,52,'Person',8,'CMDBChangeOpSetAttributeScalar'),(96,53,'Organization',5,'CMDBChangeOpCreate'),(97,54,'Organization',4,'CMDBChangeOpSetAttributeScalar'),(98,55,'Organization',3,'CMDBChangeOpSetAttributeScalar'),(99,56,'Organization',2,'CMDBChangeOpSetAttributeScalar'),(100,57,'Organization',1,'CMDBChangeOpSetAttributeScalar'),(101,58,'CoverageWindow',1,'CMDBChangeOpCreate'),(102,59,'HolidayCalendar',1,'CMDBChangeOpCreate'),(103,60,'Holiday',1,'CMDBChangeOpCreate'),(104,61,'Holiday',2,'CMDBChangeOpCreate'),(105,62,'Holiday',3,'CMDBChangeOpCreate'),(106,63,'Holiday',4,'CMDBChangeOpCreate'),(107,64,'Holiday',5,'CMDBChangeOpCreate'),(108,65,'Holiday',6,'CMDBChangeOpCreate'),(109,66,'Holiday',7,'CMDBChangeOpCreate'),(110,67,'Holiday',8,'CMDBChangeOpCreate'),(111,68,'Holiday',9,'CMDBChangeOpCreate'),(112,69,'Holiday',10,'CMDBChangeOpCreate'),(113,70,'Holiday',11,'CMDBChangeOpCreate'),(114,71,'Holiday',12,'CMDBChangeOpCreate'),(115,72,'Holiday',13,'CMDBChangeOpCreate'),(116,73,'Holiday',14,'CMDBChangeOpCreate'),(117,74,'Holiday',15,'CMDBChangeOpCreate'),(118,75,'Holiday',16,'CMDBChangeOpCreate'),(119,76,'Holiday',17,'CMDBChangeOpCreate'),(120,77,'Holiday',18,'CMDBChangeOpCreate'),(121,78,'Holiday',19,'CMDBChangeOpCreate'),(122,79,'Holiday',1,'CMDBChangeOpSetAttributeScalar'),(123,80,'HolidayCalendar',1,'CMDBChangeOpSetAttributeScalar'),(124,81,'Holiday',3,'CMDBChangeOpSetAttributeScalar'),(125,82,'Holiday',13,'CMDBChangeOpSetAttributeScalar'),(126,83,'Holiday',10,'CMDBChangeOpSetAttributeScalar'),(127,84,'Holiday',9,'CMDBChangeOpSetAttributeScalar'),(128,85,'Holiday',14,'CMDBChangeOpSetAttributeScalar'),(129,86,'Holiday',12,'CMDBChangeOpSetAttributeScalar'),(130,87,'Holiday',15,'CMDBChangeOpSetAttributeScalar'),(131,88,'Holiday',4,'CMDBChangeOpSetAttributeScalar'),(132,89,'SLA',1,'CMDBChangeOpCreate'),(133,90,'SLT',1,'CMDBChangeOpCreate'),(134,91,'SLT',2,'CMDBChangeOpCreate'),(135,92,'SLT',1,'CMDBChangeOpSetAttributeScalar'),(136,92,'SLT',1,'CMDBChangeOpSetAttributeScalar'),(137,93,'SLT',2,'CMDBChangeOpSetAttributeScalar'),(138,94,'SLT',3,'CMDBChangeOpCreate'),(139,95,'SLT',4,'CMDBChangeOpCreate'),(140,96,'SLT',5,'CMDBChangeOpCreate'),(141,97,'SLT',6,'CMDBChangeOpCreate'),(142,98,'SLT',6,'CMDBChangeOpSetAttributeScalar'),(143,99,'SLT',7,'CMDBChangeOpCreate'),(144,100,'SLT',7,'CMDBChangeOpSetAttributeScalar'),(145,101,'SLT',3,'CMDBChangeOpSetAttributeScalar'),(146,101,'SLT',3,'CMDBChangeOpSetAttributeScalar'),(147,102,'SLT',4,'CMDBChangeOpSetAttributeScalar'),(148,102,'SLT',4,'CMDBChangeOpSetAttributeScalar'),(149,103,'SLT',8,'CMDBChangeOpCreate'),(150,104,'SLT',9,'CMDBChangeOpCreate'),(151,105,'SLT',10,'CMDBChangeOpCreate'),(152,106,'SLT',11,'CMDBChangeOpCreate'),(153,107,'SLT',12,'CMDBChangeOpCreate'),(154,108,'SLT',13,'CMDBChangeOpCreate'),(155,109,'SLT',14,'CMDBChangeOpCreate'),(156,110,'SLT',15,'CMDBChangeOpCreate'),(157,111,'SLT',16,'CMDBChangeOpCreate'),(158,112,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(159,112,'lnkSLAToSLT',1,'CMDBChangeOpCreate'),(160,112,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(161,112,'lnkSLAToSLT',2,'CMDBChangeOpCreate'),(162,112,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(163,112,'lnkSLAToSLT',3,'CMDBChangeOpCreate'),(164,112,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(165,112,'lnkSLAToSLT',4,'CMDBChangeOpCreate'),(166,112,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(167,112,'lnkSLAToSLT',5,'CMDBChangeOpCreate'),(168,112,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(169,112,'lnkSLAToSLT',6,'CMDBChangeOpCreate'),(170,112,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(171,112,'lnkSLAToSLT',7,'CMDBChangeOpCreate'),(172,112,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(173,112,'lnkSLAToSLT',8,'CMDBChangeOpCreate'),(174,112,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(175,112,'lnkSLAToSLT',9,'CMDBChangeOpCreate'),(176,112,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(177,112,'lnkSLAToSLT',10,'CMDBChangeOpCreate'),(178,112,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(179,112,'lnkSLAToSLT',11,'CMDBChangeOpCreate'),(180,112,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(181,112,'lnkSLAToSLT',12,'CMDBChangeOpCreate'),(182,112,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(183,112,'lnkSLAToSLT',13,'CMDBChangeOpCreate'),(184,112,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(185,112,'lnkSLAToSLT',14,'CMDBChangeOpCreate'),(186,112,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(187,112,'lnkSLAToSLT',15,'CMDBChangeOpCreate'),(188,112,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(189,112,'lnkSLAToSLT',16,'CMDBChangeOpCreate'),(190,113,'CustomerContract',1,'CMDBChangeOpCreate'),(191,114,'ServiceFamily',1,'CMDBChangeOpCreate'),(192,115,'Service',1,'CMDBChangeOpCreate'),(193,116,'ServiceSubcategory',1,'CMDBChangeOpCreate'),(194,117,'ServiceSubcategory',2,'CMDBChangeOpCreate'),(195,118,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(196,118,'Service',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(197,118,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(198,118,'lnkCustomerContractToService',1,'CMDBChangeOpCreate'),(199,119,'Service',2,'CMDBChangeOpCreate'),(200,120,'ServiceSubcategory',3,'CMDBChangeOpCreate'),(201,121,'ServiceSubcategory',4,'CMDBChangeOpCreate'),(202,122,'ServiceSubcategory',5,'CMDBChangeOpCreate'),(203,123,'Service',1,'CMDBChangeOpSetAttributeScalar'),(204,124,'ServiceSubcategory',4,'CMDBChangeOpSetAttributeScalar'),(205,125,'ServiceSubcategory',6,'CMDBChangeOpCreate'),(206,126,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(207,126,'Service',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(208,126,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(209,126,'lnkCustomerContractToService',2,'CMDBChangeOpCreate'),(210,127,'Service',1,'CMDBChangeOpSetAttributeScalar'),(212,129,'OSFamily',3,'CMDBChangeOpCreate'),(213,130,'OSVersion',4,'CMDBChangeOpCreate'),(214,131,'OSLicence',2,'CMDBChangeOpCreate'),(239,145,'Person',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(253,146,'lnkApplicationSolutionToFunctionalCI',3,'CMDBChangeOpDelete'),(254,147,'FunctionalCI',4,'CMDBChangeOpDelete'),(255,147,'FunctionalCI',5,'CMDBChangeOpDelete'),(256,147,'FunctionalCI',6,'CMDBChangeOpDelete'),(258,147,'lnkApplicationSolutionToFunctionalCI',1,'CMDBChangeOpDelete'),(259,147,'NetworkInterface',1,'CMDBChangeOpDelete'),(260,147,'FunctionalCI',7,'CMDBChangeOpDelete'),(261,147,'FunctionalCI',9,'CMDBChangeOpDelete'),(263,147,'lnkApplicationSolutionToFunctionalCI',2,'CMDBChangeOpDelete'),(264,147,'FunctionalCI',8,'CMDBChangeOpDelete'),(265,147,'FunctionalCI',3,'CMDBChangeOpDelete'),(266,147,'FunctionalCI',10,'CMDBChangeOpDelete'),(267,147,'Person',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(268,147,'lnkContactToFunctionalCI',1,'CMDBChangeOpDelete'),(269,148,'Software',1,'CMDBChangeOpDelete'),(270,148,'Software',4,'CMDBChangeOpDelete'),(271,148,'Software',7,'CMDBChangeOpDelete'),(272,148,'Software',6,'CMDBChangeOpDelete'),(273,148,'Software',2,'CMDBChangeOpDelete'),(274,148,'Software',3,'CMDBChangeOpDelete'),(275,148,'Software',5,'CMDBChangeOpDelete'),(276,149,'DocumentType',5,'CMDBChangeOpCreate'),(278,151,'Document',1,'CMDBChangeOpDelete'),(279,152,'DocumentWeb',2,'CMDBChangeOpCreate'),(280,153,'Software',8,'CMDBChangeOpCreate'),(281,154,'Farm',11,'CMDBChangeOpCreate'),(282,155,'Hypervisor',12,'CMDBChangeOpCreate'),(283,156,'Hypervisor',13,'CMDBChangeOpCreate'),(284,157,'VirtualMachine',14,'CMDBChangeOpCreate'),(285,158,'VirtualMachine',15,'CMDBChangeOpCreate'),(286,159,'VirtualMachine',16,'CMDBChangeOpCreate'),(287,160,'Software',9,'CMDBChangeOpCreate'),(288,161,'VirtualMachine',16,'CMDBChangeOpSetAttributeLinksAddRemove'),(289,161,'WebServer',17,'CMDBChangeOpCreate'),(291,162,'Person',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(292,162,'lnkContactToFunctionalCI',2,'CMDBChangeOpCreate'),(293,162,'WebServer',17,'CMDBChangeOpSetAttributeLinksAddRemove'),(294,162,'WebApplication',18,'CMDBChangeOpCreate'),(295,163,'Software',10,'CMDBChangeOpCreate'),(296,164,'VirtualMachine',15,'CMDBChangeOpSetAttributeLinksAddRemove'),(297,164,'DBServer',19,'CMDBChangeOpCreate'),(298,165,'DBServer',19,'CMDBChangeOpSetAttributeLinksAddRemove'),(299,165,'DatabaseSchema',20,'CMDBChangeOpCreate'),(300,166,'DBServer',19,'CMDBChangeOpSetAttributeLinksAddRemove'),(301,166,'DatabaseSchema',21,'CMDBChangeOpCreate'),(302,167,'VirtualMachine',16,'CMDBChangeOpSetAttributeScalar'),(303,168,'Software',11,'CMDBChangeOpCreate'),(305,169,'Person',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(306,169,'lnkContactToFunctionalCI',3,'CMDBChangeOpCreate'),(307,169,'VirtualMachine',14,'CMDBChangeOpSetAttributeLinksAddRemove'),(308,169,'DBServer',22,'CMDBChangeOpCreate'),(309,170,'DBServer',22,'CMDBChangeOpSetAttributeLinksAddRemove'),(310,170,'DatabaseSchema',23,'CMDBChangeOpCreate'),(311,170,'DBServer',22,'CMDBChangeOpSetAttributeLinksAddRemove'),(312,170,'DatabaseSchema',24,'CMDBChangeOpCreate'),(313,170,'DBServer',22,'CMDBChangeOpSetAttributeLinksAddRemove'),(314,170,'DatabaseSchema',25,'CMDBChangeOpCreate'),(315,170,'DBServer',22,'CMDBChangeOpSetAttributeLinksAddRemove'),(316,170,'DatabaseSchema',26,'CMDBChangeOpCreate'),(317,170,'VirtualMachine',14,'CMDBChangeOpSetAttributeLinksTune'),(318,171,'Software',12,'CMDBChangeOpCreate'),(320,172,'WebApplication',28,'CMDBChangeOpCreate'),(321,172,'VirtualMachine',14,'CMDBChangeOpSetAttributeLinksAddRemove'),(322,172,'WebServer',27,'CMDBChangeOpCreate'),(323,173,'WebServer',27,'CMDBChangeOpSetAttributeLinksAddRemove'),(324,173,'WebApplication',29,'CMDBChangeOpCreate'),(325,173,'WebServer',27,'CMDBChangeOpSetAttributeLinksAddRemove'),(326,173,'WebApplication',30,'CMDBChangeOpCreate'),(327,173,'WebServer',27,'CMDBChangeOpSetAttributeLinksAddRemove'),(328,173,'WebApplication',31,'CMDBChangeOpCreate'),(329,173,'VirtualMachine',14,'CMDBChangeOpSetAttributeLinksTune'),(330,173,'WebServer',27,'CMDBChangeOpSetAttributeScalar'),(332,174,'Person',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(333,174,'lnkContactToFunctionalCI',4,'CMDBChangeOpCreate'),(335,174,'WebApplication',28,'CMDBChangeOpSetAttributeLinksAddRemove'),(336,174,'lnkApplicationSolutionToFunctionalCI',4,'CMDBChangeOpCreate'),(337,174,'ApplicationSolution',32,'CMDBChangeOpCreate'),(338,175,'ApplicationSolution',32,'CMDBChangeOpSetAttributeLinksAddRemove'),(339,175,'DatabaseSchema',23,'CMDBChangeOpSetAttributeLinksAddRemove'),(340,175,'lnkApplicationSolutionToFunctionalCI',5,'CMDBChangeOpCreate'),(341,176,'VirtualMachine',14,'CMDBChangeOpSetAttributeLinksTune'),(342,176,'DBServer',22,'CMDBChangeOpSetAttributeScalar'),(344,177,'DatabaseSchema',21,'CMDBChangeOpSetAttributeLinksAddRemove'),(347,177,'VirtualMachine',16,'CMDBChangeOpSetAttributeLinksAddRemove'),(350,177,'VirtualMachine',15,'CMDBChangeOpSetAttributeLinksAddRemove'),(351,177,'lnkApplicationSolutionToFunctionalCI',8,'CMDBChangeOpCreate'),(353,177,'DBServer',19,'CMDBChangeOpSetAttributeLinksAddRemove'),(356,177,'WebServer',17,'CMDBChangeOpSetAttributeLinksAddRemove'),(357,177,'lnkApplicationSolutionToFunctionalCI',10,'CMDBChangeOpCreate'),(359,177,'ApplicationSolution',32,'CMDBChangeOpSetAttributeLinksAddRemove'),(361,177,'ApplicationSolution',33,'CMDBChangeOpCreate'),(362,178,'ApplicationSolution',33,'CMDBChangeOpSetAttributeLinksAddRemove'),(363,178,'VirtualMachine',16,'CMDBChangeOpSetAttributeLinksAddRemove'),(364,178,'lnkApplicationSolutionToFunctionalCI',7,'CMDBChangeOpDelete'),(365,178,'ApplicationSolution',33,'CMDBChangeOpSetAttributeLinksAddRemove'),(366,178,'DBServer',19,'CMDBChangeOpSetAttributeLinksAddRemove'),(367,178,'lnkApplicationSolutionToFunctionalCI',9,'CMDBChangeOpDelete'),(368,179,'ApplicationSolution',33,'CMDBChangeOpSetAttributeLinksAddRemove'),(369,179,'DatabaseSchema',21,'CMDBChangeOpSetAttributeLinksAddRemove'),(370,179,'lnkApplicationSolutionToFunctionalCI',6,'CMDBChangeOpDelete'),(371,180,'Software',13,'CMDBChangeOpCreate'),(372,181,'VirtualMachine',15,'CMDBChangeOpSetAttributeLinksAddRemove'),(373,181,'OtherSoftware',34,'CMDBChangeOpCreate'),(374,182,'ApplicationSolution',33,'CMDBChangeOpSetAttributeLinksAddRemove'),(375,182,'OtherSoftware',34,'CMDBChangeOpSetAttributeLinksAddRemove'),(377,182,'VirtualMachine',15,'CMDBChangeOpSetAttributeLinksTune'),(378,183,'ApplicationSolution',33,'CMDBChangeOpSetAttributeLinksAddRemove'),(379,183,'OtherSoftware',34,'CMDBChangeOpSetAttributeLinksAddRemove'),(380,183,'lnkApplicationSolutionToFunctionalCI',12,'CMDBChangeOpDelete'),(381,183,'VirtualMachine',15,'CMDBChangeOpSetAttributeLinksTune'),(382,184,'ApplicationSolution',33,'CMDBChangeOpSetAttributeLinksAddRemove'),(383,184,'OtherSoftware',34,'CMDBChangeOpSetAttributeLinksAddRemove'),(385,184,'ApplicationSolution',32,'CMDBChangeOpSetAttributeLinksAddRemove'),(386,184,'OtherSoftware',34,'CMDBChangeOpSetAttributeLinksAddRemove'),(388,184,'VirtualMachine',15,'CMDBChangeOpSetAttributeLinksTune'),(389,185,'ApplicationSolution',33,'CMDBChangeOpSetAttributeLinksAddRemove'),(390,185,'ApplicationSolution',32,'CMDBChangeOpSetAttributeLinksAddRemove'),(391,185,'lnkApplicationSolutionToFunctionalCI',11,'CMDBChangeOpDelete'),(392,186,'ApplicationSolution',33,'CMDBChangeOpSetAttributeLinksAddRemove'),(393,186,'ApplicationSolution',32,'CMDBChangeOpSetAttributeLinksAddRemove'),(394,186,'lnkApplicationSolutionToFunctionalCI',15,'CMDBChangeOpCreate'),(395,186,'ApplicationSolution',33,'CMDBChangeOpSetAttributeLinksAddRemove'),(396,186,'OtherSoftware',34,'CMDBChangeOpSetAttributeLinksAddRemove'),(397,186,'lnkApplicationSolutionToFunctionalCI',13,'CMDBChangeOpDelete'),(398,187,'ApplicationSolution',32,'CMDBChangeOpSetAttributeLinksAddRemove'),(399,187,'OtherSoftware',34,'CMDBChangeOpSetAttributeLinksAddRemove'),(400,187,'lnkApplicationSolutionToFunctionalCI',14,'CMDBChangeOpDelete'),(401,187,'VirtualMachine',15,'CMDBChangeOpSetAttributeLinksTune'),(402,188,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(403,188,'lnkCustomerContractToFunctionalCI',1,'CMDBChangeOpCreate'),(404,188,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(405,188,'lnkCustomerContractToFunctionalCI',2,'CMDBChangeOpCreate'),(406,188,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(407,188,'lnkCustomerContractToFunctionalCI',3,'CMDBChangeOpCreate'),(408,188,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(409,188,'lnkCustomerContractToFunctionalCI',4,'CMDBChangeOpCreate'),(410,188,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(411,188,'lnkCustomerContractToFunctionalCI',5,'CMDBChangeOpCreate'),(412,188,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(413,188,'lnkCustomerContractToFunctionalCI',6,'CMDBChangeOpCreate'),(414,188,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(415,188,'lnkCustomerContractToFunctionalCI',7,'CMDBChangeOpCreate'),(416,188,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(417,188,'lnkCustomerContractToFunctionalCI',8,'CMDBChangeOpCreate'),(418,188,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(419,188,'lnkCustomerContractToFunctionalCI',9,'CMDBChangeOpCreate'),(420,188,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(421,188,'lnkCustomerContractToFunctionalCI',10,'CMDBChangeOpCreate'),(422,188,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(423,188,'lnkCustomerContractToFunctionalCI',11,'CMDBChangeOpCreate'),(424,188,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(425,188,'lnkCustomerContractToFunctionalCI',12,'CMDBChangeOpCreate'),(426,188,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(427,188,'lnkCustomerContractToFunctionalCI',13,'CMDBChangeOpCreate'),(428,188,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(429,188,'lnkCustomerContractToFunctionalCI',14,'CMDBChangeOpCreate'),(430,188,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(431,188,'lnkCustomerContractToFunctionalCI',15,'CMDBChangeOpCreate'),(432,188,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(433,188,'lnkCustomerContractToFunctionalCI',16,'CMDBChangeOpCreate'),(434,188,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(435,188,'lnkCustomerContractToFunctionalCI',17,'CMDBChangeOpCreate'),(436,188,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(437,188,'lnkCustomerContractToFunctionalCI',18,'CMDBChangeOpCreate'),(438,188,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(439,188,'lnkCustomerContractToFunctionalCI',19,'CMDBChangeOpCreate'),(440,188,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(441,188,'lnkCustomerContractToFunctionalCI',20,'CMDBChangeOpCreate'),(442,188,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(443,188,'lnkCustomerContractToFunctionalCI',21,'CMDBChangeOpCreate'),(444,188,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(445,188,'lnkCustomerContractToFunctionalCI',22,'CMDBChangeOpCreate'),(446,188,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(447,188,'lnkCustomerContractToFunctionalCI',23,'CMDBChangeOpCreate'),(448,188,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(449,188,'lnkCustomerContractToFunctionalCI',24,'CMDBChangeOpCreate'),(451,189,'lnkDeliveryModelToContact',1,'CMDBChangeOpCreate'),(453,189,'lnkDeliveryModelToContact',2,'CMDBChangeOpCreate'),(454,189,'Organization',2,'CMDBChangeOpSetAttributeScalar'),(455,189,'Organization',1,'CMDBChangeOpSetAttributeScalar'),(456,189,'Organization',3,'CMDBChangeOpSetAttributeScalar'),(457,189,'Organization',4,'CMDBChangeOpSetAttributeScalar'),(458,189,'DeliveryModel',1,'CMDBChangeOpCreate'),(459,190,'CustomerContract',1,'CMDBChangeOpSetAttributeScalar'),(460,191,'Organization',1,'CMDBChangeOpSetAttributeScalar');
/*!40000 ALTER TABLE `priv_changeop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_attachment_added`
--

DROP TABLE IF EXISTS `priv_changeop_attachment_added`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_attachment_added` (
  `id` int(11) NOT NULL,
  `attachment_id` int(11) DEFAULT '0',
  `filename` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `attachment_id` (`attachment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_attachment_added`
--

LOCK TABLES `priv_changeop_attachment_added` WRITE;
/*!40000 ALTER TABLE `priv_changeop_attachment_added` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_attachment_added` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_attachment_removed`
--

DROP TABLE IF EXISTS `priv_changeop_attachment_removed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_attachment_removed` (
  `id` int(11) NOT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_attachment_removed`
--

LOCK TABLES `priv_changeop_attachment_removed` WRITE;
/*!40000 ALTER TABLE `priv_changeop_attachment_removed` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_attachment_removed` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_create`
--

DROP TABLE IF EXISTS `priv_changeop_create`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_create` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_create`
--

LOCK TABLES `priv_changeop_create` WRITE;
/*!40000 ALTER TABLE `priv_changeop_create` DISABLE KEYS */;
INSERT INTO `priv_changeop_create` VALUES (1),(2),(3),(4),(5),(6),(7),(8),(9),(10),(11),(12),(13),(17),(18),(19),(20),(21),(22),(23),(24),(25),(26),(27),(28),(29),(30),(31),(32),(33),(34),(35),(36),(37),(38),(39),(40),(41),(42),(43),(44),(45),(46),(49),(50),(51),(53),(54),(55),(61),(62),(64),(65),(66),(67),(68),(69),(70),(71),(72),(73),(74),(75),(76),(77),(96),(101),(102),(103),(104),(105),(106),(107),(108),(109),(110),(111),(112),(113),(114),(115),(116),(117),(118),(119),(120),(121),(132),(133),(134),(138),(139),(140),(141),(143),(149),(150),(151),(152),(153),(154),(155),(156),(157),(159),(161),(163),(165),(167),(169),(171),(173),(175),(177),(179),(181),(183),(185),(187),(189),(190),(191),(192),(193),(194),(198),(199),(200),(201),(202),(205),(209),(212),(213),(214),(276),(279),(280),(281),(282),(283),(284),(285),(286),(287),(289),(292),(294),(295),(297),(299),(301),(303),(306),(308),(310),(312),(314),(316),(318),(320),(322),(324),(326),(328),(333),(336),(337),(340),(351),(357),(361),(371),(373),(394),(403),(405),(407),(409),(411),(413),(415),(417),(419),(421),(423),(425),(427),(429),(431),(433),(435),(437),(439),(441),(443),(445),(447),(449),(451),(453),(458);
/*!40000 ALTER TABLE `priv_changeop_create` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_delete`
--

DROP TABLE IF EXISTS `priv_changeop_delete`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_delete` (
  `id` int(11) NOT NULL,
  `fclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `fname` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_delete`
--

LOCK TABLES `priv_changeop_delete` WRITE;
/*!40000 ALTER TABLE `priv_changeop_delete` DISABLE KEYS */;
INSERT INTO `priv_changeop_delete` VALUES (57,'VirtualMachine','ITOP'),(58,'Hypervisor','AWS'),(59,'Person','My first name My last name'),(253,'lnkApplicationSolutionToFunctionalCI','10 3'),(254,'VirtualMachine','AT-Reporting Services'),(255,'WebServer','Internet Information services AT-Reporting Services'),(256,'OtherSoftware','SQL server Reporting services AT-Reporting Services'),(258,'lnkApplicationSolutionToFunctionalCI','10 4'),(259,'LogicalInterface','Ethernet 01 AT-Reporting Services'),(260,'VirtualMachine','AT-SQL Server'),(261,'OtherSoftware','ODBC Mysql AT-SQL Server'),(263,'lnkApplicationSolutionToFunctionalCI','10 7'),(264,'DBServer','SQL Server AT-SQL Server'),(265,'Hypervisor','AWS'),(266,'ApplicationSolution','Sistema de Indicadores'),(268,'lnkContactToFunctionalCI','10 7'),(269,'Software','IIS 7.0'),(270,'Software','ODBC 3.5'),(271,'Software','Office 2016 Plus'),(272,'Software','Office 365'),(273,'Software','SQL Reporting Services 2014'),(274,'Software','SQL Server Developer 2016'),(275,'Software','WIndows Server 2012 R2'),(278,'DocumentFile','AT-Documentacion Sistema de indicadores Alltic'),(364,'lnkApplicationSolutionToFunctionalCI','33 16'),(367,'lnkApplicationSolutionToFunctionalCI','33 19'),(370,'lnkApplicationSolutionToFunctionalCI','33 21'),(380,'lnkApplicationSolutionToFunctionalCI','33 34'),(391,'lnkApplicationSolutionToFunctionalCI','33 32'),(397,'lnkApplicationSolutionToFunctionalCI','33 34'),(400,'lnkApplicationSolutionToFunctionalCI','32 34');
/*!40000 ALTER TABLE `priv_changeop_delete` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_links`
--

DROP TABLE IF EXISTS `priv_changeop_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_links` (
  `id` int(11) NOT NULL,
  `item_class` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `item_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_links`
--

LOCK TABLES `priv_changeop_links` WRITE;
/*!40000 ALTER TABLE `priv_changeop_links` DISABLE KEYS */;
INSERT INTO `priv_changeop_links` VALUES (16,'User',1),(158,'SLT',2),(160,'SLT',9),(162,'SLT',13),(164,'SLT',8),(166,'SLT',1),(168,'SLT',11),(170,'SLT',15),(172,'SLT',5),(174,'SLT',3),(176,'SLT',10),(178,'SLT',14),(180,'SLT',6),(182,'SLT',4),(184,'SLT',12),(186,'SLT',16),(188,'SLT',7),(195,'Service',1),(196,'CustomerContract',1),(197,'CustomerContract',1),(206,'Service',2),(207,'CustomerContract',1),(208,'CustomerContract',1),(239,'FunctionalCI',10),(267,'FunctionalCI',10),(288,'WebServer',17),(291,'FunctionalCI',18),(293,'WebApplication',18),(296,'DBServer',19),(298,'DatabaseSchema',20),(300,'DatabaseSchema',21),(305,'FunctionalCI',22),(307,'DBServer',22),(309,'DatabaseSchema',23),(311,'DatabaseSchema',24),(313,'DatabaseSchema',25),(315,'DatabaseSchema',26),(317,'DBServer',22),(321,'WebServer',27),(323,'WebApplication',29),(325,'WebApplication',30),(327,'WebApplication',31),(329,'WebServer',27),(332,'FunctionalCI',32),(335,'ApplicationSolution',32),(338,'FunctionalCI',23),(339,'ApplicationSolution',32),(341,'DBServer',22),(344,'ApplicationSolution',33),(347,'ApplicationSolution',33),(350,'ApplicationSolution',33),(353,'ApplicationSolution',33),(356,'ApplicationSolution',33),(359,'ApplicationSolution',33),(362,'FunctionalCI',16),(363,'ApplicationSolution',33),(365,'FunctionalCI',19),(366,'ApplicationSolution',33),(368,'FunctionalCI',21),(369,'ApplicationSolution',33),(372,'OtherSoftware',34),(374,'FunctionalCI',34),(375,'ApplicationSolution',33),(377,'OtherSoftware',34),(378,'FunctionalCI',34),(379,'ApplicationSolution',33),(381,'OtherSoftware',34),(382,'FunctionalCI',34),(383,'ApplicationSolution',33),(385,'FunctionalCI',34),(386,'ApplicationSolution',32),(388,'OtherSoftware',34),(389,'FunctionalCI',32),(390,'ApplicationSolution',33),(392,'FunctionalCI',32),(393,'ApplicationSolution',33),(395,'FunctionalCI',34),(396,'ApplicationSolution',33),(398,'FunctionalCI',34),(399,'ApplicationSolution',32),(401,'OtherSoftware',34),(402,'FunctionalCI',27),(404,'FunctionalCI',28),(406,'FunctionalCI',29),(408,'FunctionalCI',30),(410,'FunctionalCI',31),(412,'FunctionalCI',13),(414,'FunctionalCI',20),(416,'FunctionalCI',23),(418,'FunctionalCI',25),(420,'FunctionalCI',21),(422,'FunctionalCI',24),(424,'FunctionalCI',26),(426,'FunctionalCI',12),(428,'FunctionalCI',18),(430,'FunctionalCI',22),(432,'FunctionalCI',16),(434,'FunctionalCI',33),(436,'FunctionalCI',32),(438,'FunctionalCI',15),(440,'FunctionalCI',19),(442,'FunctionalCI',14),(444,'FunctionalCI',17),(446,'FunctionalCI',34),(448,'FunctionalCI',11);
/*!40000 ALTER TABLE `priv_changeop_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_links_addremove`
--

DROP TABLE IF EXISTS `priv_changeop_links_addremove`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_links_addremove` (
  `id` int(11) NOT NULL,
  `type` enum('added','removed') COLLATE utf8_unicode_ci DEFAULT 'added',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_links_addremove`
--

LOCK TABLES `priv_changeop_links_addremove` WRITE;
/*!40000 ALTER TABLE `priv_changeop_links_addremove` DISABLE KEYS */;
INSERT INTO `priv_changeop_links_addremove` VALUES (16,'added'),(158,'added'),(160,'added'),(162,'added'),(164,'added'),(166,'added'),(168,'added'),(170,'added'),(172,'added'),(174,'added'),(176,'added'),(178,'added'),(180,'added'),(182,'added'),(184,'added'),(186,'added'),(188,'added'),(195,'added'),(196,'added'),(197,'added'),(206,'added'),(207,'added'),(208,'added'),(239,'added'),(267,'removed'),(288,'added'),(291,'added'),(293,'added'),(296,'added'),(298,'added'),(300,'added'),(305,'added'),(307,'added'),(309,'added'),(311,'added'),(313,'added'),(315,'added'),(321,'added'),(323,'added'),(325,'added'),(327,'added'),(332,'added'),(335,'added'),(338,'added'),(339,'added'),(344,'added'),(347,'added'),(350,'added'),(353,'added'),(356,'added'),(359,'added'),(362,'removed'),(363,'removed'),(365,'removed'),(366,'removed'),(368,'removed'),(369,'removed'),(372,'added'),(374,'added'),(375,'added'),(378,'removed'),(379,'removed'),(382,'added'),(383,'added'),(385,'added'),(386,'added'),(389,'removed'),(390,'removed'),(392,'added'),(393,'added'),(395,'removed'),(396,'removed'),(398,'removed'),(399,'removed'),(402,'added'),(404,'added'),(406,'added'),(408,'added'),(410,'added'),(412,'added'),(414,'added'),(416,'added'),(418,'added'),(420,'added'),(422,'added'),(424,'added'),(426,'added'),(428,'added'),(430,'added'),(432,'added'),(434,'added'),(436,'added'),(438,'added'),(440,'added'),(442,'added'),(444,'added'),(446,'added'),(448,'added');
/*!40000 ALTER TABLE `priv_changeop_links_addremove` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_links_tune`
--

DROP TABLE IF EXISTS `priv_changeop_links_tune`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_links_tune` (
  `id` int(11) NOT NULL,
  `link_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_links_tune`
--

LOCK TABLES `priv_changeop_links_tune` WRITE;
/*!40000 ALTER TABLE `priv_changeop_links_tune` DISABLE KEYS */;
INSERT INTO `priv_changeop_links_tune` VALUES (317,22),(329,27),(341,22),(377,34),(381,34),(388,34),(401,34);
/*!40000 ALTER TABLE `priv_changeop_links_tune` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_plugin`
--

DROP TABLE IF EXISTS `priv_changeop_plugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_plugin` (
  `id` int(11) NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_plugin`
--

LOCK TABLES `priv_changeop_plugin` WRITE;
/*!40000 ALTER TABLE `priv_changeop_plugin` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_plugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt`
--

DROP TABLE IF EXISTS `priv_changeop_setatt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_setatt` (
  `id` int(11) NOT NULL,
  `attcode` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt`
--

LOCK TABLES `priv_changeop_setatt` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt` DISABLE KEYS */;
INSERT INTO `priv_changeop_setatt` VALUES (16,'user_list'),(47,'name'),(48,'code'),(60,'contactid'),(63,'employee_number'),(78,'phone'),(79,'org_id'),(80,'org_id'),(81,'org_id'),(82,'org_id'),(83,'org_id'),(84,'org_id'),(85,'org_id'),(86,'org_id'),(87,'org_id'),(88,'org_id'),(89,'org_id'),(90,'org_id'),(91,'org_id'),(92,'org_id'),(93,'mobile_phone'),(94,'org_id'),(95,'org_id'),(97,'code'),(98,'code'),(99,'code'),(100,'code'),(122,'date'),(123,'name'),(124,'calendar_id'),(125,'calendar_id'),(126,'calendar_id'),(127,'calendar_id'),(128,'calendar_id'),(129,'calendar_id'),(130,'calendar_id'),(131,'calendar_id'),(135,'name'),(136,'value'),(137,'value'),(142,'unit'),(144,'value'),(145,'value'),(146,'unit'),(147,'value'),(148,'unit'),(158,'slts_list'),(160,'slts_list'),(162,'slts_list'),(164,'slts_list'),(166,'slts_list'),(168,'slts_list'),(170,'slts_list'),(172,'slts_list'),(174,'slts_list'),(176,'slts_list'),(178,'slts_list'),(180,'slts_list'),(182,'slts_list'),(184,'slts_list'),(186,'slts_list'),(188,'slts_list'),(195,'services_list'),(196,'customercontracts_list'),(197,'customercontracts_list'),(203,'name'),(204,'name'),(206,'services_list'),(207,'customercontracts_list'),(208,'customercontracts_list'),(210,'description'),(239,'cis_list'),(267,'cis_list'),(288,'softwares_list'),(291,'cis_list'),(293,'webapp_list'),(296,'softwares_list'),(298,'dbschema_list'),(300,'dbschema_list'),(302,'name'),(305,'cis_list'),(307,'softwares_list'),(309,'dbschema_list'),(311,'dbschema_list'),(313,'dbschema_list'),(315,'dbschema_list'),(317,'softwares_list'),(321,'softwares_list'),(323,'webapp_list'),(325,'webapp_list'),(327,'webapp_list'),(329,'softwares_list'),(330,'name'),(332,'cis_list'),(335,'applicationsolution_list'),(338,'functionalcis_list'),(339,'applicationsolution_list'),(341,'softwares_list'),(342,'name'),(344,'applicationsolution_list'),(347,'applicationsolution_list'),(350,'applicationsolution_list'),(353,'applicationsolution_list'),(356,'applicationsolution_list'),(359,'applicationsolution_list'),(362,'functionalcis_list'),(363,'applicationsolution_list'),(365,'functionalcis_list'),(366,'applicationsolution_list'),(368,'functionalcis_list'),(369,'applicationsolution_list'),(372,'softwares_list'),(374,'functionalcis_list'),(375,'applicationsolution_list'),(377,'softwares_list'),(378,'functionalcis_list'),(379,'applicationsolution_list'),(381,'softwares_list'),(382,'functionalcis_list'),(383,'applicationsolution_list'),(385,'functionalcis_list'),(386,'applicationsolution_list'),(388,'softwares_list'),(389,'functionalcis_list'),(390,'applicationsolution_list'),(392,'functionalcis_list'),(393,'applicationsolution_list'),(395,'functionalcis_list'),(396,'applicationsolution_list'),(398,'functionalcis_list'),(399,'applicationsolution_list'),(401,'softwares_list'),(402,'functionalcis_list'),(404,'functionalcis_list'),(406,'functionalcis_list'),(408,'functionalcis_list'),(410,'functionalcis_list'),(412,'functionalcis_list'),(414,'functionalcis_list'),(416,'functionalcis_list'),(418,'functionalcis_list'),(420,'functionalcis_list'),(422,'functionalcis_list'),(424,'functionalcis_list'),(426,'functionalcis_list'),(428,'functionalcis_list'),(430,'functionalcis_list'),(432,'functionalcis_list'),(434,'functionalcis_list'),(436,'functionalcis_list'),(438,'functionalcis_list'),(440,'functionalcis_list'),(442,'functionalcis_list'),(444,'functionalcis_list'),(446,'functionalcis_list'),(448,'functionalcis_list'),(454,'deliverymodel_id'),(455,'deliverymodel_id'),(456,'deliverymodel_id'),(457,'deliverymodel_id'),(459,'org_id'),(460,'deliverymodel_id');
/*!40000 ALTER TABLE `priv_changeop_setatt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_custfields`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_custfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_setatt_custfields` (
  `id` int(11) NOT NULL,
  `prevdata` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_custfields`
--

LOCK TABLES `priv_changeop_setatt_custfields` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_custfields` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_setatt_custfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_data`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_setatt_data` (
  `id` int(11) NOT NULL,
  `prevdata_data` longblob,
  `prevdata_mimetype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prevdata_filename` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_data`
--

LOCK TABLES `priv_changeop_setatt_data` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_setatt_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_encrypted`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_encrypted`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_setatt_encrypted` (
  `id` int(11) NOT NULL,
  `data` tinyblob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_encrypted`
--

LOCK TABLES `priv_changeop_setatt_encrypted` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_encrypted` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_setatt_encrypted` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_html`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_html`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_setatt_html` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_html`
--

LOCK TABLES `priv_changeop_setatt_html` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_html` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_setatt_html` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_log`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_setatt_log` (
  `id` int(11) NOT NULL,
  `lastentry` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_log`
--

LOCK TABLES `priv_changeop_setatt_log` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_setatt_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_longtext`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_longtext`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_setatt_longtext` (
  `id` int(11) NOT NULL,
  `prevdata` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_longtext`
--

LOCK TABLES `priv_changeop_setatt_longtext` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_longtext` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_setatt_longtext` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_pwd`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_pwd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_setatt_pwd` (
  `id` int(11) NOT NULL,
  `prev_pwd_hash` tinyblob,
  `prev_pwd_salt` tinyblob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_pwd`
--

LOCK TABLES `priv_changeop_setatt_pwd` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_pwd` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_setatt_pwd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_scalar`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_scalar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_setatt_scalar` (
  `id` int(11) NOT NULL,
  `oldvalue` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `newvalue` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_scalar`
--

LOCK TABLES `priv_changeop_setatt_scalar` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_scalar` DISABLE KEYS */;
INSERT INTO `priv_changeop_setatt_scalar` VALUES (47,'My Company/Department','Alltic'),(48,'SOMECODE','AT-001'),(60,'1','0'),(63,'AT-C03','AT-C003'),(78,'7399683','3799683'),(79,'1','3'),(80,'1','3'),(81,'1','3'),(82,'1','4'),(83,'1','4'),(84,'1','4'),(85,'1','4'),(86,'1','3'),(87,'1','4'),(88,'1','4'),(89,'1','2'),(90,'1','4'),(91,'1','2'),(92,'1','4'),(93,'','3162588605'),(94,'1','3'),(95,'1','2'),(97,'AT-004','AT-O004'),(98,'AT-003','AT-O003'),(99,'AT-002','AT-O002'),(100,'AT-001','AT-O001'),(122,'2018-12-24','2018-12-25'),(123,'Navidad','Calendario Alltic ITSM'),(124,'0','1'),(125,'0','1'),(126,'0','1'),(127,'0','1'),(128,'0','1'),(129,'0','1'),(130,'0','1'),(131,'0','1'),(135,'TDA Alto','TDA S-Alto'),(136,'24','30'),(137,'24','30'),(142,'','hours'),(144,'4','20'),(145,'210','3'),(146,'minutes','hours'),(147,'210','3'),(148,'minutes','hours'),(203,'AT-TestLink','AT-TL'),(204,'Creación de usuarios BT','Gestion roles y perfiles de usuario'),(210,'Herramientas de diseño y ejeucion de Casos de prueba','TestLink / diseño y ejeucion de Casos de prueba'),(302,'AT-Reporting','AT-REPORTING'),(330,'AT-APP-ITOP-HUGHES','AT-APACHE'),(342,'AT-SERVERR-MYSQL','AT-MYSQL-SERVER'),(454,'0','1'),(455,'0','1'),(456,'0','1'),(457,'0','1'),(459,'1','3'),(460,'1','0');
/*!40000 ALTER TABLE `priv_changeop_setatt_scalar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_text`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_text`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_setatt_text` (
  `id` int(11) NOT NULL,
  `prevdata` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_text`
--

LOCK TABLES `priv_changeop_setatt_text` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_text` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_setatt_text` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_url`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_url`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_setatt_url` (
  `id` int(11) NOT NULL,
  `oldvalue` varchar(2048) COLLATE utf8_unicode_ci DEFAULT '',
  `newvalue` varchar(2048) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_url`
--

LOCK TABLES `priv_changeop_setatt_url` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_url` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_setatt_url` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_db_properties`
--

DROP TABLE IF EXISTS `priv_db_properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_db_properties` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `change_date` datetime DEFAULT NULL,
  `change_comment` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_db_properties`
--

LOCK TABLES `priv_db_properties` WRITE;
/*!40000 ALTER TABLE `priv_db_properties` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_db_properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event`
--

DROP TABLE IF EXISTS `priv_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message` text COLLATE utf8_unicode_ci,
  `date` datetime DEFAULT NULL,
  `userinfo` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `realclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Event',
  PRIMARY KEY (`id`),
  KEY `realclass` (`realclass`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event`
--

LOCK TABLES `priv_event` WRITE;
/*!40000 ALTER TABLE `priv_event` DISABLE KEYS */;
INSERT INTO `priv_event` VALUES (1,'Unknown attribute pais_ticket from class UserRequest','2018-11-22 10:32:17','','EventIssue'),(2,'Unknown attribute pais_ticket from class UserRequest','2018-11-23 17:57:44','','EventIssue'),(3,'Unknown attribute pais_ticket from class UserRequest','2018-11-23 17:58:46','','EventIssue'),(4,'Unknown attribute pais_ticket from class Incident','2018-11-23 17:59:19','','EventIssue'),(5,'Unknown attribute pais_ticket from class Incident','2018-11-24 00:16:54','','EventIssue'),(6,'Unknown attribute pais_ticket from class UserRequest','2018-11-24 00:48:55','','EventIssue');
/*!40000 ALTER TABLE `priv_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event_email`
--

DROP TABLE IF EXISTS `priv_event_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_event_email` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `to` text COLLATE utf8_unicode_ci,
  `cc` text COLLATE utf8_unicode_ci,
  `bcc` text COLLATE utf8_unicode_ci,
  `from` text COLLATE utf8_unicode_ci,
  `subject` text COLLATE utf8_unicode_ci,
  `body` longtext COLLATE utf8_unicode_ci,
  `attachments` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event_email`
--

LOCK TABLES `priv_event_email` WRITE;
/*!40000 ALTER TABLE `priv_event_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_event_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event_issue`
--

DROP TABLE IF EXISTS `priv_event_issue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_event_issue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `issue` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `impact` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `page` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `arguments_post` longtext COLLATE utf8_unicode_ci,
  `arguments_get` longtext COLLATE utf8_unicode_ci,
  `callstack` longtext COLLATE utf8_unicode_ci,
  `data` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event_issue`
--

LOCK TABLES `priv_event_issue` WRITE;
/*!40000 ALTER TABLE `priv_event_issue` DISABLE KEYS */;
INSERT INTO `priv_event_issue` VALUES (1,'PHP Exception','Page could not be displayed','/itsm/pages/UI.php','a:0:{}','a:3:{s:9:\"operation\";s:3:\"new\";s:5:\"class\";s:11:\"UserRequest\";s:1:\"c\";a:1:{s:4:\"menu\";s:14:\"NewUserRequest\";}}','a:3:{i:0;a:6:{s:4:\"file\";s:54:\"/home/alltic/public_html/itsm/core/metamodel.class.php\";s:4:\"line\";i:481;s:8:\"function\";s:15:\"GetAttributeDef\";s:5:\"class\";s:9:\"MetaModel\";s:4:\"type\";s:2:\"::\";s:4:\"args\";a:2:{i:0;s:11:\"UserRequest\";i:1;s:11:\"pais_ticket\";}}i:1;a:6:{s:4:\"file\";s:68:\"/home/alltic/public_html/itsm/application/cmdbabstract.class.inc.php\";s:4:\"line\";i:2389;s:8:\"function\";s:25:\"GetPrerequisiteAttributes\";s:5:\"class\";s:9:\"MetaModel\";s:4:\"type\";s:2:\"::\";s:4:\"args\";a:2:{i:0;s:11:\"UserRequest\";i:1;s:11:\"pais_ticket\";}}i:2;a:6:{s:4:\"file\";s:42:\"/home/alltic/public_html/itsm/pages/UI.php\";s:4:\"line\";i:758;s:8:\"function\";s:19:\"DisplayCreationForm\";s:5:\"class\";s:18:\"cmdbAbstractObject\";s:4:\"type\";s:2:\"::\";s:4:\"args\";a:4:{i:0;O:11:\"iTopWebPage\":35:{s:20:\"\0iTopWebPage\0m_sMenu\";s:0:\"\";s:23:\"\0iTopWebPage\0m_sMessage\";s:0:\"\";s:26:\"\0iTopWebPage\0m_sInitScript\";s:3833:\"	try\n	{\n		var myLayout; // a var is required because this page utilizes: myLayout.allowOverflow() method\n	\n		// Layout\n		paneSize = GetUserPreference(\'menu_size\', 300)\n		myLayout = $(\'body\').layout({\n			west :	{\n						 minSize: 200, size: paneSize, spacing_open: 16, spacing_close: 16, slideTrigger_open: \"click\", hideTogglerOnSlide: true, enableCursorHotkey: false,\n						onclose_end: function(name, elt, state, options, layout)\n						{\n								if (state.isSliding == false)\n								{\n									$(\'.menu-pane-exclusive\').show();\n									SetUserPreference(\'menu_pane\', \'closed\', true);\n								}\n						},\n						onresize_end: function(name, elt, state, options, layout)\n						{\n								if (state.isSliding == false)\n								{\n									SetUserPreference(\'menu_size\', state.size, true);\n								}\n						},\n									\n						onopen_end: function(name, elt, state, options, layout)\n						{\n							if (state.isSliding == false)\n							{\n								$(\'.menu-pane-exclusive\').hide();\n								SetUserPreference(\'menu_pane\', \'open\', true);\n							}\n						}\n					},\n			center: {\n						onresize_end: function(name, elt, state, options, layout)\n						{\n								$(\'.v-resizable\').each( function() {\n									var fixedWidth = $(this).parent().innerWidth() - 6;\n									$(this).width(fixedWidth);\n									// Make sure it cannot be resized horizontally\n									$(this).resizable(\'options\', { minWidth: fixedWidth, maxWidth:	fixedWidth });\n									// Now adjust all the child \'items\'\n									var innerWidth = $(this).innerWidth() - 10;\n									$(this).find(\'.item\').width(innerWidth);\n								});\n								$(\'.panel-resized\').trigger(\'resized\');\n						}\n				\n					}\n		});\n		window.clearTimeout(iPaneVisWatchDog);\n		//myLayout.open( \"west\" );\n		$(\'.ui-layout-resizer-west .ui-layout-toggler\').css({background: \'transparent\'});\n						myLayout.addPinBtn( \"#tPinMenu\", \"west\" );\n		\n		$(\'#left-pane\').layout({ resizable: false, spacing_open: 0, south: { size: 94 }, enableCursorHotkey: false });\n		\n		// Tabs, using JQuery BBQ to store the history\n		// The \"tab widgets\" to handle.\n		var tabs = $(\'div[id^=tabbedContent]\');\n			\n		// This selector will be reused when selecting actual tab widget A elements.\n		var tab_a_selector = \'ul.ui-tabs-nav a\';\n		  \n		// Ugly patch for a change in the behavior of jQuery UI:\n		// Before jQuery UI 1.9, tabs were always considered as \"local\" (opposed to Ajax)\n		// when their href was beginning by #. Starting with 1.9, a <base> tag in the page\n		// is taken into account and causes \"local\" tabs to be considered as Ajax\n		// unless their URL is equal to the URL of the page...\n		$(\'div[id^=tabbedContent] > ul > li > a\').each(function() {\n			var sHash = location.hash;\n			var sHref = $(this).attr(\"href\");\n			if (sHref.match(/^#/))\n			{\n				var sCleanLocation = location.href.toString().replace(sHash, \'\').replace(/#$/, \'\');\n				$(this).attr(\"href\", sCleanLocation+$(this).attr(\"href\"));\n			}\n		});\n\n		// Enable tabs on all tab widgets. The `event` property must be overridden so\n		// that the tabs aren\'t changed on click, and any custom event name can be\n		// specified. Note that if you define a callback for the \'select\' event, it\n		// will be executed for the selected tab whenever the hash changes.\n		tabs.tabs({\n			event: \'change\', \'show\': function(event, ui) {\n				$(\'.resizable\', ui.panel).resizable(); // Make resizable everything that claims to be resizable !\n			},\n			beforeLoad: function( event, ui ) {\n				if ( ui.tab.data(\'loaded\') && (ui.tab.attr(\'data-cache\') == \'true\')) {\n					event.preventDefault();\n					return;\n				}\n				ui.panel.html(\'<div><img src=\"../images/indicator.gif\"></div>\');\n				ui.jqXHR.success(function() {\n					ui.tab.data( \"loaded\", true );\n				});\n			}\n		});\n\n		$(\'.resizable\').filter(\':visible\').resizable();\n	}\n	catch(err)\n	{\n		// Do something with the error !\n		alert(err);\n	}\";s:10:\"\0*\0m_oTabs\";O:10:\"TabManager\":3:{s:10:\"\0*\0m_aTabs\";a:0:{}s:25:\"\0*\0m_sCurrentTabContainer\";s:0:\"\";s:16:\"\0*\0m_sCurrentTab\";s:0:\"\";}s:21:\"\0*\0bBreadCrumbEnabled\";b:0;s:21:\"\0*\0sBreadCrumbEntryId\";N;s:24:\"\0*\0sBreadCrumbEntryLabel\";N;s:30:\"\0*\0sBreadCrumbEntryDescription\";N;s:22:\"\0*\0sBreadCrumbEntryUrl\";N;s:23:\"\0*\0sBreadCrumbEntryIcon\";N;s:7:\"\0*\0oCtx\";O:10:\"ContextTag\":0:{}s:15:\"m_aReadyScripts\";a:3:{i:0;s:1728:\"	//add new widget called TruncatedList to properly display truncated lists when they are sorted\n	$.tablesorter.addWidget({ \n		// give the widget a id \n		id: \"truncatedList\", \n		// format is called when the on init and when a sorting has finished \n		format: function(table)\n		{ \n			// Check if there is a \"truncated\" line\n			this.truncatedList = false;  \n			if ($(\"tr td.truncated\",table).length > 0)\n			{\n				this.truncatedList = true;\n			}\n			if (this.truncatedList)\n			{\n				$(\"tr td\",table).removeClass(\'truncated\');\n				$(\"tr:last td\",table).addClass(\'truncated\');\n			}\n		} \n	});\n	\n	$.tablesorter.addWidget({ \n		// give the widget a id \n		id: \"myZebra\", \n		// format is called when the on init and when a sorting has finished \n		format: function(table)\n		{\n			// Replace the \'red even\' lines by \'red_even\' since most browser do not support 2 classes selector in CSS, etc..\n			$(\"tbody tr:even\",table).addClass(\'even\');\n			$(\"tbody tr.red:even\",table).removeClass(\'red\').removeClass(\'even\').addClass(\'red_even\');\n			$(\"tbody tr.orange:even\",table).removeClass(\'orange\').removeClass(\'even\').addClass(\'orange_even\');\n			$(\"tbody tr.green:even\",table).removeClass(\'green\').removeClass(\'even\').addClass(\'green_even\');\n			// In case we sort again the table, we need to remove the added \'even\' classes on odd rows\n			$(\"tbody tr:odd\",table).removeClass(\'even\');\n			$(\"tbody tr.red_even:odd\",table).removeClass(\'even\').removeClass(\'red_even\').addClass(\'red\');\n			$(\"tbody tr.orange_even:odd\",table).removeClass(\'even\').removeClass(\'orange_even\').addClass(\'orange\');\n			$(\"tbody tr.green_even:odd\",table).removeClass(\'even\').removeClass(\'green_even\').addClass(\'green\');\n		} \n	});\n	$(\"table.listResults\").tableHover(); // hover tables\";i:1;s:5505:\"	\n	// Adjust initial size\n	$(\'.v-resizable\').each( function()\n		{\n			var parent_id = $(this).parent().id;\n			// Restore the saved height\n			var iHeight = GetUserPreference(parent_id+\'_\'+this.id+\'_height\', undefined);\n			if (iHeight != undefined)\n			{\n				$(this).height(parseInt(iHeight, 10)); // Parse in base 10 !);\n			}\n			// Adjust the child \'item\'\'s height and width to fit\n			var container = $(this);\n			var fixedWidth = container.parent().innerWidth() - 6;\n			// Set the width to fit the parent\n			$(this).width(fixedWidth);\n			var headerHeight = $(this).find(\'.drag_handle\').height();\n			// Now adjust the width and height of the child \'item\'\n			container.find(\'.item\').height(container.innerHeight() - headerHeight - 12).width(fixedWidth - 10);\n		}\n	);\n	// Make resizable, vertically only everything that claims to be v-resizable !\n	$(\'.v-resizable\').resizable( { handles: \'s\', minHeight: $(this).find(\'.drag_handle\').height(), minWidth: $(this).parent().innerWidth() - 6, maxWidth: $(this).parent().innerWidth() - 6, stop: function()\n		{\n			// Adjust the content\n			var container = $(this);\n			var headerHeight = $(this).find(\'.drag_handle\').height();\n			container.find(\'.item\').height(container.innerHeight() - headerHeight - 12);//.width(container.innerWidth());\n			var parent_id = $(this).parent().id;\n			SetUserPreference(parent_id+\'_\'+this.id+\'_height\', $(this).height(), true); // true => persistent\n		}\n	} );\n		\n	// Tabs, using JQuery BBQ to store the history\n	// The \"tab widgets\" to handle.\n	var tabs = $(\'div[id^=tabbedContent]\');\n		\n	// This selector will be reused when selecting actual tab widget A elements.\n	var tab_a_selector = \'ul.ui-tabs-nav a\';\n	  \n	// Define our own click handler for the tabs, overriding the default.\n	tabs.find( tab_a_selector ).click(function()\n	{\n		var state = {};\n				  \n		// Get the id of this tab widget.\n		var id = $(this).closest( \'div[id^=tabbedContent]\' ).attr( \'id\' );\n		  \n		// Get the index of this tab.\n		var idx = $(this).parent().prevAll().length;\n		\n		// Set the state!\n		state[ id ] = idx;\n		$.bbq.pushState( state );\n	});\n	\n	// refresh the hash when the tab is changed (from a JS script)\n	$(\'body\').on( \'tabsactivate\', \'.ui-tabs\', function(event, ui) {\n		var state = {};\n			\n		// Get the id of this tab widget.\n		var id = $(ui.newTab).closest( \'div[id^=tabbedContent]\' ).attr( \'id\' );\n		\n		// Get the index of this tab.\n		var idx = $(ui.newTab).prevAll().length;\n			\n		// Set the state!\n		state[ id ] = idx;\n		$.bbq.pushState( state );\n	});\n	\n	// Bind an event to window.onhashchange that, when the history state changes,\n	// iterates over all tab widgets, changing the current tab as necessary.\n	$(window).bind( \'hashchange\', function(e)\n	{\n		// Iterate over all tab widgets.\n		tabs.each(function()\n		{  \n			// Get the index for this tab widget from the hash, based on the\n			// appropriate id property. In jQuery 1.4, you should use e.getState()\n			// instead of $.bbq.getState(). The second, \'true\' argument coerces the\n			// string value to a number.\n			var idx = $.bbq.getState( this.id, true ) || 0;\n			  \n			// Select the appropriate tab for this tab widget by triggering the custom\n			// event specified in the .tabs() init above (you could keep track of what\n			// tab each widget is on using .data, and only select a tab if it has\n			// changed).\n			$(this).find( tab_a_selector ).eq( idx ).triggerHandler( \'change\' );\n		});\n\n		// Iterate over all truncated lists to find whether they are expanded or not\n		$(\'a.truncated\').each(function()\n		{\n			var state = $.bbq.getState( this.id, true ) || \'close\';\n			if (state == \'open\')\n			{\n				$(this).trigger(\'open\');\n			}\n			else\n			{\n				$(this).trigger(\'close\');	\n			}\n		});\n	});\n	\n	// Shortcut menu actions\n	$(\'.actions_button a\').click( function() {\n		aMatches = /#(.*)$/.exec(window.location.href);\n		if (aMatches != null)\n		{\n			currentHash = aMatches[1];\n			if ( /#(.*)$/.test(this.href))\n			{\n				this.href = this.href.replace(/#(.*)$/, \'#\'+currentHash);\n			}\n		}\n	});\n\n	// End of Tabs handling\n\n	PrepareWidgets();\n\n	// Make sortable, everything that claims to be sortable\n	$(\'.sortable\').sortable( {axis: \'y\', cursor: \'move\', handle: \'.drag_handle\', stop: function()\n		{\n			if ($(this).hasClass(\'persistent\'))\n			{\n				// remember the sort order for next time the page is loaded...\n				sSerialized = $(this).sortable(\'serialize\', {key: \'menu\'});\n				var sTemp = sSerialized.replace(/menu=/g, \'\');\n				SetUserPreference(this.id+\'_order\', sTemp.replace(/&/g, \',\'), true); // true => persistent !\n			}\n		}\n	});\n	docWidth = $(document).width();\n	$(\'#ModalDlg\').dialog({ autoOpen: false, modal: true, width: 0.8*docWidth }); // JQuery UI dialogs\n	ShowDebug();\n	$(\'#logOffBtn>ul\').popupmenu();\n	\n	$(\'.caselog_header\').click( function () { $(this).toggleClass(\'open\').next(\'.caselog_entry,.caselog_entry_html\').toggle(); });\n	\n	$(document).ajaxSend(function(event, jqxhr, options) {\n		jqxhr.setRequestHeader(\'X-Combodo-Ajax\', \'true\');\n	});\n	$(document).ajaxError(function(event, jqxhr, options) {\n		if (jqxhr.status == 401)\n		{\n			$(\'<div>\'+\"You are disconnected. You must identify yourself to continue using the application.\"+\'</div>\').dialog({\n				modal:true,\n				title: \"Warning!\",\n				close: function() { $(this).remove(); },\n				minWidth: 400,\n				buttons: [\n					{ text: \"Login again\", click: function() { window.location.href= GetAbsoluteUrlAppRoot()+\'pages/UI.php\' } },\n					{ text: \"Stay on this page\", click: function() { $(this).dialog(\'close\'); } }\n				]\n			});\n		}\n	});\";i:2;s:285:\"$(\'img[data-img-id]\').each(function() {\n	if ($(this).width() > 250)\n	{\n		$(this).css({\'max-width\': \'250px\', width: \'\', height: \'\', \'max-height\': \'\'});\n	}\n	$(this).addClass(\'inline-image\').attr(\'href\', $(this).attr(\'src\'));\n}).magnificPopup({type: \'image\', closeOnContentClick: true });\";}s:10:\"m_sRootUrl\";s:23:\"https://alltic.co/itsm/\";s:10:\"\0*\0s_title\";s:32:\"iTop - Creación de Solicitudes \";s:12:\"\0*\0s_content\";s:195:\"<h1><img src=\"https://alltic.co/itsm/env-production/itop-request-mgmt-itil/images/user-request.png\" style=\"vertical-align:middle;\"/>&nbsp;Creación de Solicitudes</h1>\n<div class=\"wizContainer\">\n\";s:21:\"\0*\0s_deferred_content\";s:0:\"\";s:12:\"\0*\0a_scripts\";a:4:{i:0;s:860:\"function GetAbsoluteUrlAppRoot()\n{\n	return \'https://alltic.co/itsm/\';\n}\n\nfunction GetAbsoluteUrlModulesRoot()\n{\n	return \'https://alltic.co/itsm/env-production/\';\n}\n\nfunction GetAbsoluteUrlModulePage(sModule, sPage, aArguments)\n{\n	// aArguments is optional, it default to an empty hash\n	aArguments = typeof aArguments !== \'undefined\' ? aArguments : {};\n\n	var sUrl = \'https://alltic.co/itsm/\'+\'pages/exec.php?exec_module=\'+sModule+\'&exec_page=\'+sPage+\'&exec_env=\'+\'production\';\n	for (var sArgName in aArguments)\n	{\n		if (aArguments.hasOwnProperty(sArgName))\n		{\n			sUrl = sUrl + \'&\'+sArgName+\'=\'+aArguments[sArgname];\n		}\n	}\n	return sUrl;\n}\n\nfunction AddAppContext(sURL)\n{\n	var sContext = \'c[menu]=NewUserRequest\';\n	if (sContext.length > 0)\n	{\n		if (sURL.indexOf(\'?\') == -1)\n		{\n			return sURL+\'?\'+sContext;\n		}				\n		return sURL+\'&\'+sContext;\n	}\n	return sURL;\n}\";i:1;s:1971:\"	function PrepareWidgets()\n	{\n		// note: each action implemented here must be idempotent,\n		//       because this helper function might be called several times on a given page \n	\n		$(\".date-pick\").datepicker({\"showOn\":\"button\",\"buttonImage\":\"..\\/images\\/calendar.png\",\"buttonImageOnly\":true,\"dateFormat\":\"yy-mm-dd\",\"constrainInput\":false,\"changeMonth\":true,\"changeYear\":true,\"dayNamesMin\":[\"Su\",\"Mo\",\"Tu\",\"We\",\"Th\",\"Fr\",\"Sa\"],\"monthNamesShort\":[\"Jan\",\"Feb\",\"Mar\",\"Apr\",\"May\",\"Jun\",\"Jul\",\"Aug\",\"Sep\",\"Oct\",\"Nov\",\"Dec\"],\"firstDay\":0});\n	\n		// Hack for the date and time picker addon issue on Chrome (see #1305)\n		// The workaround is to instantiate the widget on demand\n		// It relies on the same markup, thus reverting to the original implementation should be straightforward\n		$(\".datetime-pick:not(.is-widget-ready)\").each(function(){\n			var oInput = this;\n			$(oInput).addClass(\'is-widget-ready\');\n			$(\'<img class=\"datetime-pick-button\" src=\"../images/calendar.png\">\')\n				.insertAfter($(this))\n				.on(\'click\', function(){\n					$(oInput)\n						.datetimepicker({\"showOn\":\"\",\"buttonImage\":null,\"buttonImageOnly\":true,\"dateFormat\":\"yy-mm-dd\",\"constrainInput\":false,\"changeMonth\":true,\"changeYear\":true,\"dayNamesMin\":[\"Su\",\"Mo\",\"Tu\",\"We\",\"Th\",\"Fr\",\"Sa\"],\"monthNamesShort\":[\"Jan\",\"Feb\",\"Mar\",\"Apr\",\"May\",\"Jun\",\"Jul\",\"Aug\",\"Sep\",\"Oct\",\"Nov\",\"Dec\"],\"firstDay\":0,\"timeFormat\":\"HH:mm:ss\",\"controlType\":\"select\",\"closeText\":\"Ok\",\n				\'timeText\': $.timepicker.regional[\"es\"].timeText,\n				\'hourText\': $.timepicker.regional[\"es\"].hourText,\n				\'minuteText\': $.timepicker.regional[\"es\"].minuteText,\n				\'secondText\': $.timepicker.regional[\"es\"].secondText,\n				\'currentText\': $.timepicker.regional[\"es\"].currentText\n			})\n						.datetimepicker(\'show\')\n						.datetimepicker(\'option\', \'onClose\', function(dateText,inst){\n							$(oInput).datetimepicker(\'destroy\');\n						})\n						.on(\'click keypress\', function(){\n							$(oInput).datetimepicker(\'hide\');\n						});\n				});\n		});\n	}\";i:2;s:1734:\"//		// for JQuery history\n//		function history_callback(hash)\n//		{\n//			// do stuff that loads page content based on hash variable\n//			var aMatches = /^tab_(.*)$/.exec(hash);\n//			if (aMatches != null)\n//			{\n//				var tab = $(\'#\'+hash);\n//				tab.parents(\'div[id^=tabbedContent]:first\').tabs(\'select\', aMatches[1]);\n//			}\n//		}\n\n		function goBack()\n		{\n			window.history.back();\n		}\n		\n		function BackToDetails(sClass, id, sDefaultUrl, sOwnershipToken)\n		{\n			window.bInCancel = true;\n			if (id > 0)\n			{\n				sToken = \'\';\n				if (sOwnershipToken != undefined)\n				{\n					sToken = \'&token=\'+sOwnershipToken;\n				}\n				window.location.href = AddAppContext(GetAbsoluteUrlAppRoot()+\'pages/UI.php?operation=release_lock_and_details&class=\'+sClass+\'&id=\'+id+sToken);\n			}\n			else\n			{\n				window.location.href = sDefaultUrl; // Already contains the context...				\n			}\n		}\n\n		function BackToList(sClass)\n		{\n			window.location.href = AddAppContext(GetAbsoluteUrlAppRoot()+\'pages/UI.php?operation=search_oql&oql_class=\'+sClass+\'&oql_clause=WHERE id=0\');\n		}\n		\n		function ShowDebug()\n		{\n			if ($(\'#rawOutput > div\').html() != \'\')\n			{\n				$(\'#rawOutput\').dialog( {autoOpen: true, modal:false, width: \'80%\'});\n			}\n		}\n		\n		var oUserPreferences = {\"welcome_popup\":\"1\",\"menu_pane\":\"open\",\"menu_size\":\"421\"};\n\n		// For disabling the CKEditor at init time when the corresponding textarea is disabled !\n		CKEDITOR.plugins.add( \'disabler\',\n		{\n			init : function( editor )\n			{\n				editor.on( \'instanceReady\', function(e)\n				{\n					e.removeListener();\n					$(\'#\'+ editor.name).trigger(\'update\');\n				});\n			}\n			\n		});\n\n		\n		function FixPaneVis()\n		{\n			$(\'.ui-layout-center, .ui-layout-north, .ui-layout-south\').css({display: \'block\'});\n		}\";i:3;s:172:\"function ShowAboutBox()\n{\n	$.post(GetAbsoluteUrlAppRoot()+\'pages/ajax.render.php\', {operation: \'about_box\'}, function(data){\n		$(\'body\').append(data);\n	});\n	return false;\n}\";}s:17:\"\0*\0a_dict_entries\";a:3:{s:25:\"UI:FillAllMandatoryFields\";s:41:\"Por favor llenar los campos obligatorios.\";s:16:\"UI:Button:Cancel\";s:8:\"Cancelar\";s:14:\"UI:Button:Done\";s:5:\"Listo\";}s:11:\"\0*\0a_styles\";a:0:{}s:20:\"\0*\0a_include_scripts\";N;s:24:\"\0*\0a_include_stylesheets\";N;s:12:\"\0*\0a_headers\";a:2:{i:0;s:38:\"Content-type: text/html; charset=utf-8\";i:1;s:23:\"Cache-control: no-cache\";}s:9:\"\0*\0a_base\";a:2:{s:4:\"href\";s:0:\"\";s:6:\"target\";s:0:\"\";}s:10:\"\0*\0iNextId\";i:0;s:17:\"\0*\0iTransactionId\";i:0;s:15:\"\0*\0sContentType\";s:0:\"\";s:22:\"\0*\0sContentDisposition\";s:0:\"\";s:19:\"\0*\0sContentFileName\";s:0:\"\";s:25:\"\0*\0bTrashUnexpectedOutput\";b:0;s:18:\"\0*\0s_sOutputFormat\";N;s:18:\"\0*\0a_OutputOptions\";a:0:{}s:13:\"\0*\0bPrintable\";b:0;s:16:\"a_linked_scripts\";a:43:{s:46:\"https://alltic.co/itsm/js/jquery-1.10.0.min.js\";s:46:\"https://alltic.co/itsm/js/jquery-1.10.0.min.js\";s:53:\"https://alltic.co/itsm/js/jquery-migrate-1.2.1.min.js\";s:53:\"https://alltic.co/itsm/js/jquery-migrate-1.2.1.min.js\";s:56:\"https://alltic.co/itsm/js/jquery-ui-1.10.3.custom.min.js\";s:56:\"https://alltic.co/itsm/js/jquery-ui-1.10.3.custom.min.js\";s:37:\"https://alltic.co/itsm/js/hovertip.js\";s:37:\"https://alltic.co/itsm/js/hovertip.js\";s:47:\"https://alltic.co/itsm/js/jquery.tablesorter.js\";s:47:\"https://alltic.co/itsm/js/jquery.tablesorter.js\";s:53:\"https://alltic.co/itsm/js/jquery.tablesorter.pager.js\";s:53:\"https://alltic.co/itsm/js/jquery.tablesorter.pager.js\";s:46:\"https://alltic.co/itsm/js/jquery.tablehover.js\";s:46:\"https://alltic.co/itsm/js/jquery.tablehover.js\";s:41:\"https://alltic.co/itsm/js/field_sorter.js\";s:41:\"https://alltic.co/itsm/js/field_sorter.js\";s:38:\"https://alltic.co/itsm/js/datatable.js\";s:38:\"https://alltic.co/itsm/js/datatable.js\";s:46:\"https://alltic.co/itsm/js/jquery.positionBy.js\";s:46:\"https://alltic.co/itsm/js/jquery.positionBy.js\";s:45:\"https://alltic.co/itsm/js/jquery.popupmenu.js\";s:45:\"https://alltic.co/itsm/js/jquery.popupmenu.js\";s:26:\"../js/jquery.layout.min.js\";s:26:\"../js/jquery.layout.min.js\";s:26:\"../js/jquery.ba-bbq.min.js\";s:26:\"../js/jquery.ba-bbq.min.js\";s:24:\"../js/jquery.treeview.js\";s:24:\"../js/jquery.treeview.js\";s:28:\"../js/jquery.autocomplete.js\";s:28:\"../js/jquery.autocomplete.js\";s:13:\"../js/date.js\";s:13:\"../js/date.js\";s:35:\"../js/jquery-ui-timepicker-addon.js\";s:35:\"../js/jquery-ui-timepicker-addon.js\";s:44:\"../js/jquery-ui-timepicker-addon-i18n.min.js\";s:44:\"../js/jquery-ui-timepicker-addon-i18n.min.js\";s:23:\"../js/jquery.blockUI.js\";s:23:\"../js/jquery.blockUI.js\";s:14:\"../js/utils.js\";s:14:\"../js/utils.js\";s:18:\"../js/swfobject.js\";s:18:\"../js/swfobject.js\";s:26:\"../js/ckeditor/ckeditor.js\";s:26:\"../js/ckeditor/ckeditor.js\";s:33:\"../js/ckeditor/adapters/jquery.js\";s:33:\"../js/ckeditor/adapters/jquery.js\";s:28:\"../js/jquery.qtip-1.0.min.js\";s:28:\"../js/jquery.qtip-1.0.min.js\";s:23:\"../js/property_field.js\";s:23:\"../js/property_field.js\";s:16:\"../js/fg.menu.js\";s:16:\"../js/fg.menu.js\";s:20:\"../js/icon_select.js\";s:20:\"../js/icon_select.js\";s:20:\"../js/raphael-min.js\";s:20:\"../js/raphael-min.js\";s:11:\"../js/d3.js\";s:11:\"../js/d3.js\";s:11:\"../js/c3.js\";s:11:\"../js/c3.js\";s:27:\"../js/jquery.multiselect.js\";s:27:\"../js/jquery.multiselect.js\";s:23:\"../js/ajaxfileupload.js\";s:23:\"../js/ajaxfileupload.js\";s:26:\"../js/jquery.mousewheel.js\";s:26:\"../js/jquery.mousewheel.js\";s:34:\"../js/jquery.magnific-popup.min.js\";s:34:\"../js/jquery.magnific-popup.min.js\";s:19:\"../js/breadcrumb.js\";s:19:\"../js/breadcrumb.js\";s:19:\"../js/moment.min.js\";s:19:\"../js/moment.min.js\";s:13:\"../js/json.js\";s:13:\"../js/json.js\";s:25:\"../js/forms-json-utils.js\";s:25:\"../js/forms-json-utils.js\";s:21:\"../js/wizardhelper.js\";s:21:\"../js/wizardhelper.js\";s:21:\"../js/wizard.utils.js\";s:21:\"../js/wizard.utils.js\";s:20:\"../js/linkswidget.js\";s:20:\"../js/linkswidget.js\";s:26:\"../js/linksdirectwidget.js\";s:26:\"../js/linksdirectwidget.js\";s:21:\"../js/extkeywidget.js\";s:21:\"../js/extkeywidget.js\";}s:20:\"a_linked_stylesheets\";a:9:{i:0;a:2:{s:4:\"link\";s:71:\"https://alltic.co/itsm/css/ui-lightness/jquery-ui-1.10.3.custom.min.css\";s:9:\"condition\";s:0:\"\";}i:1;a:2:{s:4:\"link\";s:41:\"https://alltic.co/itsm/css/light-grey.css\";s:9:\"condition\";s:0:\"\";}i:2;a:2:{s:4:\"link\";s:26:\"../css/jquery.treeview.css\";s:9:\"condition\";s:0:\"\";}i:3;a:2:{s:4:\"link\";s:30:\"../css/jquery.autocomplete.css\";s:9:\"condition\";s:0:\"\";}i:4;a:2:{s:4:\"link\";s:37:\"../css/jquery-ui-timepicker-addon.css\";s:9:\"condition\";s:0:\"\";}i:5;a:2:{s:4:\"link\";s:18:\"../css/fg.menu.css\";s:9:\"condition\";s:0:\"\";}i:6;a:2:{s:4:\"link\";s:29:\"../css/jquery.multiselect.css\";s:9:\"condition\";s:0:\"\";}i:7;a:2:{s:4:\"link\";s:25:\"../css/magnific-popup.css\";s:9:\"condition\";s:0:\"\";}i:8;a:2:{s:4:\"link\";s:17:\"../css/c3.min.css\";s:9:\"condition\";s:0:\"\";}}s:14:\"s_OutputFormat\";s:4:\"html\";}i:1;s:11:\"UserRequest\";i:2;O:11:\"UserRequest\":22:{s:12:\"\0*\0m_iFormId\";N;s:13:\"\0*\0aFieldsMap\";N;s:14:\"\0*\0bAllowWrite\";b:0;s:15:\"\0*\0m_datCreated\";N;s:15:\"\0*\0m_datUpdated\";N;s:19:\"\0DBObject\0m_bIsInDB\";b:0;s:16:\"\0DBObject\0m_iKey\";i:-1;s:23:\"\0DBObject\0m_aCurrValues\";a:79:{s:18:\"operational_status\";s:7:\"ongoing\";s:3:\"ref\";s:0:\"\";s:6:\"org_id\";i:0;s:8:\"org_name\";s:0:\"\";s:9:\"caller_id\";i:0;s:11:\"caller_name\";s:0:\"\";s:7:\"team_id\";i:0;s:9:\"team_name\";s:0:\"\";s:8:\"agent_id\";i:0;s:10:\"agent_name\";s:0:\"\";s:5:\"title\";s:0:\"\";s:11:\"description\";s:0:\"\";s:10:\"start_date\";N;s:8:\"end_date\";N;s:11:\"last_update\";N;s:10:\"close_date\";N;s:11:\"private_log\";O:10:\"ormCaseLog\":3:{s:9:\"\0*\0m_sLog\";s:0:\"\";s:11:\"\0*\0m_aIndex\";a:0:{}s:14:\"\0*\0m_bModified\";b:0;}s:13:\"contacts_list\";O:11:\"DBObjectSet\":14:{s:14:\"\0*\0m_aAddedIds\";a:0:{}s:18:\"\0*\0m_aAddedObjects\";a:0:{}s:10:\"\0*\0m_aArgs\";a:0:{}s:15:\"\0*\0m_aAttToLoad\";N;s:13:\"\0*\0m_aOrderBy\";a:0:{}s:9:\"m_bLoaded\";b:1;s:20:\"\0*\0m_iNumTotalDBRows\";i:0;s:21:\"\0*\0m_iNumLoadedDBRows\";i:0;s:13:\"\0*\0m_iCurrRow\";i:0;s:12:\"\0*\0m_oFilter\";O:14:\"DBObjectSearch\":11:{s:26:\"\0DBObjectSearch\0m_aClasses\";a:1:{s:18:\"lnkContactToTicket\";s:18:\"lnkContactToTicket\";}s:34:\"\0DBObjectSearch\0m_aSelectedClasses\";a:1:{s:18:\"lnkContactToTicket\";s:18:\"lnkContactToTicket\";}s:34:\"\0DBObjectSearch\0m_oSearchCondition\";O:15:\"FalseExpression\":1:{s:10:\"\0*\0m_value\";i:0;}s:25:\"\0DBObjectSearch\0m_aParams\";a:0:{}s:27:\"\0DBObjectSearch\0m_aFullText\";a:0:{}s:29:\"\0DBObjectSearch\0m_aPointingTo\";a:0:{}s:31:\"\0DBObjectSearch\0m_aReferencedBy\";a:0:{}s:18:\"\0*\0m_bAllowAllData\";b:0;s:18:\"\0*\0m_bDataFiltered\";b:0;s:25:\"\0*\0m_bNoContextParameters\";b:0;s:24:\"\0*\0m_aModifierProperties\";a:0:{}}s:15:\"\0*\0m_oSQLResult\";N;s:19:\"m_aExtendedDataSpec\";N;s:13:\"m_iLimitCount\";i:0;s:13:\"m_iLimitStart\";i:0;}s:18:\"functionalcis_list\";O:11:\"DBObjectSet\":14:{s:14:\"\0*\0m_aAddedIds\";a:0:{}s:18:\"\0*\0m_aAddedObjects\";a:0:{}s:10:\"\0*\0m_aArgs\";a:0:{}s:15:\"\0*\0m_aAttToLoad\";N;s:13:\"\0*\0m_aOrderBy\";a:0:{}s:9:\"m_bLoaded\";b:1;s:20:\"\0*\0m_iNumTotalDBRows\";i:0;s:21:\"\0*\0m_iNumLoadedDBRows\";i:0;s:13:\"\0*\0m_iCurrRow\";i:0;s:12:\"\0*\0m_oFilter\";O:14:\"DBObjectSearch\":11:{s:26:\"\0DBObjectSearch\0m_aClasses\";a:1:{s:23:\"lnkFunctionalCIToTicket\";s:23:\"lnkFunctionalCIToTicket\";}s:34:\"\0DBObjectSearch\0m_aSelectedClasses\";a:1:{s:23:\"lnkFunctionalCIToTicket\";s:23:\"lnkFunctionalCIToTicket\";}s:34:\"\0DBObjectSearch\0m_oSearchCondition\";O:15:\"FalseExpression\":1:{s:10:\"\0*\0m_value\";i:0;}s:25:\"\0DBObjectSearch\0m_aParams\";a:0:{}s:27:\"\0DBObjectSearch\0m_aFullText\";a:0:{}s:29:\"\0DBObjectSearch\0m_aPointingTo\";a:0:{}s:31:\"\0DBObjectSearch\0m_aReferencedBy\";a:0:{}s:18:\"\0*\0m_bAllowAllData\";b:0;s:18:\"\0*\0m_bDataFiltered\";b:0;s:25:\"\0*\0m_bNoContextParameters\";b:0;s:24:\"\0*\0m_aModifierProperties\";a:0:{}}s:15:\"\0*\0m_oSQLResult\";N;s:19:\"m_aExtendedDataSpec\";N;s:13:\"m_iLimitCount\";i:0;s:13:\"m_iLimitStart\";i:0;}s:15:\"workorders_list\";O:11:\"DBObjectSet\":14:{s:14:\"\0*\0m_aAddedIds\";a:0:{}s:18:\"\0*\0m_aAddedObjects\";a:0:{}s:10:\"\0*\0m_aArgs\";a:0:{}s:15:\"\0*\0m_aAttToLoad\";N;s:13:\"\0*\0m_aOrderBy\";a:0:{}s:9:\"m_bLoaded\";b:1;s:20:\"\0*\0m_iNumTotalDBRows\";i:0;s:21:\"\0*\0m_iNumLoadedDBRows\";i:0;s:13:\"\0*\0m_iCurrRow\";i:0;s:12:\"\0*\0m_oFilter\";O:14:\"DBObjectSearch\":11:{s:26:\"\0DBObjectSearch\0m_aClasses\";a:1:{s:9:\"WorkOrder\";s:9:\"WorkOrder\";}s:34:\"\0DBObjectSearch\0m_aSelectedClasses\";a:1:{s:9:\"WorkOrder\";s:9:\"WorkOrder\";}s:34:\"\0DBObjectSearch\0m_oSearchCondition\";O:15:\"FalseExpression\":1:{s:10:\"\0*\0m_value\";i:0;}s:25:\"\0DBObjectSearch\0m_aParams\";a:0:{}s:27:\"\0DBObjectSearch\0m_aFullText\";a:0:{}s:29:\"\0DBObjectSearch\0m_aPointingTo\";a:0:{}s:31:\"\0DBObjectSearch\0m_aReferencedBy\";a:0:{}s:18:\"\0*\0m_bAllowAllData\";b:0;s:18:\"\0*\0m_bDataFiltered\";b:0;s:25:\"\0*\0m_bNoContextParameters\";b:0;s:24:\"\0*\0m_aModifierProperties\";a:0:{}}s:15:\"\0*\0m_oSQLResult\";N;s:19:\"m_aExtendedDataSpec\";N;s:13:\"m_iLimitCount\";i:0;s:13:\"m_iLimitStart\";i:0;}s:6:\"status\";s:3:\"new\";s:12:\"request_type\";s:15:\"service_request\";s:6:\"impact\";s:1:\"2\";s:8:\"priority\";s:1:\"4\";s:7:\"urgency\";s:1:\"4\";s:6:\"origin\";s:5:\"phone\";s:11:\"approver_id\";i:0;s:14:\"approver_email\";s:0:\"\";s:16:\"servicefamily_id\";i:0;s:18:\"servicefamily_name\";s:0:\"\";s:10:\"service_id\";i:0;s:12:\"service_name\";s:0:\"\";s:21:\"servicesubcategory_id\";i:0;s:23:\"servicesubcategory_name\";s:0:\"\";s:15:\"escalation_flag\";s:2:\"no\";s:17:\"escalation_reason\";s:0:\"\";s:15:\"assignment_date\";N;s:15:\"resolution_date\";N;s:17:\"last_pending_date\";N;s:16:\"cumulatedpending\";O:12:\"ormStopWatch\":5:{s:13:\"\0*\0iTimeSpent\";i:0;s:11:\"\0*\0iStarted\";N;s:13:\"\0*\0iLastStart\";N;s:11:\"\0*\0iStopped\";N;s:14:\"\0*\0aThresholds\";a:0:{}}s:3:\"tto\";O:12:\"ormStopWatch\":5:{s:13:\"\0*\0iTimeSpent\";i:0;s:11:\"\0*\0iStarted\";N;s:13:\"\0*\0iLastStart\";N;s:11:\"\0*\0iStopped\";N;s:14:\"\0*\0aThresholds\";a:2:{i:75;a:4:{s:8:\"deadline\";N;s:9:\"triggered\";b:0;s:7:\"overrun\";N;s:9:\"highlight\";N;}i:100;a:4:{s:8:\"deadline\";N;s:9:\"triggered\";b:0;s:7:\"overrun\";N;s:9:\"highlight\";N;}}}s:3:\"ttr\";O:12:\"ormStopWatch\":5:{s:13:\"\0*\0iTimeSpent\";i:0;s:11:\"\0*\0iStarted\";N;s:13:\"\0*\0iLastStart\";N;s:11:\"\0*\0iStopped\";N;s:14:\"\0*\0aThresholds\";a:2:{i:75;a:4:{s:8:\"deadline\";N;s:9:\"triggered\";b:0;s:7:\"overrun\";N;s:9:\"highlight\";N;}i:100;a:4:{s:8:\"deadline\";N;s:9:\"triggered\";b:0;s:7:\"overrun\";N;s:9:\"highlight\";N;}}}s:23:\"tto_escalation_deadline\";N;s:14:\"sla_tto_passed\";N;s:12:\"sla_tto_over\";N;s:23:\"ttr_escalation_deadline\";N;s:14:\"sla_ttr_passed\";N;s:12:\"sla_ttr_over\";N;s:10:\"time_spent\";N;s:15:\"resolution_code\";N;s:8:\"solution\";s:0:\"\";s:14:\"pending_reason\";s:0:\"\";s:17:\"parent_request_id\";i:0;s:18:\"parent_request_ref\";s:0:\"\";s:18:\"parent_incident_id\";i:0;s:19:\"parent_incident_ref\";s:0:\"\";s:17:\"parent_problem_id\";i:0;s:18:\"parent_problem_ref\";s:0:\"\";s:16:\"parent_change_id\";i:0;s:17:\"parent_change_ref\";s:0:\"\";s:20:\"related_request_list\";O:11:\"DBObjectSet\":14:{s:14:\"\0*\0m_aAddedIds\";a:0:{}s:18:\"\0*\0m_aAddedObjects\";a:0:{}s:10:\"\0*\0m_aArgs\";a:0:{}s:15:\"\0*\0m_aAttToLoad\";N;s:13:\"\0*\0m_aOrderBy\";a:0:{}s:9:\"m_bLoaded\";b:1;s:20:\"\0*\0m_iNumTotalDBRows\";i:0;s:21:\"\0*\0m_iNumLoadedDBRows\";i:0;s:13:\"\0*\0m_iCurrRow\";i:0;s:12:\"\0*\0m_oFilter\";O:14:\"DBObjectSearch\":11:{s:26:\"\0DBObjectSearch\0m_aClasses\";a:1:{s:11:\"UserRequest\";s:11:\"UserRequest\";}s:34:\"\0DBObjectSearch\0m_aSelectedClasses\";a:1:{s:11:\"UserRequest\";s:11:\"UserRequest\";}s:34:\"\0DBObjectSearch\0m_oSearchCondition\";O:15:\"FalseExpression\":1:{s:10:\"\0*\0m_value\";i:0;}s:25:\"\0DBObjectSearch\0m_aParams\";a:0:{}s:27:\"\0DBObjectSearch\0m_aFullText\";a:0:{}s:29:\"\0DBObjectSearch\0m_aPointingTo\";a:0:{}s:31:\"\0DBObjectSearch\0m_aReferencedBy\";a:0:{}s:18:\"\0*\0m_bAllowAllData\";b:0;s:18:\"\0*\0m_bDataFiltered\";b:0;s:25:\"\0*\0m_bNoContextParameters\";b:0;s:24:\"\0*\0m_aModifierProperties\";a:0:{}}s:15:\"\0*\0m_oSQLResult\";N;s:19:\"m_aExtendedDataSpec\";N;s:13:\"m_iLimitCount\";i:0;s:13:\"m_iLimitStart\";i:0;}s:10:\"public_log\";O:10:\"ormCaseLog\":3:{s:9:\"\0*\0m_sLog\";s:0:\"\";s:11:\"\0*\0m_aIndex\";a:0:{}s:14:\"\0*\0m_bModified\";b:0;}s:17:\"user_satisfaction\";s:1:\"1\";s:12:\"user_comment\";s:0:\"\";s:10:\"finalclass\";s:11:\"UserRequest\";s:12:\"friendlyname\";s:0:\"\";s:19:\"org_id_friendlyname\";s:0:\"\";s:22:\"caller_id_friendlyname\";s:0:\"\";s:20:\"team_id_friendlyname\";s:0:\"\";s:21:\"agent_id_friendlyname\";s:0:\"\";s:24:\"approver_id_friendlyname\";s:0:\"\";s:29:\"servicefamily_id_friendlyname\";s:0:\"\";s:23:\"service_id_friendlyname\";s:0:\"\";s:34:\"servicesubcategory_id_friendlyname\";s:0:\"\";s:30:\"parent_request_id_friendlyname\";s:0:\"\";s:31:\"parent_incident_id_friendlyname\";s:0:\"\";s:30:\"parent_problem_id_friendlyname\";s:0:\"\";s:29:\"parent_change_id_friendlyname\";s:0:\"\";s:34:\"parent_change_id_finalclass_recall\";s:6:\"Change\";}s:16:\"\0*\0m_aOrigValues\";a:79:{s:18:\"operational_status\";N;s:3:\"ref\";N;s:6:\"org_id\";N;s:8:\"org_name\";N;s:9:\"caller_id\";N;s:11:\"caller_name\";N;s:7:\"team_id\";N;s:9:\"team_name\";N;s:8:\"agent_id\";N;s:10:\"agent_name\";N;s:5:\"title\";N;s:11:\"description\";N;s:10:\"start_date\";N;s:8:\"end_date\";N;s:11:\"last_update\";N;s:10:\"close_date\";N;s:11:\"private_log\";N;s:13:\"contacts_list\";N;s:18:\"functionalcis_list\";N;s:15:\"workorders_list\";N;s:6:\"status\";N;s:12:\"request_type\";N;s:6:\"impact\";N;s:8:\"priority\";N;s:7:\"urgency\";N;s:6:\"origin\";N;s:11:\"approver_id\";N;s:14:\"approver_email\";N;s:16:\"servicefamily_id\";N;s:18:\"servicefamily_name\";N;s:10:\"service_id\";N;s:12:\"service_name\";N;s:21:\"servicesubcategory_id\";N;s:23:\"servicesubcategory_name\";N;s:15:\"escalation_flag\";N;s:17:\"escalation_reason\";N;s:15:\"assignment_date\";N;s:15:\"resolution_date\";N;s:17:\"last_pending_date\";N;s:16:\"cumulatedpending\";N;s:3:\"tto\";N;s:3:\"ttr\";N;s:23:\"tto_escalation_deadline\";N;s:14:\"sla_tto_passed\";N;s:12:\"sla_tto_over\";N;s:23:\"ttr_escalation_deadline\";N;s:14:\"sla_ttr_passed\";N;s:12:\"sla_ttr_over\";N;s:10:\"time_spent\";N;s:15:\"resolution_code\";N;s:8:\"solution\";N;s:14:\"pending_reason\";N;s:17:\"parent_request_id\";N;s:18:\"parent_request_ref\";N;s:18:\"parent_incident_id\";N;s:19:\"parent_incident_ref\";N;s:17:\"parent_problem_id\";N;s:18:\"parent_problem_ref\";N;s:16:\"parent_change_id\";N;s:17:\"parent_change_ref\";N;s:20:\"related_request_list\";N;s:10:\"public_log\";N;s:17:\"user_satisfaction\";N;s:12:\"user_comment\";N;s:10:\"finalclass\";N;s:12:\"friendlyname\";N;s:19:\"org_id_friendlyname\";N;s:22:\"caller_id_friendlyname\";N;s:20:\"team_id_friendlyname\";N;s:21:\"agent_id_friendlyname\";N;s:24:\"approver_id_friendlyname\";N;s:29:\"servicefamily_id_friendlyname\";N;s:23:\"service_id_friendlyname\";N;s:34:\"servicesubcategory_id_friendlyname\";N;s:30:\"parent_request_id_friendlyname\";N;s:31:\"parent_incident_id_friendlyname\";N;s:30:\"parent_problem_id_friendlyname\";N;s:29:\"parent_change_id_friendlyname\";N;s:34:\"parent_change_id_finalclass_recall\";N;}s:18:\"\0*\0m_aExtendedData\";N;s:18:\"\0DBObject\0m_bDirty\";b:0;s:24:\"\0DBObject\0m_bCheckStatus\";N;s:19:\"\0*\0m_bSecurityIssue\";N;s:17:\"\0*\0m_aCheckIssues\";N;s:18:\"\0*\0m_aDeleteIssues\";N;s:24:\"\0DBObject\0m_bFullyLoaded\";b:0;s:22:\"\0DBObject\0m_aLoadedAtt\";a:53:{s:18:\"operational_status\";b:1;s:3:\"ref\";b:1;s:6:\"org_id\";b:1;s:9:\"caller_id\";b:1;s:7:\"team_id\";b:1;s:8:\"agent_id\";b:1;s:5:\"title\";b:1;s:11:\"description\";b:1;s:10:\"start_date\";b:1;s:8:\"end_date\";b:1;s:11:\"last_update\";b:1;s:10:\"close_date\";b:1;s:11:\"private_log\";b:1;s:13:\"contacts_list\";b:1;s:18:\"functionalcis_list\";b:1;s:15:\"workorders_list\";b:1;s:6:\"status\";b:1;s:12:\"request_type\";b:1;s:6:\"impact\";b:1;s:8:\"priority\";b:1;s:7:\"urgency\";b:1;s:6:\"origin\";b:1;s:11:\"approver_id\";b:1;s:16:\"servicefamily_id\";b:1;s:10:\"service_id\";b:1;s:21:\"servicesubcategory_id\";b:1;s:15:\"escalation_flag\";b:1;s:17:\"escalation_reason\";b:1;s:15:\"assignment_date\";b:1;s:15:\"resolution_date\";b:1;s:17:\"last_pending_date\";b:1;s:16:\"cumulatedpending\";b:1;s:3:\"tto\";b:1;s:3:\"ttr\";b:1;s:23:\"tto_escalation_deadline\";b:1;s:14:\"sla_tto_passed\";b:1;s:12:\"sla_tto_over\";b:1;s:23:\"ttr_escalation_deadline\";b:1;s:14:\"sla_ttr_passed\";b:1;s:12:\"sla_ttr_over\";b:1;s:10:\"time_spent\";b:1;s:15:\"resolution_code\";b:1;s:8:\"solution\";b:1;s:14:\"pending_reason\";b:1;s:17:\"parent_request_id\";b:1;s:18:\"parent_incident_id\";b:1;s:17:\"parent_problem_id\";b:1;s:16:\"parent_change_id\";b:1;s:20:\"related_request_list\";b:1;s:10:\"public_log\";b:1;s:17:\"user_satisfaction\";b:1;s:12:\"user_comment\";b:1;s:10:\"finalclass\";b:1;}s:16:\"\0*\0m_aTouchedAtt\";a:0:{}s:17:\"\0*\0m_aModifiedAtt\";a:0:{}s:17:\"\0*\0m_aSynchroData\";N;s:19:\"\0*\0m_sHighlightCode\";N;s:15:\"\0*\0m_aCallbacks\";a:0:{}}i:3;a:0:{}}}}','a:0:{}'),(2,'PHP Exception','Page could not be displayed','/itsm/pages/UI.php','a:0:{}','a:3:{s:9:\"operation\";s:3:\"new\";s:5:\"class\";s:11:\"UserRequest\";s:1:\"c\";a:1:{s:4:\"menu\";s:14:\"NewUserRequest\";}}','a:3:{i:0;a:6:{s:4:\"file\";s:54:\"/home/alltic/public_html/itsm/core/metamodel.class.php\";s:4:\"line\";i:481;s:8:\"function\";s:15:\"GetAttributeDef\";s:5:\"class\";s:9:\"MetaModel\";s:4:\"type\";s:2:\"::\";s:4:\"args\";a:2:{i:0;s:11:\"UserRequest\";i:1;s:11:\"pais_ticket\";}}i:1;a:6:{s:4:\"file\";s:68:\"/home/alltic/public_html/itsm/application/cmdbabstract.class.inc.php\";s:4:\"line\";i:2389;s:8:\"function\";s:25:\"GetPrerequisiteAttributes\";s:5:\"class\";s:9:\"MetaModel\";s:4:\"type\";s:2:\"::\";s:4:\"args\";a:2:{i:0;s:11:\"UserRequest\";i:1;s:11:\"pais_ticket\";}}i:2;a:6:{s:4:\"file\";s:42:\"/home/alltic/public_html/itsm/pages/UI.php\";s:4:\"line\";i:758;s:8:\"function\";s:19:\"DisplayCreationForm\";s:5:\"class\";s:18:\"cmdbAbstractObject\";s:4:\"type\";s:2:\"::\";s:4:\"args\";a:4:{i:0;O:11:\"iTopWebPage\":35:{s:20:\"\0iTopWebPage\0m_sMenu\";s:0:\"\";s:23:\"\0iTopWebPage\0m_sMessage\";s:0:\"\";s:26:\"\0iTopWebPage\0m_sInitScript\";s:3833:\"	try\n	{\n		var myLayout; // a var is required because this page utilizes: myLayout.allowOverflow() method\n	\n		// Layout\n		paneSize = GetUserPreference(\'menu_size\', 300)\n		myLayout = $(\'body\').layout({\n			west :	{\n						 minSize: 200, size: paneSize, spacing_open: 16, spacing_close: 16, slideTrigger_open: \"click\", hideTogglerOnSlide: true, enableCursorHotkey: false,\n						onclose_end: function(name, elt, state, options, layout)\n						{\n								if (state.isSliding == false)\n								{\n									$(\'.menu-pane-exclusive\').show();\n									SetUserPreference(\'menu_pane\', \'closed\', true);\n								}\n						},\n						onresize_end: function(name, elt, state, options, layout)\n						{\n								if (state.isSliding == false)\n								{\n									SetUserPreference(\'menu_size\', state.size, true);\n								}\n						},\n									\n						onopen_end: function(name, elt, state, options, layout)\n						{\n							if (state.isSliding == false)\n							{\n								$(\'.menu-pane-exclusive\').hide();\n								SetUserPreference(\'menu_pane\', \'open\', true);\n							}\n						}\n					},\n			center: {\n						onresize_end: function(name, elt, state, options, layout)\n						{\n								$(\'.v-resizable\').each( function() {\n									var fixedWidth = $(this).parent().innerWidth() - 6;\n									$(this).width(fixedWidth);\n									// Make sure it cannot be resized horizontally\n									$(this).resizable(\'options\', { minWidth: fixedWidth, maxWidth:	fixedWidth });\n									// Now adjust all the child \'items\'\n									var innerWidth = $(this).innerWidth() - 10;\n									$(this).find(\'.item\').width(innerWidth);\n								});\n								$(\'.panel-resized\').trigger(\'resized\');\n						}\n				\n					}\n		});\n		window.clearTimeout(iPaneVisWatchDog);\n		//myLayout.open( \"west\" );\n		$(\'.ui-layout-resizer-west .ui-layout-toggler\').css({background: \'transparent\'});\n						myLayout.addPinBtn( \"#tPinMenu\", \"west\" );\n		\n		$(\'#left-pane\').layout({ resizable: false, spacing_open: 0, south: { size: 94 }, enableCursorHotkey: false });\n		\n		// Tabs, using JQuery BBQ to store the history\n		// The \"tab widgets\" to handle.\n		var tabs = $(\'div[id^=tabbedContent]\');\n			\n		// This selector will be reused when selecting actual tab widget A elements.\n		var tab_a_selector = \'ul.ui-tabs-nav a\';\n		  \n		// Ugly patch for a change in the behavior of jQuery UI:\n		// Before jQuery UI 1.9, tabs were always considered as \"local\" (opposed to Ajax)\n		// when their href was beginning by #. Starting with 1.9, a <base> tag in the page\n		// is taken into account and causes \"local\" tabs to be considered as Ajax\n		// unless their URL is equal to the URL of the page...\n		$(\'div[id^=tabbedContent] > ul > li > a\').each(function() {\n			var sHash = location.hash;\n			var sHref = $(this).attr(\"href\");\n			if (sHref.match(/^#/))\n			{\n				var sCleanLocation = location.href.toString().replace(sHash, \'\').replace(/#$/, \'\');\n				$(this).attr(\"href\", sCleanLocation+$(this).attr(\"href\"));\n			}\n		});\n\n		// Enable tabs on all tab widgets. The `event` property must be overridden so\n		// that the tabs aren\'t changed on click, and any custom event name can be\n		// specified. Note that if you define a callback for the \'select\' event, it\n		// will be executed for the selected tab whenever the hash changes.\n		tabs.tabs({\n			event: \'change\', \'show\': function(event, ui) {\n				$(\'.resizable\', ui.panel).resizable(); // Make resizable everything that claims to be resizable !\n			},\n			beforeLoad: function( event, ui ) {\n				if ( ui.tab.data(\'loaded\') && (ui.tab.attr(\'data-cache\') == \'true\')) {\n					event.preventDefault();\n					return;\n				}\n				ui.panel.html(\'<div><img src=\"../images/indicator.gif\"></div>\');\n				ui.jqXHR.success(function() {\n					ui.tab.data( \"loaded\", true );\n				});\n			}\n		});\n\n		$(\'.resizable\').filter(\':visible\').resizable();\n	}\n	catch(err)\n	{\n		// Do something with the error !\n		alert(err);\n	}\";s:10:\"\0*\0m_oTabs\";O:10:\"TabManager\":3:{s:10:\"\0*\0m_aTabs\";a:0:{}s:25:\"\0*\0m_sCurrentTabContainer\";s:0:\"\";s:16:\"\0*\0m_sCurrentTab\";s:0:\"\";}s:21:\"\0*\0bBreadCrumbEnabled\";b:0;s:21:\"\0*\0sBreadCrumbEntryId\";N;s:24:\"\0*\0sBreadCrumbEntryLabel\";N;s:30:\"\0*\0sBreadCrumbEntryDescription\";N;s:22:\"\0*\0sBreadCrumbEntryUrl\";N;s:23:\"\0*\0sBreadCrumbEntryIcon\";N;s:7:\"\0*\0oCtx\";O:10:\"ContextTag\":0:{}s:15:\"m_aReadyScripts\";a:3:{i:0;s:1728:\"	//add new widget called TruncatedList to properly display truncated lists when they are sorted\n	$.tablesorter.addWidget({ \n		// give the widget a id \n		id: \"truncatedList\", \n		// format is called when the on init and when a sorting has finished \n		format: function(table)\n		{ \n			// Check if there is a \"truncated\" line\n			this.truncatedList = false;  \n			if ($(\"tr td.truncated\",table).length > 0)\n			{\n				this.truncatedList = true;\n			}\n			if (this.truncatedList)\n			{\n				$(\"tr td\",table).removeClass(\'truncated\');\n				$(\"tr:last td\",table).addClass(\'truncated\');\n			}\n		} \n	});\n	\n	$.tablesorter.addWidget({ \n		// give the widget a id \n		id: \"myZebra\", \n		// format is called when the on init and when a sorting has finished \n		format: function(table)\n		{\n			// Replace the \'red even\' lines by \'red_even\' since most browser do not support 2 classes selector in CSS, etc..\n			$(\"tbody tr:even\",table).addClass(\'even\');\n			$(\"tbody tr.red:even\",table).removeClass(\'red\').removeClass(\'even\').addClass(\'red_even\');\n			$(\"tbody tr.orange:even\",table).removeClass(\'orange\').removeClass(\'even\').addClass(\'orange_even\');\n			$(\"tbody tr.green:even\",table).removeClass(\'green\').removeClass(\'even\').addClass(\'green_even\');\n			// In case we sort again the table, we need to remove the added \'even\' classes on odd rows\n			$(\"tbody tr:odd\",table).removeClass(\'even\');\n			$(\"tbody tr.red_even:odd\",table).removeClass(\'even\').removeClass(\'red_even\').addClass(\'red\');\n			$(\"tbody tr.orange_even:odd\",table).removeClass(\'even\').removeClass(\'orange_even\').addClass(\'orange\');\n			$(\"tbody tr.green_even:odd\",table).removeClass(\'even\').removeClass(\'green_even\').addClass(\'green\');\n		} \n	});\n	$(\"table.listResults\").tableHover(); // hover tables\";i:1;s:5505:\"	\n	// Adjust initial size\n	$(\'.v-resizable\').each( function()\n		{\n			var parent_id = $(this).parent().id;\n			// Restore the saved height\n			var iHeight = GetUserPreference(parent_id+\'_\'+this.id+\'_height\', undefined);\n			if (iHeight != undefined)\n			{\n				$(this).height(parseInt(iHeight, 10)); // Parse in base 10 !);\n			}\n			// Adjust the child \'item\'\'s height and width to fit\n			var container = $(this);\n			var fixedWidth = container.parent().innerWidth() - 6;\n			// Set the width to fit the parent\n			$(this).width(fixedWidth);\n			var headerHeight = $(this).find(\'.drag_handle\').height();\n			// Now adjust the width and height of the child \'item\'\n			container.find(\'.item\').height(container.innerHeight() - headerHeight - 12).width(fixedWidth - 10);\n		}\n	);\n	// Make resizable, vertically only everything that claims to be v-resizable !\n	$(\'.v-resizable\').resizable( { handles: \'s\', minHeight: $(this).find(\'.drag_handle\').height(), minWidth: $(this).parent().innerWidth() - 6, maxWidth: $(this).parent().innerWidth() - 6, stop: function()\n		{\n			// Adjust the content\n			var container = $(this);\n			var headerHeight = $(this).find(\'.drag_handle\').height();\n			container.find(\'.item\').height(container.innerHeight() - headerHeight - 12);//.width(container.innerWidth());\n			var parent_id = $(this).parent().id;\n			SetUserPreference(parent_id+\'_\'+this.id+\'_height\', $(this).height(), true); // true => persistent\n		}\n	} );\n		\n	// Tabs, using JQuery BBQ to store the history\n	// The \"tab widgets\" to handle.\n	var tabs = $(\'div[id^=tabbedContent]\');\n		\n	// This selector will be reused when selecting actual tab widget A elements.\n	var tab_a_selector = \'ul.ui-tabs-nav a\';\n	  \n	// Define our own click handler for the tabs, overriding the default.\n	tabs.find( tab_a_selector ).click(function()\n	{\n		var state = {};\n				  \n		// Get the id of this tab widget.\n		var id = $(this).closest( \'div[id^=tabbedContent]\' ).attr( \'id\' );\n		  \n		// Get the index of this tab.\n		var idx = $(this).parent().prevAll().length;\n		\n		// Set the state!\n		state[ id ] = idx;\n		$.bbq.pushState( state );\n	});\n	\n	// refresh the hash when the tab is changed (from a JS script)\n	$(\'body\').on( \'tabsactivate\', \'.ui-tabs\', function(event, ui) {\n		var state = {};\n			\n		// Get the id of this tab widget.\n		var id = $(ui.newTab).closest( \'div[id^=tabbedContent]\' ).attr( \'id\' );\n		\n		// Get the index of this tab.\n		var idx = $(ui.newTab).prevAll().length;\n			\n		// Set the state!\n		state[ id ] = idx;\n		$.bbq.pushState( state );\n	});\n	\n	// Bind an event to window.onhashchange that, when the history state changes,\n	// iterates over all tab widgets, changing the current tab as necessary.\n	$(window).bind( \'hashchange\', function(e)\n	{\n		// Iterate over all tab widgets.\n		tabs.each(function()\n		{  \n			// Get the index for this tab widget from the hash, based on the\n			// appropriate id property. In jQuery 1.4, you should use e.getState()\n			// instead of $.bbq.getState(). The second, \'true\' argument coerces the\n			// string value to a number.\n			var idx = $.bbq.getState( this.id, true ) || 0;\n			  \n			// Select the appropriate tab for this tab widget by triggering the custom\n			// event specified in the .tabs() init above (you could keep track of what\n			// tab each widget is on using .data, and only select a tab if it has\n			// changed).\n			$(this).find( tab_a_selector ).eq( idx ).triggerHandler( \'change\' );\n		});\n\n		// Iterate over all truncated lists to find whether they are expanded or not\n		$(\'a.truncated\').each(function()\n		{\n			var state = $.bbq.getState( this.id, true ) || \'close\';\n			if (state == \'open\')\n			{\n				$(this).trigger(\'open\');\n			}\n			else\n			{\n				$(this).trigger(\'close\');	\n			}\n		});\n	});\n	\n	// Shortcut menu actions\n	$(\'.actions_button a\').click( function() {\n		aMatches = /#(.*)$/.exec(window.location.href);\n		if (aMatches != null)\n		{\n			currentHash = aMatches[1];\n			if ( /#(.*)$/.test(this.href))\n			{\n				this.href = this.href.replace(/#(.*)$/, \'#\'+currentHash);\n			}\n		}\n	});\n\n	// End of Tabs handling\n\n	PrepareWidgets();\n\n	// Make sortable, everything that claims to be sortable\n	$(\'.sortable\').sortable( {axis: \'y\', cursor: \'move\', handle: \'.drag_handle\', stop: function()\n		{\n			if ($(this).hasClass(\'persistent\'))\n			{\n				// remember the sort order for next time the page is loaded...\n				sSerialized = $(this).sortable(\'serialize\', {key: \'menu\'});\n				var sTemp = sSerialized.replace(/menu=/g, \'\');\n				SetUserPreference(this.id+\'_order\', sTemp.replace(/&/g, \',\'), true); // true => persistent !\n			}\n		}\n	});\n	docWidth = $(document).width();\n	$(\'#ModalDlg\').dialog({ autoOpen: false, modal: true, width: 0.8*docWidth }); // JQuery UI dialogs\n	ShowDebug();\n	$(\'#logOffBtn>ul\').popupmenu();\n	\n	$(\'.caselog_header\').click( function () { $(this).toggleClass(\'open\').next(\'.caselog_entry,.caselog_entry_html\').toggle(); });\n	\n	$(document).ajaxSend(function(event, jqxhr, options) {\n		jqxhr.setRequestHeader(\'X-Combodo-Ajax\', \'true\');\n	});\n	$(document).ajaxError(function(event, jqxhr, options) {\n		if (jqxhr.status == 401)\n		{\n			$(\'<div>\'+\"You are disconnected. You must identify yourself to continue using the application.\"+\'</div>\').dialog({\n				modal:true,\n				title: \"Warning!\",\n				close: function() { $(this).remove(); },\n				minWidth: 400,\n				buttons: [\n					{ text: \"Login again\", click: function() { window.location.href= GetAbsoluteUrlAppRoot()+\'pages/UI.php\' } },\n					{ text: \"Stay on this page\", click: function() { $(this).dialog(\'close\'); } }\n				]\n			});\n		}\n	});\";i:2;s:285:\"$(\'img[data-img-id]\').each(function() {\n	if ($(this).width() > 250)\n	{\n		$(this).css({\'max-width\': \'250px\', width: \'\', height: \'\', \'max-height\': \'\'});\n	}\n	$(this).addClass(\'inline-image\').attr(\'href\', $(this).attr(\'src\'));\n}).magnificPopup({type: \'image\', closeOnContentClick: true });\";}s:10:\"m_sRootUrl\";s:23:\"https://alltic.co/itsm/\";s:10:\"\0*\0s_title\";s:32:\"iTop - Creación de Solicitudes \";s:12:\"\0*\0s_content\";s:195:\"<h1><img src=\"https://alltic.co/itsm/env-production/itop-request-mgmt-itil/images/user-request.png\" style=\"vertical-align:middle;\"/>&nbsp;Creación de Solicitudes</h1>\n<div class=\"wizContainer\">\n\";s:21:\"\0*\0s_deferred_content\";s:0:\"\";s:12:\"\0*\0a_scripts\";a:4:{i:0;s:860:\"function GetAbsoluteUrlAppRoot()\n{\n	return \'https://alltic.co/itsm/\';\n}\n\nfunction GetAbsoluteUrlModulesRoot()\n{\n	return \'https://alltic.co/itsm/env-production/\';\n}\n\nfunction GetAbsoluteUrlModulePage(sModule, sPage, aArguments)\n{\n	// aArguments is optional, it default to an empty hash\n	aArguments = typeof aArguments !== \'undefined\' ? aArguments : {};\n\n	var sUrl = \'https://alltic.co/itsm/\'+\'pages/exec.php?exec_module=\'+sModule+\'&exec_page=\'+sPage+\'&exec_env=\'+\'production\';\n	for (var sArgName in aArguments)\n	{\n		if (aArguments.hasOwnProperty(sArgName))\n		{\n			sUrl = sUrl + \'&\'+sArgName+\'=\'+aArguments[sArgname];\n		}\n	}\n	return sUrl;\n}\n\nfunction AddAppContext(sURL)\n{\n	var sContext = \'c[menu]=NewUserRequest\';\n	if (sContext.length > 0)\n	{\n		if (sURL.indexOf(\'?\') == -1)\n		{\n			return sURL+\'?\'+sContext;\n		}				\n		return sURL+\'&\'+sContext;\n	}\n	return sURL;\n}\";i:1;s:1971:\"	function PrepareWidgets()\n	{\n		// note: each action implemented here must be idempotent,\n		//       because this helper function might be called several times on a given page \n	\n		$(\".date-pick\").datepicker({\"showOn\":\"button\",\"buttonImage\":\"..\\/images\\/calendar.png\",\"buttonImageOnly\":true,\"dateFormat\":\"yy-mm-dd\",\"constrainInput\":false,\"changeMonth\":true,\"changeYear\":true,\"dayNamesMin\":[\"Su\",\"Mo\",\"Tu\",\"We\",\"Th\",\"Fr\",\"Sa\"],\"monthNamesShort\":[\"Jan\",\"Feb\",\"Mar\",\"Apr\",\"May\",\"Jun\",\"Jul\",\"Aug\",\"Sep\",\"Oct\",\"Nov\",\"Dec\"],\"firstDay\":0});\n	\n		// Hack for the date and time picker addon issue on Chrome (see #1305)\n		// The workaround is to instantiate the widget on demand\n		// It relies on the same markup, thus reverting to the original implementation should be straightforward\n		$(\".datetime-pick:not(.is-widget-ready)\").each(function(){\n			var oInput = this;\n			$(oInput).addClass(\'is-widget-ready\');\n			$(\'<img class=\"datetime-pick-button\" src=\"../images/calendar.png\">\')\n				.insertAfter($(this))\n				.on(\'click\', function(){\n					$(oInput)\n						.datetimepicker({\"showOn\":\"\",\"buttonImage\":null,\"buttonImageOnly\":true,\"dateFormat\":\"yy-mm-dd\",\"constrainInput\":false,\"changeMonth\":true,\"changeYear\":true,\"dayNamesMin\":[\"Su\",\"Mo\",\"Tu\",\"We\",\"Th\",\"Fr\",\"Sa\"],\"monthNamesShort\":[\"Jan\",\"Feb\",\"Mar\",\"Apr\",\"May\",\"Jun\",\"Jul\",\"Aug\",\"Sep\",\"Oct\",\"Nov\",\"Dec\"],\"firstDay\":0,\"timeFormat\":\"HH:mm:ss\",\"controlType\":\"select\",\"closeText\":\"Ok\",\n				\'timeText\': $.timepicker.regional[\"es\"].timeText,\n				\'hourText\': $.timepicker.regional[\"es\"].hourText,\n				\'minuteText\': $.timepicker.regional[\"es\"].minuteText,\n				\'secondText\': $.timepicker.regional[\"es\"].secondText,\n				\'currentText\': $.timepicker.regional[\"es\"].currentText\n			})\n						.datetimepicker(\'show\')\n						.datetimepicker(\'option\', \'onClose\', function(dateText,inst){\n							$(oInput).datetimepicker(\'destroy\');\n						})\n						.on(\'click keypress\', function(){\n							$(oInput).datetimepicker(\'hide\');\n						});\n				});\n		});\n	}\";i:2;s:1734:\"//		// for JQuery history\n//		function history_callback(hash)\n//		{\n//			// do stuff that loads page content based on hash variable\n//			var aMatches = /^tab_(.*)$/.exec(hash);\n//			if (aMatches != null)\n//			{\n//				var tab = $(\'#\'+hash);\n//				tab.parents(\'div[id^=tabbedContent]:first\').tabs(\'select\', aMatches[1]);\n//			}\n//		}\n\n		function goBack()\n		{\n			window.history.back();\n		}\n		\n		function BackToDetails(sClass, id, sDefaultUrl, sOwnershipToken)\n		{\n			window.bInCancel = true;\n			if (id > 0)\n			{\n				sToken = \'\';\n				if (sOwnershipToken != undefined)\n				{\n					sToken = \'&token=\'+sOwnershipToken;\n				}\n				window.location.href = AddAppContext(GetAbsoluteUrlAppRoot()+\'pages/UI.php?operation=release_lock_and_details&class=\'+sClass+\'&id=\'+id+sToken);\n			}\n			else\n			{\n				window.location.href = sDefaultUrl; // Already contains the context...				\n			}\n		}\n\n		function BackToList(sClass)\n		{\n			window.location.href = AddAppContext(GetAbsoluteUrlAppRoot()+\'pages/UI.php?operation=search_oql&oql_class=\'+sClass+\'&oql_clause=WHERE id=0\');\n		}\n		\n		function ShowDebug()\n		{\n			if ($(\'#rawOutput > div\').html() != \'\')\n			{\n				$(\'#rawOutput\').dialog( {autoOpen: true, modal:false, width: \'80%\'});\n			}\n		}\n		\n		var oUserPreferences = {\"welcome_popup\":\"0\",\"menu_pane\":\"open\",\"menu_size\":\"421\"};\n\n		// For disabling the CKEditor at init time when the corresponding textarea is disabled !\n		CKEDITOR.plugins.add( \'disabler\',\n		{\n			init : function( editor )\n			{\n				editor.on( \'instanceReady\', function(e)\n				{\n					e.removeListener();\n					$(\'#\'+ editor.name).trigger(\'update\');\n				});\n			}\n			\n		});\n\n		\n		function FixPaneVis()\n		{\n			$(\'.ui-layout-center, .ui-layout-north, .ui-layout-south\').css({display: \'block\'});\n		}\";i:3;s:172:\"function ShowAboutBox()\n{\n	$.post(GetAbsoluteUrlAppRoot()+\'pages/ajax.render.php\', {operation: \'about_box\'}, function(data){\n		$(\'body\').append(data);\n	});\n	return false;\n}\";}s:17:\"\0*\0a_dict_entries\";a:3:{s:25:\"UI:FillAllMandatoryFields\";s:41:\"Por favor llenar los campos obligatorios.\";s:16:\"UI:Button:Cancel\";s:8:\"Cancelar\";s:14:\"UI:Button:Done\";s:5:\"Listo\";}s:11:\"\0*\0a_styles\";a:0:{}s:20:\"\0*\0a_include_scripts\";N;s:24:\"\0*\0a_include_stylesheets\";N;s:12:\"\0*\0a_headers\";a:2:{i:0;s:38:\"Content-type: text/html; charset=utf-8\";i:1;s:23:\"Cache-control: no-cache\";}s:9:\"\0*\0a_base\";a:2:{s:4:\"href\";s:0:\"\";s:6:\"target\";s:0:\"\";}s:10:\"\0*\0iNextId\";i:0;s:17:\"\0*\0iTransactionId\";i:0;s:15:\"\0*\0sContentType\";s:0:\"\";s:22:\"\0*\0sContentDisposition\";s:0:\"\";s:19:\"\0*\0sContentFileName\";s:0:\"\";s:25:\"\0*\0bTrashUnexpectedOutput\";b:0;s:18:\"\0*\0s_sOutputFormat\";N;s:18:\"\0*\0a_OutputOptions\";a:0:{}s:13:\"\0*\0bPrintable\";b:0;s:16:\"a_linked_scripts\";a:43:{s:46:\"https://alltic.co/itsm/js/jquery-1.10.0.min.js\";s:46:\"https://alltic.co/itsm/js/jquery-1.10.0.min.js\";s:53:\"https://alltic.co/itsm/js/jquery-migrate-1.2.1.min.js\";s:53:\"https://alltic.co/itsm/js/jquery-migrate-1.2.1.min.js\";s:56:\"https://alltic.co/itsm/js/jquery-ui-1.10.3.custom.min.js\";s:56:\"https://alltic.co/itsm/js/jquery-ui-1.10.3.custom.min.js\";s:37:\"https://alltic.co/itsm/js/hovertip.js\";s:37:\"https://alltic.co/itsm/js/hovertip.js\";s:47:\"https://alltic.co/itsm/js/jquery.tablesorter.js\";s:47:\"https://alltic.co/itsm/js/jquery.tablesorter.js\";s:53:\"https://alltic.co/itsm/js/jquery.tablesorter.pager.js\";s:53:\"https://alltic.co/itsm/js/jquery.tablesorter.pager.js\";s:46:\"https://alltic.co/itsm/js/jquery.tablehover.js\";s:46:\"https://alltic.co/itsm/js/jquery.tablehover.js\";s:41:\"https://alltic.co/itsm/js/field_sorter.js\";s:41:\"https://alltic.co/itsm/js/field_sorter.js\";s:38:\"https://alltic.co/itsm/js/datatable.js\";s:38:\"https://alltic.co/itsm/js/datatable.js\";s:46:\"https://alltic.co/itsm/js/jquery.positionBy.js\";s:46:\"https://alltic.co/itsm/js/jquery.positionBy.js\";s:45:\"https://alltic.co/itsm/js/jquery.popupmenu.js\";s:45:\"https://alltic.co/itsm/js/jquery.popupmenu.js\";s:26:\"../js/jquery.layout.min.js\";s:26:\"../js/jquery.layout.min.js\";s:26:\"../js/jquery.ba-bbq.min.js\";s:26:\"../js/jquery.ba-bbq.min.js\";s:24:\"../js/jquery.treeview.js\";s:24:\"../js/jquery.treeview.js\";s:28:\"../js/jquery.autocomplete.js\";s:28:\"../js/jquery.autocomplete.js\";s:13:\"../js/date.js\";s:13:\"../js/date.js\";s:35:\"../js/jquery-ui-timepicker-addon.js\";s:35:\"../js/jquery-ui-timepicker-addon.js\";s:44:\"../js/jquery-ui-timepicker-addon-i18n.min.js\";s:44:\"../js/jquery-ui-timepicker-addon-i18n.min.js\";s:23:\"../js/jquery.blockUI.js\";s:23:\"../js/jquery.blockUI.js\";s:14:\"../js/utils.js\";s:14:\"../js/utils.js\";s:18:\"../js/swfobject.js\";s:18:\"../js/swfobject.js\";s:26:\"../js/ckeditor/ckeditor.js\";s:26:\"../js/ckeditor/ckeditor.js\";s:33:\"../js/ckeditor/adapters/jquery.js\";s:33:\"../js/ckeditor/adapters/jquery.js\";s:28:\"../js/jquery.qtip-1.0.min.js\";s:28:\"../js/jquery.qtip-1.0.min.js\";s:23:\"../js/property_field.js\";s:23:\"../js/property_field.js\";s:16:\"../js/fg.menu.js\";s:16:\"../js/fg.menu.js\";s:20:\"../js/icon_select.js\";s:20:\"../js/icon_select.js\";s:20:\"../js/raphael-min.js\";s:20:\"../js/raphael-min.js\";s:11:\"../js/d3.js\";s:11:\"../js/d3.js\";s:11:\"../js/c3.js\";s:11:\"../js/c3.js\";s:27:\"../js/jquery.multiselect.js\";s:27:\"../js/jquery.multiselect.js\";s:23:\"../js/ajaxfileupload.js\";s:23:\"../js/ajaxfileupload.js\";s:26:\"../js/jquery.mousewheel.js\";s:26:\"../js/jquery.mousewheel.js\";s:34:\"../js/jquery.magnific-popup.min.js\";s:34:\"../js/jquery.magnific-popup.min.js\";s:19:\"../js/breadcrumb.js\";s:19:\"../js/breadcrumb.js\";s:19:\"../js/moment.min.js\";s:19:\"../js/moment.min.js\";s:13:\"../js/json.js\";s:13:\"../js/json.js\";s:25:\"../js/forms-json-utils.js\";s:25:\"../js/forms-json-utils.js\";s:21:\"../js/wizardhelper.js\";s:21:\"../js/wizardhelper.js\";s:21:\"../js/wizard.utils.js\";s:21:\"../js/wizard.utils.js\";s:20:\"../js/linkswidget.js\";s:20:\"../js/linkswidget.js\";s:26:\"../js/linksdirectwidget.js\";s:26:\"../js/linksdirectwidget.js\";s:21:\"../js/extkeywidget.js\";s:21:\"../js/extkeywidget.js\";}s:20:\"a_linked_stylesheets\";a:9:{i:0;a:2:{s:4:\"link\";s:71:\"https://alltic.co/itsm/css/ui-lightness/jquery-ui-1.10.3.custom.min.css\";s:9:\"condition\";s:0:\"\";}i:1;a:2:{s:4:\"link\";s:41:\"https://alltic.co/itsm/css/light-grey.css\";s:9:\"condition\";s:0:\"\";}i:2;a:2:{s:4:\"link\";s:26:\"../css/jquery.treeview.css\";s:9:\"condition\";s:0:\"\";}i:3;a:2:{s:4:\"link\";s:30:\"../css/jquery.autocomplete.css\";s:9:\"condition\";s:0:\"\";}i:4;a:2:{s:4:\"link\";s:37:\"../css/jquery-ui-timepicker-addon.css\";s:9:\"condition\";s:0:\"\";}i:5;a:2:{s:4:\"link\";s:18:\"../css/fg.menu.css\";s:9:\"condition\";s:0:\"\";}i:6;a:2:{s:4:\"link\";s:29:\"../css/jquery.multiselect.css\";s:9:\"condition\";s:0:\"\";}i:7;a:2:{s:4:\"link\";s:25:\"../css/magnific-popup.css\";s:9:\"condition\";s:0:\"\";}i:8;a:2:{s:4:\"link\";s:17:\"../css/c3.min.css\";s:9:\"condition\";s:0:\"\";}}s:14:\"s_OutputFormat\";s:4:\"html\";}i:1;s:11:\"UserRequest\";i:2;O:11:\"UserRequest\":22:{s:12:\"\0*\0m_iFormId\";N;s:13:\"\0*\0aFieldsMap\";N;s:14:\"\0*\0bAllowWrite\";b:0;s:15:\"\0*\0m_datCreated\";N;s:15:\"\0*\0m_datUpdated\";N;s:19:\"\0DBObject\0m_bIsInDB\";b:0;s:16:\"\0DBObject\0m_iKey\";i:-1;s:23:\"\0DBObject\0m_aCurrValues\";a:79:{s:18:\"operational_status\";s:7:\"ongoing\";s:3:\"ref\";s:0:\"\";s:6:\"org_id\";i:0;s:8:\"org_name\";s:0:\"\";s:9:\"caller_id\";i:0;s:11:\"caller_name\";s:0:\"\";s:7:\"team_id\";i:0;s:9:\"team_name\";s:0:\"\";s:8:\"agent_id\";i:0;s:10:\"agent_name\";s:0:\"\";s:5:\"title\";s:0:\"\";s:11:\"description\";s:0:\"\";s:10:\"start_date\";N;s:8:\"end_date\";N;s:11:\"last_update\";N;s:10:\"close_date\";N;s:11:\"private_log\";O:10:\"ormCaseLog\":3:{s:9:\"\0*\0m_sLog\";s:0:\"\";s:11:\"\0*\0m_aIndex\";a:0:{}s:14:\"\0*\0m_bModified\";b:0;}s:13:\"contacts_list\";O:11:\"DBObjectSet\":14:{s:14:\"\0*\0m_aAddedIds\";a:0:{}s:18:\"\0*\0m_aAddedObjects\";a:0:{}s:10:\"\0*\0m_aArgs\";a:0:{}s:15:\"\0*\0m_aAttToLoad\";N;s:13:\"\0*\0m_aOrderBy\";a:0:{}s:9:\"m_bLoaded\";b:1;s:20:\"\0*\0m_iNumTotalDBRows\";i:0;s:21:\"\0*\0m_iNumLoadedDBRows\";i:0;s:13:\"\0*\0m_iCurrRow\";i:0;s:12:\"\0*\0m_oFilter\";O:14:\"DBObjectSearch\":11:{s:26:\"\0DBObjectSearch\0m_aClasses\";a:1:{s:18:\"lnkContactToTicket\";s:18:\"lnkContactToTicket\";}s:34:\"\0DBObjectSearch\0m_aSelectedClasses\";a:1:{s:18:\"lnkContactToTicket\";s:18:\"lnkContactToTicket\";}s:34:\"\0DBObjectSearch\0m_oSearchCondition\";O:15:\"FalseExpression\":1:{s:10:\"\0*\0m_value\";i:0;}s:25:\"\0DBObjectSearch\0m_aParams\";a:0:{}s:27:\"\0DBObjectSearch\0m_aFullText\";a:0:{}s:29:\"\0DBObjectSearch\0m_aPointingTo\";a:0:{}s:31:\"\0DBObjectSearch\0m_aReferencedBy\";a:0:{}s:18:\"\0*\0m_bAllowAllData\";b:0;s:18:\"\0*\0m_bDataFiltered\";b:0;s:25:\"\0*\0m_bNoContextParameters\";b:0;s:24:\"\0*\0m_aModifierProperties\";a:0:{}}s:15:\"\0*\0m_oSQLResult\";N;s:19:\"m_aExtendedDataSpec\";N;s:13:\"m_iLimitCount\";i:0;s:13:\"m_iLimitStart\";i:0;}s:18:\"functionalcis_list\";O:11:\"DBObjectSet\":14:{s:14:\"\0*\0m_aAddedIds\";a:0:{}s:18:\"\0*\0m_aAddedObjects\";a:0:{}s:10:\"\0*\0m_aArgs\";a:0:{}s:15:\"\0*\0m_aAttToLoad\";N;s:13:\"\0*\0m_aOrderBy\";a:0:{}s:9:\"m_bLoaded\";b:1;s:20:\"\0*\0m_iNumTotalDBRows\";i:0;s:21:\"\0*\0m_iNumLoadedDBRows\";i:0;s:13:\"\0*\0m_iCurrRow\";i:0;s:12:\"\0*\0m_oFilter\";O:14:\"DBObjectSearch\":11:{s:26:\"\0DBObjectSearch\0m_aClasses\";a:1:{s:23:\"lnkFunctionalCIToTicket\";s:23:\"lnkFunctionalCIToTicket\";}s:34:\"\0DBObjectSearch\0m_aSelectedClasses\";a:1:{s:23:\"lnkFunctionalCIToTicket\";s:23:\"lnkFunctionalCIToTicket\";}s:34:\"\0DBObjectSearch\0m_oSearchCondition\";O:15:\"FalseExpression\":1:{s:10:\"\0*\0m_value\";i:0;}s:25:\"\0DBObjectSearch\0m_aParams\";a:0:{}s:27:\"\0DBObjectSearch\0m_aFullText\";a:0:{}s:29:\"\0DBObjectSearch\0m_aPointingTo\";a:0:{}s:31:\"\0DBObjectSearch\0m_aReferencedBy\";a:0:{}s:18:\"\0*\0m_bAllowAllData\";b:0;s:18:\"\0*\0m_bDataFiltered\";b:0;s:25:\"\0*\0m_bNoContextParameters\";b:0;s:24:\"\0*\0m_aModifierProperties\";a:0:{}}s:15:\"\0*\0m_oSQLResult\";N;s:19:\"m_aExtendedDataSpec\";N;s:13:\"m_iLimitCount\";i:0;s:13:\"m_iLimitStart\";i:0;}s:15:\"workorders_list\";O:11:\"DBObjectSet\":14:{s:14:\"\0*\0m_aAddedIds\";a:0:{}s:18:\"\0*\0m_aAddedObjects\";a:0:{}s:10:\"\0*\0m_aArgs\";a:0:{}s:15:\"\0*\0m_aAttToLoad\";N;s:13:\"\0*\0m_aOrderBy\";a:0:{}s:9:\"m_bLoaded\";b:1;s:20:\"\0*\0m_iNumTotalDBRows\";i:0;s:21:\"\0*\0m_iNumLoadedDBRows\";i:0;s:13:\"\0*\0m_iCurrRow\";i:0;s:12:\"\0*\0m_oFilter\";O:14:\"DBObjectSearch\":11:{s:26:\"\0DBObjectSearch\0m_aClasses\";a:1:{s:9:\"WorkOrder\";s:9:\"WorkOrder\";}s:34:\"\0DBObjectSearch\0m_aSelectedClasses\";a:1:{s:9:\"WorkOrder\";s:9:\"WorkOrder\";}s:34:\"\0DBObjectSearch\0m_oSearchCondition\";O:15:\"FalseExpression\":1:{s:10:\"\0*\0m_value\";i:0;}s:25:\"\0DBObjectSearch\0m_aParams\";a:0:{}s:27:\"\0DBObjectSearch\0m_aFullText\";a:0:{}s:29:\"\0DBObjectSearch\0m_aPointingTo\";a:0:{}s:31:\"\0DBObjectSearch\0m_aReferencedBy\";a:0:{}s:18:\"\0*\0m_bAllowAllData\";b:0;s:18:\"\0*\0m_bDataFiltered\";b:0;s:25:\"\0*\0m_bNoContextParameters\";b:0;s:24:\"\0*\0m_aModifierProperties\";a:0:{}}s:15:\"\0*\0m_oSQLResult\";N;s:19:\"m_aExtendedDataSpec\";N;s:13:\"m_iLimitCount\";i:0;s:13:\"m_iLimitStart\";i:0;}s:6:\"status\";s:3:\"new\";s:12:\"request_type\";s:15:\"service_request\";s:6:\"impact\";s:1:\"2\";s:8:\"priority\";s:1:\"4\";s:7:\"urgency\";s:1:\"4\";s:6:\"origin\";s:5:\"phone\";s:11:\"approver_id\";i:0;s:14:\"approver_email\";s:0:\"\";s:16:\"servicefamily_id\";i:0;s:18:\"servicefamily_name\";s:0:\"\";s:10:\"service_id\";i:0;s:12:\"service_name\";s:0:\"\";s:21:\"servicesubcategory_id\";i:0;s:23:\"servicesubcategory_name\";s:0:\"\";s:15:\"escalation_flag\";s:2:\"no\";s:17:\"escalation_reason\";s:0:\"\";s:15:\"assignment_date\";N;s:15:\"resolution_date\";N;s:17:\"last_pending_date\";N;s:16:\"cumulatedpending\";O:12:\"ormStopWatch\":5:{s:13:\"\0*\0iTimeSpent\";i:0;s:11:\"\0*\0iStarted\";N;s:13:\"\0*\0iLastStart\";N;s:11:\"\0*\0iStopped\";N;s:14:\"\0*\0aThresholds\";a:0:{}}s:3:\"tto\";O:12:\"ormStopWatch\":5:{s:13:\"\0*\0iTimeSpent\";i:0;s:11:\"\0*\0iStarted\";N;s:13:\"\0*\0iLastStart\";N;s:11:\"\0*\0iStopped\";N;s:14:\"\0*\0aThresholds\";a:2:{i:75;a:4:{s:8:\"deadline\";N;s:9:\"triggered\";b:0;s:7:\"overrun\";N;s:9:\"highlight\";N;}i:100;a:4:{s:8:\"deadline\";N;s:9:\"triggered\";b:0;s:7:\"overrun\";N;s:9:\"highlight\";N;}}}s:3:\"ttr\";O:12:\"ormStopWatch\":5:{s:13:\"\0*\0iTimeSpent\";i:0;s:11:\"\0*\0iStarted\";N;s:13:\"\0*\0iLastStart\";N;s:11:\"\0*\0iStopped\";N;s:14:\"\0*\0aThresholds\";a:2:{i:75;a:4:{s:8:\"deadline\";N;s:9:\"triggered\";b:0;s:7:\"overrun\";N;s:9:\"highlight\";N;}i:100;a:4:{s:8:\"deadline\";N;s:9:\"triggered\";b:0;s:7:\"overrun\";N;s:9:\"highlight\";N;}}}s:23:\"tto_escalation_deadline\";N;s:14:\"sla_tto_passed\";N;s:12:\"sla_tto_over\";N;s:23:\"ttr_escalation_deadline\";N;s:14:\"sla_ttr_passed\";N;s:12:\"sla_ttr_over\";N;s:10:\"time_spent\";N;s:15:\"resolution_code\";N;s:8:\"solution\";s:0:\"\";s:14:\"pending_reason\";s:0:\"\";s:17:\"parent_request_id\";i:0;s:18:\"parent_request_ref\";s:0:\"\";s:18:\"parent_incident_id\";i:0;s:19:\"parent_incident_ref\";s:0:\"\";s:17:\"parent_problem_id\";i:0;s:18:\"parent_problem_ref\";s:0:\"\";s:16:\"parent_change_id\";i:0;s:17:\"parent_change_ref\";s:0:\"\";s:20:\"related_request_list\";O:11:\"DBObjectSet\":14:{s:14:\"\0*\0m_aAddedIds\";a:0:{}s:18:\"\0*\0m_aAddedObjects\";a:0:{}s:10:\"\0*\0m_aArgs\";a:0:{}s:15:\"\0*\0m_aAttToLoad\";N;s:13:\"\0*\0m_aOrderBy\";a:0:{}s:9:\"m_bLoaded\";b:1;s:20:\"\0*\0m_iNumTotalDBRows\";i:0;s:21:\"\0*\0m_iNumLoadedDBRows\";i:0;s:13:\"\0*\0m_iCurrRow\";i:0;s:12:\"\0*\0m_oFilter\";O:14:\"DBObjectSearch\":11:{s:26:\"\0DBObjectSearch\0m_aClasses\";a:1:{s:11:\"UserRequest\";s:11:\"UserRequest\";}s:34:\"\0DBObjectSearch\0m_aSelectedClasses\";a:1:{s:11:\"UserRequest\";s:11:\"UserRequest\";}s:34:\"\0DBObjectSearch\0m_oSearchCondition\";O:15:\"FalseExpression\":1:{s:10:\"\0*\0m_value\";i:0;}s:25:\"\0DBObjectSearch\0m_aParams\";a:0:{}s:27:\"\0DBObjectSearch\0m_aFullText\";a:0:{}s:29:\"\0DBObjectSearch\0m_aPointingTo\";a:0:{}s:31:\"\0DBObjectSearch\0m_aReferencedBy\";a:0:{}s:18:\"\0*\0m_bAllowAllData\";b:0;s:18:\"\0*\0m_bDataFiltered\";b:0;s:25:\"\0*\0m_bNoContextParameters\";b:0;s:24:\"\0*\0m_aModifierProperties\";a:0:{}}s:15:\"\0*\0m_oSQLResult\";N;s:19:\"m_aExtendedDataSpec\";N;s:13:\"m_iLimitCount\";i:0;s:13:\"m_iLimitStart\";i:0;}s:10:\"public_log\";O:10:\"ormCaseLog\":3:{s:9:\"\0*\0m_sLog\";s:0:\"\";s:11:\"\0*\0m_aIndex\";a:0:{}s:14:\"\0*\0m_bModified\";b:0;}s:17:\"user_satisfaction\";s:1:\"1\";s:12:\"user_comment\";s:0:\"\";s:10:\"finalclass\";s:11:\"UserRequest\";s:12:\"friendlyname\";s:0:\"\";s:19:\"org_id_friendlyname\";s:0:\"\";s:22:\"caller_id_friendlyname\";s:0:\"\";s:20:\"team_id_friendlyname\";s:0:\"\";s:21:\"agent_id_friendlyname\";s:0:\"\";s:24:\"approver_id_friendlyname\";s:0:\"\";s:29:\"servicefamily_id_friendlyname\";s:0:\"\";s:23:\"service_id_friendlyname\";s:0:\"\";s:34:\"servicesubcategory_id_friendlyname\";s:0:\"\";s:30:\"parent_request_id_friendlyname\";s:0:\"\";s:31:\"parent_incident_id_friendlyname\";s:0:\"\";s:30:\"parent_problem_id_friendlyname\";s:0:\"\";s:29:\"parent_change_id_friendlyname\";s:0:\"\";s:34:\"parent_change_id_finalclass_recall\";s:6:\"Change\";}s:16:\"\0*\0m_aOrigValues\";a:79:{s:18:\"operational_status\";N;s:3:\"ref\";N;s:6:\"org_id\";N;s:8:\"org_name\";N;s:9:\"caller_id\";N;s:11:\"caller_name\";N;s:7:\"team_id\";N;s:9:\"team_name\";N;s:8:\"agent_id\";N;s:10:\"agent_name\";N;s:5:\"title\";N;s:11:\"description\";N;s:10:\"start_date\";N;s:8:\"end_date\";N;s:11:\"last_update\";N;s:10:\"close_date\";N;s:11:\"private_log\";N;s:13:\"contacts_list\";N;s:18:\"functionalcis_list\";N;s:15:\"workorders_list\";N;s:6:\"status\";N;s:12:\"request_type\";N;s:6:\"impact\";N;s:8:\"priority\";N;s:7:\"urgency\";N;s:6:\"origin\";N;s:11:\"approver_id\";N;s:14:\"approver_email\";N;s:16:\"servicefamily_id\";N;s:18:\"servicefamily_name\";N;s:10:\"service_id\";N;s:12:\"service_name\";N;s:21:\"servicesubcategory_id\";N;s:23:\"servicesubcategory_name\";N;s:15:\"escalation_flag\";N;s:17:\"escalation_reason\";N;s:15:\"assignment_date\";N;s:15:\"resolution_date\";N;s:17:\"last_pending_date\";N;s:16:\"cumulatedpending\";N;s:3:\"tto\";N;s:3:\"ttr\";N;s:23:\"tto_escalation_deadline\";N;s:14:\"sla_tto_passed\";N;s:12:\"sla_tto_over\";N;s:23:\"ttr_escalation_deadline\";N;s:14:\"sla_ttr_passed\";N;s:12:\"sla_ttr_over\";N;s:10:\"time_spent\";N;s:15:\"resolution_code\";N;s:8:\"solution\";N;s:14:\"pending_reason\";N;s:17:\"parent_request_id\";N;s:18:\"parent_request_ref\";N;s:18:\"parent_incident_id\";N;s:19:\"parent_incident_ref\";N;s:17:\"parent_problem_id\";N;s:18:\"parent_problem_ref\";N;s:16:\"parent_change_id\";N;s:17:\"parent_change_ref\";N;s:20:\"related_request_list\";N;s:10:\"public_log\";N;s:17:\"user_satisfaction\";N;s:12:\"user_comment\";N;s:10:\"finalclass\";N;s:12:\"friendlyname\";N;s:19:\"org_id_friendlyname\";N;s:22:\"caller_id_friendlyname\";N;s:20:\"team_id_friendlyname\";N;s:21:\"agent_id_friendlyname\";N;s:24:\"approver_id_friendlyname\";N;s:29:\"servicefamily_id_friendlyname\";N;s:23:\"service_id_friendlyname\";N;s:34:\"servicesubcategory_id_friendlyname\";N;s:30:\"parent_request_id_friendlyname\";N;s:31:\"parent_incident_id_friendlyname\";N;s:30:\"parent_problem_id_friendlyname\";N;s:29:\"parent_change_id_friendlyname\";N;s:34:\"parent_change_id_finalclass_recall\";N;}s:18:\"\0*\0m_aExtendedData\";N;s:18:\"\0DBObject\0m_bDirty\";b:0;s:24:\"\0DBObject\0m_bCheckStatus\";N;s:19:\"\0*\0m_bSecurityIssue\";N;s:17:\"\0*\0m_aCheckIssues\";N;s:18:\"\0*\0m_aDeleteIssues\";N;s:24:\"\0DBObject\0m_bFullyLoaded\";b:0;s:22:\"\0DBObject\0m_aLoadedAtt\";a:53:{s:18:\"operational_status\";b:1;s:3:\"ref\";b:1;s:6:\"org_id\";b:1;s:9:\"caller_id\";b:1;s:7:\"team_id\";b:1;s:8:\"agent_id\";b:1;s:5:\"title\";b:1;s:11:\"description\";b:1;s:10:\"start_date\";b:1;s:8:\"end_date\";b:1;s:11:\"last_update\";b:1;s:10:\"close_date\";b:1;s:11:\"private_log\";b:1;s:13:\"contacts_list\";b:1;s:18:\"functionalcis_list\";b:1;s:15:\"workorders_list\";b:1;s:6:\"status\";b:1;s:12:\"request_type\";b:1;s:6:\"impact\";b:1;s:8:\"priority\";b:1;s:7:\"urgency\";b:1;s:6:\"origin\";b:1;s:11:\"approver_id\";b:1;s:16:\"servicefamily_id\";b:1;s:10:\"service_id\";b:1;s:21:\"servicesubcategory_id\";b:1;s:15:\"escalation_flag\";b:1;s:17:\"escalation_reason\";b:1;s:15:\"assignment_date\";b:1;s:15:\"resolution_date\";b:1;s:17:\"last_pending_date\";b:1;s:16:\"cumulatedpending\";b:1;s:3:\"tto\";b:1;s:3:\"ttr\";b:1;s:23:\"tto_escalation_deadline\";b:1;s:14:\"sla_tto_passed\";b:1;s:12:\"sla_tto_over\";b:1;s:23:\"ttr_escalation_deadline\";b:1;s:14:\"sla_ttr_passed\";b:1;s:12:\"sla_ttr_over\";b:1;s:10:\"time_spent\";b:1;s:15:\"resolution_code\";b:1;s:8:\"solution\";b:1;s:14:\"pending_reason\";b:1;s:17:\"parent_request_id\";b:1;s:18:\"parent_incident_id\";b:1;s:17:\"parent_problem_id\";b:1;s:16:\"parent_change_id\";b:1;s:20:\"related_request_list\";b:1;s:10:\"public_log\";b:1;s:17:\"user_satisfaction\";b:1;s:12:\"user_comment\";b:1;s:10:\"finalclass\";b:1;}s:16:\"\0*\0m_aTouchedAtt\";a:0:{}s:17:\"\0*\0m_aModifiedAtt\";a:0:{}s:17:\"\0*\0m_aSynchroData\";N;s:19:\"\0*\0m_sHighlightCode\";N;s:15:\"\0*\0m_aCallbacks\";a:0:{}}i:3;a:0:{}}}}','a:0:{}'),(3,'PHP Exception','Page could not be displayed','/itsm/pages/UI.php','a:0:{}','a:3:{s:9:\"operation\";s:3:\"new\";s:5:\"class\";s:11:\"UserRequest\";s:1:\"c\";a:1:{s:4:\"menu\";s:14:\"NewUserRequest\";}}','a:3:{i:0;a:6:{s:4:\"file\";s:54:\"/home/alltic/public_html/itsm/core/metamodel.class.php\";s:4:\"line\";i:481;s:8:\"function\";s:15:\"GetAttributeDef\";s:5:\"class\";s:9:\"MetaModel\";s:4:\"type\";s:2:\"::\";s:4:\"args\";a:2:{i:0;s:11:\"UserRequest\";i:1;s:11:\"pais_ticket\";}}i:1;a:6:{s:4:\"file\";s:68:\"/home/alltic/public_html/itsm/application/cmdbabstract.class.inc.php\";s:4:\"line\";i:2389;s:8:\"function\";s:25:\"GetPrerequisiteAttributes\";s:5:\"class\";s:9:\"MetaModel\";s:4:\"type\";s:2:\"::\";s:4:\"args\";a:2:{i:0;s:11:\"UserRequest\";i:1;s:11:\"pais_ticket\";}}i:2;a:6:{s:4:\"file\";s:42:\"/home/alltic/public_html/itsm/pages/UI.php\";s:4:\"line\";i:758;s:8:\"function\";s:19:\"DisplayCreationForm\";s:5:\"class\";s:18:\"cmdbAbstractObject\";s:4:\"type\";s:2:\"::\";s:4:\"args\";a:4:{i:0;O:11:\"iTopWebPage\":35:{s:20:\"\0iTopWebPage\0m_sMenu\";s:0:\"\";s:23:\"\0iTopWebPage\0m_sMessage\";s:0:\"\";s:26:\"\0iTopWebPage\0m_sInitScript\";s:3833:\"	try\n	{\n		var myLayout; // a var is required because this page utilizes: myLayout.allowOverflow() method\n	\n		// Layout\n		paneSize = GetUserPreference(\'menu_size\', 300)\n		myLayout = $(\'body\').layout({\n			west :	{\n						 minSize: 200, size: paneSize, spacing_open: 16, spacing_close: 16, slideTrigger_open: \"click\", hideTogglerOnSlide: true, enableCursorHotkey: false,\n						onclose_end: function(name, elt, state, options, layout)\n						{\n								if (state.isSliding == false)\n								{\n									$(\'.menu-pane-exclusive\').show();\n									SetUserPreference(\'menu_pane\', \'closed\', true);\n								}\n						},\n						onresize_end: function(name, elt, state, options, layout)\n						{\n								if (state.isSliding == false)\n								{\n									SetUserPreference(\'menu_size\', state.size, true);\n								}\n						},\n									\n						onopen_end: function(name, elt, state, options, layout)\n						{\n							if (state.isSliding == false)\n							{\n								$(\'.menu-pane-exclusive\').hide();\n								SetUserPreference(\'menu_pane\', \'open\', true);\n							}\n						}\n					},\n			center: {\n						onresize_end: function(name, elt, state, options, layout)\n						{\n								$(\'.v-resizable\').each( function() {\n									var fixedWidth = $(this).parent().innerWidth() - 6;\n									$(this).width(fixedWidth);\n									// Make sure it cannot be resized horizontally\n									$(this).resizable(\'options\', { minWidth: fixedWidth, maxWidth:	fixedWidth });\n									// Now adjust all the child \'items\'\n									var innerWidth = $(this).innerWidth() - 10;\n									$(this).find(\'.item\').width(innerWidth);\n								});\n								$(\'.panel-resized\').trigger(\'resized\');\n						}\n				\n					}\n		});\n		window.clearTimeout(iPaneVisWatchDog);\n		//myLayout.open( \"west\" );\n		$(\'.ui-layout-resizer-west .ui-layout-toggler\').css({background: \'transparent\'});\n						myLayout.addPinBtn( \"#tPinMenu\", \"west\" );\n		\n		$(\'#left-pane\').layout({ resizable: false, spacing_open: 0, south: { size: 94 }, enableCursorHotkey: false });\n		\n		// Tabs, using JQuery BBQ to store the history\n		// The \"tab widgets\" to handle.\n		var tabs = $(\'div[id^=tabbedContent]\');\n			\n		// This selector will be reused when selecting actual tab widget A elements.\n		var tab_a_selector = \'ul.ui-tabs-nav a\';\n		  \n		// Ugly patch for a change in the behavior of jQuery UI:\n		// Before jQuery UI 1.9, tabs were always considered as \"local\" (opposed to Ajax)\n		// when their href was beginning by #. Starting with 1.9, a <base> tag in the page\n		// is taken into account and causes \"local\" tabs to be considered as Ajax\n		// unless their URL is equal to the URL of the page...\n		$(\'div[id^=tabbedContent] > ul > li > a\').each(function() {\n			var sHash = location.hash;\n			var sHref = $(this).attr(\"href\");\n			if (sHref.match(/^#/))\n			{\n				var sCleanLocation = location.href.toString().replace(sHash, \'\').replace(/#$/, \'\');\n				$(this).attr(\"href\", sCleanLocation+$(this).attr(\"href\"));\n			}\n		});\n\n		// Enable tabs on all tab widgets. The `event` property must be overridden so\n		// that the tabs aren\'t changed on click, and any custom event name can be\n		// specified. Note that if you define a callback for the \'select\' event, it\n		// will be executed for the selected tab whenever the hash changes.\n		tabs.tabs({\n			event: \'change\', \'show\': function(event, ui) {\n				$(\'.resizable\', ui.panel).resizable(); // Make resizable everything that claims to be resizable !\n			},\n			beforeLoad: function( event, ui ) {\n				if ( ui.tab.data(\'loaded\') && (ui.tab.attr(\'data-cache\') == \'true\')) {\n					event.preventDefault();\n					return;\n				}\n				ui.panel.html(\'<div><img src=\"../images/indicator.gif\"></div>\');\n				ui.jqXHR.success(function() {\n					ui.tab.data( \"loaded\", true );\n				});\n			}\n		});\n\n		$(\'.resizable\').filter(\':visible\').resizable();\n	}\n	catch(err)\n	{\n		// Do something with the error !\n		alert(err);\n	}\";s:10:\"\0*\0m_oTabs\";O:10:\"TabManager\":3:{s:10:\"\0*\0m_aTabs\";a:0:{}s:25:\"\0*\0m_sCurrentTabContainer\";s:0:\"\";s:16:\"\0*\0m_sCurrentTab\";s:0:\"\";}s:21:\"\0*\0bBreadCrumbEnabled\";b:0;s:21:\"\0*\0sBreadCrumbEntryId\";N;s:24:\"\0*\0sBreadCrumbEntryLabel\";N;s:30:\"\0*\0sBreadCrumbEntryDescription\";N;s:22:\"\0*\0sBreadCrumbEntryUrl\";N;s:23:\"\0*\0sBreadCrumbEntryIcon\";N;s:7:\"\0*\0oCtx\";O:10:\"ContextTag\":0:{}s:15:\"m_aReadyScripts\";a:3:{i:0;s:1728:\"	//add new widget called TruncatedList to properly display truncated lists when they are sorted\n	$.tablesorter.addWidget({ \n		// give the widget a id \n		id: \"truncatedList\", \n		// format is called when the on init and when a sorting has finished \n		format: function(table)\n		{ \n			// Check if there is a \"truncated\" line\n			this.truncatedList = false;  \n			if ($(\"tr td.truncated\",table).length > 0)\n			{\n				this.truncatedList = true;\n			}\n			if (this.truncatedList)\n			{\n				$(\"tr td\",table).removeClass(\'truncated\');\n				$(\"tr:last td\",table).addClass(\'truncated\');\n			}\n		} \n	});\n	\n	$.tablesorter.addWidget({ \n		// give the widget a id \n		id: \"myZebra\", \n		// format is called when the on init and when a sorting has finished \n		format: function(table)\n		{\n			// Replace the \'red even\' lines by \'red_even\' since most browser do not support 2 classes selector in CSS, etc..\n			$(\"tbody tr:even\",table).addClass(\'even\');\n			$(\"tbody tr.red:even\",table).removeClass(\'red\').removeClass(\'even\').addClass(\'red_even\');\n			$(\"tbody tr.orange:even\",table).removeClass(\'orange\').removeClass(\'even\').addClass(\'orange_even\');\n			$(\"tbody tr.green:even\",table).removeClass(\'green\').removeClass(\'even\').addClass(\'green_even\');\n			// In case we sort again the table, we need to remove the added \'even\' classes on odd rows\n			$(\"tbody tr:odd\",table).removeClass(\'even\');\n			$(\"tbody tr.red_even:odd\",table).removeClass(\'even\').removeClass(\'red_even\').addClass(\'red\');\n			$(\"tbody tr.orange_even:odd\",table).removeClass(\'even\').removeClass(\'orange_even\').addClass(\'orange\');\n			$(\"tbody tr.green_even:odd\",table).removeClass(\'even\').removeClass(\'green_even\').addClass(\'green\');\n		} \n	});\n	$(\"table.listResults\").tableHover(); // hover tables\";i:1;s:5505:\"	\n	// Adjust initial size\n	$(\'.v-resizable\').each( function()\n		{\n			var parent_id = $(this).parent().id;\n			// Restore the saved height\n			var iHeight = GetUserPreference(parent_id+\'_\'+this.id+\'_height\', undefined);\n			if (iHeight != undefined)\n			{\n				$(this).height(parseInt(iHeight, 10)); // Parse in base 10 !);\n			}\n			// Adjust the child \'item\'\'s height and width to fit\n			var container = $(this);\n			var fixedWidth = container.parent().innerWidth() - 6;\n			// Set the width to fit the parent\n			$(this).width(fixedWidth);\n			var headerHeight = $(this).find(\'.drag_handle\').height();\n			// Now adjust the width and height of the child \'item\'\n			container.find(\'.item\').height(container.innerHeight() - headerHeight - 12).width(fixedWidth - 10);\n		}\n	);\n	// Make resizable, vertically only everything that claims to be v-resizable !\n	$(\'.v-resizable\').resizable( { handles: \'s\', minHeight: $(this).find(\'.drag_handle\').height(), minWidth: $(this).parent().innerWidth() - 6, maxWidth: $(this).parent().innerWidth() - 6, stop: function()\n		{\n			// Adjust the content\n			var container = $(this);\n			var headerHeight = $(this).find(\'.drag_handle\').height();\n			container.find(\'.item\').height(container.innerHeight() - headerHeight - 12);//.width(container.innerWidth());\n			var parent_id = $(this).parent().id;\n			SetUserPreference(parent_id+\'_\'+this.id+\'_height\', $(this).height(), true); // true => persistent\n		}\n	} );\n		\n	// Tabs, using JQuery BBQ to store the history\n	// The \"tab widgets\" to handle.\n	var tabs = $(\'div[id^=tabbedContent]\');\n		\n	// This selector will be reused when selecting actual tab widget A elements.\n	var tab_a_selector = \'ul.ui-tabs-nav a\';\n	  \n	// Define our own click handler for the tabs, overriding the default.\n	tabs.find( tab_a_selector ).click(function()\n	{\n		var state = {};\n				  \n		// Get the id of this tab widget.\n		var id = $(this).closest( \'div[id^=tabbedContent]\' ).attr( \'id\' );\n		  \n		// Get the index of this tab.\n		var idx = $(this).parent().prevAll().length;\n		\n		// Set the state!\n		state[ id ] = idx;\n		$.bbq.pushState( state );\n	});\n	\n	// refresh the hash when the tab is changed (from a JS script)\n	$(\'body\').on( \'tabsactivate\', \'.ui-tabs\', function(event, ui) {\n		var state = {};\n			\n		// Get the id of this tab widget.\n		var id = $(ui.newTab).closest( \'div[id^=tabbedContent]\' ).attr( \'id\' );\n		\n		// Get the index of this tab.\n		var idx = $(ui.newTab).prevAll().length;\n			\n		// Set the state!\n		state[ id ] = idx;\n		$.bbq.pushState( state );\n	});\n	\n	// Bind an event to window.onhashchange that, when the history state changes,\n	// iterates over all tab widgets, changing the current tab as necessary.\n	$(window).bind( \'hashchange\', function(e)\n	{\n		// Iterate over all tab widgets.\n		tabs.each(function()\n		{  \n			// Get the index for this tab widget from the hash, based on the\n			// appropriate id property. In jQuery 1.4, you should use e.getState()\n			// instead of $.bbq.getState(). The second, \'true\' argument coerces the\n			// string value to a number.\n			var idx = $.bbq.getState( this.id, true ) || 0;\n			  \n			// Select the appropriate tab for this tab widget by triggering the custom\n			// event specified in the .tabs() init above (you could keep track of what\n			// tab each widget is on using .data, and only select a tab if it has\n			// changed).\n			$(this).find( tab_a_selector ).eq( idx ).triggerHandler( \'change\' );\n		});\n\n		// Iterate over all truncated lists to find whether they are expanded or not\n		$(\'a.truncated\').each(function()\n		{\n			var state = $.bbq.getState( this.id, true ) || \'close\';\n			if (state == \'open\')\n			{\n				$(this).trigger(\'open\');\n			}\n			else\n			{\n				$(this).trigger(\'close\');	\n			}\n		});\n	});\n	\n	// Shortcut menu actions\n	$(\'.actions_button a\').click( function() {\n		aMatches = /#(.*)$/.exec(window.location.href);\n		if (aMatches != null)\n		{\n			currentHash = aMatches[1];\n			if ( /#(.*)$/.test(this.href))\n			{\n				this.href = this.href.replace(/#(.*)$/, \'#\'+currentHash);\n			}\n		}\n	});\n\n	// End of Tabs handling\n\n	PrepareWidgets();\n\n	// Make sortable, everything that claims to be sortable\n	$(\'.sortable\').sortable( {axis: \'y\', cursor: \'move\', handle: \'.drag_handle\', stop: function()\n		{\n			if ($(this).hasClass(\'persistent\'))\n			{\n				// remember the sort order for next time the page is loaded...\n				sSerialized = $(this).sortable(\'serialize\', {key: \'menu\'});\n				var sTemp = sSerialized.replace(/menu=/g, \'\');\n				SetUserPreference(this.id+\'_order\', sTemp.replace(/&/g, \',\'), true); // true => persistent !\n			}\n		}\n	});\n	docWidth = $(document).width();\n	$(\'#ModalDlg\').dialog({ autoOpen: false, modal: true, width: 0.8*docWidth }); // JQuery UI dialogs\n	ShowDebug();\n	$(\'#logOffBtn>ul\').popupmenu();\n	\n	$(\'.caselog_header\').click( function () { $(this).toggleClass(\'open\').next(\'.caselog_entry,.caselog_entry_html\').toggle(); });\n	\n	$(document).ajaxSend(function(event, jqxhr, options) {\n		jqxhr.setRequestHeader(\'X-Combodo-Ajax\', \'true\');\n	});\n	$(document).ajaxError(function(event, jqxhr, options) {\n		if (jqxhr.status == 401)\n		{\n			$(\'<div>\'+\"You are disconnected. You must identify yourself to continue using the application.\"+\'</div>\').dialog({\n				modal:true,\n				title: \"Warning!\",\n				close: function() { $(this).remove(); },\n				minWidth: 400,\n				buttons: [\n					{ text: \"Login again\", click: function() { window.location.href= GetAbsoluteUrlAppRoot()+\'pages/UI.php\' } },\n					{ text: \"Stay on this page\", click: function() { $(this).dialog(\'close\'); } }\n				]\n			});\n		}\n	});\";i:2;s:285:\"$(\'img[data-img-id]\').each(function() {\n	if ($(this).width() > 250)\n	{\n		$(this).css({\'max-width\': \'250px\', width: \'\', height: \'\', \'max-height\': \'\'});\n	}\n	$(this).addClass(\'inline-image\').attr(\'href\', $(this).attr(\'src\'));\n}).magnificPopup({type: \'image\', closeOnContentClick: true });\";}s:10:\"m_sRootUrl\";s:23:\"https://alltic.co/itsm/\";s:10:\"\0*\0s_title\";s:32:\"iTop - Creación de Solicitudes \";s:12:\"\0*\0s_content\";s:195:\"<h1><img src=\"https://alltic.co/itsm/env-production/itop-request-mgmt-itil/images/user-request.png\" style=\"vertical-align:middle;\"/>&nbsp;Creación de Solicitudes</h1>\n<div class=\"wizContainer\">\n\";s:21:\"\0*\0s_deferred_content\";s:0:\"\";s:12:\"\0*\0a_scripts\";a:4:{i:0;s:860:\"function GetAbsoluteUrlAppRoot()\n{\n	return \'https://alltic.co/itsm/\';\n}\n\nfunction GetAbsoluteUrlModulesRoot()\n{\n	return \'https://alltic.co/itsm/env-production/\';\n}\n\nfunction GetAbsoluteUrlModulePage(sModule, sPage, aArguments)\n{\n	// aArguments is optional, it default to an empty hash\n	aArguments = typeof aArguments !== \'undefined\' ? aArguments : {};\n\n	var sUrl = \'https://alltic.co/itsm/\'+\'pages/exec.php?exec_module=\'+sModule+\'&exec_page=\'+sPage+\'&exec_env=\'+\'production\';\n	for (var sArgName in aArguments)\n	{\n		if (aArguments.hasOwnProperty(sArgName))\n		{\n			sUrl = sUrl + \'&\'+sArgName+\'=\'+aArguments[sArgname];\n		}\n	}\n	return sUrl;\n}\n\nfunction AddAppContext(sURL)\n{\n	var sContext = \'c[menu]=NewUserRequest\';\n	if (sContext.length > 0)\n	{\n		if (sURL.indexOf(\'?\') == -1)\n		{\n			return sURL+\'?\'+sContext;\n		}				\n		return sURL+\'&\'+sContext;\n	}\n	return sURL;\n}\";i:1;s:1971:\"	function PrepareWidgets()\n	{\n		// note: each action implemented here must be idempotent,\n		//       because this helper function might be called several times on a given page \n	\n		$(\".date-pick\").datepicker({\"showOn\":\"button\",\"buttonImage\":\"..\\/images\\/calendar.png\",\"buttonImageOnly\":true,\"dateFormat\":\"yy-mm-dd\",\"constrainInput\":false,\"changeMonth\":true,\"changeYear\":true,\"dayNamesMin\":[\"Su\",\"Mo\",\"Tu\",\"We\",\"Th\",\"Fr\",\"Sa\"],\"monthNamesShort\":[\"Jan\",\"Feb\",\"Mar\",\"Apr\",\"May\",\"Jun\",\"Jul\",\"Aug\",\"Sep\",\"Oct\",\"Nov\",\"Dec\"],\"firstDay\":0});\n	\n		// Hack for the date and time picker addon issue on Chrome (see #1305)\n		// The workaround is to instantiate the widget on demand\n		// It relies on the same markup, thus reverting to the original implementation should be straightforward\n		$(\".datetime-pick:not(.is-widget-ready)\").each(function(){\n			var oInput = this;\n			$(oInput).addClass(\'is-widget-ready\');\n			$(\'<img class=\"datetime-pick-button\" src=\"../images/calendar.png\">\')\n				.insertAfter($(this))\n				.on(\'click\', function(){\n					$(oInput)\n						.datetimepicker({\"showOn\":\"\",\"buttonImage\":null,\"buttonImageOnly\":true,\"dateFormat\":\"yy-mm-dd\",\"constrainInput\":false,\"changeMonth\":true,\"changeYear\":true,\"dayNamesMin\":[\"Su\",\"Mo\",\"Tu\",\"We\",\"Th\",\"Fr\",\"Sa\"],\"monthNamesShort\":[\"Jan\",\"Feb\",\"Mar\",\"Apr\",\"May\",\"Jun\",\"Jul\",\"Aug\",\"Sep\",\"Oct\",\"Nov\",\"Dec\"],\"firstDay\":0,\"timeFormat\":\"HH:mm:ss\",\"controlType\":\"select\",\"closeText\":\"Ok\",\n				\'timeText\': $.timepicker.regional[\"es\"].timeText,\n				\'hourText\': $.timepicker.regional[\"es\"].hourText,\n				\'minuteText\': $.timepicker.regional[\"es\"].minuteText,\n				\'secondText\': $.timepicker.regional[\"es\"].secondText,\n				\'currentText\': $.timepicker.regional[\"es\"].currentText\n			})\n						.datetimepicker(\'show\')\n						.datetimepicker(\'option\', \'onClose\', function(dateText,inst){\n							$(oInput).datetimepicker(\'destroy\');\n						})\n						.on(\'click keypress\', function(){\n							$(oInput).datetimepicker(\'hide\');\n						});\n				});\n		});\n	}\";i:2;s:1734:\"//		// for JQuery history\n//		function history_callback(hash)\n//		{\n//			// do stuff that loads page content based on hash variable\n//			var aMatches = /^tab_(.*)$/.exec(hash);\n//			if (aMatches != null)\n//			{\n//				var tab = $(\'#\'+hash);\n//				tab.parents(\'div[id^=tabbedContent]:first\').tabs(\'select\', aMatches[1]);\n//			}\n//		}\n\n		function goBack()\n		{\n			window.history.back();\n		}\n		\n		function BackToDetails(sClass, id, sDefaultUrl, sOwnershipToken)\n		{\n			window.bInCancel = true;\n			if (id > 0)\n			{\n				sToken = \'\';\n				if (sOwnershipToken != undefined)\n				{\n					sToken = \'&token=\'+sOwnershipToken;\n				}\n				window.location.href = AddAppContext(GetAbsoluteUrlAppRoot()+\'pages/UI.php?operation=release_lock_and_details&class=\'+sClass+\'&id=\'+id+sToken);\n			}\n			else\n			{\n				window.location.href = sDefaultUrl; // Already contains the context...				\n			}\n		}\n\n		function BackToList(sClass)\n		{\n			window.location.href = AddAppContext(GetAbsoluteUrlAppRoot()+\'pages/UI.php?operation=search_oql&oql_class=\'+sClass+\'&oql_clause=WHERE id=0\');\n		}\n		\n		function ShowDebug()\n		{\n			if ($(\'#rawOutput > div\').html() != \'\')\n			{\n				$(\'#rawOutput\').dialog( {autoOpen: true, modal:false, width: \'80%\'});\n			}\n		}\n		\n		var oUserPreferences = {\"welcome_popup\":\"0\",\"menu_pane\":\"open\",\"menu_size\":\"421\"};\n\n		// For disabling the CKEditor at init time when the corresponding textarea is disabled !\n		CKEDITOR.plugins.add( \'disabler\',\n		{\n			init : function( editor )\n			{\n				editor.on( \'instanceReady\', function(e)\n				{\n					e.removeListener();\n					$(\'#\'+ editor.name).trigger(\'update\');\n				});\n			}\n			\n		});\n\n		\n		function FixPaneVis()\n		{\n			$(\'.ui-layout-center, .ui-layout-north, .ui-layout-south\').css({display: \'block\'});\n		}\";i:3;s:172:\"function ShowAboutBox()\n{\n	$.post(GetAbsoluteUrlAppRoot()+\'pages/ajax.render.php\', {operation: \'about_box\'}, function(data){\n		$(\'body\').append(data);\n	});\n	return false;\n}\";}s:17:\"\0*\0a_dict_entries\";a:3:{s:25:\"UI:FillAllMandatoryFields\";s:41:\"Por favor llenar los campos obligatorios.\";s:16:\"UI:Button:Cancel\";s:8:\"Cancelar\";s:14:\"UI:Button:Done\";s:5:\"Listo\";}s:11:\"\0*\0a_styles\";a:0:{}s:20:\"\0*\0a_include_scripts\";N;s:24:\"\0*\0a_include_stylesheets\";N;s:12:\"\0*\0a_headers\";a:2:{i:0;s:38:\"Content-type: text/html; charset=utf-8\";i:1;s:23:\"Cache-control: no-cache\";}s:9:\"\0*\0a_base\";a:2:{s:4:\"href\";s:0:\"\";s:6:\"target\";s:0:\"\";}s:10:\"\0*\0iNextId\";i:0;s:17:\"\0*\0iTransactionId\";i:0;s:15:\"\0*\0sContentType\";s:0:\"\";s:22:\"\0*\0sContentDisposition\";s:0:\"\";s:19:\"\0*\0sContentFileName\";s:0:\"\";s:25:\"\0*\0bTrashUnexpectedOutput\";b:0;s:18:\"\0*\0s_sOutputFormat\";N;s:18:\"\0*\0a_OutputOptions\";a:0:{}s:13:\"\0*\0bPrintable\";b:0;s:16:\"a_linked_scripts\";a:43:{s:46:\"https://alltic.co/itsm/js/jquery-1.10.0.min.js\";s:46:\"https://alltic.co/itsm/js/jquery-1.10.0.min.js\";s:53:\"https://alltic.co/itsm/js/jquery-migrate-1.2.1.min.js\";s:53:\"https://alltic.co/itsm/js/jquery-migrate-1.2.1.min.js\";s:56:\"https://alltic.co/itsm/js/jquery-ui-1.10.3.custom.min.js\";s:56:\"https://alltic.co/itsm/js/jquery-ui-1.10.3.custom.min.js\";s:37:\"https://alltic.co/itsm/js/hovertip.js\";s:37:\"https://alltic.co/itsm/js/hovertip.js\";s:47:\"https://alltic.co/itsm/js/jquery.tablesorter.js\";s:47:\"https://alltic.co/itsm/js/jquery.tablesorter.js\";s:53:\"https://alltic.co/itsm/js/jquery.tablesorter.pager.js\";s:53:\"https://alltic.co/itsm/js/jquery.tablesorter.pager.js\";s:46:\"https://alltic.co/itsm/js/jquery.tablehover.js\";s:46:\"https://alltic.co/itsm/js/jquery.tablehover.js\";s:41:\"https://alltic.co/itsm/js/field_sorter.js\";s:41:\"https://alltic.co/itsm/js/field_sorter.js\";s:38:\"https://alltic.co/itsm/js/datatable.js\";s:38:\"https://alltic.co/itsm/js/datatable.js\";s:46:\"https://alltic.co/itsm/js/jquery.positionBy.js\";s:46:\"https://alltic.co/itsm/js/jquery.positionBy.js\";s:45:\"https://alltic.co/itsm/js/jquery.popupmenu.js\";s:45:\"https://alltic.co/itsm/js/jquery.popupmenu.js\";s:26:\"../js/jquery.layout.min.js\";s:26:\"../js/jquery.layout.min.js\";s:26:\"../js/jquery.ba-bbq.min.js\";s:26:\"../js/jquery.ba-bbq.min.js\";s:24:\"../js/jquery.treeview.js\";s:24:\"../js/jquery.treeview.js\";s:28:\"../js/jquery.autocomplete.js\";s:28:\"../js/jquery.autocomplete.js\";s:13:\"../js/date.js\";s:13:\"../js/date.js\";s:35:\"../js/jquery-ui-timepicker-addon.js\";s:35:\"../js/jquery-ui-timepicker-addon.js\";s:44:\"../js/jquery-ui-timepicker-addon-i18n.min.js\";s:44:\"../js/jquery-ui-timepicker-addon-i18n.min.js\";s:23:\"../js/jquery.blockUI.js\";s:23:\"../js/jquery.blockUI.js\";s:14:\"../js/utils.js\";s:14:\"../js/utils.js\";s:18:\"../js/swfobject.js\";s:18:\"../js/swfobject.js\";s:26:\"../js/ckeditor/ckeditor.js\";s:26:\"../js/ckeditor/ckeditor.js\";s:33:\"../js/ckeditor/adapters/jquery.js\";s:33:\"../js/ckeditor/adapters/jquery.js\";s:28:\"../js/jquery.qtip-1.0.min.js\";s:28:\"../js/jquery.qtip-1.0.min.js\";s:23:\"../js/property_field.js\";s:23:\"../js/property_field.js\";s:16:\"../js/fg.menu.js\";s:16:\"../js/fg.menu.js\";s:20:\"../js/icon_select.js\";s:20:\"../js/icon_select.js\";s:20:\"../js/raphael-min.js\";s:20:\"../js/raphael-min.js\";s:11:\"../js/d3.js\";s:11:\"../js/d3.js\";s:11:\"../js/c3.js\";s:11:\"../js/c3.js\";s:27:\"../js/jquery.multiselect.js\";s:27:\"../js/jquery.multiselect.js\";s:23:\"../js/ajaxfileupload.js\";s:23:\"../js/ajaxfileupload.js\";s:26:\"../js/jquery.mousewheel.js\";s:26:\"../js/jquery.mousewheel.js\";s:34:\"../js/jquery.magnific-popup.min.js\";s:34:\"../js/jquery.magnific-popup.min.js\";s:19:\"../js/breadcrumb.js\";s:19:\"../js/breadcrumb.js\";s:19:\"../js/moment.min.js\";s:19:\"../js/moment.min.js\";s:13:\"../js/json.js\";s:13:\"../js/json.js\";s:25:\"../js/forms-json-utils.js\";s:25:\"../js/forms-json-utils.js\";s:21:\"../js/wizardhelper.js\";s:21:\"../js/wizardhelper.js\";s:21:\"../js/wizard.utils.js\";s:21:\"../js/wizard.utils.js\";s:20:\"../js/linkswidget.js\";s:20:\"../js/linkswidget.js\";s:26:\"../js/linksdirectwidget.js\";s:26:\"../js/linksdirectwidget.js\";s:21:\"../js/extkeywidget.js\";s:21:\"../js/extkeywidget.js\";}s:20:\"a_linked_stylesheets\";a:9:{i:0;a:2:{s:4:\"link\";s:71:\"https://alltic.co/itsm/css/ui-lightness/jquery-ui-1.10.3.custom.min.css\";s:9:\"condition\";s:0:\"\";}i:1;a:2:{s:4:\"link\";s:41:\"https://alltic.co/itsm/css/light-grey.css\";s:9:\"condition\";s:0:\"\";}i:2;a:2:{s:4:\"link\";s:26:\"../css/jquery.treeview.css\";s:9:\"condition\";s:0:\"\";}i:3;a:2:{s:4:\"link\";s:30:\"../css/jquery.autocomplete.css\";s:9:\"condition\";s:0:\"\";}i:4;a:2:{s:4:\"link\";s:37:\"../css/jquery-ui-timepicker-addon.css\";s:9:\"condition\";s:0:\"\";}i:5;a:2:{s:4:\"link\";s:18:\"../css/fg.menu.css\";s:9:\"condition\";s:0:\"\";}i:6;a:2:{s:4:\"link\";s:29:\"../css/jquery.multiselect.css\";s:9:\"condition\";s:0:\"\";}i:7;a:2:{s:4:\"link\";s:25:\"../css/magnific-popup.css\";s:9:\"condition\";s:0:\"\";}i:8;a:2:{s:4:\"link\";s:17:\"../css/c3.min.css\";s:9:\"condition\";s:0:\"\";}}s:14:\"s_OutputFormat\";s:4:\"html\";}i:1;s:11:\"UserRequest\";i:2;O:11:\"UserRequest\":22:{s:12:\"\0*\0m_iFormId\";N;s:13:\"\0*\0aFieldsMap\";N;s:14:\"\0*\0bAllowWrite\";b:0;s:15:\"\0*\0m_datCreated\";N;s:15:\"\0*\0m_datUpdated\";N;s:19:\"\0DBObject\0m_bIsInDB\";b:0;s:16:\"\0DBObject\0m_iKey\";i:-1;s:23:\"\0DBObject\0m_aCurrValues\";a:79:{s:18:\"operational_status\";s:7:\"ongoing\";s:3:\"ref\";s:0:\"\";s:6:\"org_id\";i:0;s:8:\"org_name\";s:0:\"\";s:9:\"caller_id\";i:0;s:11:\"caller_name\";s:0:\"\";s:7:\"team_id\";i:0;s:9:\"team_name\";s:0:\"\";s:8:\"agent_id\";i:0;s:10:\"agent_name\";s:0:\"\";s:5:\"title\";s:0:\"\";s:11:\"description\";s:0:\"\";s:10:\"start_date\";N;s:8:\"end_date\";N;s:11:\"last_update\";N;s:10:\"close_date\";N;s:11:\"private_log\";O:10:\"ormCaseLog\":3:{s:9:\"\0*\0m_sLog\";s:0:\"\";s:11:\"\0*\0m_aIndex\";a:0:{}s:14:\"\0*\0m_bModified\";b:0;}s:13:\"contacts_list\";O:11:\"DBObjectSet\":14:{s:14:\"\0*\0m_aAddedIds\";a:0:{}s:18:\"\0*\0m_aAddedObjects\";a:0:{}s:10:\"\0*\0m_aArgs\";a:0:{}s:15:\"\0*\0m_aAttToLoad\";N;s:13:\"\0*\0m_aOrderBy\";a:0:{}s:9:\"m_bLoaded\";b:1;s:20:\"\0*\0m_iNumTotalDBRows\";i:0;s:21:\"\0*\0m_iNumLoadedDBRows\";i:0;s:13:\"\0*\0m_iCurrRow\";i:0;s:12:\"\0*\0m_oFilter\";O:14:\"DBObjectSearch\":11:{s:26:\"\0DBObjectSearch\0m_aClasses\";a:1:{s:18:\"lnkContactToTicket\";s:18:\"lnkContactToTicket\";}s:34:\"\0DBObjectSearch\0m_aSelectedClasses\";a:1:{s:18:\"lnkContactToTicket\";s:18:\"lnkContactToTicket\";}s:34:\"\0DBObjectSearch\0m_oSearchCondition\";O:15:\"FalseExpression\":1:{s:10:\"\0*\0m_value\";i:0;}s:25:\"\0DBObjectSearch\0m_aParams\";a:0:{}s:27:\"\0DBObjectSearch\0m_aFullText\";a:0:{}s:29:\"\0DBObjectSearch\0m_aPointingTo\";a:0:{}s:31:\"\0DBObjectSearch\0m_aReferencedBy\";a:0:{}s:18:\"\0*\0m_bAllowAllData\";b:0;s:18:\"\0*\0m_bDataFiltered\";b:0;s:25:\"\0*\0m_bNoContextParameters\";b:0;s:24:\"\0*\0m_aModifierProperties\";a:0:{}}s:15:\"\0*\0m_oSQLResult\";N;s:19:\"m_aExtendedDataSpec\";N;s:13:\"m_iLimitCount\";i:0;s:13:\"m_iLimitStart\";i:0;}s:18:\"functionalcis_list\";O:11:\"DBObjectSet\":14:{s:14:\"\0*\0m_aAddedIds\";a:0:{}s:18:\"\0*\0m_aAddedObjects\";a:0:{}s:10:\"\0*\0m_aArgs\";a:0:{}s:15:\"\0*\0m_aAttToLoad\";N;s:13:\"\0*\0m_aOrderBy\";a:0:{}s:9:\"m_bLoaded\";b:1;s:20:\"\0*\0m_iNumTotalDBRows\";i:0;s:21:\"\0*\0m_iNumLoadedDBRows\";i:0;s:13:\"\0*\0m_iCurrRow\";i:0;s:12:\"\0*\0m_oFilter\";O:14:\"DBObjectSearch\":11:{s:26:\"\0DBObjectSearch\0m_aClasses\";a:1:{s:23:\"lnkFunctionalCIToTicket\";s:23:\"lnkFunctionalCIToTicket\";}s:34:\"\0DBObjectSearch\0m_aSelectedClasses\";a:1:{s:23:\"lnkFunctionalCIToTicket\";s:23:\"lnkFunctionalCIToTicket\";}s:34:\"\0DBObjectSearch\0m_oSearchCondition\";O:15:\"FalseExpression\":1:{s:10:\"\0*\0m_value\";i:0;}s:25:\"\0DBObjectSearch\0m_aParams\";a:0:{}s:27:\"\0DBObjectSearch\0m_aFullText\";a:0:{}s:29:\"\0DBObjectSearch\0m_aPointingTo\";a:0:{}s:31:\"\0DBObjectSearch\0m_aReferencedBy\";a:0:{}s:18:\"\0*\0m_bAllowAllData\";b:0;s:18:\"\0*\0m_bDataFiltered\";b:0;s:25:\"\0*\0m_bNoContextParameters\";b:0;s:24:\"\0*\0m_aModifierProperties\";a:0:{}}s:15:\"\0*\0m_oSQLResult\";N;s:19:\"m_aExtendedDataSpec\";N;s:13:\"m_iLimitCount\";i:0;s:13:\"m_iLimitStart\";i:0;}s:15:\"workorders_list\";O:11:\"DBObjectSet\":14:{s:14:\"\0*\0m_aAddedIds\";a:0:{}s:18:\"\0*\0m_aAddedObjects\";a:0:{}s:10:\"\0*\0m_aArgs\";a:0:{}s:15:\"\0*\0m_aAttToLoad\";N;s:13:\"\0*\0m_aOrderBy\";a:0:{}s:9:\"m_bLoaded\";b:1;s:20:\"\0*\0m_iNumTotalDBRows\";i:0;s:21:\"\0*\0m_iNumLoadedDBRows\";i:0;s:13:\"\0*\0m_iCurrRow\";i:0;s:12:\"\0*\0m_oFilter\";O:14:\"DBObjectSearch\":11:{s:26:\"\0DBObjectSearch\0m_aClasses\";a:1:{s:9:\"WorkOrder\";s:9:\"WorkOrder\";}s:34:\"\0DBObjectSearch\0m_aSelectedClasses\";a:1:{s:9:\"WorkOrder\";s:9:\"WorkOrder\";}s:34:\"\0DBObjectSearch\0m_oSearchCondition\";O:15:\"FalseExpression\":1:{s:10:\"\0*\0m_value\";i:0;}s:25:\"\0DBObjectSearch\0m_aParams\";a:0:{}s:27:\"\0DBObjectSearch\0m_aFullText\";a:0:{}s:29:\"\0DBObjectSearch\0m_aPointingTo\";a:0:{}s:31:\"\0DBObjectSearch\0m_aReferencedBy\";a:0:{}s:18:\"\0*\0m_bAllowAllData\";b:0;s:18:\"\0*\0m_bDataFiltered\";b:0;s:25:\"\0*\0m_bNoContextParameters\";b:0;s:24:\"\0*\0m_aModifierProperties\";a:0:{}}s:15:\"\0*\0m_oSQLResult\";N;s:19:\"m_aExtendedDataSpec\";N;s:13:\"m_iLimitCount\";i:0;s:13:\"m_iLimitStart\";i:0;}s:6:\"status\";s:3:\"new\";s:12:\"request_type\";s:15:\"service_request\";s:6:\"impact\";s:1:\"2\";s:8:\"priority\";s:1:\"4\";s:7:\"urgency\";s:1:\"4\";s:6:\"origin\";s:5:\"phone\";s:11:\"approver_id\";i:0;s:14:\"approver_email\";s:0:\"\";s:16:\"servicefamily_id\";i:0;s:18:\"servicefamily_name\";s:0:\"\";s:10:\"service_id\";i:0;s:12:\"service_name\";s:0:\"\";s:21:\"servicesubcategory_id\";i:0;s:23:\"servicesubcategory_name\";s:0:\"\";s:15:\"escalation_flag\";s:2:\"no\";s:17:\"escalation_reason\";s:0:\"\";s:15:\"assignment_date\";N;s:15:\"resolution_date\";N;s:17:\"last_pending_date\";N;s:16:\"cumulatedpending\";O:12:\"ormStopWatch\":5:{s:13:\"\0*\0iTimeSpent\";i:0;s:11:\"\0*\0iStarted\";N;s:13:\"\0*\0iLastStart\";N;s:11:\"\0*\0iStopped\";N;s:14:\"\0*\0aThresholds\";a:0:{}}s:3:\"tto\";O:12:\"ormStopWatch\":5:{s:13:\"\0*\0iTimeSpent\";i:0;s:11:\"\0*\0iStarted\";N;s:13:\"\0*\0iLastStart\";N;s:11:\"\0*\0iStopped\";N;s:14:\"\0*\0aThresholds\";a:2:{i:75;a:4:{s:8:\"deadline\";N;s:9:\"triggered\";b:0;s:7:\"overrun\";N;s:9:\"highlight\";N;}i:100;a:4:{s:8:\"deadline\";N;s:9:\"triggered\";b:0;s:7:\"overrun\";N;s:9:\"highlight\";N;}}}s:3:\"ttr\";O:12:\"ormStopWatch\":5:{s:13:\"\0*\0iTimeSpent\";i:0;s:11:\"\0*\0iStarted\";N;s:13:\"\0*\0iLastStart\";N;s:11:\"\0*\0iStopped\";N;s:14:\"\0*\0aThresholds\";a:2:{i:75;a:4:{s:8:\"deadline\";N;s:9:\"triggered\";b:0;s:7:\"overrun\";N;s:9:\"highlight\";N;}i:100;a:4:{s:8:\"deadline\";N;s:9:\"triggered\";b:0;s:7:\"overrun\";N;s:9:\"highlight\";N;}}}s:23:\"tto_escalation_deadline\";N;s:14:\"sla_tto_passed\";N;s:12:\"sla_tto_over\";N;s:23:\"ttr_escalation_deadline\";N;s:14:\"sla_ttr_passed\";N;s:12:\"sla_ttr_over\";N;s:10:\"time_spent\";N;s:15:\"resolution_code\";N;s:8:\"solution\";s:0:\"\";s:14:\"pending_reason\";s:0:\"\";s:17:\"parent_request_id\";i:0;s:18:\"parent_request_ref\";s:0:\"\";s:18:\"parent_incident_id\";i:0;s:19:\"parent_incident_ref\";s:0:\"\";s:17:\"parent_problem_id\";i:0;s:18:\"parent_problem_ref\";s:0:\"\";s:16:\"parent_change_id\";i:0;s:17:\"parent_change_ref\";s:0:\"\";s:20:\"related_request_list\";O:11:\"DBObjectSet\":14:{s:14:\"\0*\0m_aAddedIds\";a:0:{}s:18:\"\0*\0m_aAddedObjects\";a:0:{}s:10:\"\0*\0m_aArgs\";a:0:{}s:15:\"\0*\0m_aAttToLoad\";N;s:13:\"\0*\0m_aOrderBy\";a:0:{}s:9:\"m_bLoaded\";b:1;s:20:\"\0*\0m_iNumTotalDBRows\";i:0;s:21:\"\0*\0m_iNumLoadedDBRows\";i:0;s:13:\"\0*\0m_iCurrRow\";i:0;s:12:\"\0*\0m_oFilter\";O:14:\"DBObjectSearch\":11:{s:26:\"\0DBObjectSearch\0m_aClasses\";a:1:{s:11:\"UserRequest\";s:11:\"UserRequest\";}s:34:\"\0DBObjectSearch\0m_aSelectedClasses\";a:1:{s:11:\"UserRequest\";s:11:\"UserRequest\";}s:34:\"\0DBObjectSearch\0m_oSearchCondition\";O:15:\"FalseExpression\":1:{s:10:\"\0*\0m_value\";i:0;}s:25:\"\0DBObjectSearch\0m_aParams\";a:0:{}s:27:\"\0DBObjectSearch\0m_aFullText\";a:0:{}s:29:\"\0DBObjectSearch\0m_aPointingTo\";a:0:{}s:31:\"\0DBObjectSearch\0m_aReferencedBy\";a:0:{}s:18:\"\0*\0m_bAllowAllData\";b:0;s:18:\"\0*\0m_bDataFiltered\";b:0;s:25:\"\0*\0m_bNoContextParameters\";b:0;s:24:\"\0*\0m_aModifierProperties\";a:0:{}}s:15:\"\0*\0m_oSQLResult\";N;s:19:\"m_aExtendedDataSpec\";N;s:13:\"m_iLimitCount\";i:0;s:13:\"m_iLimitStart\";i:0;}s:10:\"public_log\";O:10:\"ormCaseLog\":3:{s:9:\"\0*\0m_sLog\";s:0:\"\";s:11:\"\0*\0m_aIndex\";a:0:{}s:14:\"\0*\0m_bModified\";b:0;}s:17:\"user_satisfaction\";s:1:\"1\";s:12:\"user_comment\";s:0:\"\";s:10:\"finalclass\";s:11:\"UserRequest\";s:12:\"friendlyname\";s:0:\"\";s:19:\"org_id_friendlyname\";s:0:\"\";s:22:\"caller_id_friendlyname\";s:0:\"\";s:20:\"team_id_friendlyname\";s:0:\"\";s:21:\"agent_id_friendlyname\";s:0:\"\";s:24:\"approver_id_friendlyname\";s:0:\"\";s:29:\"servicefamily_id_friendlyname\";s:0:\"\";s:23:\"service_id_friendlyname\";s:0:\"\";s:34:\"servicesubcategory_id_friendlyname\";s:0:\"\";s:30:\"parent_request_id_friendlyname\";s:0:\"\";s:31:\"parent_incident_id_friendlyname\";s:0:\"\";s:30:\"parent_problem_id_friendlyname\";s:0:\"\";s:29:\"parent_change_id_friendlyname\";s:0:\"\";s:34:\"parent_change_id_finalclass_recall\";s:6:\"Change\";}s:16:\"\0*\0m_aOrigValues\";a:79:{s:18:\"operational_status\";N;s:3:\"ref\";N;s:6:\"org_id\";N;s:8:\"org_name\";N;s:9:\"caller_id\";N;s:11:\"caller_name\";N;s:7:\"team_id\";N;s:9:\"team_name\";N;s:8:\"agent_id\";N;s:10:\"agent_name\";N;s:5:\"title\";N;s:11:\"description\";N;s:10:\"start_date\";N;s:8:\"end_date\";N;s:11:\"last_update\";N;s:10:\"close_date\";N;s:11:\"private_log\";N;s:13:\"contacts_list\";N;s:18:\"functionalcis_list\";N;s:15:\"workorders_list\";N;s:6:\"status\";N;s:12:\"request_type\";N;s:6:\"impact\";N;s:8:\"priority\";N;s:7:\"urgency\";N;s:6:\"origin\";N;s:11:\"approver_id\";N;s:14:\"approver_email\";N;s:16:\"servicefamily_id\";N;s:18:\"servicefamily_name\";N;s:10:\"service_id\";N;s:12:\"service_name\";N;s:21:\"servicesubcategory_id\";N;s:23:\"servicesubcategory_name\";N;s:15:\"escalation_flag\";N;s:17:\"escalation_reason\";N;s:15:\"assignment_date\";N;s:15:\"resolution_date\";N;s:17:\"last_pending_date\";N;s:16:\"cumulatedpending\";N;s:3:\"tto\";N;s:3:\"ttr\";N;s:23:\"tto_escalation_deadline\";N;s:14:\"sla_tto_passed\";N;s:12:\"sla_tto_over\";N;s:23:\"ttr_escalation_deadline\";N;s:14:\"sla_ttr_passed\";N;s:12:\"sla_ttr_over\";N;s:10:\"time_spent\";N;s:15:\"resolution_code\";N;s:8:\"solution\";N;s:14:\"pending_reason\";N;s:17:\"parent_request_id\";N;s:18:\"parent_request_ref\";N;s:18:\"parent_incident_id\";N;s:19:\"parent_incident_ref\";N;s:17:\"parent_problem_id\";N;s:18:\"parent_problem_ref\";N;s:16:\"parent_change_id\";N;s:17:\"parent_change_ref\";N;s:20:\"related_request_list\";N;s:10:\"public_log\";N;s:17:\"user_satisfaction\";N;s:12:\"user_comment\";N;s:10:\"finalclass\";N;s:12:\"friendlyname\";N;s:19:\"org_id_friendlyname\";N;s:22:\"caller_id_friendlyname\";N;s:20:\"team_id_friendlyname\";N;s:21:\"agent_id_friendlyname\";N;s:24:\"approver_id_friendlyname\";N;s:29:\"servicefamily_id_friendlyname\";N;s:23:\"service_id_friendlyname\";N;s:34:\"servicesubcategory_id_friendlyname\";N;s:30:\"parent_request_id_friendlyname\";N;s:31:\"parent_incident_id_friendlyname\";N;s:30:\"parent_problem_id_friendlyname\";N;s:29:\"parent_change_id_friendlyname\";N;s:34:\"parent_change_id_finalclass_recall\";N;}s:18:\"\0*\0m_aExtendedData\";N;s:18:\"\0DBObject\0m_bDirty\";b:0;s:24:\"\0DBObject\0m_bCheckStatus\";N;s:19:\"\0*\0m_bSecurityIssue\";N;s:17:\"\0*\0m_aCheckIssues\";N;s:18:\"\0*\0m_aDeleteIssues\";N;s:24:\"\0DBObject\0m_bFullyLoaded\";b:0;s:22:\"\0DBObject\0m_aLoadedAtt\";a:53:{s:18:\"operational_status\";b:1;s:3:\"ref\";b:1;s:6:\"org_id\";b:1;s:9:\"caller_id\";b:1;s:7:\"team_id\";b:1;s:8:\"agent_id\";b:1;s:5:\"title\";b:1;s:11:\"description\";b:1;s:10:\"start_date\";b:1;s:8:\"end_date\";b:1;s:11:\"last_update\";b:1;s:10:\"close_date\";b:1;s:11:\"private_log\";b:1;s:13:\"contacts_list\";b:1;s:18:\"functionalcis_list\";b:1;s:15:\"workorders_list\";b:1;s:6:\"status\";b:1;s:12:\"request_type\";b:1;s:6:\"impact\";b:1;s:8:\"priority\";b:1;s:7:\"urgency\";b:1;s:6:\"origin\";b:1;s:11:\"approver_id\";b:1;s:16:\"servicefamily_id\";b:1;s:10:\"service_id\";b:1;s:21:\"servicesubcategory_id\";b:1;s:15:\"escalation_flag\";b:1;s:17:\"escalation_reason\";b:1;s:15:\"assignment_date\";b:1;s:15:\"resolution_date\";b:1;s:17:\"last_pending_date\";b:1;s:16:\"cumulatedpending\";b:1;s:3:\"tto\";b:1;s:3:\"ttr\";b:1;s:23:\"tto_escalation_deadline\";b:1;s:14:\"sla_tto_passed\";b:1;s:12:\"sla_tto_over\";b:1;s:23:\"ttr_escalation_deadline\";b:1;s:14:\"sla_ttr_passed\";b:1;s:12:\"sla_ttr_over\";b:1;s:10:\"time_spent\";b:1;s:15:\"resolution_code\";b:1;s:8:\"solution\";b:1;s:14:\"pending_reason\";b:1;s:17:\"parent_request_id\";b:1;s:18:\"parent_incident_id\";b:1;s:17:\"parent_problem_id\";b:1;s:16:\"parent_change_id\";b:1;s:20:\"related_request_list\";b:1;s:10:\"public_log\";b:1;s:17:\"user_satisfaction\";b:1;s:12:\"user_comment\";b:1;s:10:\"finalclass\";b:1;}s:16:\"\0*\0m_aTouchedAtt\";a:0:{}s:17:\"\0*\0m_aModifiedAtt\";a:0:{}s:17:\"\0*\0m_aSynchroData\";N;s:19:\"\0*\0m_sHighlightCode\";N;s:15:\"\0*\0m_aCallbacks\";a:0:{}}i:3;a:0:{}}}}','a:0:{}'),(4,'PHP Exception','Page could not be displayed','/itsm/pages/UI.php','a:0:{}','a:3:{s:9:\"operation\";s:3:\"new\";s:5:\"class\";s:8:\"Incident\";s:1:\"c\";a:1:{s:4:\"menu\";s:11:\"NewIncident\";}}','a:3:{i:0;a:6:{s:4:\"file\";s:54:\"/home/alltic/public_html/itsm/core/metamodel.class.php\";s:4:\"line\";i:481;s:8:\"function\";s:15:\"GetAttributeDef\";s:5:\"class\";s:9:\"MetaModel\";s:4:\"type\";s:2:\"::\";s:4:\"args\";a:2:{i:0;s:8:\"Incident\";i:1;s:11:\"pais_ticket\";}}i:1;a:6:{s:4:\"file\";s:68:\"/home/alltic/public_html/itsm/application/cmdbabstract.class.inc.php\";s:4:\"line\";i:2389;s:8:\"function\";s:25:\"GetPrerequisiteAttributes\";s:5:\"class\";s:9:\"MetaModel\";s:4:\"type\";s:2:\"::\";s:4:\"args\";a:2:{i:0;s:8:\"Incident\";i:1;s:11:\"pais_ticket\";}}i:2;a:6:{s:4:\"file\";s:42:\"/home/alltic/public_html/itsm/pages/UI.php\";s:4:\"line\";i:758;s:8:\"function\";s:19:\"DisplayCreationForm\";s:5:\"class\";s:18:\"cmdbAbstractObject\";s:4:\"type\";s:2:\"::\";s:4:\"args\";a:4:{i:0;O:11:\"iTopWebPage\":35:{s:20:\"\0iTopWebPage\0m_sMenu\";s:0:\"\";s:23:\"\0iTopWebPage\0m_sMessage\";s:0:\"\";s:26:\"\0iTopWebPage\0m_sInitScript\";s:3833:\"	try\n	{\n		var myLayout; // a var is required because this page utilizes: myLayout.allowOverflow() method\n	\n		// Layout\n		paneSize = GetUserPreference(\'menu_size\', 300)\n		myLayout = $(\'body\').layout({\n			west :	{\n						 minSize: 200, size: paneSize, spacing_open: 16, spacing_close: 16, slideTrigger_open: \"click\", hideTogglerOnSlide: true, enableCursorHotkey: false,\n						onclose_end: function(name, elt, state, options, layout)\n						{\n								if (state.isSliding == false)\n								{\n									$(\'.menu-pane-exclusive\').show();\n									SetUserPreference(\'menu_pane\', \'closed\', true);\n								}\n						},\n						onresize_end: function(name, elt, state, options, layout)\n						{\n								if (state.isSliding == false)\n								{\n									SetUserPreference(\'menu_size\', state.size, true);\n								}\n						},\n									\n						onopen_end: function(name, elt, state, options, layout)\n						{\n							if (state.isSliding == false)\n							{\n								$(\'.menu-pane-exclusive\').hide();\n								SetUserPreference(\'menu_pane\', \'open\', true);\n							}\n						}\n					},\n			center: {\n						onresize_end: function(name, elt, state, options, layout)\n						{\n								$(\'.v-resizable\').each( function() {\n									var fixedWidth = $(this).parent().innerWidth() - 6;\n									$(this).width(fixedWidth);\n									// Make sure it cannot be resized horizontally\n									$(this).resizable(\'options\', { minWidth: fixedWidth, maxWidth:	fixedWidth });\n									// Now adjust all the child \'items\'\n									var innerWidth = $(this).innerWidth() - 10;\n									$(this).find(\'.item\').width(innerWidth);\n								});\n								$(\'.panel-resized\').trigger(\'resized\');\n						}\n				\n					}\n		});\n		window.clearTimeout(iPaneVisWatchDog);\n		//myLayout.open( \"west\" );\n		$(\'.ui-layout-resizer-west .ui-layout-toggler\').css({background: \'transparent\'});\n						myLayout.addPinBtn( \"#tPinMenu\", \"west\" );\n		\n		$(\'#left-pane\').layout({ resizable: false, spacing_open: 0, south: { size: 94 }, enableCursorHotkey: false });\n		\n		// Tabs, using JQuery BBQ to store the history\n		// The \"tab widgets\" to handle.\n		var tabs = $(\'div[id^=tabbedContent]\');\n			\n		// This selector will be reused when selecting actual tab widget A elements.\n		var tab_a_selector = \'ul.ui-tabs-nav a\';\n		  \n		// Ugly patch for a change in the behavior of jQuery UI:\n		// Before jQuery UI 1.9, tabs were always considered as \"local\" (opposed to Ajax)\n		// when their href was beginning by #. Starting with 1.9, a <base> tag in the page\n		// is taken into account and causes \"local\" tabs to be considered as Ajax\n		// unless their URL is equal to the URL of the page...\n		$(\'div[id^=tabbedContent] > ul > li > a\').each(function() {\n			var sHash = location.hash;\n			var sHref = $(this).attr(\"href\");\n			if (sHref.match(/^#/))\n			{\n				var sCleanLocation = location.href.toString().replace(sHash, \'\').replace(/#$/, \'\');\n				$(this).attr(\"href\", sCleanLocation+$(this).attr(\"href\"));\n			}\n		});\n\n		// Enable tabs on all tab widgets. The `event` property must be overridden so\n		// that the tabs aren\'t changed on click, and any custom event name can be\n		// specified. Note that if you define a callback for the \'select\' event, it\n		// will be executed for the selected tab whenever the hash changes.\n		tabs.tabs({\n			event: \'change\', \'show\': function(event, ui) {\n				$(\'.resizable\', ui.panel).resizable(); // Make resizable everything that claims to be resizable !\n			},\n			beforeLoad: function( event, ui ) {\n				if ( ui.tab.data(\'loaded\') && (ui.tab.attr(\'data-cache\') == \'true\')) {\n					event.preventDefault();\n					return;\n				}\n				ui.panel.html(\'<div><img src=\"../images/indicator.gif\"></div>\');\n				ui.jqXHR.success(function() {\n					ui.tab.data( \"loaded\", true );\n				});\n			}\n		});\n\n		$(\'.resizable\').filter(\':visible\').resizable();\n	}\n	catch(err)\n	{\n		// Do something with the error !\n		alert(err);\n	}\";s:10:\"\0*\0m_oTabs\";O:10:\"TabManager\":3:{s:10:\"\0*\0m_aTabs\";a:0:{}s:25:\"\0*\0m_sCurrentTabContainer\";s:0:\"\";s:16:\"\0*\0m_sCurrentTab\";s:0:\"\";}s:21:\"\0*\0bBreadCrumbEnabled\";b:0;s:21:\"\0*\0sBreadCrumbEntryId\";N;s:24:\"\0*\0sBreadCrumbEntryLabel\";N;s:30:\"\0*\0sBreadCrumbEntryDescription\";N;s:22:\"\0*\0sBreadCrumbEntryUrl\";N;s:23:\"\0*\0sBreadCrumbEntryIcon\";N;s:7:\"\0*\0oCtx\";O:10:\"ContextTag\":0:{}s:15:\"m_aReadyScripts\";a:3:{i:0;s:1728:\"	//add new widget called TruncatedList to properly display truncated lists when they are sorted\n	$.tablesorter.addWidget({ \n		// give the widget a id \n		id: \"truncatedList\", \n		// format is called when the on init and when a sorting has finished \n		format: function(table)\n		{ \n			// Check if there is a \"truncated\" line\n			this.truncatedList = false;  \n			if ($(\"tr td.truncated\",table).length > 0)\n			{\n				this.truncatedList = true;\n			}\n			if (this.truncatedList)\n			{\n				$(\"tr td\",table).removeClass(\'truncated\');\n				$(\"tr:last td\",table).addClass(\'truncated\');\n			}\n		} \n	});\n	\n	$.tablesorter.addWidget({ \n		// give the widget a id \n		id: \"myZebra\", \n		// format is called when the on init and when a sorting has finished \n		format: function(table)\n		{\n			// Replace the \'red even\' lines by \'red_even\' since most browser do not support 2 classes selector in CSS, etc..\n			$(\"tbody tr:even\",table).addClass(\'even\');\n			$(\"tbody tr.red:even\",table).removeClass(\'red\').removeClass(\'even\').addClass(\'red_even\');\n			$(\"tbody tr.orange:even\",table).removeClass(\'orange\').removeClass(\'even\').addClass(\'orange_even\');\n			$(\"tbody tr.green:even\",table).removeClass(\'green\').removeClass(\'even\').addClass(\'green_even\');\n			// In case we sort again the table, we need to remove the added \'even\' classes on odd rows\n			$(\"tbody tr:odd\",table).removeClass(\'even\');\n			$(\"tbody tr.red_even:odd\",table).removeClass(\'even\').removeClass(\'red_even\').addClass(\'red\');\n			$(\"tbody tr.orange_even:odd\",table).removeClass(\'even\').removeClass(\'orange_even\').addClass(\'orange\');\n			$(\"tbody tr.green_even:odd\",table).removeClass(\'even\').removeClass(\'green_even\').addClass(\'green\');\n		} \n	});\n	$(\"table.listResults\").tableHover(); // hover tables\";i:1;s:5505:\"	\n	// Adjust initial size\n	$(\'.v-resizable\').each( function()\n		{\n			var parent_id = $(this).parent().id;\n			// Restore the saved height\n			var iHeight = GetUserPreference(parent_id+\'_\'+this.id+\'_height\', undefined);\n			if (iHeight != undefined)\n			{\n				$(this).height(parseInt(iHeight, 10)); // Parse in base 10 !);\n			}\n			// Adjust the child \'item\'\'s height and width to fit\n			var container = $(this);\n			var fixedWidth = container.parent().innerWidth() - 6;\n			// Set the width to fit the parent\n			$(this).width(fixedWidth);\n			var headerHeight = $(this).find(\'.drag_handle\').height();\n			// Now adjust the width and height of the child \'item\'\n			container.find(\'.item\').height(container.innerHeight() - headerHeight - 12).width(fixedWidth - 10);\n		}\n	);\n	// Make resizable, vertically only everything that claims to be v-resizable !\n	$(\'.v-resizable\').resizable( { handles: \'s\', minHeight: $(this).find(\'.drag_handle\').height(), minWidth: $(this).parent().innerWidth() - 6, maxWidth: $(this).parent().innerWidth() - 6, stop: function()\n		{\n			// Adjust the content\n			var container = $(this);\n			var headerHeight = $(this).find(\'.drag_handle\').height();\n			container.find(\'.item\').height(container.innerHeight() - headerHeight - 12);//.width(container.innerWidth());\n			var parent_id = $(this).parent().id;\n			SetUserPreference(parent_id+\'_\'+this.id+\'_height\', $(this).height(), true); // true => persistent\n		}\n	} );\n		\n	// Tabs, using JQuery BBQ to store the history\n	// The \"tab widgets\" to handle.\n	var tabs = $(\'div[id^=tabbedContent]\');\n		\n	// This selector will be reused when selecting actual tab widget A elements.\n	var tab_a_selector = \'ul.ui-tabs-nav a\';\n	  \n	// Define our own click handler for the tabs, overriding the default.\n	tabs.find( tab_a_selector ).click(function()\n	{\n		var state = {};\n				  \n		// Get the id of this tab widget.\n		var id = $(this).closest( \'div[id^=tabbedContent]\' ).attr( \'id\' );\n		  \n		// Get the index of this tab.\n		var idx = $(this).parent().prevAll().length;\n		\n		// Set the state!\n		state[ id ] = idx;\n		$.bbq.pushState( state );\n	});\n	\n	// refresh the hash when the tab is changed (from a JS script)\n	$(\'body\').on( \'tabsactivate\', \'.ui-tabs\', function(event, ui) {\n		var state = {};\n			\n		// Get the id of this tab widget.\n		var id = $(ui.newTab).closest( \'div[id^=tabbedContent]\' ).attr( \'id\' );\n		\n		// Get the index of this tab.\n		var idx = $(ui.newTab).prevAll().length;\n			\n		// Set the state!\n		state[ id ] = idx;\n		$.bbq.pushState( state );\n	});\n	\n	// Bind an event to window.onhashchange that, when the history state changes,\n	// iterates over all tab widgets, changing the current tab as necessary.\n	$(window).bind( \'hashchange\', function(e)\n	{\n		// Iterate over all tab widgets.\n		tabs.each(function()\n		{  \n			// Get the index for this tab widget from the hash, based on the\n			// appropriate id property. In jQuery 1.4, you should use e.getState()\n			// instead of $.bbq.getState(). The second, \'true\' argument coerces the\n			// string value to a number.\n			var idx = $.bbq.getState( this.id, true ) || 0;\n			  \n			// Select the appropriate tab for this tab widget by triggering the custom\n			// event specified in the .tabs() init above (you could keep track of what\n			// tab each widget is on using .data, and only select a tab if it has\n			// changed).\n			$(this).find( tab_a_selector ).eq( idx ).triggerHandler( \'change\' );\n		});\n\n		// Iterate over all truncated lists to find whether they are expanded or not\n		$(\'a.truncated\').each(function()\n		{\n			var state = $.bbq.getState( this.id, true ) || \'close\';\n			if (state == \'open\')\n			{\n				$(this).trigger(\'open\');\n			}\n			else\n			{\n				$(this).trigger(\'close\');	\n			}\n		});\n	});\n	\n	// Shortcut menu actions\n	$(\'.actions_button a\').click( function() {\n		aMatches = /#(.*)$/.exec(window.location.href);\n		if (aMatches != null)\n		{\n			currentHash = aMatches[1];\n			if ( /#(.*)$/.test(this.href))\n			{\n				this.href = this.href.replace(/#(.*)$/, \'#\'+currentHash);\n			}\n		}\n	});\n\n	// End of Tabs handling\n\n	PrepareWidgets();\n\n	// Make sortable, everything that claims to be sortable\n	$(\'.sortable\').sortable( {axis: \'y\', cursor: \'move\', handle: \'.drag_handle\', stop: function()\n		{\n			if ($(this).hasClass(\'persistent\'))\n			{\n				// remember the sort order for next time the page is loaded...\n				sSerialized = $(this).sortable(\'serialize\', {key: \'menu\'});\n				var sTemp = sSerialized.replace(/menu=/g, \'\');\n				SetUserPreference(this.id+\'_order\', sTemp.replace(/&/g, \',\'), true); // true => persistent !\n			}\n		}\n	});\n	docWidth = $(document).width();\n	$(\'#ModalDlg\').dialog({ autoOpen: false, modal: true, width: 0.8*docWidth }); // JQuery UI dialogs\n	ShowDebug();\n	$(\'#logOffBtn>ul\').popupmenu();\n	\n	$(\'.caselog_header\').click( function () { $(this).toggleClass(\'open\').next(\'.caselog_entry,.caselog_entry_html\').toggle(); });\n	\n	$(document).ajaxSend(function(event, jqxhr, options) {\n		jqxhr.setRequestHeader(\'X-Combodo-Ajax\', \'true\');\n	});\n	$(document).ajaxError(function(event, jqxhr, options) {\n		if (jqxhr.status == 401)\n		{\n			$(\'<div>\'+\"You are disconnected. You must identify yourself to continue using the application.\"+\'</div>\').dialog({\n				modal:true,\n				title: \"Warning!\",\n				close: function() { $(this).remove(); },\n				minWidth: 400,\n				buttons: [\n					{ text: \"Login again\", click: function() { window.location.href= GetAbsoluteUrlAppRoot()+\'pages/UI.php\' } },\n					{ text: \"Stay on this page\", click: function() { $(this).dialog(\'close\'); } }\n				]\n			});\n		}\n	});\";i:2;s:285:\"$(\'img[data-img-id]\').each(function() {\n	if ($(this).width() > 250)\n	{\n		$(this).css({\'max-width\': \'250px\', width: \'\', height: \'\', \'max-height\': \'\'});\n	}\n	$(this).addClass(\'inline-image\').attr(\'href\', $(this).attr(\'src\'));\n}).magnificPopup({type: \'image\', closeOnContentClick: true });\";}s:10:\"m_sRootUrl\";s:23:\"https://alltic.co/itsm/\";s:10:\"\0*\0s_title\";s:30:\"iTop - Creación de Incidente \";s:12:\"\0*\0s_content\";s:190:\"<h1><img src=\"https://alltic.co/itsm/env-production/itop-incident-mgmt-itil/images/incident.png\" style=\"vertical-align:middle;\"/>&nbsp;Creación de Incidente</h1>\n<div class=\"wizContainer\">\n\";s:21:\"\0*\0s_deferred_content\";s:0:\"\";s:12:\"\0*\0a_scripts\";a:4:{i:0;s:857:\"function GetAbsoluteUrlAppRoot()\n{\n	return \'https://alltic.co/itsm/\';\n}\n\nfunction GetAbsoluteUrlModulesRoot()\n{\n	return \'https://alltic.co/itsm/env-production/\';\n}\n\nfunction GetAbsoluteUrlModulePage(sModule, sPage, aArguments)\n{\n	// aArguments is optional, it default to an empty hash\n	aArguments = typeof aArguments !== \'undefined\' ? aArguments : {};\n\n	var sUrl = \'https://alltic.co/itsm/\'+\'pages/exec.php?exec_module=\'+sModule+\'&exec_page=\'+sPage+\'&exec_env=\'+\'production\';\n	for (var sArgName in aArguments)\n	{\n		if (aArguments.hasOwnProperty(sArgName))\n		{\n			sUrl = sUrl + \'&\'+sArgName+\'=\'+aArguments[sArgname];\n		}\n	}\n	return sUrl;\n}\n\nfunction AddAppContext(sURL)\n{\n	var sContext = \'c[menu]=NewIncident\';\n	if (sContext.length > 0)\n	{\n		if (sURL.indexOf(\'?\') == -1)\n		{\n			return sURL+\'?\'+sContext;\n		}				\n		return sURL+\'&\'+sContext;\n	}\n	return sURL;\n}\";i:1;s:1971:\"	function PrepareWidgets()\n	{\n		// note: each action implemented here must be idempotent,\n		//       because this helper function might be called several times on a given page \n	\n		$(\".date-pick\").datepicker({\"showOn\":\"button\",\"buttonImage\":\"..\\/images\\/calendar.png\",\"buttonImageOnly\":true,\"dateFormat\":\"yy-mm-dd\",\"constrainInput\":false,\"changeMonth\":true,\"changeYear\":true,\"dayNamesMin\":[\"Su\",\"Mo\",\"Tu\",\"We\",\"Th\",\"Fr\",\"Sa\"],\"monthNamesShort\":[\"Jan\",\"Feb\",\"Mar\",\"Apr\",\"May\",\"Jun\",\"Jul\",\"Aug\",\"Sep\",\"Oct\",\"Nov\",\"Dec\"],\"firstDay\":0});\n	\n		// Hack for the date and time picker addon issue on Chrome (see #1305)\n		// The workaround is to instantiate the widget on demand\n		// It relies on the same markup, thus reverting to the original implementation should be straightforward\n		$(\".datetime-pick:not(.is-widget-ready)\").each(function(){\n			var oInput = this;\n			$(oInput).addClass(\'is-widget-ready\');\n			$(\'<img class=\"datetime-pick-button\" src=\"../images/calendar.png\">\')\n				.insertAfter($(this))\n				.on(\'click\', function(){\n					$(oInput)\n						.datetimepicker({\"showOn\":\"\",\"buttonImage\":null,\"buttonImageOnly\":true,\"dateFormat\":\"yy-mm-dd\",\"constrainInput\":false,\"changeMonth\":true,\"changeYear\":true,\"dayNamesMin\":[\"Su\",\"Mo\",\"Tu\",\"We\",\"Th\",\"Fr\",\"Sa\"],\"monthNamesShort\":[\"Jan\",\"Feb\",\"Mar\",\"Apr\",\"May\",\"Jun\",\"Jul\",\"Aug\",\"Sep\",\"Oct\",\"Nov\",\"Dec\"],\"firstDay\":0,\"timeFormat\":\"HH:mm:ss\",\"controlType\":\"select\",\"closeText\":\"Ok\",\n				\'timeText\': $.timepicker.regional[\"es\"].timeText,\n				\'hourText\': $.timepicker.regional[\"es\"].hourText,\n				\'minuteText\': $.timepicker.regional[\"es\"].minuteText,\n				\'secondText\': $.timepicker.regional[\"es\"].secondText,\n				\'currentText\': $.timepicker.regional[\"es\"].currentText\n			})\n						.datetimepicker(\'show\')\n						.datetimepicker(\'option\', \'onClose\', function(dateText,inst){\n							$(oInput).datetimepicker(\'destroy\');\n						})\n						.on(\'click keypress\', function(){\n							$(oInput).datetimepicker(\'hide\');\n						});\n				});\n		});\n	}\";i:2;s:1734:\"//		// for JQuery history\n//		function history_callback(hash)\n//		{\n//			// do stuff that loads page content based on hash variable\n//			var aMatches = /^tab_(.*)$/.exec(hash);\n//			if (aMatches != null)\n//			{\n//				var tab = $(\'#\'+hash);\n//				tab.parents(\'div[id^=tabbedContent]:first\').tabs(\'select\', aMatches[1]);\n//			}\n//		}\n\n		function goBack()\n		{\n			window.history.back();\n		}\n		\n		function BackToDetails(sClass, id, sDefaultUrl, sOwnershipToken)\n		{\n			window.bInCancel = true;\n			if (id > 0)\n			{\n				sToken = \'\';\n				if (sOwnershipToken != undefined)\n				{\n					sToken = \'&token=\'+sOwnershipToken;\n				}\n				window.location.href = AddAppContext(GetAbsoluteUrlAppRoot()+\'pages/UI.php?operation=release_lock_and_details&class=\'+sClass+\'&id=\'+id+sToken);\n			}\n			else\n			{\n				window.location.href = sDefaultUrl; // Already contains the context...				\n			}\n		}\n\n		function BackToList(sClass)\n		{\n			window.location.href = AddAppContext(GetAbsoluteUrlAppRoot()+\'pages/UI.php?operation=search_oql&oql_class=\'+sClass+\'&oql_clause=WHERE id=0\');\n		}\n		\n		function ShowDebug()\n		{\n			if ($(\'#rawOutput > div\').html() != \'\')\n			{\n				$(\'#rawOutput\').dialog( {autoOpen: true, modal:false, width: \'80%\'});\n			}\n		}\n		\n		var oUserPreferences = {\"welcome_popup\":\"0\",\"menu_pane\":\"open\",\"menu_size\":\"421\"};\n\n		// For disabling the CKEditor at init time when the corresponding textarea is disabled !\n		CKEDITOR.plugins.add( \'disabler\',\n		{\n			init : function( editor )\n			{\n				editor.on( \'instanceReady\', function(e)\n				{\n					e.removeListener();\n					$(\'#\'+ editor.name).trigger(\'update\');\n				});\n			}\n			\n		});\n\n		\n		function FixPaneVis()\n		{\n			$(\'.ui-layout-center, .ui-layout-north, .ui-layout-south\').css({display: \'block\'});\n		}\";i:3;s:172:\"function ShowAboutBox()\n{\n	$.post(GetAbsoluteUrlAppRoot()+\'pages/ajax.render.php\', {operation: \'about_box\'}, function(data){\n		$(\'body\').append(data);\n	});\n	return false;\n}\";}s:17:\"\0*\0a_dict_entries\";a:3:{s:25:\"UI:FillAllMandatoryFields\";s:41:\"Por favor llenar los campos obligatorios.\";s:16:\"UI:Button:Cancel\";s:8:\"Cancelar\";s:14:\"UI:Button:Done\";s:5:\"Listo\";}s:11:\"\0*\0a_styles\";a:0:{}s:20:\"\0*\0a_include_scripts\";N;s:24:\"\0*\0a_include_stylesheets\";N;s:12:\"\0*\0a_headers\";a:2:{i:0;s:38:\"Content-type: text/html; charset=utf-8\";i:1;s:23:\"Cache-control: no-cache\";}s:9:\"\0*\0a_base\";a:2:{s:4:\"href\";s:0:\"\";s:6:\"target\";s:0:\"\";}s:10:\"\0*\0iNextId\";i:0;s:17:\"\0*\0iTransactionId\";i:0;s:15:\"\0*\0sContentType\";s:0:\"\";s:22:\"\0*\0sContentDisposition\";s:0:\"\";s:19:\"\0*\0sContentFileName\";s:0:\"\";s:25:\"\0*\0bTrashUnexpectedOutput\";b:0;s:18:\"\0*\0s_sOutputFormat\";N;s:18:\"\0*\0a_OutputOptions\";a:0:{}s:13:\"\0*\0bPrintable\";b:0;s:16:\"a_linked_scripts\";a:43:{s:46:\"https://alltic.co/itsm/js/jquery-1.10.0.min.js\";s:46:\"https://alltic.co/itsm/js/jquery-1.10.0.min.js\";s:53:\"https://alltic.co/itsm/js/jquery-migrate-1.2.1.min.js\";s:53:\"https://alltic.co/itsm/js/jquery-migrate-1.2.1.min.js\";s:56:\"https://alltic.co/itsm/js/jquery-ui-1.10.3.custom.min.js\";s:56:\"https://alltic.co/itsm/js/jquery-ui-1.10.3.custom.min.js\";s:37:\"https://alltic.co/itsm/js/hovertip.js\";s:37:\"https://alltic.co/itsm/js/hovertip.js\";s:47:\"https://alltic.co/itsm/js/jquery.tablesorter.js\";s:47:\"https://alltic.co/itsm/js/jquery.tablesorter.js\";s:53:\"https://alltic.co/itsm/js/jquery.tablesorter.pager.js\";s:53:\"https://alltic.co/itsm/js/jquery.tablesorter.pager.js\";s:46:\"https://alltic.co/itsm/js/jquery.tablehover.js\";s:46:\"https://alltic.co/itsm/js/jquery.tablehover.js\";s:41:\"https://alltic.co/itsm/js/field_sorter.js\";s:41:\"https://alltic.co/itsm/js/field_sorter.js\";s:38:\"https://alltic.co/itsm/js/datatable.js\";s:38:\"https://alltic.co/itsm/js/datatable.js\";s:46:\"https://alltic.co/itsm/js/jquery.positionBy.js\";s:46:\"https://alltic.co/itsm/js/jquery.positionBy.js\";s:45:\"https://alltic.co/itsm/js/jquery.popupmenu.js\";s:45:\"https://alltic.co/itsm/js/jquery.popupmenu.js\";s:26:\"../js/jquery.layout.min.js\";s:26:\"../js/jquery.layout.min.js\";s:26:\"../js/jquery.ba-bbq.min.js\";s:26:\"../js/jquery.ba-bbq.min.js\";s:24:\"../js/jquery.treeview.js\";s:24:\"../js/jquery.treeview.js\";s:28:\"../js/jquery.autocomplete.js\";s:28:\"../js/jquery.autocomplete.js\";s:13:\"../js/date.js\";s:13:\"../js/date.js\";s:35:\"../js/jquery-ui-timepicker-addon.js\";s:35:\"../js/jquery-ui-timepicker-addon.js\";s:44:\"../js/jquery-ui-timepicker-addon-i18n.min.js\";s:44:\"../js/jquery-ui-timepicker-addon-i18n.min.js\";s:23:\"../js/jquery.blockUI.js\";s:23:\"../js/jquery.blockUI.js\";s:14:\"../js/utils.js\";s:14:\"../js/utils.js\";s:18:\"../js/swfobject.js\";s:18:\"../js/swfobject.js\";s:26:\"../js/ckeditor/ckeditor.js\";s:26:\"../js/ckeditor/ckeditor.js\";s:33:\"../js/ckeditor/adapters/jquery.js\";s:33:\"../js/ckeditor/adapters/jquery.js\";s:28:\"../js/jquery.qtip-1.0.min.js\";s:28:\"../js/jquery.qtip-1.0.min.js\";s:23:\"../js/property_field.js\";s:23:\"../js/property_field.js\";s:16:\"../js/fg.menu.js\";s:16:\"../js/fg.menu.js\";s:20:\"../js/icon_select.js\";s:20:\"../js/icon_select.js\";s:20:\"../js/raphael-min.js\";s:20:\"../js/raphael-min.js\";s:11:\"../js/d3.js\";s:11:\"../js/d3.js\";s:11:\"../js/c3.js\";s:11:\"../js/c3.js\";s:27:\"../js/jquery.multiselect.js\";s:27:\"../js/jquery.multiselect.js\";s:23:\"../js/ajaxfileupload.js\";s:23:\"../js/ajaxfileupload.js\";s:26:\"../js/jquery.mousewheel.js\";s:26:\"../js/jquery.mousewheel.js\";s:34:\"../js/jquery.magnific-popup.min.js\";s:34:\"../js/jquery.magnific-popup.min.js\";s:19:\"../js/breadcrumb.js\";s:19:\"../js/breadcrumb.js\";s:19:\"../js/moment.min.js\";s:19:\"../js/moment.min.js\";s:13:\"../js/json.js\";s:13:\"../js/json.js\";s:25:\"../js/forms-json-utils.js\";s:25:\"../js/forms-json-utils.js\";s:21:\"../js/wizardhelper.js\";s:21:\"../js/wizardhelper.js\";s:21:\"../js/wizard.utils.js\";s:21:\"../js/wizard.utils.js\";s:20:\"../js/linkswidget.js\";s:20:\"../js/linkswidget.js\";s:26:\"../js/linksdirectwidget.js\";s:26:\"../js/linksdirectwidget.js\";s:21:\"../js/extkeywidget.js\";s:21:\"../js/extkeywidget.js\";}s:20:\"a_linked_stylesheets\";a:9:{i:0;a:2:{s:4:\"link\";s:71:\"https://alltic.co/itsm/css/ui-lightness/jquery-ui-1.10.3.custom.min.css\";s:9:\"condition\";s:0:\"\";}i:1;a:2:{s:4:\"link\";s:41:\"https://alltic.co/itsm/css/light-grey.css\";s:9:\"condition\";s:0:\"\";}i:2;a:2:{s:4:\"link\";s:26:\"../css/jquery.treeview.css\";s:9:\"condition\";s:0:\"\";}i:3;a:2:{s:4:\"link\";s:30:\"../css/jquery.autocomplete.css\";s:9:\"condition\";s:0:\"\";}i:4;a:2:{s:4:\"link\";s:37:\"../css/jquery-ui-timepicker-addon.css\";s:9:\"condition\";s:0:\"\";}i:5;a:2:{s:4:\"link\";s:18:\"../css/fg.menu.css\";s:9:\"condition\";s:0:\"\";}i:6;a:2:{s:4:\"link\";s:29:\"../css/jquery.multiselect.css\";s:9:\"condition\";s:0:\"\";}i:7;a:2:{s:4:\"link\";s:25:\"../css/magnific-popup.css\";s:9:\"condition\";s:0:\"\";}i:8;a:2:{s:4:\"link\";s:17:\"../css/c3.min.css\";s:9:\"condition\";s:0:\"\";}}s:14:\"s_OutputFormat\";s:4:\"html\";}i:1;s:8:\"Incident\";i:2;O:8:\"Incident\":22:{s:12:\"\0*\0m_iFormId\";N;s:13:\"\0*\0aFieldsMap\";N;s:14:\"\0*\0bAllowWrite\";b:0;s:15:\"\0*\0m_datCreated\";N;s:15:\"\0*\0m_datUpdated\";N;s:19:\"\0DBObject\0m_bIsInDB\";b:0;s:16:\"\0DBObject\0m_iKey\";i:-1;s:23:\"\0DBObject\0m_aCurrValues\";a:70:{s:18:\"operational_status\";s:7:\"ongoing\";s:3:\"ref\";s:0:\"\";s:6:\"org_id\";i:0;s:8:\"org_name\";s:0:\"\";s:9:\"caller_id\";i:0;s:11:\"caller_name\";s:0:\"\";s:7:\"team_id\";i:0;s:9:\"team_name\";s:0:\"\";s:8:\"agent_id\";i:0;s:10:\"agent_name\";s:0:\"\";s:5:\"title\";s:0:\"\";s:11:\"description\";s:0:\"\";s:10:\"start_date\";N;s:8:\"end_date\";N;s:11:\"last_update\";N;s:10:\"close_date\";N;s:11:\"private_log\";O:10:\"ormCaseLog\":3:{s:9:\"\0*\0m_sLog\";s:0:\"\";s:11:\"\0*\0m_aIndex\";a:0:{}s:14:\"\0*\0m_bModified\";b:0;}s:13:\"contacts_list\";O:11:\"DBObjectSet\":14:{s:14:\"\0*\0m_aAddedIds\";a:0:{}s:18:\"\0*\0m_aAddedObjects\";a:0:{}s:10:\"\0*\0m_aArgs\";a:0:{}s:15:\"\0*\0m_aAttToLoad\";N;s:13:\"\0*\0m_aOrderBy\";a:0:{}s:9:\"m_bLoaded\";b:1;s:20:\"\0*\0m_iNumTotalDBRows\";i:0;s:21:\"\0*\0m_iNumLoadedDBRows\";i:0;s:13:\"\0*\0m_iCurrRow\";i:0;s:12:\"\0*\0m_oFilter\";O:14:\"DBObjectSearch\":11:{s:26:\"\0DBObjectSearch\0m_aClasses\";a:1:{s:18:\"lnkContactToTicket\";s:18:\"lnkContactToTicket\";}s:34:\"\0DBObjectSearch\0m_aSelectedClasses\";a:1:{s:18:\"lnkContactToTicket\";s:18:\"lnkContactToTicket\";}s:34:\"\0DBObjectSearch\0m_oSearchCondition\";O:15:\"FalseExpression\":1:{s:10:\"\0*\0m_value\";i:0;}s:25:\"\0DBObjectSearch\0m_aParams\";a:0:{}s:27:\"\0DBObjectSearch\0m_aFullText\";a:0:{}s:29:\"\0DBObjectSearch\0m_aPointingTo\";a:0:{}s:31:\"\0DBObjectSearch\0m_aReferencedBy\";a:0:{}s:18:\"\0*\0m_bAllowAllData\";b:0;s:18:\"\0*\0m_bDataFiltered\";b:0;s:25:\"\0*\0m_bNoContextParameters\";b:0;s:24:\"\0*\0m_aModifierProperties\";a:0:{}}s:15:\"\0*\0m_oSQLResult\";N;s:19:\"m_aExtendedDataSpec\";N;s:13:\"m_iLimitCount\";i:0;s:13:\"m_iLimitStart\";i:0;}s:18:\"functionalcis_list\";O:11:\"DBObjectSet\":14:{s:14:\"\0*\0m_aAddedIds\";a:0:{}s:18:\"\0*\0m_aAddedObjects\";a:0:{}s:10:\"\0*\0m_aArgs\";a:0:{}s:15:\"\0*\0m_aAttToLoad\";N;s:13:\"\0*\0m_aOrderBy\";a:0:{}s:9:\"m_bLoaded\";b:1;s:20:\"\0*\0m_iNumTotalDBRows\";i:0;s:21:\"\0*\0m_iNumLoadedDBRows\";i:0;s:13:\"\0*\0m_iCurrRow\";i:0;s:12:\"\0*\0m_oFilter\";O:14:\"DBObjectSearch\":11:{s:26:\"\0DBObjectSearch\0m_aClasses\";a:1:{s:23:\"lnkFunctionalCIToTicket\";s:23:\"lnkFunctionalCIToTicket\";}s:34:\"\0DBObjectSearch\0m_aSelectedClasses\";a:1:{s:23:\"lnkFunctionalCIToTicket\";s:23:\"lnkFunctionalCIToTicket\";}s:34:\"\0DBObjectSearch\0m_oSearchCondition\";O:15:\"FalseExpression\":1:{s:10:\"\0*\0m_value\";i:0;}s:25:\"\0DBObjectSearch\0m_aParams\";a:0:{}s:27:\"\0DBObjectSearch\0m_aFullText\";a:0:{}s:29:\"\0DBObjectSearch\0m_aPointingTo\";a:0:{}s:31:\"\0DBObjectSearch\0m_aReferencedBy\";a:0:{}s:18:\"\0*\0m_bAllowAllData\";b:0;s:18:\"\0*\0m_bDataFiltered\";b:0;s:25:\"\0*\0m_bNoContextParameters\";b:0;s:24:\"\0*\0m_aModifierProperties\";a:0:{}}s:15:\"\0*\0m_oSQLResult\";N;s:19:\"m_aExtendedDataSpec\";N;s:13:\"m_iLimitCount\";i:0;s:13:\"m_iLimitStart\";i:0;}s:15:\"workorders_list\";O:11:\"DBObjectSet\":14:{s:14:\"\0*\0m_aAddedIds\";a:0:{}s:18:\"\0*\0m_aAddedObjects\";a:0:{}s:10:\"\0*\0m_aArgs\";a:0:{}s:15:\"\0*\0m_aAttToLoad\";N;s:13:\"\0*\0m_aOrderBy\";a:0:{}s:9:\"m_bLoaded\";b:1;s:20:\"\0*\0m_iNumTotalDBRows\";i:0;s:21:\"\0*\0m_iNumLoadedDBRows\";i:0;s:13:\"\0*\0m_iCurrRow\";i:0;s:12:\"\0*\0m_oFilter\";O:14:\"DBObjectSearch\":11:{s:26:\"\0DBObjectSearch\0m_aClasses\";a:1:{s:9:\"WorkOrder\";s:9:\"WorkOrder\";}s:34:\"\0DBObjectSearch\0m_aSelectedClasses\";a:1:{s:9:\"WorkOrder\";s:9:\"WorkOrder\";}s:34:\"\0DBObjectSearch\0m_oSearchCondition\";O:15:\"FalseExpression\":1:{s:10:\"\0*\0m_value\";i:0;}s:25:\"\0DBObjectSearch\0m_aParams\";a:0:{}s:27:\"\0DBObjectSearch\0m_aFullText\";a:0:{}s:29:\"\0DBObjectSearch\0m_aPointingTo\";a:0:{}s:31:\"\0DBObjectSearch\0m_aReferencedBy\";a:0:{}s:18:\"\0*\0m_bAllowAllData\";b:0;s:18:\"\0*\0m_bDataFiltered\";b:0;s:25:\"\0*\0m_bNoContextParameters\";b:0;s:24:\"\0*\0m_aModifierProperties\";a:0:{}}s:15:\"\0*\0m_oSQLResult\";N;s:19:\"m_aExtendedDataSpec\";N;s:13:\"m_iLimitCount\";i:0;s:13:\"m_iLimitStart\";i:0;}s:6:\"status\";s:3:\"new\";s:6:\"impact\";s:1:\"2\";s:8:\"priority\";s:1:\"2\";s:7:\"urgency\";s:1:\"2\";s:6:\"origin\";s:5:\"phone\";s:10:\"service_id\";i:0;s:12:\"service_name\";s:0:\"\";s:21:\"servicesubcategory_id\";i:0;s:23:\"servicesubcategory_name\";s:0:\"\";s:15:\"escalation_flag\";s:2:\"no\";s:17:\"escalation_reason\";s:0:\"\";s:15:\"assignment_date\";N;s:15:\"resolution_date\";N;s:17:\"last_pending_date\";N;s:16:\"cumulatedpending\";O:12:\"ormStopWatch\":5:{s:13:\"\0*\0iTimeSpent\";i:0;s:11:\"\0*\0iStarted\";N;s:13:\"\0*\0iLastStart\";N;s:11:\"\0*\0iStopped\";N;s:14:\"\0*\0aThresholds\";a:0:{}}s:3:\"tto\";O:12:\"ormStopWatch\":5:{s:13:\"\0*\0iTimeSpent\";i:0;s:11:\"\0*\0iStarted\";N;s:13:\"\0*\0iLastStart\";N;s:11:\"\0*\0iStopped\";N;s:14:\"\0*\0aThresholds\";a:2:{i:75;a:4:{s:8:\"deadline\";N;s:9:\"triggered\";b:0;s:7:\"overrun\";N;s:9:\"highlight\";N;}i:100;a:4:{s:8:\"deadline\";N;s:9:\"triggered\";b:0;s:7:\"overrun\";N;s:9:\"highlight\";N;}}}s:3:\"ttr\";O:12:\"ormStopWatch\":5:{s:13:\"\0*\0iTimeSpent\";i:0;s:11:\"\0*\0iStarted\";N;s:13:\"\0*\0iLastStart\";N;s:11:\"\0*\0iStopped\";N;s:14:\"\0*\0aThresholds\";a:2:{i:75;a:4:{s:8:\"deadline\";N;s:9:\"triggered\";b:0;s:7:\"overrun\";N;s:9:\"highlight\";N;}i:100;a:4:{s:8:\"deadline\";N;s:9:\"triggered\";b:0;s:7:\"overrun\";N;s:9:\"highlight\";N;}}}s:23:\"tto_escalation_deadline\";N;s:14:\"sla_tto_passed\";N;s:12:\"sla_tto_over\";N;s:23:\"ttr_escalation_deadline\";N;s:14:\"sla_ttr_passed\";N;s:12:\"sla_ttr_over\";N;s:10:\"time_spent\";N;s:15:\"resolution_code\";N;s:8:\"solution\";s:0:\"\";s:14:\"pending_reason\";s:0:\"\";s:18:\"parent_incident_id\";i:0;s:19:\"parent_incident_ref\";s:0:\"\";s:17:\"parent_problem_id\";i:0;s:18:\"parent_problem_ref\";s:0:\"\";s:16:\"parent_change_id\";i:0;s:17:\"parent_change_ref\";s:0:\"\";s:20:\"related_request_list\";O:11:\"DBObjectSet\":14:{s:14:\"\0*\0m_aAddedIds\";a:0:{}s:18:\"\0*\0m_aAddedObjects\";a:0:{}s:10:\"\0*\0m_aArgs\";a:0:{}s:15:\"\0*\0m_aAttToLoad\";N;s:13:\"\0*\0m_aOrderBy\";a:0:{}s:9:\"m_bLoaded\";b:1;s:20:\"\0*\0m_iNumTotalDBRows\";i:0;s:21:\"\0*\0m_iNumLoadedDBRows\";i:0;s:13:\"\0*\0m_iCurrRow\";i:0;s:12:\"\0*\0m_oFilter\";O:14:\"DBObjectSearch\":11:{s:26:\"\0DBObjectSearch\0m_aClasses\";a:1:{s:11:\"UserRequest\";s:11:\"UserRequest\";}s:34:\"\0DBObjectSearch\0m_aSelectedClasses\";a:1:{s:11:\"UserRequest\";s:11:\"UserRequest\";}s:34:\"\0DBObjectSearch\0m_oSearchCondition\";O:15:\"FalseExpression\":1:{s:10:\"\0*\0m_value\";i:0;}s:25:\"\0DBObjectSearch\0m_aParams\";a:0:{}s:27:\"\0DBObjectSearch\0m_aFullText\";a:0:{}s:29:\"\0DBObjectSearch\0m_aPointingTo\";a:0:{}s:31:\"\0DBObjectSearch\0m_aReferencedBy\";a:0:{}s:18:\"\0*\0m_bAllowAllData\";b:0;s:18:\"\0*\0m_bDataFiltered\";b:0;s:25:\"\0*\0m_bNoContextParameters\";b:0;s:24:\"\0*\0m_aModifierProperties\";a:0:{}}s:15:\"\0*\0m_oSQLResult\";N;s:19:\"m_aExtendedDataSpec\";N;s:13:\"m_iLimitCount\";i:0;s:13:\"m_iLimitStart\";i:0;}s:20:\"child_incidents_list\";O:11:\"DBObjectSet\":14:{s:14:\"\0*\0m_aAddedIds\";a:0:{}s:18:\"\0*\0m_aAddedObjects\";a:0:{}s:10:\"\0*\0m_aArgs\";a:0:{}s:15:\"\0*\0m_aAttToLoad\";N;s:13:\"\0*\0m_aOrderBy\";a:0:{}s:9:\"m_bLoaded\";b:1;s:20:\"\0*\0m_iNumTotalDBRows\";i:0;s:21:\"\0*\0m_iNumLoadedDBRows\";i:0;s:13:\"\0*\0m_iCurrRow\";i:0;s:12:\"\0*\0m_oFilter\";O:14:\"DBObjectSearch\":11:{s:26:\"\0DBObjectSearch\0m_aClasses\";a:1:{s:8:\"Incident\";s:8:\"Incident\";}s:34:\"\0DBObjectSearch\0m_aSelectedClasses\";a:1:{s:8:\"Incident\";s:8:\"Incident\";}s:34:\"\0DBObjectSearch\0m_oSearchCondition\";O:15:\"FalseExpression\":1:{s:10:\"\0*\0m_value\";i:0;}s:25:\"\0DBObjectSearch\0m_aParams\";a:0:{}s:27:\"\0DBObjectSearch\0m_aFullText\";a:0:{}s:29:\"\0DBObjectSearch\0m_aPointingTo\";a:0:{}s:31:\"\0DBObjectSearch\0m_aReferencedBy\";a:0:{}s:18:\"\0*\0m_bAllowAllData\";b:0;s:18:\"\0*\0m_bDataFiltered\";b:0;s:25:\"\0*\0m_bNoContextParameters\";b:0;s:24:\"\0*\0m_aModifierProperties\";a:0:{}}s:15:\"\0*\0m_oSQLResult\";N;s:19:\"m_aExtendedDataSpec\";N;s:13:\"m_iLimitCount\";i:0;s:13:\"m_iLimitStart\";i:0;}s:10:\"public_log\";O:10:\"ormCaseLog\":3:{s:9:\"\0*\0m_sLog\";s:0:\"\";s:11:\"\0*\0m_aIndex\";a:0:{}s:14:\"\0*\0m_bModified\";b:0;}s:17:\"user_satisfaction\";s:1:\"1\";s:12:\"user_comment\";s:0:\"\";s:10:\"finalclass\";s:8:\"Incident\";s:12:\"friendlyname\";s:0:\"\";s:19:\"org_id_friendlyname\";s:0:\"\";s:22:\"caller_id_friendlyname\";s:0:\"\";s:20:\"team_id_friendlyname\";s:0:\"\";s:21:\"agent_id_friendlyname\";s:0:\"\";s:23:\"service_id_friendlyname\";s:0:\"\";s:34:\"servicesubcategory_id_friendlyname\";s:0:\"\";s:31:\"parent_incident_id_friendlyname\";s:0:\"\";s:30:\"parent_problem_id_friendlyname\";s:0:\"\";s:29:\"parent_change_id_friendlyname\";s:0:\"\";s:34:\"parent_change_id_finalclass_recall\";s:6:\"Change\";}s:16:\"\0*\0m_aOrigValues\";a:70:{s:18:\"operational_status\";N;s:3:\"ref\";N;s:6:\"org_id\";N;s:8:\"org_name\";N;s:9:\"caller_id\";N;s:11:\"caller_name\";N;s:7:\"team_id\";N;s:9:\"team_name\";N;s:8:\"agent_id\";N;s:10:\"agent_name\";N;s:5:\"title\";N;s:11:\"description\";N;s:10:\"start_date\";N;s:8:\"end_date\";N;s:11:\"last_update\";N;s:10:\"close_date\";N;s:11:\"private_log\";N;s:13:\"contacts_list\";N;s:18:\"functionalcis_list\";N;s:15:\"workorders_list\";N;s:6:\"status\";N;s:6:\"impact\";N;s:8:\"priority\";N;s:7:\"urgency\";N;s:6:\"origin\";N;s:10:\"service_id\";N;s:12:\"service_name\";N;s:21:\"servicesubcategory_id\";N;s:23:\"servicesubcategory_name\";N;s:15:\"escalation_flag\";N;s:17:\"escalation_reason\";N;s:15:\"assignment_date\";N;s:15:\"resolution_date\";N;s:17:\"last_pending_date\";N;s:16:\"cumulatedpending\";N;s:3:\"tto\";N;s:3:\"ttr\";N;s:23:\"tto_escalation_deadline\";N;s:14:\"sla_tto_passed\";N;s:12:\"sla_tto_over\";N;s:23:\"ttr_escalation_deadline\";N;s:14:\"sla_ttr_passed\";N;s:12:\"sla_ttr_over\";N;s:10:\"time_spent\";N;s:15:\"resolution_code\";N;s:8:\"solution\";N;s:14:\"pending_reason\";N;s:18:\"parent_incident_id\";N;s:19:\"parent_incident_ref\";N;s:17:\"parent_problem_id\";N;s:18:\"parent_problem_ref\";N;s:16:\"parent_change_id\";N;s:17:\"parent_change_ref\";N;s:20:\"related_request_list\";N;s:20:\"child_incidents_list\";N;s:10:\"public_log\";N;s:17:\"user_satisfaction\";N;s:12:\"user_comment\";N;s:10:\"finalclass\";N;s:12:\"friendlyname\";N;s:19:\"org_id_friendlyname\";N;s:22:\"caller_id_friendlyname\";N;s:20:\"team_id_friendlyname\";N;s:21:\"agent_id_friendlyname\";N;s:23:\"service_id_friendlyname\";N;s:34:\"servicesubcategory_id_friendlyname\";N;s:31:\"parent_incident_id_friendlyname\";N;s:30:\"parent_problem_id_friendlyname\";N;s:29:\"parent_change_id_friendlyname\";N;s:34:\"parent_change_id_finalclass_recall\";N;}s:18:\"\0*\0m_aExtendedData\";N;s:18:\"\0DBObject\0m_bDirty\";b:0;s:24:\"\0DBObject\0m_bCheckStatus\";N;s:19:\"\0*\0m_bSecurityIssue\";N;s:17:\"\0*\0m_aCheckIssues\";N;s:18:\"\0*\0m_aDeleteIssues\";N;s:24:\"\0DBObject\0m_bFullyLoaded\";b:0;s:22:\"\0DBObject\0m_aLoadedAtt\";a:50:{s:18:\"operational_status\";b:1;s:3:\"ref\";b:1;s:6:\"org_id\";b:1;s:9:\"caller_id\";b:1;s:7:\"team_id\";b:1;s:8:\"agent_id\";b:1;s:5:\"title\";b:1;s:11:\"description\";b:1;s:10:\"start_date\";b:1;s:8:\"end_date\";b:1;s:11:\"last_update\";b:1;s:10:\"close_date\";b:1;s:11:\"private_log\";b:1;s:13:\"contacts_list\";b:1;s:18:\"functionalcis_list\";b:1;s:15:\"workorders_list\";b:1;s:6:\"status\";b:1;s:6:\"impact\";b:1;s:8:\"priority\";b:1;s:7:\"urgency\";b:1;s:6:\"origin\";b:1;s:10:\"service_id\";b:1;s:21:\"servicesubcategory_id\";b:1;s:15:\"escalation_flag\";b:1;s:17:\"escalation_reason\";b:1;s:15:\"assignment_date\";b:1;s:15:\"resolution_date\";b:1;s:17:\"last_pending_date\";b:1;s:16:\"cumulatedpending\";b:1;s:3:\"tto\";b:1;s:3:\"ttr\";b:1;s:23:\"tto_escalation_deadline\";b:1;s:14:\"sla_tto_passed\";b:1;s:12:\"sla_tto_over\";b:1;s:23:\"ttr_escalation_deadline\";b:1;s:14:\"sla_ttr_passed\";b:1;s:12:\"sla_ttr_over\";b:1;s:10:\"time_spent\";b:1;s:15:\"resolution_code\";b:1;s:8:\"solution\";b:1;s:14:\"pending_reason\";b:1;s:18:\"parent_incident_id\";b:1;s:17:\"parent_problem_id\";b:1;s:16:\"parent_change_id\";b:1;s:20:\"related_request_list\";b:1;s:20:\"child_incidents_list\";b:1;s:10:\"public_log\";b:1;s:17:\"user_satisfaction\";b:1;s:12:\"user_comment\";b:1;s:10:\"finalclass\";b:1;}s:16:\"\0*\0m_aTouchedAtt\";a:0:{}s:17:\"\0*\0m_aModifiedAtt\";a:0:{}s:17:\"\0*\0m_aSynchroData\";N;s:19:\"\0*\0m_sHighlightCode\";N;s:15:\"\0*\0m_aCallbacks\";a:0:{}}i:3;a:0:{}}}}','a:0:{}'),(5,'PHP Exception','Page could not be displayed','/itsm/pages/UI.php','a:0:{}','a:3:{s:9:\"operation\";s:3:\"new\";s:5:\"class\";s:8:\"Incident\";s:1:\"c\";a:1:{s:4:\"menu\";s:11:\"NewIncident\";}}','a:3:{i:0;a:6:{s:4:\"file\";s:54:\"/home/alltic/public_html/itsm/core/metamodel.class.php\";s:4:\"line\";i:481;s:8:\"function\";s:15:\"GetAttributeDef\";s:5:\"class\";s:9:\"MetaModel\";s:4:\"type\";s:2:\"::\";s:4:\"args\";a:2:{i:0;s:8:\"Incident\";i:1;s:11:\"pais_ticket\";}}i:1;a:6:{s:4:\"file\";s:68:\"/home/alltic/public_html/itsm/application/cmdbabstract.class.inc.php\";s:4:\"line\";i:2389;s:8:\"function\";s:25:\"GetPrerequisiteAttributes\";s:5:\"class\";s:9:\"MetaModel\";s:4:\"type\";s:2:\"::\";s:4:\"args\";a:2:{i:0;s:8:\"Incident\";i:1;s:11:\"pais_ticket\";}}i:2;a:6:{s:4:\"file\";s:42:\"/home/alltic/public_html/itsm/pages/UI.php\";s:4:\"line\";i:758;s:8:\"function\";s:19:\"DisplayCreationForm\";s:5:\"class\";s:18:\"cmdbAbstractObject\";s:4:\"type\";s:2:\"::\";s:4:\"args\";a:4:{i:0;O:11:\"iTopWebPage\":35:{s:20:\"\0iTopWebPage\0m_sMenu\";s:0:\"\";s:23:\"\0iTopWebPage\0m_sMessage\";s:0:\"\";s:26:\"\0iTopWebPage\0m_sInitScript\";s:3833:\"	try\n	{\n		var myLayout; // a var is required because this page utilizes: myLayout.allowOverflow() method\n	\n		// Layout\n		paneSize = GetUserPreference(\'menu_size\', 300)\n		myLayout = $(\'body\').layout({\n			west :	{\n						 minSize: 200, size: paneSize, spacing_open: 16, spacing_close: 16, slideTrigger_open: \"click\", hideTogglerOnSlide: true, enableCursorHotkey: false,\n						onclose_end: function(name, elt, state, options, layout)\n						{\n								if (state.isSliding == false)\n								{\n									$(\'.menu-pane-exclusive\').show();\n									SetUserPreference(\'menu_pane\', \'closed\', true);\n								}\n						},\n						onresize_end: function(name, elt, state, options, layout)\n						{\n								if (state.isSliding == false)\n								{\n									SetUserPreference(\'menu_size\', state.size, true);\n								}\n						},\n									\n						onopen_end: function(name, elt, state, options, layout)\n						{\n							if (state.isSliding == false)\n							{\n								$(\'.menu-pane-exclusive\').hide();\n								SetUserPreference(\'menu_pane\', \'open\', true);\n							}\n						}\n					},\n			center: {\n						onresize_end: function(name, elt, state, options, layout)\n						{\n								$(\'.v-resizable\').each( function() {\n									var fixedWidth = $(this).parent().innerWidth() - 6;\n									$(this).width(fixedWidth);\n									// Make sure it cannot be resized horizontally\n									$(this).resizable(\'options\', { minWidth: fixedWidth, maxWidth:	fixedWidth });\n									// Now adjust all the child \'items\'\n									var innerWidth = $(this).innerWidth() - 10;\n									$(this).find(\'.item\').width(innerWidth);\n								});\n								$(\'.panel-resized\').trigger(\'resized\');\n						}\n				\n					}\n		});\n		window.clearTimeout(iPaneVisWatchDog);\n		//myLayout.open( \"west\" );\n		$(\'.ui-layout-resizer-west .ui-layout-toggler\').css({background: \'transparent\'});\n						myLayout.addPinBtn( \"#tPinMenu\", \"west\" );\n		\n		$(\'#left-pane\').layout({ resizable: false, spacing_open: 0, south: { size: 94 }, enableCursorHotkey: false });\n		\n		// Tabs, using JQuery BBQ to store the history\n		// The \"tab widgets\" to handle.\n		var tabs = $(\'div[id^=tabbedContent]\');\n			\n		// This selector will be reused when selecting actual tab widget A elements.\n		var tab_a_selector = \'ul.ui-tabs-nav a\';\n		  \n		// Ugly patch for a change in the behavior of jQuery UI:\n		// Before jQuery UI 1.9, tabs were always considered as \"local\" (opposed to Ajax)\n		// when their href was beginning by #. Starting with 1.9, a <base> tag in the page\n		// is taken into account and causes \"local\" tabs to be considered as Ajax\n		// unless their URL is equal to the URL of the page...\n		$(\'div[id^=tabbedContent] > ul > li > a\').each(function() {\n			var sHash = location.hash;\n			var sHref = $(this).attr(\"href\");\n			if (sHref.match(/^#/))\n			{\n				var sCleanLocation = location.href.toString().replace(sHash, \'\').replace(/#$/, \'\');\n				$(this).attr(\"href\", sCleanLocation+$(this).attr(\"href\"));\n			}\n		});\n\n		// Enable tabs on all tab widgets. The `event` property must be overridden so\n		// that the tabs aren\'t changed on click, and any custom event name can be\n		// specified. Note that if you define a callback for the \'select\' event, it\n		// will be executed for the selected tab whenever the hash changes.\n		tabs.tabs({\n			event: \'change\', \'show\': function(event, ui) {\n				$(\'.resizable\', ui.panel).resizable(); // Make resizable everything that claims to be resizable !\n			},\n			beforeLoad: function( event, ui ) {\n				if ( ui.tab.data(\'loaded\') && (ui.tab.attr(\'data-cache\') == \'true\')) {\n					event.preventDefault();\n					return;\n				}\n				ui.panel.html(\'<div><img src=\"../images/indicator.gif\"></div>\');\n				ui.jqXHR.success(function() {\n					ui.tab.data( \"loaded\", true );\n				});\n			}\n		});\n\n		$(\'.resizable\').filter(\':visible\').resizable();\n	}\n	catch(err)\n	{\n		// Do something with the error !\n		alert(err);\n	}\";s:10:\"\0*\0m_oTabs\";O:10:\"TabManager\":3:{s:10:\"\0*\0m_aTabs\";a:0:{}s:25:\"\0*\0m_sCurrentTabContainer\";s:0:\"\";s:16:\"\0*\0m_sCurrentTab\";s:0:\"\";}s:21:\"\0*\0bBreadCrumbEnabled\";b:0;s:21:\"\0*\0sBreadCrumbEntryId\";N;s:24:\"\0*\0sBreadCrumbEntryLabel\";N;s:30:\"\0*\0sBreadCrumbEntryDescription\";N;s:22:\"\0*\0sBreadCrumbEntryUrl\";N;s:23:\"\0*\0sBreadCrumbEntryIcon\";N;s:7:\"\0*\0oCtx\";O:10:\"ContextTag\":0:{}s:15:\"m_aReadyScripts\";a:3:{i:0;s:1728:\"	//add new widget called TruncatedList to properly display truncated lists when they are sorted\n	$.tablesorter.addWidget({ \n		// give the widget a id \n		id: \"truncatedList\", \n		// format is called when the on init and when a sorting has finished \n		format: function(table)\n		{ \n			// Check if there is a \"truncated\" line\n			this.truncatedList = false;  \n			if ($(\"tr td.truncated\",table).length > 0)\n			{\n				this.truncatedList = true;\n			}\n			if (this.truncatedList)\n			{\n				$(\"tr td\",table).removeClass(\'truncated\');\n				$(\"tr:last td\",table).addClass(\'truncated\');\n			}\n		} \n	});\n	\n	$.tablesorter.addWidget({ \n		// give the widget a id \n		id: \"myZebra\", \n		// format is called when the on init and when a sorting has finished \n		format: function(table)\n		{\n			// Replace the \'red even\' lines by \'red_even\' since most browser do not support 2 classes selector in CSS, etc..\n			$(\"tbody tr:even\",table).addClass(\'even\');\n			$(\"tbody tr.red:even\",table).removeClass(\'red\').removeClass(\'even\').addClass(\'red_even\');\n			$(\"tbody tr.orange:even\",table).removeClass(\'orange\').removeClass(\'even\').addClass(\'orange_even\');\n			$(\"tbody tr.green:even\",table).removeClass(\'green\').removeClass(\'even\').addClass(\'green_even\');\n			// In case we sort again the table, we need to remove the added \'even\' classes on odd rows\n			$(\"tbody tr:odd\",table).removeClass(\'even\');\n			$(\"tbody tr.red_even:odd\",table).removeClass(\'even\').removeClass(\'red_even\').addClass(\'red\');\n			$(\"tbody tr.orange_even:odd\",table).removeClass(\'even\').removeClass(\'orange_even\').addClass(\'orange\');\n			$(\"tbody tr.green_even:odd\",table).removeClass(\'even\').removeClass(\'green_even\').addClass(\'green\');\n		} \n	});\n	$(\"table.listResults\").tableHover(); // hover tables\";i:1;s:5505:\"	\n	// Adjust initial size\n	$(\'.v-resizable\').each( function()\n		{\n			var parent_id = $(this).parent().id;\n			// Restore the saved height\n			var iHeight = GetUserPreference(parent_id+\'_\'+this.id+\'_height\', undefined);\n			if (iHeight != undefined)\n			{\n				$(this).height(parseInt(iHeight, 10)); // Parse in base 10 !);\n			}\n			// Adjust the child \'item\'\'s height and width to fit\n			var container = $(this);\n			var fixedWidth = container.parent().innerWidth() - 6;\n			// Set the width to fit the parent\n			$(this).width(fixedWidth);\n			var headerHeight = $(this).find(\'.drag_handle\').height();\n			// Now adjust the width and height of the child \'item\'\n			container.find(\'.item\').height(container.innerHeight() - headerHeight - 12).width(fixedWidth - 10);\n		}\n	);\n	// Make resizable, vertically only everything that claims to be v-resizable !\n	$(\'.v-resizable\').resizable( { handles: \'s\', minHeight: $(this).find(\'.drag_handle\').height(), minWidth: $(this).parent().innerWidth() - 6, maxWidth: $(this).parent().innerWidth() - 6, stop: function()\n		{\n			// Adjust the content\n			var container = $(this);\n			var headerHeight = $(this).find(\'.drag_handle\').height();\n			container.find(\'.item\').height(container.innerHeight() - headerHeight - 12);//.width(container.innerWidth());\n			var parent_id = $(this).parent().id;\n			SetUserPreference(parent_id+\'_\'+this.id+\'_height\', $(this).height(), true); // true => persistent\n		}\n	} );\n		\n	// Tabs, using JQuery BBQ to store the history\n	// The \"tab widgets\" to handle.\n	var tabs = $(\'div[id^=tabbedContent]\');\n		\n	// This selector will be reused when selecting actual tab widget A elements.\n	var tab_a_selector = \'ul.ui-tabs-nav a\';\n	  \n	// Define our own click handler for the tabs, overriding the default.\n	tabs.find( tab_a_selector ).click(function()\n	{\n		var state = {};\n				  \n		// Get the id of this tab widget.\n		var id = $(this).closest( \'div[id^=tabbedContent]\' ).attr( \'id\' );\n		  \n		// Get the index of this tab.\n		var idx = $(this).parent().prevAll().length;\n		\n		// Set the state!\n		state[ id ] = idx;\n		$.bbq.pushState( state );\n	});\n	\n	// refresh the hash when the tab is changed (from a JS script)\n	$(\'body\').on( \'tabsactivate\', \'.ui-tabs\', function(event, ui) {\n		var state = {};\n			\n		// Get the id of this tab widget.\n		var id = $(ui.newTab).closest( \'div[id^=tabbedContent]\' ).attr( \'id\' );\n		\n		// Get the index of this tab.\n		var idx = $(ui.newTab).prevAll().length;\n			\n		// Set the state!\n		state[ id ] = idx;\n		$.bbq.pushState( state );\n	});\n	\n	// Bind an event to window.onhashchange that, when the history state changes,\n	// iterates over all tab widgets, changing the current tab as necessary.\n	$(window).bind( \'hashchange\', function(e)\n	{\n		// Iterate over all tab widgets.\n		tabs.each(function()\n		{  \n			// Get the index for this tab widget from the hash, based on the\n			// appropriate id property. In jQuery 1.4, you should use e.getState()\n			// instead of $.bbq.getState(). The second, \'true\' argument coerces the\n			// string value to a number.\n			var idx = $.bbq.getState( this.id, true ) || 0;\n			  \n			// Select the appropriate tab for this tab widget by triggering the custom\n			// event specified in the .tabs() init above (you could keep track of what\n			// tab each widget is on using .data, and only select a tab if it has\n			// changed).\n			$(this).find( tab_a_selector ).eq( idx ).triggerHandler( \'change\' );\n		});\n\n		// Iterate over all truncated lists to find whether they are expanded or not\n		$(\'a.truncated\').each(function()\n		{\n			var state = $.bbq.getState( this.id, true ) || \'close\';\n			if (state == \'open\')\n			{\n				$(this).trigger(\'open\');\n			}\n			else\n			{\n				$(this).trigger(\'close\');	\n			}\n		});\n	});\n	\n	// Shortcut menu actions\n	$(\'.actions_button a\').click( function() {\n		aMatches = /#(.*)$/.exec(window.location.href);\n		if (aMatches != null)\n		{\n			currentHash = aMatches[1];\n			if ( /#(.*)$/.test(this.href))\n			{\n				this.href = this.href.replace(/#(.*)$/, \'#\'+currentHash);\n			}\n		}\n	});\n\n	// End of Tabs handling\n\n	PrepareWidgets();\n\n	// Make sortable, everything that claims to be sortable\n	$(\'.sortable\').sortable( {axis: \'y\', cursor: \'move\', handle: \'.drag_handle\', stop: function()\n		{\n			if ($(this).hasClass(\'persistent\'))\n			{\n				// remember the sort order for next time the page is loaded...\n				sSerialized = $(this).sortable(\'serialize\', {key: \'menu\'});\n				var sTemp = sSerialized.replace(/menu=/g, \'\');\n				SetUserPreference(this.id+\'_order\', sTemp.replace(/&/g, \',\'), true); // true => persistent !\n			}\n		}\n	});\n	docWidth = $(document).width();\n	$(\'#ModalDlg\').dialog({ autoOpen: false, modal: true, width: 0.8*docWidth }); // JQuery UI dialogs\n	ShowDebug();\n	$(\'#logOffBtn>ul\').popupmenu();\n	\n	$(\'.caselog_header\').click( function () { $(this).toggleClass(\'open\').next(\'.caselog_entry,.caselog_entry_html\').toggle(); });\n	\n	$(document).ajaxSend(function(event, jqxhr, options) {\n		jqxhr.setRequestHeader(\'X-Combodo-Ajax\', \'true\');\n	});\n	$(document).ajaxError(function(event, jqxhr, options) {\n		if (jqxhr.status == 401)\n		{\n			$(\'<div>\'+\"You are disconnected. You must identify yourself to continue using the application.\"+\'</div>\').dialog({\n				modal:true,\n				title: \"Warning!\",\n				close: function() { $(this).remove(); },\n				minWidth: 400,\n				buttons: [\n					{ text: \"Login again\", click: function() { window.location.href= GetAbsoluteUrlAppRoot()+\'pages/UI.php\' } },\n					{ text: \"Stay on this page\", click: function() { $(this).dialog(\'close\'); } }\n				]\n			});\n		}\n	});\";i:2;s:285:\"$(\'img[data-img-id]\').each(function() {\n	if ($(this).width() > 250)\n	{\n		$(this).css({\'max-width\': \'250px\', width: \'\', height: \'\', \'max-height\': \'\'});\n	}\n	$(this).addClass(\'inline-image\').attr(\'href\', $(this).attr(\'src\'));\n}).magnificPopup({type: \'image\', closeOnContentClick: true });\";}s:10:\"m_sRootUrl\";s:22:\"http://alltic.co/itsm/\";s:10:\"\0*\0s_title\";s:30:\"iTop - Creación de Incidente \";s:12:\"\0*\0s_content\";s:189:\"<h1><img src=\"http://alltic.co/itsm/env-production/itop-incident-mgmt-itil/images/incident.png\" style=\"vertical-align:middle;\"/>&nbsp;Creación de Incidente</h1>\n<div class=\"wizContainer\">\n\";s:21:\"\0*\0s_deferred_content\";s:0:\"\";s:12:\"\0*\0a_scripts\";a:4:{i:0;s:854:\"function GetAbsoluteUrlAppRoot()\n{\n	return \'http://alltic.co/itsm/\';\n}\n\nfunction GetAbsoluteUrlModulesRoot()\n{\n	return \'http://alltic.co/itsm/env-production/\';\n}\n\nfunction GetAbsoluteUrlModulePage(sModule, sPage, aArguments)\n{\n	// aArguments is optional, it default to an empty hash\n	aArguments = typeof aArguments !== \'undefined\' ? aArguments : {};\n\n	var sUrl = \'http://alltic.co/itsm/\'+\'pages/exec.php?exec_module=\'+sModule+\'&exec_page=\'+sPage+\'&exec_env=\'+\'production\';\n	for (var sArgName in aArguments)\n	{\n		if (aArguments.hasOwnProperty(sArgName))\n		{\n			sUrl = sUrl + \'&\'+sArgName+\'=\'+aArguments[sArgname];\n		}\n	}\n	return sUrl;\n}\n\nfunction AddAppContext(sURL)\n{\n	var sContext = \'c[menu]=NewIncident\';\n	if (sContext.length > 0)\n	{\n		if (sURL.indexOf(\'?\') == -1)\n		{\n			return sURL+\'?\'+sContext;\n		}				\n		return sURL+\'&\'+sContext;\n	}\n	return sURL;\n}\";i:1;s:1971:\"	function PrepareWidgets()\n	{\n		// note: each action implemented here must be idempotent,\n		//       because this helper function might be called several times on a given page \n	\n		$(\".date-pick\").datepicker({\"showOn\":\"button\",\"buttonImage\":\"..\\/images\\/calendar.png\",\"buttonImageOnly\":true,\"dateFormat\":\"yy-mm-dd\",\"constrainInput\":false,\"changeMonth\":true,\"changeYear\":true,\"dayNamesMin\":[\"Su\",\"Mo\",\"Tu\",\"We\",\"Th\",\"Fr\",\"Sa\"],\"monthNamesShort\":[\"Jan\",\"Feb\",\"Mar\",\"Apr\",\"May\",\"Jun\",\"Jul\",\"Aug\",\"Sep\",\"Oct\",\"Nov\",\"Dec\"],\"firstDay\":0});\n	\n		// Hack for the date and time picker addon issue on Chrome (see #1305)\n		// The workaround is to instantiate the widget on demand\n		// It relies on the same markup, thus reverting to the original implementation should be straightforward\n		$(\".datetime-pick:not(.is-widget-ready)\").each(function(){\n			var oInput = this;\n			$(oInput).addClass(\'is-widget-ready\');\n			$(\'<img class=\"datetime-pick-button\" src=\"../images/calendar.png\">\')\n				.insertAfter($(this))\n				.on(\'click\', function(){\n					$(oInput)\n						.datetimepicker({\"showOn\":\"\",\"buttonImage\":null,\"buttonImageOnly\":true,\"dateFormat\":\"yy-mm-dd\",\"constrainInput\":false,\"changeMonth\":true,\"changeYear\":true,\"dayNamesMin\":[\"Su\",\"Mo\",\"Tu\",\"We\",\"Th\",\"Fr\",\"Sa\"],\"monthNamesShort\":[\"Jan\",\"Feb\",\"Mar\",\"Apr\",\"May\",\"Jun\",\"Jul\",\"Aug\",\"Sep\",\"Oct\",\"Nov\",\"Dec\"],\"firstDay\":0,\"timeFormat\":\"HH:mm:ss\",\"controlType\":\"select\",\"closeText\":\"Ok\",\n				\'timeText\': $.timepicker.regional[\"es\"].timeText,\n				\'hourText\': $.timepicker.regional[\"es\"].hourText,\n				\'minuteText\': $.timepicker.regional[\"es\"].minuteText,\n				\'secondText\': $.timepicker.regional[\"es\"].secondText,\n				\'currentText\': $.timepicker.regional[\"es\"].currentText\n			})\n						.datetimepicker(\'show\')\n						.datetimepicker(\'option\', \'onClose\', function(dateText,inst){\n							$(oInput).datetimepicker(\'destroy\');\n						})\n						.on(\'click keypress\', function(){\n							$(oInput).datetimepicker(\'hide\');\n						});\n				});\n		});\n	}\";i:2;s:1734:\"//		// for JQuery history\n//		function history_callback(hash)\n//		{\n//			// do stuff that loads page content based on hash variable\n//			var aMatches = /^tab_(.*)$/.exec(hash);\n//			if (aMatches != null)\n//			{\n//				var tab = $(\'#\'+hash);\n//				tab.parents(\'div[id^=tabbedContent]:first\').tabs(\'select\', aMatches[1]);\n//			}\n//		}\n\n		function goBack()\n		{\n			window.history.back();\n		}\n		\n		function BackToDetails(sClass, id, sDefaultUrl, sOwnershipToken)\n		{\n			window.bInCancel = true;\n			if (id > 0)\n			{\n				sToken = \'\';\n				if (sOwnershipToken != undefined)\n				{\n					sToken = \'&token=\'+sOwnershipToken;\n				}\n				window.location.href = AddAppContext(GetAbsoluteUrlAppRoot()+\'pages/UI.php?operation=release_lock_and_details&class=\'+sClass+\'&id=\'+id+sToken);\n			}\n			else\n			{\n				window.location.href = sDefaultUrl; // Already contains the context...				\n			}\n		}\n\n		function BackToList(sClass)\n		{\n			window.location.href = AddAppContext(GetAbsoluteUrlAppRoot()+\'pages/UI.php?operation=search_oql&oql_class=\'+sClass+\'&oql_clause=WHERE id=0\');\n		}\n		\n		function ShowDebug()\n		{\n			if ($(\'#rawOutput > div\').html() != \'\')\n			{\n				$(\'#rawOutput\').dialog( {autoOpen: true, modal:false, width: \'80%\'});\n			}\n		}\n		\n		var oUserPreferences = {\"welcome_popup\":\"0\",\"menu_pane\":\"open\",\"menu_size\":\"421\"};\n\n		// For disabling the CKEditor at init time when the corresponding textarea is disabled !\n		CKEDITOR.plugins.add( \'disabler\',\n		{\n			init : function( editor )\n			{\n				editor.on( \'instanceReady\', function(e)\n				{\n					e.removeListener();\n					$(\'#\'+ editor.name).trigger(\'update\');\n				});\n			}\n			\n		});\n\n		\n		function FixPaneVis()\n		{\n			$(\'.ui-layout-center, .ui-layout-north, .ui-layout-south\').css({display: \'block\'});\n		}\";i:3;s:172:\"function ShowAboutBox()\n{\n	$.post(GetAbsoluteUrlAppRoot()+\'pages/ajax.render.php\', {operation: \'about_box\'}, function(data){\n		$(\'body\').append(data);\n	});\n	return false;\n}\";}s:17:\"\0*\0a_dict_entries\";a:3:{s:25:\"UI:FillAllMandatoryFields\";s:41:\"Por favor llenar los campos obligatorios.\";s:16:\"UI:Button:Cancel\";s:8:\"Cancelar\";s:14:\"UI:Button:Done\";s:5:\"Listo\";}s:11:\"\0*\0a_styles\";a:0:{}s:20:\"\0*\0a_include_scripts\";N;s:24:\"\0*\0a_include_stylesheets\";N;s:12:\"\0*\0a_headers\";a:2:{i:0;s:38:\"Content-type: text/html; charset=utf-8\";i:1;s:23:\"Cache-control: no-cache\";}s:9:\"\0*\0a_base\";a:2:{s:4:\"href\";s:0:\"\";s:6:\"target\";s:0:\"\";}s:10:\"\0*\0iNextId\";i:0;s:17:\"\0*\0iTransactionId\";i:0;s:15:\"\0*\0sContentType\";s:0:\"\";s:22:\"\0*\0sContentDisposition\";s:0:\"\";s:19:\"\0*\0sContentFileName\";s:0:\"\";s:25:\"\0*\0bTrashUnexpectedOutput\";b:0;s:18:\"\0*\0s_sOutputFormat\";N;s:18:\"\0*\0a_OutputOptions\";a:0:{}s:13:\"\0*\0bPrintable\";b:0;s:16:\"a_linked_scripts\";a:43:{s:45:\"http://alltic.co/itsm/js/jquery-1.10.0.min.js\";s:45:\"http://alltic.co/itsm/js/jquery-1.10.0.min.js\";s:52:\"http://alltic.co/itsm/js/jquery-migrate-1.2.1.min.js\";s:52:\"http://alltic.co/itsm/js/jquery-migrate-1.2.1.min.js\";s:55:\"http://alltic.co/itsm/js/jquery-ui-1.10.3.custom.min.js\";s:55:\"http://alltic.co/itsm/js/jquery-ui-1.10.3.custom.min.js\";s:36:\"http://alltic.co/itsm/js/hovertip.js\";s:36:\"http://alltic.co/itsm/js/hovertip.js\";s:46:\"http://alltic.co/itsm/js/jquery.tablesorter.js\";s:46:\"http://alltic.co/itsm/js/jquery.tablesorter.js\";s:52:\"http://alltic.co/itsm/js/jquery.tablesorter.pager.js\";s:52:\"http://alltic.co/itsm/js/jquery.tablesorter.pager.js\";s:45:\"http://alltic.co/itsm/js/jquery.tablehover.js\";s:45:\"http://alltic.co/itsm/js/jquery.tablehover.js\";s:40:\"http://alltic.co/itsm/js/field_sorter.js\";s:40:\"http://alltic.co/itsm/js/field_sorter.js\";s:37:\"http://alltic.co/itsm/js/datatable.js\";s:37:\"http://alltic.co/itsm/js/datatable.js\";s:45:\"http://alltic.co/itsm/js/jquery.positionBy.js\";s:45:\"http://alltic.co/itsm/js/jquery.positionBy.js\";s:44:\"http://alltic.co/itsm/js/jquery.popupmenu.js\";s:44:\"http://alltic.co/itsm/js/jquery.popupmenu.js\";s:26:\"../js/jquery.layout.min.js\";s:26:\"../js/jquery.layout.min.js\";s:26:\"../js/jquery.ba-bbq.min.js\";s:26:\"../js/jquery.ba-bbq.min.js\";s:24:\"../js/jquery.treeview.js\";s:24:\"../js/jquery.treeview.js\";s:28:\"../js/jquery.autocomplete.js\";s:28:\"../js/jquery.autocomplete.js\";s:13:\"../js/date.js\";s:13:\"../js/date.js\";s:35:\"../js/jquery-ui-timepicker-addon.js\";s:35:\"../js/jquery-ui-timepicker-addon.js\";s:44:\"../js/jquery-ui-timepicker-addon-i18n.min.js\";s:44:\"../js/jquery-ui-timepicker-addon-i18n.min.js\";s:23:\"../js/jquery.blockUI.js\";s:23:\"../js/jquery.blockUI.js\";s:14:\"../js/utils.js\";s:14:\"../js/utils.js\";s:18:\"../js/swfobject.js\";s:18:\"../js/swfobject.js\";s:26:\"../js/ckeditor/ckeditor.js\";s:26:\"../js/ckeditor/ckeditor.js\";s:33:\"../js/ckeditor/adapters/jquery.js\";s:33:\"../js/ckeditor/adapters/jquery.js\";s:28:\"../js/jquery.qtip-1.0.min.js\";s:28:\"../js/jquery.qtip-1.0.min.js\";s:23:\"../js/property_field.js\";s:23:\"../js/property_field.js\";s:16:\"../js/fg.menu.js\";s:16:\"../js/fg.menu.js\";s:20:\"../js/icon_select.js\";s:20:\"../js/icon_select.js\";s:20:\"../js/raphael-min.js\";s:20:\"../js/raphael-min.js\";s:11:\"../js/d3.js\";s:11:\"../js/d3.js\";s:11:\"../js/c3.js\";s:11:\"../js/c3.js\";s:27:\"../js/jquery.multiselect.js\";s:27:\"../js/jquery.multiselect.js\";s:23:\"../js/ajaxfileupload.js\";s:23:\"../js/ajaxfileupload.js\";s:26:\"../js/jquery.mousewheel.js\";s:26:\"../js/jquery.mousewheel.js\";s:34:\"../js/jquery.magnific-popup.min.js\";s:34:\"../js/jquery.magnific-popup.min.js\";s:19:\"../js/breadcrumb.js\";s:19:\"../js/breadcrumb.js\";s:19:\"../js/moment.min.js\";s:19:\"../js/moment.min.js\";s:13:\"../js/json.js\";s:13:\"../js/json.js\";s:25:\"../js/forms-json-utils.js\";s:25:\"../js/forms-json-utils.js\";s:21:\"../js/wizardhelper.js\";s:21:\"../js/wizardhelper.js\";s:21:\"../js/wizard.utils.js\";s:21:\"../js/wizard.utils.js\";s:20:\"../js/linkswidget.js\";s:20:\"../js/linkswidget.js\";s:26:\"../js/linksdirectwidget.js\";s:26:\"../js/linksdirectwidget.js\";s:21:\"../js/extkeywidget.js\";s:21:\"../js/extkeywidget.js\";}s:20:\"a_linked_stylesheets\";a:9:{i:0;a:2:{s:4:\"link\";s:70:\"http://alltic.co/itsm/css/ui-lightness/jquery-ui-1.10.3.custom.min.css\";s:9:\"condition\";s:0:\"\";}i:1;a:2:{s:4:\"link\";s:40:\"http://alltic.co/itsm/css/light-grey.css\";s:9:\"condition\";s:0:\"\";}i:2;a:2:{s:4:\"link\";s:26:\"../css/jquery.treeview.css\";s:9:\"condition\";s:0:\"\";}i:3;a:2:{s:4:\"link\";s:30:\"../css/jquery.autocomplete.css\";s:9:\"condition\";s:0:\"\";}i:4;a:2:{s:4:\"link\";s:37:\"../css/jquery-ui-timepicker-addon.css\";s:9:\"condition\";s:0:\"\";}i:5;a:2:{s:4:\"link\";s:18:\"../css/fg.menu.css\";s:9:\"condition\";s:0:\"\";}i:6;a:2:{s:4:\"link\";s:29:\"../css/jquery.multiselect.css\";s:9:\"condition\";s:0:\"\";}i:7;a:2:{s:4:\"link\";s:25:\"../css/magnific-popup.css\";s:9:\"condition\";s:0:\"\";}i:8;a:2:{s:4:\"link\";s:17:\"../css/c3.min.css\";s:9:\"condition\";s:0:\"\";}}s:14:\"s_OutputFormat\";s:4:\"html\";}i:1;s:8:\"Incident\";i:2;O:8:\"Incident\":22:{s:12:\"\0*\0m_iFormId\";N;s:13:\"\0*\0aFieldsMap\";N;s:14:\"\0*\0bAllowWrite\";b:0;s:15:\"\0*\0m_datCreated\";N;s:15:\"\0*\0m_datUpdated\";N;s:19:\"\0DBObject\0m_bIsInDB\";b:0;s:16:\"\0DBObject\0m_iKey\";i:-1;s:23:\"\0DBObject\0m_aCurrValues\";a:70:{s:18:\"operational_status\";s:7:\"ongoing\";s:3:\"ref\";s:0:\"\";s:6:\"org_id\";i:0;s:8:\"org_name\";s:0:\"\";s:9:\"caller_id\";i:0;s:11:\"caller_name\";s:0:\"\";s:7:\"team_id\";i:0;s:9:\"team_name\";s:0:\"\";s:8:\"agent_id\";i:0;s:10:\"agent_name\";s:0:\"\";s:5:\"title\";s:0:\"\";s:11:\"description\";s:0:\"\";s:10:\"start_date\";N;s:8:\"end_date\";N;s:11:\"last_update\";N;s:10:\"close_date\";N;s:11:\"private_log\";O:10:\"ormCaseLog\":3:{s:9:\"\0*\0m_sLog\";s:0:\"\";s:11:\"\0*\0m_aIndex\";a:0:{}s:14:\"\0*\0m_bModified\";b:0;}s:13:\"contacts_list\";O:11:\"DBObjectSet\":14:{s:14:\"\0*\0m_aAddedIds\";a:0:{}s:18:\"\0*\0m_aAddedObjects\";a:0:{}s:10:\"\0*\0m_aArgs\";a:0:{}s:15:\"\0*\0m_aAttToLoad\";N;s:13:\"\0*\0m_aOrderBy\";a:0:{}s:9:\"m_bLoaded\";b:1;s:20:\"\0*\0m_iNumTotalDBRows\";i:0;s:21:\"\0*\0m_iNumLoadedDBRows\";i:0;s:13:\"\0*\0m_iCurrRow\";i:0;s:12:\"\0*\0m_oFilter\";O:14:\"DBObjectSearch\":11:{s:26:\"\0DBObjectSearch\0m_aClasses\";a:1:{s:18:\"lnkContactToTicket\";s:18:\"lnkContactToTicket\";}s:34:\"\0DBObjectSearch\0m_aSelectedClasses\";a:1:{s:18:\"lnkContactToTicket\";s:18:\"lnkContactToTicket\";}s:34:\"\0DBObjectSearch\0m_oSearchCondition\";O:15:\"FalseExpression\":1:{s:10:\"\0*\0m_value\";i:0;}s:25:\"\0DBObjectSearch\0m_aParams\";a:0:{}s:27:\"\0DBObjectSearch\0m_aFullText\";a:0:{}s:29:\"\0DBObjectSearch\0m_aPointingTo\";a:0:{}s:31:\"\0DBObjectSearch\0m_aReferencedBy\";a:0:{}s:18:\"\0*\0m_bAllowAllData\";b:0;s:18:\"\0*\0m_bDataFiltered\";b:0;s:25:\"\0*\0m_bNoContextParameters\";b:0;s:24:\"\0*\0m_aModifierProperties\";a:0:{}}s:15:\"\0*\0m_oSQLResult\";N;s:19:\"m_aExtendedDataSpec\";N;s:13:\"m_iLimitCount\";i:0;s:13:\"m_iLimitStart\";i:0;}s:18:\"functionalcis_list\";O:11:\"DBObjectSet\":14:{s:14:\"\0*\0m_aAddedIds\";a:0:{}s:18:\"\0*\0m_aAddedObjects\";a:0:{}s:10:\"\0*\0m_aArgs\";a:0:{}s:15:\"\0*\0m_aAttToLoad\";N;s:13:\"\0*\0m_aOrderBy\";a:0:{}s:9:\"m_bLoaded\";b:1;s:20:\"\0*\0m_iNumTotalDBRows\";i:0;s:21:\"\0*\0m_iNumLoadedDBRows\";i:0;s:13:\"\0*\0m_iCurrRow\";i:0;s:12:\"\0*\0m_oFilter\";O:14:\"DBObjectSearch\":11:{s:26:\"\0DBObjectSearch\0m_aClasses\";a:1:{s:23:\"lnkFunctionalCIToTicket\";s:23:\"lnkFunctionalCIToTicket\";}s:34:\"\0DBObjectSearch\0m_aSelectedClasses\";a:1:{s:23:\"lnkFunctionalCIToTicket\";s:23:\"lnkFunctionalCIToTicket\";}s:34:\"\0DBObjectSearch\0m_oSearchCondition\";O:15:\"FalseExpression\":1:{s:10:\"\0*\0m_value\";i:0;}s:25:\"\0DBObjectSearch\0m_aParams\";a:0:{}s:27:\"\0DBObjectSearch\0m_aFullText\";a:0:{}s:29:\"\0DBObjectSearch\0m_aPointingTo\";a:0:{}s:31:\"\0DBObjectSearch\0m_aReferencedBy\";a:0:{}s:18:\"\0*\0m_bAllowAllData\";b:0;s:18:\"\0*\0m_bDataFiltered\";b:0;s:25:\"\0*\0m_bNoContextParameters\";b:0;s:24:\"\0*\0m_aModifierProperties\";a:0:{}}s:15:\"\0*\0m_oSQLResult\";N;s:19:\"m_aExtendedDataSpec\";N;s:13:\"m_iLimitCount\";i:0;s:13:\"m_iLimitStart\";i:0;}s:15:\"workorders_list\";O:11:\"DBObjectSet\":14:{s:14:\"\0*\0m_aAddedIds\";a:0:{}s:18:\"\0*\0m_aAddedObjects\";a:0:{}s:10:\"\0*\0m_aArgs\";a:0:{}s:15:\"\0*\0m_aAttToLoad\";N;s:13:\"\0*\0m_aOrderBy\";a:0:{}s:9:\"m_bLoaded\";b:1;s:20:\"\0*\0m_iNumTotalDBRows\";i:0;s:21:\"\0*\0m_iNumLoadedDBRows\";i:0;s:13:\"\0*\0m_iCurrRow\";i:0;s:12:\"\0*\0m_oFilter\";O:14:\"DBObjectSearch\":11:{s:26:\"\0DBObjectSearch\0m_aClasses\";a:1:{s:9:\"WorkOrder\";s:9:\"WorkOrder\";}s:34:\"\0DBObjectSearch\0m_aSelectedClasses\";a:1:{s:9:\"WorkOrder\";s:9:\"WorkOrder\";}s:34:\"\0DBObjectSearch\0m_oSearchCondition\";O:15:\"FalseExpression\":1:{s:10:\"\0*\0m_value\";i:0;}s:25:\"\0DBObjectSearch\0m_aParams\";a:0:{}s:27:\"\0DBObjectSearch\0m_aFullText\";a:0:{}s:29:\"\0DBObjectSearch\0m_aPointingTo\";a:0:{}s:31:\"\0DBObjectSearch\0m_aReferencedBy\";a:0:{}s:18:\"\0*\0m_bAllowAllData\";b:0;s:18:\"\0*\0m_bDataFiltered\";b:0;s:25:\"\0*\0m_bNoContextParameters\";b:0;s:24:\"\0*\0m_aModifierProperties\";a:0:{}}s:15:\"\0*\0m_oSQLResult\";N;s:19:\"m_aExtendedDataSpec\";N;s:13:\"m_iLimitCount\";i:0;s:13:\"m_iLimitStart\";i:0;}s:6:\"status\";s:3:\"new\";s:6:\"impact\";s:1:\"2\";s:8:\"priority\";s:1:\"2\";s:7:\"urgency\";s:1:\"2\";s:6:\"origin\";s:5:\"phone\";s:10:\"service_id\";i:0;s:12:\"service_name\";s:0:\"\";s:21:\"servicesubcategory_id\";i:0;s:23:\"servicesubcategory_name\";s:0:\"\";s:15:\"escalation_flag\";s:2:\"no\";s:17:\"escalation_reason\";s:0:\"\";s:15:\"assignment_date\";N;s:15:\"resolution_date\";N;s:17:\"last_pending_date\";N;s:16:\"cumulatedpending\";O:12:\"ormStopWatch\":5:{s:13:\"\0*\0iTimeSpent\";i:0;s:11:\"\0*\0iStarted\";N;s:13:\"\0*\0iLastStart\";N;s:11:\"\0*\0iStopped\";N;s:14:\"\0*\0aThresholds\";a:0:{}}s:3:\"tto\";O:12:\"ormStopWatch\":5:{s:13:\"\0*\0iTimeSpent\";i:0;s:11:\"\0*\0iStarted\";N;s:13:\"\0*\0iLastStart\";N;s:11:\"\0*\0iStopped\";N;s:14:\"\0*\0aThresholds\";a:2:{i:75;a:4:{s:8:\"deadline\";N;s:9:\"triggered\";b:0;s:7:\"overrun\";N;s:9:\"highlight\";N;}i:100;a:4:{s:8:\"deadline\";N;s:9:\"triggered\";b:0;s:7:\"overrun\";N;s:9:\"highlight\";N;}}}s:3:\"ttr\";O:12:\"ormStopWatch\":5:{s:13:\"\0*\0iTimeSpent\";i:0;s:11:\"\0*\0iStarted\";N;s:13:\"\0*\0iLastStart\";N;s:11:\"\0*\0iStopped\";N;s:14:\"\0*\0aThresholds\";a:2:{i:75;a:4:{s:8:\"deadline\";N;s:9:\"triggered\";b:0;s:7:\"overrun\";N;s:9:\"highlight\";N;}i:100;a:4:{s:8:\"deadline\";N;s:9:\"triggered\";b:0;s:7:\"overrun\";N;s:9:\"highlight\";N;}}}s:23:\"tto_escalation_deadline\";N;s:14:\"sla_tto_passed\";N;s:12:\"sla_tto_over\";N;s:23:\"ttr_escalation_deadline\";N;s:14:\"sla_ttr_passed\";N;s:12:\"sla_ttr_over\";N;s:10:\"time_spent\";N;s:15:\"resolution_code\";N;s:8:\"solution\";s:0:\"\";s:14:\"pending_reason\";s:0:\"\";s:18:\"parent_incident_id\";i:0;s:19:\"parent_incident_ref\";s:0:\"\";s:17:\"parent_problem_id\";i:0;s:18:\"parent_problem_ref\";s:0:\"\";s:16:\"parent_change_id\";i:0;s:17:\"parent_change_ref\";s:0:\"\";s:20:\"related_request_list\";O:11:\"DBObjectSet\":14:{s:14:\"\0*\0m_aAddedIds\";a:0:{}s:18:\"\0*\0m_aAddedObjects\";a:0:{}s:10:\"\0*\0m_aArgs\";a:0:{}s:15:\"\0*\0m_aAttToLoad\";N;s:13:\"\0*\0m_aOrderBy\";a:0:{}s:9:\"m_bLoaded\";b:1;s:20:\"\0*\0m_iNumTotalDBRows\";i:0;s:21:\"\0*\0m_iNumLoadedDBRows\";i:0;s:13:\"\0*\0m_iCurrRow\";i:0;s:12:\"\0*\0m_oFilter\";O:14:\"DBObjectSearch\":11:{s:26:\"\0DBObjectSearch\0m_aClasses\";a:1:{s:11:\"UserRequest\";s:11:\"UserRequest\";}s:34:\"\0DBObjectSearch\0m_aSelectedClasses\";a:1:{s:11:\"UserRequest\";s:11:\"UserRequest\";}s:34:\"\0DBObjectSearch\0m_oSearchCondition\";O:15:\"FalseExpression\":1:{s:10:\"\0*\0m_value\";i:0;}s:25:\"\0DBObjectSearch\0m_aParams\";a:0:{}s:27:\"\0DBObjectSearch\0m_aFullText\";a:0:{}s:29:\"\0DBObjectSearch\0m_aPointingTo\";a:0:{}s:31:\"\0DBObjectSearch\0m_aReferencedBy\";a:0:{}s:18:\"\0*\0m_bAllowAllData\";b:0;s:18:\"\0*\0m_bDataFiltered\";b:0;s:25:\"\0*\0m_bNoContextParameters\";b:0;s:24:\"\0*\0m_aModifierProperties\";a:0:{}}s:15:\"\0*\0m_oSQLResult\";N;s:19:\"m_aExtendedDataSpec\";N;s:13:\"m_iLimitCount\";i:0;s:13:\"m_iLimitStart\";i:0;}s:20:\"child_incidents_list\";O:11:\"DBObjectSet\":14:{s:14:\"\0*\0m_aAddedIds\";a:0:{}s:18:\"\0*\0m_aAddedObjects\";a:0:{}s:10:\"\0*\0m_aArgs\";a:0:{}s:15:\"\0*\0m_aAttToLoad\";N;s:13:\"\0*\0m_aOrderBy\";a:0:{}s:9:\"m_bLoaded\";b:1;s:20:\"\0*\0m_iNumTotalDBRows\";i:0;s:21:\"\0*\0m_iNumLoadedDBRows\";i:0;s:13:\"\0*\0m_iCurrRow\";i:0;s:12:\"\0*\0m_oFilter\";O:14:\"DBObjectSearch\":11:{s:26:\"\0DBObjectSearch\0m_aClasses\";a:1:{s:8:\"Incident\";s:8:\"Incident\";}s:34:\"\0DBObjectSearch\0m_aSelectedClasses\";a:1:{s:8:\"Incident\";s:8:\"Incident\";}s:34:\"\0DBObjectSearch\0m_oSearchCondition\";O:15:\"FalseExpression\":1:{s:10:\"\0*\0m_value\";i:0;}s:25:\"\0DBObjectSearch\0m_aParams\";a:0:{}s:27:\"\0DBObjectSearch\0m_aFullText\";a:0:{}s:29:\"\0DBObjectSearch\0m_aPointingTo\";a:0:{}s:31:\"\0DBObjectSearch\0m_aReferencedBy\";a:0:{}s:18:\"\0*\0m_bAllowAllData\";b:0;s:18:\"\0*\0m_bDataFiltered\";b:0;s:25:\"\0*\0m_bNoContextParameters\";b:0;s:24:\"\0*\0m_aModifierProperties\";a:0:{}}s:15:\"\0*\0m_oSQLResult\";N;s:19:\"m_aExtendedDataSpec\";N;s:13:\"m_iLimitCount\";i:0;s:13:\"m_iLimitStart\";i:0;}s:10:\"public_log\";O:10:\"ormCaseLog\":3:{s:9:\"\0*\0m_sLog\";s:0:\"\";s:11:\"\0*\0m_aIndex\";a:0:{}s:14:\"\0*\0m_bModified\";b:0;}s:17:\"user_satisfaction\";s:1:\"1\";s:12:\"user_comment\";s:0:\"\";s:10:\"finalclass\";s:8:\"Incident\";s:12:\"friendlyname\";s:0:\"\";s:19:\"org_id_friendlyname\";s:0:\"\";s:22:\"caller_id_friendlyname\";s:0:\"\";s:20:\"team_id_friendlyname\";s:0:\"\";s:21:\"agent_id_friendlyname\";s:0:\"\";s:23:\"service_id_friendlyname\";s:0:\"\";s:34:\"servicesubcategory_id_friendlyname\";s:0:\"\";s:31:\"parent_incident_id_friendlyname\";s:0:\"\";s:30:\"parent_problem_id_friendlyname\";s:0:\"\";s:29:\"parent_change_id_friendlyname\";s:0:\"\";s:34:\"parent_change_id_finalclass_recall\";s:6:\"Change\";}s:16:\"\0*\0m_aOrigValues\";a:70:{s:18:\"operational_status\";N;s:3:\"ref\";N;s:6:\"org_id\";N;s:8:\"org_name\";N;s:9:\"caller_id\";N;s:11:\"caller_name\";N;s:7:\"team_id\";N;s:9:\"team_name\";N;s:8:\"agent_id\";N;s:10:\"agent_name\";N;s:5:\"title\";N;s:11:\"description\";N;s:10:\"start_date\";N;s:8:\"end_date\";N;s:11:\"last_update\";N;s:10:\"close_date\";N;s:11:\"private_log\";N;s:13:\"contacts_list\";N;s:18:\"functionalcis_list\";N;s:15:\"workorders_list\";N;s:6:\"status\";N;s:6:\"impact\";N;s:8:\"priority\";N;s:7:\"urgency\";N;s:6:\"origin\";N;s:10:\"service_id\";N;s:12:\"service_name\";N;s:21:\"servicesubcategory_id\";N;s:23:\"servicesubcategory_name\";N;s:15:\"escalation_flag\";N;s:17:\"escalation_reason\";N;s:15:\"assignment_date\";N;s:15:\"resolution_date\";N;s:17:\"last_pending_date\";N;s:16:\"cumulatedpending\";N;s:3:\"tto\";N;s:3:\"ttr\";N;s:23:\"tto_escalation_deadline\";N;s:14:\"sla_tto_passed\";N;s:12:\"sla_tto_over\";N;s:23:\"ttr_escalation_deadline\";N;s:14:\"sla_ttr_passed\";N;s:12:\"sla_ttr_over\";N;s:10:\"time_spent\";N;s:15:\"resolution_code\";N;s:8:\"solution\";N;s:14:\"pending_reason\";N;s:18:\"parent_incident_id\";N;s:19:\"parent_incident_ref\";N;s:17:\"parent_problem_id\";N;s:18:\"parent_problem_ref\";N;s:16:\"parent_change_id\";N;s:17:\"parent_change_ref\";N;s:20:\"related_request_list\";N;s:20:\"child_incidents_list\";N;s:10:\"public_log\";N;s:17:\"user_satisfaction\";N;s:12:\"user_comment\";N;s:10:\"finalclass\";N;s:12:\"friendlyname\";N;s:19:\"org_id_friendlyname\";N;s:22:\"caller_id_friendlyname\";N;s:20:\"team_id_friendlyname\";N;s:21:\"agent_id_friendlyname\";N;s:23:\"service_id_friendlyname\";N;s:34:\"servicesubcategory_id_friendlyname\";N;s:31:\"parent_incident_id_friendlyname\";N;s:30:\"parent_problem_id_friendlyname\";N;s:29:\"parent_change_id_friendlyname\";N;s:34:\"parent_change_id_finalclass_recall\";N;}s:18:\"\0*\0m_aExtendedData\";N;s:18:\"\0DBObject\0m_bDirty\";b:0;s:24:\"\0DBObject\0m_bCheckStatus\";N;s:19:\"\0*\0m_bSecurityIssue\";N;s:17:\"\0*\0m_aCheckIssues\";N;s:18:\"\0*\0m_aDeleteIssues\";N;s:24:\"\0DBObject\0m_bFullyLoaded\";b:0;s:22:\"\0DBObject\0m_aLoadedAtt\";a:50:{s:18:\"operational_status\";b:1;s:3:\"ref\";b:1;s:6:\"org_id\";b:1;s:9:\"caller_id\";b:1;s:7:\"team_id\";b:1;s:8:\"agent_id\";b:1;s:5:\"title\";b:1;s:11:\"description\";b:1;s:10:\"start_date\";b:1;s:8:\"end_date\";b:1;s:11:\"last_update\";b:1;s:10:\"close_date\";b:1;s:11:\"private_log\";b:1;s:13:\"contacts_list\";b:1;s:18:\"functionalcis_list\";b:1;s:15:\"workorders_list\";b:1;s:6:\"status\";b:1;s:6:\"impact\";b:1;s:8:\"priority\";b:1;s:7:\"urgency\";b:1;s:6:\"origin\";b:1;s:10:\"service_id\";b:1;s:21:\"servicesubcategory_id\";b:1;s:15:\"escalation_flag\";b:1;s:17:\"escalation_reason\";b:1;s:15:\"assignment_date\";b:1;s:15:\"resolution_date\";b:1;s:17:\"last_pending_date\";b:1;s:16:\"cumulatedpending\";b:1;s:3:\"tto\";b:1;s:3:\"ttr\";b:1;s:23:\"tto_escalation_deadline\";b:1;s:14:\"sla_tto_passed\";b:1;s:12:\"sla_tto_over\";b:1;s:23:\"ttr_escalation_deadline\";b:1;s:14:\"sla_ttr_passed\";b:1;s:12:\"sla_ttr_over\";b:1;s:10:\"time_spent\";b:1;s:15:\"resolution_code\";b:1;s:8:\"solution\";b:1;s:14:\"pending_reason\";b:1;s:18:\"parent_incident_id\";b:1;s:17:\"parent_problem_id\";b:1;s:16:\"parent_change_id\";b:1;s:20:\"related_request_list\";b:1;s:20:\"child_incidents_list\";b:1;s:10:\"public_log\";b:1;s:17:\"user_satisfaction\";b:1;s:12:\"user_comment\";b:1;s:10:\"finalclass\";b:1;}s:16:\"\0*\0m_aTouchedAtt\";a:0:{}s:17:\"\0*\0m_aModifiedAtt\";a:0:{}s:17:\"\0*\0m_aSynchroData\";N;s:19:\"\0*\0m_sHighlightCode\";N;s:15:\"\0*\0m_aCallbacks\";a:0:{}}i:3;a:0:{}}}}','a:0:{}'),(6,'PHP Exception','Page could not be displayed','/itsm/pages/UI.php','a:0:{}','a:3:{s:9:\"operation\";s:3:\"new\";s:5:\"class\";s:11:\"UserRequest\";s:1:\"c\";a:1:{s:4:\"menu\";s:14:\"NewUserRequest\";}}','a:3:{i:0;a:6:{s:4:\"file\";s:54:\"/home/alltic/public_html/itsm/core/metamodel.class.php\";s:4:\"line\";i:481;s:8:\"function\";s:15:\"GetAttributeDef\";s:5:\"class\";s:9:\"MetaModel\";s:4:\"type\";s:2:\"::\";s:4:\"args\";a:2:{i:0;s:11:\"UserRequest\";i:1;s:11:\"pais_ticket\";}}i:1;a:6:{s:4:\"file\";s:68:\"/home/alltic/public_html/itsm/application/cmdbabstract.class.inc.php\";s:4:\"line\";i:2389;s:8:\"function\";s:25:\"GetPrerequisiteAttributes\";s:5:\"class\";s:9:\"MetaModel\";s:4:\"type\";s:2:\"::\";s:4:\"args\";a:2:{i:0;s:11:\"UserRequest\";i:1;s:11:\"pais_ticket\";}}i:2;a:6:{s:4:\"file\";s:42:\"/home/alltic/public_html/itsm/pages/UI.php\";s:4:\"line\";i:758;s:8:\"function\";s:19:\"DisplayCreationForm\";s:5:\"class\";s:18:\"cmdbAbstractObject\";s:4:\"type\";s:2:\"::\";s:4:\"args\";a:4:{i:0;O:11:\"iTopWebPage\":35:{s:20:\"\0iTopWebPage\0m_sMenu\";s:0:\"\";s:23:\"\0iTopWebPage\0m_sMessage\";s:0:\"\";s:26:\"\0iTopWebPage\0m_sInitScript\";s:3833:\"	try\n	{\n		var myLayout; // a var is required because this page utilizes: myLayout.allowOverflow() method\n	\n		// Layout\n		paneSize = GetUserPreference(\'menu_size\', 300)\n		myLayout = $(\'body\').layout({\n			west :	{\n						 minSize: 200, size: paneSize, spacing_open: 16, spacing_close: 16, slideTrigger_open: \"click\", hideTogglerOnSlide: true, enableCursorHotkey: false,\n						onclose_end: function(name, elt, state, options, layout)\n						{\n								if (state.isSliding == false)\n								{\n									$(\'.menu-pane-exclusive\').show();\n									SetUserPreference(\'menu_pane\', \'closed\', true);\n								}\n						},\n						onresize_end: function(name, elt, state, options, layout)\n						{\n								if (state.isSliding == false)\n								{\n									SetUserPreference(\'menu_size\', state.size, true);\n								}\n						},\n									\n						onopen_end: function(name, elt, state, options, layout)\n						{\n							if (state.isSliding == false)\n							{\n								$(\'.menu-pane-exclusive\').hide();\n								SetUserPreference(\'menu_pane\', \'open\', true);\n							}\n						}\n					},\n			center: {\n						onresize_end: function(name, elt, state, options, layout)\n						{\n								$(\'.v-resizable\').each( function() {\n									var fixedWidth = $(this).parent().innerWidth() - 6;\n									$(this).width(fixedWidth);\n									// Make sure it cannot be resized horizontally\n									$(this).resizable(\'options\', { minWidth: fixedWidth, maxWidth:	fixedWidth });\n									// Now adjust all the child \'items\'\n									var innerWidth = $(this).innerWidth() - 10;\n									$(this).find(\'.item\').width(innerWidth);\n								});\n								$(\'.panel-resized\').trigger(\'resized\');\n						}\n				\n					}\n		});\n		window.clearTimeout(iPaneVisWatchDog);\n		//myLayout.open( \"west\" );\n		$(\'.ui-layout-resizer-west .ui-layout-toggler\').css({background: \'transparent\'});\n						myLayout.addPinBtn( \"#tPinMenu\", \"west\" );\n		\n		$(\'#left-pane\').layout({ resizable: false, spacing_open: 0, south: { size: 94 }, enableCursorHotkey: false });\n		\n		// Tabs, using JQuery BBQ to store the history\n		// The \"tab widgets\" to handle.\n		var tabs = $(\'div[id^=tabbedContent]\');\n			\n		// This selector will be reused when selecting actual tab widget A elements.\n		var tab_a_selector = \'ul.ui-tabs-nav a\';\n		  \n		// Ugly patch for a change in the behavior of jQuery UI:\n		// Before jQuery UI 1.9, tabs were always considered as \"local\" (opposed to Ajax)\n		// when their href was beginning by #. Starting with 1.9, a <base> tag in the page\n		// is taken into account and causes \"local\" tabs to be considered as Ajax\n		// unless their URL is equal to the URL of the page...\n		$(\'div[id^=tabbedContent] > ul > li > a\').each(function() {\n			var sHash = location.hash;\n			var sHref = $(this).attr(\"href\");\n			if (sHref.match(/^#/))\n			{\n				var sCleanLocation = location.href.toString().replace(sHash, \'\').replace(/#$/, \'\');\n				$(this).attr(\"href\", sCleanLocation+$(this).attr(\"href\"));\n			}\n		});\n\n		// Enable tabs on all tab widgets. The `event` property must be overridden so\n		// that the tabs aren\'t changed on click, and any custom event name can be\n		// specified. Note that if you define a callback for the \'select\' event, it\n		// will be executed for the selected tab whenever the hash changes.\n		tabs.tabs({\n			event: \'change\', \'show\': function(event, ui) {\n				$(\'.resizable\', ui.panel).resizable(); // Make resizable everything that claims to be resizable !\n			},\n			beforeLoad: function( event, ui ) {\n				if ( ui.tab.data(\'loaded\') && (ui.tab.attr(\'data-cache\') == \'true\')) {\n					event.preventDefault();\n					return;\n				}\n				ui.panel.html(\'<div><img src=\"../images/indicator.gif\"></div>\');\n				ui.jqXHR.success(function() {\n					ui.tab.data( \"loaded\", true );\n				});\n			}\n		});\n\n		$(\'.resizable\').filter(\':visible\').resizable();\n	}\n	catch(err)\n	{\n		// Do something with the error !\n		alert(err);\n	}\";s:10:\"\0*\0m_oTabs\";O:10:\"TabManager\":3:{s:10:\"\0*\0m_aTabs\";a:0:{}s:25:\"\0*\0m_sCurrentTabContainer\";s:0:\"\";s:16:\"\0*\0m_sCurrentTab\";s:0:\"\";}s:21:\"\0*\0bBreadCrumbEnabled\";b:0;s:21:\"\0*\0sBreadCrumbEntryId\";N;s:24:\"\0*\0sBreadCrumbEntryLabel\";N;s:30:\"\0*\0sBreadCrumbEntryDescription\";N;s:22:\"\0*\0sBreadCrumbEntryUrl\";N;s:23:\"\0*\0sBreadCrumbEntryIcon\";N;s:7:\"\0*\0oCtx\";O:10:\"ContextTag\":0:{}s:15:\"m_aReadyScripts\";a:3:{i:0;s:1728:\"	//add new widget called TruncatedList to properly display truncated lists when they are sorted\n	$.tablesorter.addWidget({ \n		// give the widget a id \n		id: \"truncatedList\", \n		// format is called when the on init and when a sorting has finished \n		format: function(table)\n		{ \n			// Check if there is a \"truncated\" line\n			this.truncatedList = false;  \n			if ($(\"tr td.truncated\",table).length > 0)\n			{\n				this.truncatedList = true;\n			}\n			if (this.truncatedList)\n			{\n				$(\"tr td\",table).removeClass(\'truncated\');\n				$(\"tr:last td\",table).addClass(\'truncated\');\n			}\n		} \n	});\n	\n	$.tablesorter.addWidget({ \n		// give the widget a id \n		id: \"myZebra\", \n		// format is called when the on init and when a sorting has finished \n		format: function(table)\n		{\n			// Replace the \'red even\' lines by \'red_even\' since most browser do not support 2 classes selector in CSS, etc..\n			$(\"tbody tr:even\",table).addClass(\'even\');\n			$(\"tbody tr.red:even\",table).removeClass(\'red\').removeClass(\'even\').addClass(\'red_even\');\n			$(\"tbody tr.orange:even\",table).removeClass(\'orange\').removeClass(\'even\').addClass(\'orange_even\');\n			$(\"tbody tr.green:even\",table).removeClass(\'green\').removeClass(\'even\').addClass(\'green_even\');\n			// In case we sort again the table, we need to remove the added \'even\' classes on odd rows\n			$(\"tbody tr:odd\",table).removeClass(\'even\');\n			$(\"tbody tr.red_even:odd\",table).removeClass(\'even\').removeClass(\'red_even\').addClass(\'red\');\n			$(\"tbody tr.orange_even:odd\",table).removeClass(\'even\').removeClass(\'orange_even\').addClass(\'orange\');\n			$(\"tbody tr.green_even:odd\",table).removeClass(\'even\').removeClass(\'green_even\').addClass(\'green\');\n		} \n	});\n	$(\"table.listResults\").tableHover(); // hover tables\";i:1;s:5505:\"	\n	// Adjust initial size\n	$(\'.v-resizable\').each( function()\n		{\n			var parent_id = $(this).parent().id;\n			// Restore the saved height\n			var iHeight = GetUserPreference(parent_id+\'_\'+this.id+\'_height\', undefined);\n			if (iHeight != undefined)\n			{\n				$(this).height(parseInt(iHeight, 10)); // Parse in base 10 !);\n			}\n			// Adjust the child \'item\'\'s height and width to fit\n			var container = $(this);\n			var fixedWidth = container.parent().innerWidth() - 6;\n			// Set the width to fit the parent\n			$(this).width(fixedWidth);\n			var headerHeight = $(this).find(\'.drag_handle\').height();\n			// Now adjust the width and height of the child \'item\'\n			container.find(\'.item\').height(container.innerHeight() - headerHeight - 12).width(fixedWidth - 10);\n		}\n	);\n	// Make resizable, vertically only everything that claims to be v-resizable !\n	$(\'.v-resizable\').resizable( { handles: \'s\', minHeight: $(this).find(\'.drag_handle\').height(), minWidth: $(this).parent().innerWidth() - 6, maxWidth: $(this).parent().innerWidth() - 6, stop: function()\n		{\n			// Adjust the content\n			var container = $(this);\n			var headerHeight = $(this).find(\'.drag_handle\').height();\n			container.find(\'.item\').height(container.innerHeight() - headerHeight - 12);//.width(container.innerWidth());\n			var parent_id = $(this).parent().id;\n			SetUserPreference(parent_id+\'_\'+this.id+\'_height\', $(this).height(), true); // true => persistent\n		}\n	} );\n		\n	// Tabs, using JQuery BBQ to store the history\n	// The \"tab widgets\" to handle.\n	var tabs = $(\'div[id^=tabbedContent]\');\n		\n	// This selector will be reused when selecting actual tab widget A elements.\n	var tab_a_selector = \'ul.ui-tabs-nav a\';\n	  \n	// Define our own click handler for the tabs, overriding the default.\n	tabs.find( tab_a_selector ).click(function()\n	{\n		var state = {};\n				  \n		// Get the id of this tab widget.\n		var id = $(this).closest( \'div[id^=tabbedContent]\' ).attr( \'id\' );\n		  \n		// Get the index of this tab.\n		var idx = $(this).parent().prevAll().length;\n		\n		// Set the state!\n		state[ id ] = idx;\n		$.bbq.pushState( state );\n	});\n	\n	// refresh the hash when the tab is changed (from a JS script)\n	$(\'body\').on( \'tabsactivate\', \'.ui-tabs\', function(event, ui) {\n		var state = {};\n			\n		// Get the id of this tab widget.\n		var id = $(ui.newTab).closest( \'div[id^=tabbedContent]\' ).attr( \'id\' );\n		\n		// Get the index of this tab.\n		var idx = $(ui.newTab).prevAll().length;\n			\n		// Set the state!\n		state[ id ] = idx;\n		$.bbq.pushState( state );\n	});\n	\n	// Bind an event to window.onhashchange that, when the history state changes,\n	// iterates over all tab widgets, changing the current tab as necessary.\n	$(window).bind( \'hashchange\', function(e)\n	{\n		// Iterate over all tab widgets.\n		tabs.each(function()\n		{  \n			// Get the index for this tab widget from the hash, based on the\n			// appropriate id property. In jQuery 1.4, you should use e.getState()\n			// instead of $.bbq.getState(). The second, \'true\' argument coerces the\n			// string value to a number.\n			var idx = $.bbq.getState( this.id, true ) || 0;\n			  \n			// Select the appropriate tab for this tab widget by triggering the custom\n			// event specified in the .tabs() init above (you could keep track of what\n			// tab each widget is on using .data, and only select a tab if it has\n			// changed).\n			$(this).find( tab_a_selector ).eq( idx ).triggerHandler( \'change\' );\n		});\n\n		// Iterate over all truncated lists to find whether they are expanded or not\n		$(\'a.truncated\').each(function()\n		{\n			var state = $.bbq.getState( this.id, true ) || \'close\';\n			if (state == \'open\')\n			{\n				$(this).trigger(\'open\');\n			}\n			else\n			{\n				$(this).trigger(\'close\');	\n			}\n		});\n	});\n	\n	// Shortcut menu actions\n	$(\'.actions_button a\').click( function() {\n		aMatches = /#(.*)$/.exec(window.location.href);\n		if (aMatches != null)\n		{\n			currentHash = aMatches[1];\n			if ( /#(.*)$/.test(this.href))\n			{\n				this.href = this.href.replace(/#(.*)$/, \'#\'+currentHash);\n			}\n		}\n	});\n\n	// End of Tabs handling\n\n	PrepareWidgets();\n\n	// Make sortable, everything that claims to be sortable\n	$(\'.sortable\').sortable( {axis: \'y\', cursor: \'move\', handle: \'.drag_handle\', stop: function()\n		{\n			if ($(this).hasClass(\'persistent\'))\n			{\n				// remember the sort order for next time the page is loaded...\n				sSerialized = $(this).sortable(\'serialize\', {key: \'menu\'});\n				var sTemp = sSerialized.replace(/menu=/g, \'\');\n				SetUserPreference(this.id+\'_order\', sTemp.replace(/&/g, \',\'), true); // true => persistent !\n			}\n		}\n	});\n	docWidth = $(document).width();\n	$(\'#ModalDlg\').dialog({ autoOpen: false, modal: true, width: 0.8*docWidth }); // JQuery UI dialogs\n	ShowDebug();\n	$(\'#logOffBtn>ul\').popupmenu();\n	\n	$(\'.caselog_header\').click( function () { $(this).toggleClass(\'open\').next(\'.caselog_entry,.caselog_entry_html\').toggle(); });\n	\n	$(document).ajaxSend(function(event, jqxhr, options) {\n		jqxhr.setRequestHeader(\'X-Combodo-Ajax\', \'true\');\n	});\n	$(document).ajaxError(function(event, jqxhr, options) {\n		if (jqxhr.status == 401)\n		{\n			$(\'<div>\'+\"You are disconnected. You must identify yourself to continue using the application.\"+\'</div>\').dialog({\n				modal:true,\n				title: \"Warning!\",\n				close: function() { $(this).remove(); },\n				minWidth: 400,\n				buttons: [\n					{ text: \"Login again\", click: function() { window.location.href= GetAbsoluteUrlAppRoot()+\'pages/UI.php\' } },\n					{ text: \"Stay on this page\", click: function() { $(this).dialog(\'close\'); } }\n				]\n			});\n		}\n	});\";i:2;s:285:\"$(\'img[data-img-id]\').each(function() {\n	if ($(this).width() > 250)\n	{\n		$(this).css({\'max-width\': \'250px\', width: \'\', height: \'\', \'max-height\': \'\'});\n	}\n	$(this).addClass(\'inline-image\').attr(\'href\', $(this).attr(\'src\'));\n}).magnificPopup({type: \'image\', closeOnContentClick: true });\";}s:10:\"m_sRootUrl\";s:23:\"https://alltic.co/itsm/\";s:10:\"\0*\0s_title\";s:32:\"iTop - Creación de Solicitudes \";s:12:\"\0*\0s_content\";s:195:\"<h1><img src=\"https://alltic.co/itsm/env-production/itop-request-mgmt-itil/images/user-request.png\" style=\"vertical-align:middle;\"/>&nbsp;Creación de Solicitudes</h1>\n<div class=\"wizContainer\">\n\";s:21:\"\0*\0s_deferred_content\";s:0:\"\";s:12:\"\0*\0a_scripts\";a:4:{i:0;s:860:\"function GetAbsoluteUrlAppRoot()\n{\n	return \'https://alltic.co/itsm/\';\n}\n\nfunction GetAbsoluteUrlModulesRoot()\n{\n	return \'https://alltic.co/itsm/env-production/\';\n}\n\nfunction GetAbsoluteUrlModulePage(sModule, sPage, aArguments)\n{\n	// aArguments is optional, it default to an empty hash\n	aArguments = typeof aArguments !== \'undefined\' ? aArguments : {};\n\n	var sUrl = \'https://alltic.co/itsm/\'+\'pages/exec.php?exec_module=\'+sModule+\'&exec_page=\'+sPage+\'&exec_env=\'+\'production\';\n	for (var sArgName in aArguments)\n	{\n		if (aArguments.hasOwnProperty(sArgName))\n		{\n			sUrl = sUrl + \'&\'+sArgName+\'=\'+aArguments[sArgname];\n		}\n	}\n	return sUrl;\n}\n\nfunction AddAppContext(sURL)\n{\n	var sContext = \'c[menu]=NewUserRequest\';\n	if (sContext.length > 0)\n	{\n		if (sURL.indexOf(\'?\') == -1)\n		{\n			return sURL+\'?\'+sContext;\n		}				\n		return sURL+\'&\'+sContext;\n	}\n	return sURL;\n}\";i:1;s:1971:\"	function PrepareWidgets()\n	{\n		// note: each action implemented here must be idempotent,\n		//       because this helper function might be called several times on a given page \n	\n		$(\".date-pick\").datepicker({\"showOn\":\"button\",\"buttonImage\":\"..\\/images\\/calendar.png\",\"buttonImageOnly\":true,\"dateFormat\":\"yy-mm-dd\",\"constrainInput\":false,\"changeMonth\":true,\"changeYear\":true,\"dayNamesMin\":[\"Su\",\"Mo\",\"Tu\",\"We\",\"Th\",\"Fr\",\"Sa\"],\"monthNamesShort\":[\"Jan\",\"Feb\",\"Mar\",\"Apr\",\"May\",\"Jun\",\"Jul\",\"Aug\",\"Sep\",\"Oct\",\"Nov\",\"Dec\"],\"firstDay\":0});\n	\n		// Hack for the date and time picker addon issue on Chrome (see #1305)\n		// The workaround is to instantiate the widget on demand\n		// It relies on the same markup, thus reverting to the original implementation should be straightforward\n		$(\".datetime-pick:not(.is-widget-ready)\").each(function(){\n			var oInput = this;\n			$(oInput).addClass(\'is-widget-ready\');\n			$(\'<img class=\"datetime-pick-button\" src=\"../images/calendar.png\">\')\n				.insertAfter($(this))\n				.on(\'click\', function(){\n					$(oInput)\n						.datetimepicker({\"showOn\":\"\",\"buttonImage\":null,\"buttonImageOnly\":true,\"dateFormat\":\"yy-mm-dd\",\"constrainInput\":false,\"changeMonth\":true,\"changeYear\":true,\"dayNamesMin\":[\"Su\",\"Mo\",\"Tu\",\"We\",\"Th\",\"Fr\",\"Sa\"],\"monthNamesShort\":[\"Jan\",\"Feb\",\"Mar\",\"Apr\",\"May\",\"Jun\",\"Jul\",\"Aug\",\"Sep\",\"Oct\",\"Nov\",\"Dec\"],\"firstDay\":0,\"timeFormat\":\"HH:mm:ss\",\"controlType\":\"select\",\"closeText\":\"Ok\",\n				\'timeText\': $.timepicker.regional[\"es\"].timeText,\n				\'hourText\': $.timepicker.regional[\"es\"].hourText,\n				\'minuteText\': $.timepicker.regional[\"es\"].minuteText,\n				\'secondText\': $.timepicker.regional[\"es\"].secondText,\n				\'currentText\': $.timepicker.regional[\"es\"].currentText\n			})\n						.datetimepicker(\'show\')\n						.datetimepicker(\'option\', \'onClose\', function(dateText,inst){\n							$(oInput).datetimepicker(\'destroy\');\n						})\n						.on(\'click keypress\', function(){\n							$(oInput).datetimepicker(\'hide\');\n						});\n				});\n		});\n	}\";i:2;s:1734:\"//		// for JQuery history\n//		function history_callback(hash)\n//		{\n//			// do stuff that loads page content based on hash variable\n//			var aMatches = /^tab_(.*)$/.exec(hash);\n//			if (aMatches != null)\n//			{\n//				var tab = $(\'#\'+hash);\n//				tab.parents(\'div[id^=tabbedContent]:first\').tabs(\'select\', aMatches[1]);\n//			}\n//		}\n\n		function goBack()\n		{\n			window.history.back();\n		}\n		\n		function BackToDetails(sClass, id, sDefaultUrl, sOwnershipToken)\n		{\n			window.bInCancel = true;\n			if (id > 0)\n			{\n				sToken = \'\';\n				if (sOwnershipToken != undefined)\n				{\n					sToken = \'&token=\'+sOwnershipToken;\n				}\n				window.location.href = AddAppContext(GetAbsoluteUrlAppRoot()+\'pages/UI.php?operation=release_lock_and_details&class=\'+sClass+\'&id=\'+id+sToken);\n			}\n			else\n			{\n				window.location.href = sDefaultUrl; // Already contains the context...				\n			}\n		}\n\n		function BackToList(sClass)\n		{\n			window.location.href = AddAppContext(GetAbsoluteUrlAppRoot()+\'pages/UI.php?operation=search_oql&oql_class=\'+sClass+\'&oql_clause=WHERE id=0\');\n		}\n		\n		function ShowDebug()\n		{\n			if ($(\'#rawOutput > div\').html() != \'\')\n			{\n				$(\'#rawOutput\').dialog( {autoOpen: true, modal:false, width: \'80%\'});\n			}\n		}\n		\n		var oUserPreferences = {\"welcome_popup\":\"0\",\"menu_pane\":\"open\",\"menu_size\":\"421\"};\n\n		// For disabling the CKEditor at init time when the corresponding textarea is disabled !\n		CKEDITOR.plugins.add( \'disabler\',\n		{\n			init : function( editor )\n			{\n				editor.on( \'instanceReady\', function(e)\n				{\n					e.removeListener();\n					$(\'#\'+ editor.name).trigger(\'update\');\n				});\n			}\n			\n		});\n\n		\n		function FixPaneVis()\n		{\n			$(\'.ui-layout-center, .ui-layout-north, .ui-layout-south\').css({display: \'block\'});\n		}\";i:3;s:172:\"function ShowAboutBox()\n{\n	$.post(GetAbsoluteUrlAppRoot()+\'pages/ajax.render.php\', {operation: \'about_box\'}, function(data){\n		$(\'body\').append(data);\n	});\n	return false;\n}\";}s:17:\"\0*\0a_dict_entries\";a:3:{s:25:\"UI:FillAllMandatoryFields\";s:41:\"Por favor llenar los campos obligatorios.\";s:16:\"UI:Button:Cancel\";s:8:\"Cancelar\";s:14:\"UI:Button:Done\";s:5:\"Listo\";}s:11:\"\0*\0a_styles\";a:0:{}s:20:\"\0*\0a_include_scripts\";N;s:24:\"\0*\0a_include_stylesheets\";N;s:12:\"\0*\0a_headers\";a:2:{i:0;s:38:\"Content-type: text/html; charset=utf-8\";i:1;s:23:\"Cache-control: no-cache\";}s:9:\"\0*\0a_base\";a:2:{s:4:\"href\";s:0:\"\";s:6:\"target\";s:0:\"\";}s:10:\"\0*\0iNextId\";i:0;s:17:\"\0*\0iTransactionId\";i:0;s:15:\"\0*\0sContentType\";s:0:\"\";s:22:\"\0*\0sContentDisposition\";s:0:\"\";s:19:\"\0*\0sContentFileName\";s:0:\"\";s:25:\"\0*\0bTrashUnexpectedOutput\";b:0;s:18:\"\0*\0s_sOutputFormat\";N;s:18:\"\0*\0a_OutputOptions\";a:0:{}s:13:\"\0*\0bPrintable\";b:0;s:16:\"a_linked_scripts\";a:43:{s:46:\"https://alltic.co/itsm/js/jquery-1.10.0.min.js\";s:46:\"https://alltic.co/itsm/js/jquery-1.10.0.min.js\";s:53:\"https://alltic.co/itsm/js/jquery-migrate-1.2.1.min.js\";s:53:\"https://alltic.co/itsm/js/jquery-migrate-1.2.1.min.js\";s:56:\"https://alltic.co/itsm/js/jquery-ui-1.10.3.custom.min.js\";s:56:\"https://alltic.co/itsm/js/jquery-ui-1.10.3.custom.min.js\";s:37:\"https://alltic.co/itsm/js/hovertip.js\";s:37:\"https://alltic.co/itsm/js/hovertip.js\";s:47:\"https://alltic.co/itsm/js/jquery.tablesorter.js\";s:47:\"https://alltic.co/itsm/js/jquery.tablesorter.js\";s:53:\"https://alltic.co/itsm/js/jquery.tablesorter.pager.js\";s:53:\"https://alltic.co/itsm/js/jquery.tablesorter.pager.js\";s:46:\"https://alltic.co/itsm/js/jquery.tablehover.js\";s:46:\"https://alltic.co/itsm/js/jquery.tablehover.js\";s:41:\"https://alltic.co/itsm/js/field_sorter.js\";s:41:\"https://alltic.co/itsm/js/field_sorter.js\";s:38:\"https://alltic.co/itsm/js/datatable.js\";s:38:\"https://alltic.co/itsm/js/datatable.js\";s:46:\"https://alltic.co/itsm/js/jquery.positionBy.js\";s:46:\"https://alltic.co/itsm/js/jquery.positionBy.js\";s:45:\"https://alltic.co/itsm/js/jquery.popupmenu.js\";s:45:\"https://alltic.co/itsm/js/jquery.popupmenu.js\";s:26:\"../js/jquery.layout.min.js\";s:26:\"../js/jquery.layout.min.js\";s:26:\"../js/jquery.ba-bbq.min.js\";s:26:\"../js/jquery.ba-bbq.min.js\";s:24:\"../js/jquery.treeview.js\";s:24:\"../js/jquery.treeview.js\";s:28:\"../js/jquery.autocomplete.js\";s:28:\"../js/jquery.autocomplete.js\";s:13:\"../js/date.js\";s:13:\"../js/date.js\";s:35:\"../js/jquery-ui-timepicker-addon.js\";s:35:\"../js/jquery-ui-timepicker-addon.js\";s:44:\"../js/jquery-ui-timepicker-addon-i18n.min.js\";s:44:\"../js/jquery-ui-timepicker-addon-i18n.min.js\";s:23:\"../js/jquery.blockUI.js\";s:23:\"../js/jquery.blockUI.js\";s:14:\"../js/utils.js\";s:14:\"../js/utils.js\";s:18:\"../js/swfobject.js\";s:18:\"../js/swfobject.js\";s:26:\"../js/ckeditor/ckeditor.js\";s:26:\"../js/ckeditor/ckeditor.js\";s:33:\"../js/ckeditor/adapters/jquery.js\";s:33:\"../js/ckeditor/adapters/jquery.js\";s:28:\"../js/jquery.qtip-1.0.min.js\";s:28:\"../js/jquery.qtip-1.0.min.js\";s:23:\"../js/property_field.js\";s:23:\"../js/property_field.js\";s:16:\"../js/fg.menu.js\";s:16:\"../js/fg.menu.js\";s:20:\"../js/icon_select.js\";s:20:\"../js/icon_select.js\";s:20:\"../js/raphael-min.js\";s:20:\"../js/raphael-min.js\";s:11:\"../js/d3.js\";s:11:\"../js/d3.js\";s:11:\"../js/c3.js\";s:11:\"../js/c3.js\";s:27:\"../js/jquery.multiselect.js\";s:27:\"../js/jquery.multiselect.js\";s:23:\"../js/ajaxfileupload.js\";s:23:\"../js/ajaxfileupload.js\";s:26:\"../js/jquery.mousewheel.js\";s:26:\"../js/jquery.mousewheel.js\";s:34:\"../js/jquery.magnific-popup.min.js\";s:34:\"../js/jquery.magnific-popup.min.js\";s:19:\"../js/breadcrumb.js\";s:19:\"../js/breadcrumb.js\";s:19:\"../js/moment.min.js\";s:19:\"../js/moment.min.js\";s:13:\"../js/json.js\";s:13:\"../js/json.js\";s:25:\"../js/forms-json-utils.js\";s:25:\"../js/forms-json-utils.js\";s:21:\"../js/wizardhelper.js\";s:21:\"../js/wizardhelper.js\";s:21:\"../js/wizard.utils.js\";s:21:\"../js/wizard.utils.js\";s:20:\"../js/linkswidget.js\";s:20:\"../js/linkswidget.js\";s:26:\"../js/linksdirectwidget.js\";s:26:\"../js/linksdirectwidget.js\";s:21:\"../js/extkeywidget.js\";s:21:\"../js/extkeywidget.js\";}s:20:\"a_linked_stylesheets\";a:9:{i:0;a:2:{s:4:\"link\";s:71:\"https://alltic.co/itsm/css/ui-lightness/jquery-ui-1.10.3.custom.min.css\";s:9:\"condition\";s:0:\"\";}i:1;a:2:{s:4:\"link\";s:41:\"https://alltic.co/itsm/css/light-grey.css\";s:9:\"condition\";s:0:\"\";}i:2;a:2:{s:4:\"link\";s:26:\"../css/jquery.treeview.css\";s:9:\"condition\";s:0:\"\";}i:3;a:2:{s:4:\"link\";s:30:\"../css/jquery.autocomplete.css\";s:9:\"condition\";s:0:\"\";}i:4;a:2:{s:4:\"link\";s:37:\"../css/jquery-ui-timepicker-addon.css\";s:9:\"condition\";s:0:\"\";}i:5;a:2:{s:4:\"link\";s:18:\"../css/fg.menu.css\";s:9:\"condition\";s:0:\"\";}i:6;a:2:{s:4:\"link\";s:29:\"../css/jquery.multiselect.css\";s:9:\"condition\";s:0:\"\";}i:7;a:2:{s:4:\"link\";s:25:\"../css/magnific-popup.css\";s:9:\"condition\";s:0:\"\";}i:8;a:2:{s:4:\"link\";s:17:\"../css/c3.min.css\";s:9:\"condition\";s:0:\"\";}}s:14:\"s_OutputFormat\";s:4:\"html\";}i:1;s:11:\"UserRequest\";i:2;O:11:\"UserRequest\":22:{s:12:\"\0*\0m_iFormId\";N;s:13:\"\0*\0aFieldsMap\";N;s:14:\"\0*\0bAllowWrite\";b:0;s:15:\"\0*\0m_datCreated\";N;s:15:\"\0*\0m_datUpdated\";N;s:19:\"\0DBObject\0m_bIsInDB\";b:0;s:16:\"\0DBObject\0m_iKey\";i:-1;s:23:\"\0DBObject\0m_aCurrValues\";a:79:{s:18:\"operational_status\";s:7:\"ongoing\";s:3:\"ref\";s:0:\"\";s:6:\"org_id\";i:0;s:8:\"org_name\";s:0:\"\";s:9:\"caller_id\";i:0;s:11:\"caller_name\";s:0:\"\";s:7:\"team_id\";i:0;s:9:\"team_name\";s:0:\"\";s:8:\"agent_id\";i:0;s:10:\"agent_name\";s:0:\"\";s:5:\"title\";s:0:\"\";s:11:\"description\";s:0:\"\";s:10:\"start_date\";N;s:8:\"end_date\";N;s:11:\"last_update\";N;s:10:\"close_date\";N;s:11:\"private_log\";O:10:\"ormCaseLog\":3:{s:9:\"\0*\0m_sLog\";s:0:\"\";s:11:\"\0*\0m_aIndex\";a:0:{}s:14:\"\0*\0m_bModified\";b:0;}s:13:\"contacts_list\";O:11:\"DBObjectSet\":14:{s:14:\"\0*\0m_aAddedIds\";a:0:{}s:18:\"\0*\0m_aAddedObjects\";a:0:{}s:10:\"\0*\0m_aArgs\";a:0:{}s:15:\"\0*\0m_aAttToLoad\";N;s:13:\"\0*\0m_aOrderBy\";a:0:{}s:9:\"m_bLoaded\";b:1;s:20:\"\0*\0m_iNumTotalDBRows\";i:0;s:21:\"\0*\0m_iNumLoadedDBRows\";i:0;s:13:\"\0*\0m_iCurrRow\";i:0;s:12:\"\0*\0m_oFilter\";O:14:\"DBObjectSearch\":11:{s:26:\"\0DBObjectSearch\0m_aClasses\";a:1:{s:18:\"lnkContactToTicket\";s:18:\"lnkContactToTicket\";}s:34:\"\0DBObjectSearch\0m_aSelectedClasses\";a:1:{s:18:\"lnkContactToTicket\";s:18:\"lnkContactToTicket\";}s:34:\"\0DBObjectSearch\0m_oSearchCondition\";O:15:\"FalseExpression\":1:{s:10:\"\0*\0m_value\";i:0;}s:25:\"\0DBObjectSearch\0m_aParams\";a:0:{}s:27:\"\0DBObjectSearch\0m_aFullText\";a:0:{}s:29:\"\0DBObjectSearch\0m_aPointingTo\";a:0:{}s:31:\"\0DBObjectSearch\0m_aReferencedBy\";a:0:{}s:18:\"\0*\0m_bAllowAllData\";b:0;s:18:\"\0*\0m_bDataFiltered\";b:0;s:25:\"\0*\0m_bNoContextParameters\";b:0;s:24:\"\0*\0m_aModifierProperties\";a:0:{}}s:15:\"\0*\0m_oSQLResult\";N;s:19:\"m_aExtendedDataSpec\";N;s:13:\"m_iLimitCount\";i:0;s:13:\"m_iLimitStart\";i:0;}s:18:\"functionalcis_list\";O:11:\"DBObjectSet\":14:{s:14:\"\0*\0m_aAddedIds\";a:0:{}s:18:\"\0*\0m_aAddedObjects\";a:0:{}s:10:\"\0*\0m_aArgs\";a:0:{}s:15:\"\0*\0m_aAttToLoad\";N;s:13:\"\0*\0m_aOrderBy\";a:0:{}s:9:\"m_bLoaded\";b:1;s:20:\"\0*\0m_iNumTotalDBRows\";i:0;s:21:\"\0*\0m_iNumLoadedDBRows\";i:0;s:13:\"\0*\0m_iCurrRow\";i:0;s:12:\"\0*\0m_oFilter\";O:14:\"DBObjectSearch\":11:{s:26:\"\0DBObjectSearch\0m_aClasses\";a:1:{s:23:\"lnkFunctionalCIToTicket\";s:23:\"lnkFunctionalCIToTicket\";}s:34:\"\0DBObjectSearch\0m_aSelectedClasses\";a:1:{s:23:\"lnkFunctionalCIToTicket\";s:23:\"lnkFunctionalCIToTicket\";}s:34:\"\0DBObjectSearch\0m_oSearchCondition\";O:15:\"FalseExpression\":1:{s:10:\"\0*\0m_value\";i:0;}s:25:\"\0DBObjectSearch\0m_aParams\";a:0:{}s:27:\"\0DBObjectSearch\0m_aFullText\";a:0:{}s:29:\"\0DBObjectSearch\0m_aPointingTo\";a:0:{}s:31:\"\0DBObjectSearch\0m_aReferencedBy\";a:0:{}s:18:\"\0*\0m_bAllowAllData\";b:0;s:18:\"\0*\0m_bDataFiltered\";b:0;s:25:\"\0*\0m_bNoContextParameters\";b:0;s:24:\"\0*\0m_aModifierProperties\";a:0:{}}s:15:\"\0*\0m_oSQLResult\";N;s:19:\"m_aExtendedDataSpec\";N;s:13:\"m_iLimitCount\";i:0;s:13:\"m_iLimitStart\";i:0;}s:15:\"workorders_list\";O:11:\"DBObjectSet\":14:{s:14:\"\0*\0m_aAddedIds\";a:0:{}s:18:\"\0*\0m_aAddedObjects\";a:0:{}s:10:\"\0*\0m_aArgs\";a:0:{}s:15:\"\0*\0m_aAttToLoad\";N;s:13:\"\0*\0m_aOrderBy\";a:0:{}s:9:\"m_bLoaded\";b:1;s:20:\"\0*\0m_iNumTotalDBRows\";i:0;s:21:\"\0*\0m_iNumLoadedDBRows\";i:0;s:13:\"\0*\0m_iCurrRow\";i:0;s:12:\"\0*\0m_oFilter\";O:14:\"DBObjectSearch\":11:{s:26:\"\0DBObjectSearch\0m_aClasses\";a:1:{s:9:\"WorkOrder\";s:9:\"WorkOrder\";}s:34:\"\0DBObjectSearch\0m_aSelectedClasses\";a:1:{s:9:\"WorkOrder\";s:9:\"WorkOrder\";}s:34:\"\0DBObjectSearch\0m_oSearchCondition\";O:15:\"FalseExpression\":1:{s:10:\"\0*\0m_value\";i:0;}s:25:\"\0DBObjectSearch\0m_aParams\";a:0:{}s:27:\"\0DBObjectSearch\0m_aFullText\";a:0:{}s:29:\"\0DBObjectSearch\0m_aPointingTo\";a:0:{}s:31:\"\0DBObjectSearch\0m_aReferencedBy\";a:0:{}s:18:\"\0*\0m_bAllowAllData\";b:0;s:18:\"\0*\0m_bDataFiltered\";b:0;s:25:\"\0*\0m_bNoContextParameters\";b:0;s:24:\"\0*\0m_aModifierProperties\";a:0:{}}s:15:\"\0*\0m_oSQLResult\";N;s:19:\"m_aExtendedDataSpec\";N;s:13:\"m_iLimitCount\";i:0;s:13:\"m_iLimitStart\";i:0;}s:6:\"status\";s:3:\"new\";s:12:\"request_type\";s:15:\"service_request\";s:6:\"impact\";s:1:\"2\";s:8:\"priority\";s:1:\"4\";s:7:\"urgency\";s:1:\"4\";s:6:\"origin\";s:5:\"phone\";s:11:\"approver_id\";i:0;s:14:\"approver_email\";s:0:\"\";s:16:\"servicefamily_id\";i:0;s:18:\"servicefamily_name\";s:0:\"\";s:10:\"service_id\";i:0;s:12:\"service_name\";s:0:\"\";s:21:\"servicesubcategory_id\";i:0;s:23:\"servicesubcategory_name\";s:0:\"\";s:15:\"escalation_flag\";s:2:\"no\";s:17:\"escalation_reason\";s:0:\"\";s:15:\"assignment_date\";N;s:15:\"resolution_date\";N;s:17:\"last_pending_date\";N;s:16:\"cumulatedpending\";O:12:\"ormStopWatch\":5:{s:13:\"\0*\0iTimeSpent\";i:0;s:11:\"\0*\0iStarted\";N;s:13:\"\0*\0iLastStart\";N;s:11:\"\0*\0iStopped\";N;s:14:\"\0*\0aThresholds\";a:0:{}}s:3:\"tto\";O:12:\"ormStopWatch\":5:{s:13:\"\0*\0iTimeSpent\";i:0;s:11:\"\0*\0iStarted\";N;s:13:\"\0*\0iLastStart\";N;s:11:\"\0*\0iStopped\";N;s:14:\"\0*\0aThresholds\";a:2:{i:75;a:4:{s:8:\"deadline\";N;s:9:\"triggered\";b:0;s:7:\"overrun\";N;s:9:\"highlight\";N;}i:100;a:4:{s:8:\"deadline\";N;s:9:\"triggered\";b:0;s:7:\"overrun\";N;s:9:\"highlight\";N;}}}s:3:\"ttr\";O:12:\"ormStopWatch\":5:{s:13:\"\0*\0iTimeSpent\";i:0;s:11:\"\0*\0iStarted\";N;s:13:\"\0*\0iLastStart\";N;s:11:\"\0*\0iStopped\";N;s:14:\"\0*\0aThresholds\";a:2:{i:75;a:4:{s:8:\"deadline\";N;s:9:\"triggered\";b:0;s:7:\"overrun\";N;s:9:\"highlight\";N;}i:100;a:4:{s:8:\"deadline\";N;s:9:\"triggered\";b:0;s:7:\"overrun\";N;s:9:\"highlight\";N;}}}s:23:\"tto_escalation_deadline\";N;s:14:\"sla_tto_passed\";N;s:12:\"sla_tto_over\";N;s:23:\"ttr_escalation_deadline\";N;s:14:\"sla_ttr_passed\";N;s:12:\"sla_ttr_over\";N;s:10:\"time_spent\";N;s:15:\"resolution_code\";N;s:8:\"solution\";s:0:\"\";s:14:\"pending_reason\";s:0:\"\";s:17:\"parent_request_id\";i:0;s:18:\"parent_request_ref\";s:0:\"\";s:18:\"parent_incident_id\";i:0;s:19:\"parent_incident_ref\";s:0:\"\";s:17:\"parent_problem_id\";i:0;s:18:\"parent_problem_ref\";s:0:\"\";s:16:\"parent_change_id\";i:0;s:17:\"parent_change_ref\";s:0:\"\";s:20:\"related_request_list\";O:11:\"DBObjectSet\":14:{s:14:\"\0*\0m_aAddedIds\";a:0:{}s:18:\"\0*\0m_aAddedObjects\";a:0:{}s:10:\"\0*\0m_aArgs\";a:0:{}s:15:\"\0*\0m_aAttToLoad\";N;s:13:\"\0*\0m_aOrderBy\";a:0:{}s:9:\"m_bLoaded\";b:1;s:20:\"\0*\0m_iNumTotalDBRows\";i:0;s:21:\"\0*\0m_iNumLoadedDBRows\";i:0;s:13:\"\0*\0m_iCurrRow\";i:0;s:12:\"\0*\0m_oFilter\";O:14:\"DBObjectSearch\":11:{s:26:\"\0DBObjectSearch\0m_aClasses\";a:1:{s:11:\"UserRequest\";s:11:\"UserRequest\";}s:34:\"\0DBObjectSearch\0m_aSelectedClasses\";a:1:{s:11:\"UserRequest\";s:11:\"UserRequest\";}s:34:\"\0DBObjectSearch\0m_oSearchCondition\";O:15:\"FalseExpression\":1:{s:10:\"\0*\0m_value\";i:0;}s:25:\"\0DBObjectSearch\0m_aParams\";a:0:{}s:27:\"\0DBObjectSearch\0m_aFullText\";a:0:{}s:29:\"\0DBObjectSearch\0m_aPointingTo\";a:0:{}s:31:\"\0DBObjectSearch\0m_aReferencedBy\";a:0:{}s:18:\"\0*\0m_bAllowAllData\";b:0;s:18:\"\0*\0m_bDataFiltered\";b:0;s:25:\"\0*\0m_bNoContextParameters\";b:0;s:24:\"\0*\0m_aModifierProperties\";a:0:{}}s:15:\"\0*\0m_oSQLResult\";N;s:19:\"m_aExtendedDataSpec\";N;s:13:\"m_iLimitCount\";i:0;s:13:\"m_iLimitStart\";i:0;}s:10:\"public_log\";O:10:\"ormCaseLog\":3:{s:9:\"\0*\0m_sLog\";s:0:\"\";s:11:\"\0*\0m_aIndex\";a:0:{}s:14:\"\0*\0m_bModified\";b:0;}s:17:\"user_satisfaction\";s:1:\"1\";s:12:\"user_comment\";s:0:\"\";s:10:\"finalclass\";s:11:\"UserRequest\";s:12:\"friendlyname\";s:0:\"\";s:19:\"org_id_friendlyname\";s:0:\"\";s:22:\"caller_id_friendlyname\";s:0:\"\";s:20:\"team_id_friendlyname\";s:0:\"\";s:21:\"agent_id_friendlyname\";s:0:\"\";s:24:\"approver_id_friendlyname\";s:0:\"\";s:29:\"servicefamily_id_friendlyname\";s:0:\"\";s:23:\"service_id_friendlyname\";s:0:\"\";s:34:\"servicesubcategory_id_friendlyname\";s:0:\"\";s:30:\"parent_request_id_friendlyname\";s:0:\"\";s:31:\"parent_incident_id_friendlyname\";s:0:\"\";s:30:\"parent_problem_id_friendlyname\";s:0:\"\";s:29:\"parent_change_id_friendlyname\";s:0:\"\";s:34:\"parent_change_id_finalclass_recall\";s:6:\"Change\";}s:16:\"\0*\0m_aOrigValues\";a:79:{s:18:\"operational_status\";N;s:3:\"ref\";N;s:6:\"org_id\";N;s:8:\"org_name\";N;s:9:\"caller_id\";N;s:11:\"caller_name\";N;s:7:\"team_id\";N;s:9:\"team_name\";N;s:8:\"agent_id\";N;s:10:\"agent_name\";N;s:5:\"title\";N;s:11:\"description\";N;s:10:\"start_date\";N;s:8:\"end_date\";N;s:11:\"last_update\";N;s:10:\"close_date\";N;s:11:\"private_log\";N;s:13:\"contacts_list\";N;s:18:\"functionalcis_list\";N;s:15:\"workorders_list\";N;s:6:\"status\";N;s:12:\"request_type\";N;s:6:\"impact\";N;s:8:\"priority\";N;s:7:\"urgency\";N;s:6:\"origin\";N;s:11:\"approver_id\";N;s:14:\"approver_email\";N;s:16:\"servicefamily_id\";N;s:18:\"servicefamily_name\";N;s:10:\"service_id\";N;s:12:\"service_name\";N;s:21:\"servicesubcategory_id\";N;s:23:\"servicesubcategory_name\";N;s:15:\"escalation_flag\";N;s:17:\"escalation_reason\";N;s:15:\"assignment_date\";N;s:15:\"resolution_date\";N;s:17:\"last_pending_date\";N;s:16:\"cumulatedpending\";N;s:3:\"tto\";N;s:3:\"ttr\";N;s:23:\"tto_escalation_deadline\";N;s:14:\"sla_tto_passed\";N;s:12:\"sla_tto_over\";N;s:23:\"ttr_escalation_deadline\";N;s:14:\"sla_ttr_passed\";N;s:12:\"sla_ttr_over\";N;s:10:\"time_spent\";N;s:15:\"resolution_code\";N;s:8:\"solution\";N;s:14:\"pending_reason\";N;s:17:\"parent_request_id\";N;s:18:\"parent_request_ref\";N;s:18:\"parent_incident_id\";N;s:19:\"parent_incident_ref\";N;s:17:\"parent_problem_id\";N;s:18:\"parent_problem_ref\";N;s:16:\"parent_change_id\";N;s:17:\"parent_change_ref\";N;s:20:\"related_request_list\";N;s:10:\"public_log\";N;s:17:\"user_satisfaction\";N;s:12:\"user_comment\";N;s:10:\"finalclass\";N;s:12:\"friendlyname\";N;s:19:\"org_id_friendlyname\";N;s:22:\"caller_id_friendlyname\";N;s:20:\"team_id_friendlyname\";N;s:21:\"agent_id_friendlyname\";N;s:24:\"approver_id_friendlyname\";N;s:29:\"servicefamily_id_friendlyname\";N;s:23:\"service_id_friendlyname\";N;s:34:\"servicesubcategory_id_friendlyname\";N;s:30:\"parent_request_id_friendlyname\";N;s:31:\"parent_incident_id_friendlyname\";N;s:30:\"parent_problem_id_friendlyname\";N;s:29:\"parent_change_id_friendlyname\";N;s:34:\"parent_change_id_finalclass_recall\";N;}s:18:\"\0*\0m_aExtendedData\";N;s:18:\"\0DBObject\0m_bDirty\";b:0;s:24:\"\0DBObject\0m_bCheckStatus\";N;s:19:\"\0*\0m_bSecurityIssue\";N;s:17:\"\0*\0m_aCheckIssues\";N;s:18:\"\0*\0m_aDeleteIssues\";N;s:24:\"\0DBObject\0m_bFullyLoaded\";b:0;s:22:\"\0DBObject\0m_aLoadedAtt\";a:53:{s:18:\"operational_status\";b:1;s:3:\"ref\";b:1;s:6:\"org_id\";b:1;s:9:\"caller_id\";b:1;s:7:\"team_id\";b:1;s:8:\"agent_id\";b:1;s:5:\"title\";b:1;s:11:\"description\";b:1;s:10:\"start_date\";b:1;s:8:\"end_date\";b:1;s:11:\"last_update\";b:1;s:10:\"close_date\";b:1;s:11:\"private_log\";b:1;s:13:\"contacts_list\";b:1;s:18:\"functionalcis_list\";b:1;s:15:\"workorders_list\";b:1;s:6:\"status\";b:1;s:12:\"request_type\";b:1;s:6:\"impact\";b:1;s:8:\"priority\";b:1;s:7:\"urgency\";b:1;s:6:\"origin\";b:1;s:11:\"approver_id\";b:1;s:16:\"servicefamily_id\";b:1;s:10:\"service_id\";b:1;s:21:\"servicesubcategory_id\";b:1;s:15:\"escalation_flag\";b:1;s:17:\"escalation_reason\";b:1;s:15:\"assignment_date\";b:1;s:15:\"resolution_date\";b:1;s:17:\"last_pending_date\";b:1;s:16:\"cumulatedpending\";b:1;s:3:\"tto\";b:1;s:3:\"ttr\";b:1;s:23:\"tto_escalation_deadline\";b:1;s:14:\"sla_tto_passed\";b:1;s:12:\"sla_tto_over\";b:1;s:23:\"ttr_escalation_deadline\";b:1;s:14:\"sla_ttr_passed\";b:1;s:12:\"sla_ttr_over\";b:1;s:10:\"time_spent\";b:1;s:15:\"resolution_code\";b:1;s:8:\"solution\";b:1;s:14:\"pending_reason\";b:1;s:17:\"parent_request_id\";b:1;s:18:\"parent_incident_id\";b:1;s:17:\"parent_problem_id\";b:1;s:16:\"parent_change_id\";b:1;s:20:\"related_request_list\";b:1;s:10:\"public_log\";b:1;s:17:\"user_satisfaction\";b:1;s:12:\"user_comment\";b:1;s:10:\"finalclass\";b:1;}s:16:\"\0*\0m_aTouchedAtt\";a:0:{}s:17:\"\0*\0m_aModifiedAtt\";a:0:{}s:17:\"\0*\0m_aSynchroData\";N;s:19:\"\0*\0m_sHighlightCode\";N;s:15:\"\0*\0m_aCallbacks\";a:0:{}}i:3;a:0:{}}}}','a:0:{}');
/*!40000 ALTER TABLE `priv_event_issue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event_loginusage`
--

DROP TABLE IF EXISTS `priv_event_loginusage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_event_loginusage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event_loginusage`
--

LOCK TABLES `priv_event_loginusage` WRITE;
/*!40000 ALTER TABLE `priv_event_loginusage` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_event_loginusage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event_notification`
--

DROP TABLE IF EXISTS `priv_event_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_event_notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trigger_id` int(11) DEFAULT '0',
  `action_id` int(11) DEFAULT '0',
  `object_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `trigger_id` (`trigger_id`),
  KEY `action_id` (`action_id`),
  KEY `object_id` (`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event_notification`
--

LOCK TABLES `priv_event_notification` WRITE;
/*!40000 ALTER TABLE `priv_event_notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_event_notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event_restservice`
--

DROP TABLE IF EXISTS `priv_event_restservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_event_restservice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `operation` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `version` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `json_input` text COLLATE utf8_unicode_ci,
  `code` int(11) DEFAULT '0',
  `json_output` text COLLATE utf8_unicode_ci,
  `provider` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event_restservice`
--

LOCK TABLES `priv_event_restservice` WRITE;
/*!40000 ALTER TABLE `priv_event_restservice` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_event_restservice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event_webservice`
--

DROP TABLE IF EXISTS `priv_event_webservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_event_webservice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `verb` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `result` tinyint(1) DEFAULT '0',
  `log_info` text COLLATE utf8_unicode_ci,
  `log_warning` text COLLATE utf8_unicode_ci,
  `log_error` text COLLATE utf8_unicode_ci,
  `data` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event_webservice`
--

LOCK TABLES `priv_event_webservice` WRITE;
/*!40000 ALTER TABLE `priv_event_webservice` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_event_webservice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_internaluser`
--

DROP TABLE IF EXISTS `priv_internaluser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_internaluser` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reset_pwd_token_hash` tinyblob,
  `reset_pwd_token_salt` tinyblob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_internaluser`
--

LOCK TABLES `priv_internaluser` WRITE;
/*!40000 ALTER TABLE `priv_internaluser` DISABLE KEYS */;
INSERT INTO `priv_internaluser` VALUES (1,'','');
/*!40000 ALTER TABLE `priv_internaluser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_link_action_trigger`
--

DROP TABLE IF EXISTS `priv_link_action_trigger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_link_action_trigger` (
  `link_id` int(11) NOT NULL AUTO_INCREMENT,
  `action_id` int(11) DEFAULT '0',
  `trigger_id` int(11) DEFAULT '0',
  `order` int(11) DEFAULT '0',
  PRIMARY KEY (`link_id`),
  KEY `action_id` (`action_id`),
  KEY `trigger_id` (`trigger_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_link_action_trigger`
--

LOCK TABLES `priv_link_action_trigger` WRITE;
/*!40000 ALTER TABLE `priv_link_action_trigger` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_link_action_trigger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_module_install`
--

DROP TABLE IF EXISTS `priv_module_install`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_module_install` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `version` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `installed` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `parent_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_module_install`
--

LOCK TABLES `priv_module_install` WRITE;
/*!40000 ALTER TABLE `priv_module_install` DISABLE KEYS */;
INSERT INTO `priv_module_install` VALUES (1,'datamodel','2.3.0','2018-11-19 15:35:15','{\"source_dir\":\"datamodels\\/2.x\\/\"}',0),(2,'iTop','2.3.4.3302','2018-11-19 15:35:15','Done by the setup program\nBuilt on 2017-04-14 19:00:51',0),(3,'authent-external','2.2.0','2018-11-19 15:35:15','Done by the setup program\nOptional\nVisible (during the setup)',2),(4,'authent-local','2.2.0','2018-11-19 15:35:15','Done by the setup program\nMandatory\nVisible (during the setup)',2),(5,'itop-backup','2.2.0','2018-11-19 15:35:15','Done by the setup program\nMandatory\nHidden (selected automatically)',2),(6,'itop-config','1.0.2','2018-11-19 15:35:15','Done by the setup program\nMandatory\nHidden (selected automatically)',2),(7,'itop-profiles-itil','2.3.0','2018-11-19 15:35:15','Done by the setup program\nMandatory\nHidden (selected automatically)',2),(8,'itop-sla-computation','1.0.0','2018-11-19 15:35:15','Done by the setup program\nMandatory\nHidden (selected automatically)',2),(9,'itop-tickets','2.3.0','2018-11-19 15:35:15','Done by the setup program\nMandatory\nHidden (selected automatically)\nDepends on module: itop-config-mgmt/2.2.0',2),(10,'itop-welcome-itil','2.2.0','2018-11-19 15:35:15','Done by the setup program\nMandatory\nHidden (selected automatically)',2),(11,'combodo-sla-computation','1.0.0','2018-11-19 15:35:15','Done by the setup program\nMandatory\nHidden (selected automatically)\nDepends on module: itop-sla-computation/1.0.0',2),(12,'itop-config-mgmt','2.3.0','2018-11-19 15:35:15','Done by the setup program\nMandatory\nVisible (during the setup)',2),(13,'itop-attachments','2.3.0','2018-11-19 15:35:15','Done by the setup program\nOptional\nVisible (during the setup)',2),(14,'itop-endusers-devices','2.2.0','2018-11-19 15:35:15','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0',2),(15,'itop-storage-mgmt','2.2.0','2018-11-19 15:35:15','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0',2),(16,'itop-virtualization-mgmt','2.2.0','2018-11-19 15:35:15','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0',2),(17,'itop-bridge-virtualization-storage','2.3.0','2018-11-19 15:35:15','Done by the setup program\nOptional\nHidden (selected automatically)\nDepends on module: itop-storage-mgmt/2.2.0\nDepends on module: itop-virtualization-mgmt/2.2.0',2),(18,'itop-service-mgmt-provider','2.3.0','2018-11-19 15:35:15','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0\nDepends on module: itop-tickets/2.0.0',2),(19,'itop-request-mgmt-itil','2.3.0','2018-11-19 15:35:15','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0\nDepends on module: itop-tickets/2.3.0',2),(20,'itop-incident-mgmt-itil','2.3.0','2018-11-19 15:35:15','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0\nDepends on module: itop-tickets/2.3.0\nDepends on module: itop-profiles-itil/1.0.0',2),(21,'itop-portal','1.0.0','2018-11-19 15:35:15','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-portal-base/1.0.0',2),(22,'itop-portal-base','1.0.1','2018-11-19 15:35:15','Done by the setup program\nOptional\nVisible (during the setup)',2),(23,'itop-full-itil','1.0.0','2018-11-19 15:35:15','Done by the setup program\nOptional\nHidden (selected automatically)\nDepends on module: itop-request-mgmt-itil/2.3.0\nDepends on module: itop-incident-mgmt-itil/2.3.0',2),(24,'itop-change-mgmt-itil','2.3.0','2018-11-19 15:35:15','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0\nDepends on module: itop-tickets/2.0.0',2),(25,'itop-knownerror-mgmt','2.3.0','2018-11-19 15:35:15','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0\nDepends on module: itop-tickets/2.3.0',2),(26,'itop-problem-mgmt','2.3.0','2018-11-19 15:35:15','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0\nDepends on module: itop-tickets/2.0.0',2),(27,'combodo-coverage-windows-computation-incident','1.0.0','2018-11-19 15:35:15','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: combodo-sla-computation/1.0.0\nDepends on module: itop-service-mgmt/2.0.0||itop-service-mgmt-provider/2.0.0\nDepends on module: itop-incident-mgmt-itil/2.0.0',2),(28,'combodo-coverage-windows-computation','1.0.0','2018-11-19 15:35:15','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: combodo-sla-computation/1.0.0\nDepends on module: itop-service-mgmt/2.0.0||itop-service-mgmt-provider/2.0.0\nDepends on module: itop-request-mgmt-itil/2.0.0||itop-request-mgmt/2.0.0',2);
/*!40000 ALTER TABLE `priv_module_install` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_ownership_token`
--

DROP TABLE IF EXISTS `priv_ownership_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_ownership_token` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acquired` datetime DEFAULT NULL,
  `last_seen` datetime DEFAULT NULL,
  `obj_class` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `obj_key` int(11) DEFAULT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `user_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_ownership_token`
--

LOCK TABLES `priv_ownership_token` WRITE;
/*!40000 ALTER TABLE `priv_ownership_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_ownership_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_query`
--

DROP TABLE IF EXISTS `priv_query`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_query` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` text COLLATE utf8_unicode_ci,
  `fields` text COLLATE utf8_unicode_ci,
  `realclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Query',
  PRIMARY KEY (`id`),
  KEY `realclass` (`realclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_query`
--

LOCK TABLES `priv_query` WRITE;
/*!40000 ALTER TABLE `priv_query` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_query` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_query_oql`
--

DROP TABLE IF EXISTS `priv_query_oql`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_query_oql` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `oql` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_query_oql`
--

LOCK TABLES `priv_query_oql` WRITE;
/*!40000 ALTER TABLE `priv_query_oql` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_query_oql` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_shortcut`
--

DROP TABLE IF EXISTS `priv_shortcut`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_shortcut` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `context` text COLLATE utf8_unicode_ci,
  `realclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Shortcut',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `realclass` (`realclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_shortcut`
--

LOCK TABLES `priv_shortcut` WRITE;
/*!40000 ALTER TABLE `priv_shortcut` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_shortcut` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_shortcut_oql`
--

DROP TABLE IF EXISTS `priv_shortcut_oql`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_shortcut_oql` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `oql` text COLLATE utf8_unicode_ci,
  `auto_reload` enum('custom','none') COLLATE utf8_unicode_ci DEFAULT 'none',
  `auto_reload_sec` int(11) DEFAULT '60',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_shortcut_oql`
--

LOCK TABLES `priv_shortcut_oql` WRITE;
/*!40000 ALTER TABLE `priv_shortcut_oql` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_shortcut_oql` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_sync_att`
--

DROP TABLE IF EXISTS `priv_sync_att`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_sync_att` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sync_source_id` int(11) DEFAULT '0',
  `attcode` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `update` tinyint(1) DEFAULT '1',
  `reconcile` tinyint(1) DEFAULT '0',
  `update_policy` enum('master_locked','master_unlocked','write_if_empty') COLLATE utf8_unicode_ci DEFAULT 'master_locked',
  `finalclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'SynchroAttribute',
  PRIMARY KEY (`id`),
  KEY `sync_source_id` (`sync_source_id`),
  KEY `finalclass` (`finalclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_sync_att`
--

LOCK TABLES `priv_sync_att` WRITE;
/*!40000 ALTER TABLE `priv_sync_att` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_sync_att` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_sync_att_extkey`
--

DROP TABLE IF EXISTS `priv_sync_att_extkey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_sync_att_extkey` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reconciliation_attcode` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_sync_att_extkey`
--

LOCK TABLES `priv_sync_att_extkey` WRITE;
/*!40000 ALTER TABLE `priv_sync_att_extkey` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_sync_att_extkey` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_sync_att_linkset`
--

DROP TABLE IF EXISTS `priv_sync_att_linkset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_sync_att_linkset` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `row_separator` varchar(255) COLLATE utf8_unicode_ci DEFAULT '|',
  `attribute_separator` varchar(255) COLLATE utf8_unicode_ci DEFAULT ';',
  `value_separator` varchar(255) COLLATE utf8_unicode_ci DEFAULT ':',
  `attribute_qualifier` varchar(255) COLLATE utf8_unicode_ci DEFAULT '''',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_sync_att_linkset`
--

LOCK TABLES `priv_sync_att_linkset` WRITE;
/*!40000 ALTER TABLE `priv_sync_att_linkset` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_sync_att_linkset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_sync_datasource`
--

DROP TABLE IF EXISTS `priv_sync_datasource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_sync_datasource` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` text COLLATE utf8_unicode_ci,
  `status` enum('implementation','obsolete','production') COLLATE utf8_unicode_ci DEFAULT 'implementation',
  `user_id` int(11) DEFAULT '0',
  `notify_contact_id` int(11) DEFAULT '0',
  `scope_class` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'CustomerContract',
  `database_table_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `scope_restriction` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `full_load_periodicity` int(11) unsigned DEFAULT NULL,
  `reconciliation_policy` enum('use_attributes','use_primary_key') COLLATE utf8_unicode_ci DEFAULT 'use_attributes',
  `action_on_zero` enum('create','error') COLLATE utf8_unicode_ci DEFAULT 'create',
  `action_on_one` enum('error','update') COLLATE utf8_unicode_ci DEFAULT 'update',
  `action_on_multiple` enum('create','error','take_first') COLLATE utf8_unicode_ci DEFAULT 'error',
  `delete_policy` enum('delete','ignore','update','update_then_delete') COLLATE utf8_unicode_ci DEFAULT 'ignore',
  `delete_policy_update` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `delete_policy_retention` int(11) unsigned DEFAULT NULL,
  `user_delete_policy` enum('administrators','everybody','nobody') COLLATE utf8_unicode_ci DEFAULT 'nobody',
  `url_icon` varchar(2048) COLLATE utf8_unicode_ci DEFAULT '',
  `url_application` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `notify_contact_id` (`notify_contact_id`),
  KEY `scope_class` (`scope_class`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_sync_datasource`
--

LOCK TABLES `priv_sync_datasource` WRITE;
/*!40000 ALTER TABLE `priv_sync_datasource` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_sync_datasource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_sync_log`
--

DROP TABLE IF EXISTS `priv_sync_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_sync_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sync_source_id` int(11) DEFAULT '0',
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `status` enum('completed','error','running') COLLATE utf8_unicode_ci DEFAULT 'running',
  `status_curr_job` int(11) DEFAULT '0',
  `status_curr_pos` int(11) DEFAULT '0',
  `stats_nb_replica_seen` int(11) DEFAULT '0',
  `stats_nb_replica_total` int(11) DEFAULT '0',
  `stats_nb_obj_deleted` int(11) DEFAULT '0',
  `stats_deleted_errors` int(11) DEFAULT '0',
  `stats_nb_obj_obsoleted` int(11) DEFAULT '0',
  `stats_nb_obj_obsoleted_errors` int(11) DEFAULT '0',
  `stats_nb_obj_created` int(11) DEFAULT '0',
  `stats_nb_obj_created_errors` int(11) DEFAULT '0',
  `stats_nb_obj_created_warnings` int(11) DEFAULT '0',
  `stats_nb_obj_updated` int(11) DEFAULT '0',
  `stats_nb_obj_updated_errors` int(11) DEFAULT '0',
  `stats_nb_obj_updated_warnings` int(11) DEFAULT '0',
  `stats_nb_obj_unchanged_warnings` int(11) DEFAULT '0',
  `stats_nb_replica_reconciled_errors` int(11) DEFAULT '0',
  `stats_nb_replica_disappeared_no_action` int(11) DEFAULT '0',
  `stats_nb_obj_new_updated` int(11) DEFAULT '0',
  `stats_nb_obj_new_updated_warnings` int(11) DEFAULT '0',
  `stats_nb_obj_new_unchanged` int(11) DEFAULT '0',
  `stats_nb_obj_new_unchanged_warnings` int(11) DEFAULT '0',
  `last_error` text COLLATE utf8_unicode_ci,
  `traces` longtext COLLATE utf8_unicode_ci,
  `memory_usage_peak` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sync_source_id` (`sync_source_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_sync_log`
--

LOCK TABLES `priv_sync_log` WRITE;
/*!40000 ALTER TABLE `priv_sync_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_sync_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_sync_replica`
--

DROP TABLE IF EXISTS `priv_sync_replica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_sync_replica` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sync_source_id` int(11) DEFAULT '0',
  `dest_id` int(11) DEFAULT '0',
  `dest_class` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Organization',
  `status_last_seen` datetime DEFAULT NULL,
  `status` enum('modified','new','obsolete','orphan','synchronized') COLLATE utf8_unicode_ci DEFAULT 'new',
  `status_dest_creator` tinyint(1) DEFAULT '0',
  `status_last_error` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `status_last_warning` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `info_creation_date` datetime DEFAULT NULL,
  `info_last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sync_source_id` (`sync_source_id`),
  KEY `dest_class` (`dest_class`),
  KEY `dest_class_dest_id` (`dest_class`,`dest_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_sync_replica`
--

LOCK TABLES `priv_sync_replica` WRITE;
/*!40000 ALTER TABLE `priv_sync_replica` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_sync_replica` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger`
--

DROP TABLE IF EXISTS `priv_trigger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_trigger` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `realclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Trigger',
  PRIMARY KEY (`id`),
  KEY `realclass` (`realclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger`
--

LOCK TABLES `priv_trigger` WRITE;
/*!40000 ALTER TABLE `priv_trigger` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onobjcreate`
--

DROP TABLE IF EXISTS `priv_trigger_onobjcreate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_trigger_onobjcreate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onobjcreate`
--

LOCK TABLES `priv_trigger_onobjcreate` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onobjcreate` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_onobjcreate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onobject`
--

DROP TABLE IF EXISTS `priv_trigger_onobject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_trigger_onobject` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `target_class` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'CustomerContract',
  `filter` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `target_class` (`target_class`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onobject`
--

LOCK TABLES `priv_trigger_onobject` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onobject` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_onobject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onportalupdate`
--

DROP TABLE IF EXISTS `priv_trigger_onportalupdate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_trigger_onportalupdate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onportalupdate`
--

LOCK TABLES `priv_trigger_onportalupdate` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onportalupdate` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_onportalupdate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onstatechange`
--

DROP TABLE IF EXISTS `priv_trigger_onstatechange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_trigger_onstatechange` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `state` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onstatechange`
--

LOCK TABLES `priv_trigger_onstatechange` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onstatechange` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_onstatechange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onstateenter`
--

DROP TABLE IF EXISTS `priv_trigger_onstateenter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_trigger_onstateenter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onstateenter`
--

LOCK TABLES `priv_trigger_onstateenter` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onstateenter` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_onstateenter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onstateleave`
--

DROP TABLE IF EXISTS `priv_trigger_onstateleave`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_trigger_onstateleave` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onstateleave`
--

LOCK TABLES `priv_trigger_onstateleave` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onstateleave` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_onstateleave` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_threshold`
--

DROP TABLE IF EXISTS `priv_trigger_threshold`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_trigger_threshold` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stop_watch_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `threshold_index` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_threshold`
--

LOCK TABLES `priv_trigger_threshold` WRITE;
/*!40000 ALTER TABLE `priv_trigger_threshold` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_threshold` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_urp_profiles`
--

DROP TABLE IF EXISTS `priv_urp_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_urp_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_urp_profiles`
--

LOCK TABLES `priv_urp_profiles` WRITE;
/*!40000 ALTER TABLE `priv_urp_profiles` DISABLE KEYS */;
INSERT INTO `priv_urp_profiles` VALUES (1,'Administrator','Has the rights on everything (bypassing any control)'),(2,'Portal user','Has the rights to access to the user portal. People having this profile will not be allowed to access the standard application, they will be automatically redirected to the user portal.'),(3,'Configuration Manager','Person in charge of the documentation of the managed CIs'),(4,'Service Desk Agent','Person in charge of creating incident reports'),(5,'Support Agent','Person analyzing and solving the current incidents'),(6,'Problem Manager','Person analyzing and solving the current problems'),(7,'Change Implementor','Person executing the changes'),(8,'Change Supervisor','Person responsible for the overall change execution'),(9,'Change Approver','Person who could be impacted by some changes'),(10,'Service Manager','Person responsible for the service delivered to the [internal] customer'),(11,'Document author','Any person who could contribute to documentation'),(12,'Portal power user','Users having this profile will have the rights to see all the tickets for a customer in the portal. Must be used in conjunction with other profiles (e.g. Portal User).');
/*!40000 ALTER TABLE `priv_urp_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_urp_userorg`
--

DROP TABLE IF EXISTS `priv_urp_userorg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_urp_userorg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT '0',
  `allowed_org_id` int(11) DEFAULT '0',
  `reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `allowed_org_id` (`allowed_org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_urp_userorg`
--

LOCK TABLES `priv_urp_userorg` WRITE;
/*!40000 ALTER TABLE `priv_urp_userorg` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_urp_userorg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_urp_userprofile`
--

DROP TABLE IF EXISTS `priv_urp_userprofile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_urp_userprofile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT '0',
  `profileid` int(11) DEFAULT '0',
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `profileid` (`profileid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_urp_userprofile`
--

LOCK TABLES `priv_urp_userprofile` WRITE;
/*!40000 ALTER TABLE `priv_urp_userprofile` DISABLE KEYS */;
INSERT INTO `priv_urp_userprofile` VALUES (1,1,1,'By definition, the administrator must have the administrator profile');
/*!40000 ALTER TABLE `priv_urp_userprofile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_user`
--

DROP TABLE IF EXISTS `priv_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contactid` int(11) DEFAULT '0',
  `login` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `language` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'EN US',
  `status` enum('disabled','enabled') COLLATE utf8_unicode_ci DEFAULT 'enabled',
  `finalclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'User',
  PRIMARY KEY (`id`),
  KEY `contactid` (`contactid`),
  KEY `language` (`language`),
  KEY `finalclass` (`finalclass`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_user`
--

LOCK TABLES `priv_user` WRITE;
/*!40000 ALTER TABLE `priv_user` DISABLE KEYS */;
INSERT INTO `priv_user` VALUES (1,0,'admin','ES CR','enabled','UserLocal');
/*!40000 ALTER TABLE `priv_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_user_local`
--

DROP TABLE IF EXISTS `priv_user_local`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_user_local` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password_hash` tinyblob,
  `password_salt` tinyblob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_user_local`
--

LOCK TABLES `priv_user_local` WRITE;
/*!40000 ALTER TABLE `priv_user_local` DISABLE KEYS */;
INSERT INTO `priv_user_local` VALUES (1,'4aa4f139163359cae53efef04173caff1c52691bb035cd1054180642ce790623','a53e35a327906e92');
/*!40000 ALTER TABLE `priv_user_local` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `providercontract`
--

DROP TABLE IF EXISTS `providercontract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `providercontract` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sla` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `coverage` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `providercontract`
--

LOCK TABLES `providercontract` WRITE;
/*!40000 ALTER TABLE `providercontract` DISABLE KEYS */;
/*!40000 ALTER TABLE `providercontract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rack`
--

DROP TABLE IF EXISTS `rack`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rack` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nb_u` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rack`
--

LOCK TABLES `rack` WRITE;
/*!40000 ALTER TABLE `rack` DISABLE KEYS */;
/*!40000 ALTER TABLE `rack` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sanswitch`
--

DROP TABLE IF EXISTS `sanswitch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sanswitch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sanswitch`
--

LOCK TABLES `sanswitch` WRITE;
/*!40000 ALTER TABLE `sanswitch` DISABLE KEYS */;
/*!40000 ALTER TABLE `sanswitch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `server`
--

DROP TABLE IF EXISTS `server`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `server` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `osfamily_id` int(11) DEFAULT '0',
  `osversion_id` int(11) DEFAULT '0',
  `oslicence_id` int(11) DEFAULT '0',
  `cpu` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `ram` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `osfamily_id` (`osfamily_id`),
  KEY `osversion_id` (`osversion_id`),
  KEY `oslicence_id` (`oslicence_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `server`
--

LOCK TABLES `server` WRITE;
/*!40000 ALTER TABLE `server` DISABLE KEYS */;
/*!40000 ALTER TABLE `server` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service`
--

DROP TABLE IF EXISTS `service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `org_id` int(11) DEFAULT '0',
  `servicefamily_id` int(11) DEFAULT '0',
  `description` text COLLATE utf8_unicode_ci,
  `status` enum('implementation','obsolete','production') COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `servicefamily_id` (`servicefamily_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service`
--

LOCK TABLES `service` WRITE;
/*!40000 ALTER TABLE `service` DISABLE KEYS */;
INSERT INTO `service` VALUES (1,'AT-TL',1,1,'TestLink / diseño y ejeucion de Casos de prueba','production'),(2,'AT-BT',1,1,'Bug Tracker','production');
/*!40000 ALTER TABLE `service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `servicefamilly`
--

DROP TABLE IF EXISTS `servicefamilly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `servicefamilly` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servicefamilly`
--

LOCK TABLES `servicefamilly` WRITE;
/*!40000 ALTER TABLE `servicefamilly` DISABLE KEYS */;
INSERT INTO `servicefamilly` VALUES (1,'Gestion de QA');
/*!40000 ALTER TABLE `servicefamilly` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `servicefamily`
--

DROP TABLE IF EXISTS `servicefamily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `servicefamily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servicefamily`
--

LOCK TABLES `servicefamily` WRITE;
/*!40000 ALTER TABLE `servicefamily` DISABLE KEYS */;
/*!40000 ALTER TABLE `servicefamily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `servicesubcategory`
--

DROP TABLE IF EXISTS `servicesubcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `servicesubcategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` text COLLATE utf8_unicode_ci,
  `service_id` int(11) DEFAULT '0',
  `request_type` enum('incident','service_request') COLLATE utf8_unicode_ci DEFAULT 'incident',
  `status` enum('implementation','obsolete','production') COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servicesubcategory`
--

LOCK TABLES `servicesubcategory` WRITE;
/*!40000 ALTER TABLE `servicesubcategory` DISABLE KEYS */;
INSERT INTO `servicesubcategory` VALUES (1,'Accesos a la herramienta','',1,'service_request','production'),(2,'Restauracion de Backup','',1,'service_request','production'),(3,'Acceso a la herramienta','',2,'service_request','production'),(4,'Gestion roles y perfiles de usuario','Creacion / Modificacion / Eliminacion de usuarios',2,'service_request','production'),(5,'Creación de Proyectos','Creacion/ MOdificacion/ Eliminacion  de proyectos en Bug tracker',2,'service_request','production'),(6,'Gestion roles y perfiles de usuario','Creacion, modificacion y eliminacion de usuarios de TestLink',1,'service_request','production');
/*!40000 ALTER TABLE `servicesubcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sla`
--

DROP TABLE IF EXISTS `sla`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sla` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` text COLLATE utf8_unicode_ci,
  `org_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sla`
--

LOCK TABLES `sla` WRITE;
/*!40000 ALTER TABLE `sla` DISABLE KEYS */;
INSERT INTO `sla` VALUES (1,'SLA Standar Alltic ITSM','Acuerdos de niveles de servicio que se prestaran para atender peticiones a los colaboradores internos(staff) de Alltic',1);
/*!40000 ALTER TABLE `sla` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slt`
--

DROP TABLE IF EXISTS `slt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `priority` enum('1','2','3','4') COLLATE utf8_unicode_ci DEFAULT NULL,
  `request_type` enum('incident','service_request') COLLATE utf8_unicode_ci DEFAULT NULL,
  `metric` enum('tto','ttr') COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` int(11) DEFAULT NULL,
  `unit` enum('hours','minutes') COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slt`
--

LOCK TABLES `slt` WRITE;
/*!40000 ALTER TABLE `slt` DISABLE KEYS */;
INSERT INTO `slt` VALUES (1,'TDA S-Alto','2','service_request','tto',30,'minutes'),(2,'TDA I-Alto','2','incident','tto',30,'minutes'),(3,'TDS I-Alto','2','incident','ttr',3,'hours'),(4,'TDS S-Alto','2','service_request','ttr',3,'hours'),(5,'TDA S-Medio','3','service_request','tto',4,'hours'),(6,'TDS I-Medio','3','incident','ttr',4,'hours'),(7,'TDS S-Medio','3','service_request','ttr',20,'hours'),(8,'TDA I-Medio','3','incident','tto',4,'hours'),(9,'TDA I-Bajo','4','incident','tto',8,'hours'),(10,'TDS I-Bajo','4','incident','ttr',40,'hours'),(11,'TDA S-Bajo','4','service_request','tto',8,'hours'),(12,'TDS S-Bajo','4','service_request','ttr',40,'hours'),(13,'TDA I-Critico','1','incident','tto',10,'minutes'),(14,'TDS I-Critico','1','incident','ttr',30,'minutes'),(15,'TDA S-Critico','1','service_request','tto',10,'minutes'),(16,'TDS S-Critico','1','service_request','ttr',30,'minutes');
/*!40000 ALTER TABLE `slt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `software`
--

DROP TABLE IF EXISTS `software`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `software` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `vendor` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `version` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `type` enum('DBServer','Middleware','OtherSoftware','PCSoftware','WebServer') COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `software`
--

LOCK TABLES `software` WRITE;
/*!40000 ALTER TABLE `software` DISABLE KEYS */;
INSERT INTO `software` VALUES (8,'Centos','Centos','6.10','OtherSoftware'),(9,'IIS','Microsoft','7','WebServer'),(10,'SQL SERVER','Microsoft','2014','DBServer'),(11,'MySQL','Oracle','5.6','DBServer'),(12,'Apache','Apache Software Foundation','2.4','WebServer'),(13,'ODBC MYSQL','MySQL','3.5','OtherSoftware');
/*!40000 ALTER TABLE `software` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `softwareinstance`
--

DROP TABLE IF EXISTS `softwareinstance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `softwareinstance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `functionalci_id` int(11) DEFAULT '0',
  `software_id` int(11) DEFAULT '0',
  `softwarelicence_id` int(11) DEFAULT '0',
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `status` enum('active','inactive') COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `functionalci_id` (`functionalci_id`),
  KEY `software_id` (`software_id`),
  KEY `softwarelicence_id` (`softwarelicence_id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `softwareinstance`
--

LOCK TABLES `softwareinstance` WRITE;
/*!40000 ALTER TABLE `softwareinstance` DISABLE KEYS */;
INSERT INTO `softwareinstance` VALUES (17,16,9,0,'','active'),(19,15,10,0,'','active'),(22,14,11,0,'','active'),(27,14,12,0,'','active'),(34,15,13,0,'c://System/ODBC32','active');
/*!40000 ALTER TABLE `softwareinstance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `softwarelicence`
--

DROP TABLE IF EXISTS `softwarelicence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `softwarelicence` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `software_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `software_id` (`software_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `softwarelicence`
--

LOCK TABLES `softwarelicence` WRITE;
/*!40000 ALTER TABLE `softwarelicence` DISABLE KEYS */;
/*!40000 ALTER TABLE `softwarelicence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `softwarepatch`
--

DROP TABLE IF EXISTS `softwarepatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `softwarepatch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `software_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `software_id` (`software_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `softwarepatch`
--

LOCK TABLES `softwarepatch` WRITE;
/*!40000 ALTER TABLE `softwarepatch` DISABLE KEYS */;
/*!40000 ALTER TABLE `softwarepatch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storagesystem`
--

DROP TABLE IF EXISTS `storagesystem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `storagesystem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storagesystem`
--

LOCK TABLES `storagesystem` WRITE;
/*!40000 ALTER TABLE `storagesystem` DISABLE KEYS */;
/*!40000 ALTER TABLE `storagesystem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subnet`
--

DROP TABLE IF EXISTS `subnet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subnet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` text COLLATE utf8_unicode_ci,
  `subnet_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `org_id` int(11) DEFAULT '0',
  `ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `ip_mask` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subnet`
--

LOCK TABLES `subnet` WRITE;
/*!40000 ALTER TABLE `subnet` DISABLE KEYS */;
/*!40000 ALTER TABLE `subnet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tablet`
--

DROP TABLE IF EXISTS `tablet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tablet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tablet`
--

LOCK TABLES `tablet` WRITE;
/*!40000 ALTER TABLE `tablet` DISABLE KEYS */;
/*!40000 ALTER TABLE `tablet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tape`
--

DROP TABLE IF EXISTS `tape`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tape` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` text COLLATE utf8_unicode_ci,
  `size` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `tapelibrary_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `tapelibrary_id` (`tapelibrary_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tape`
--

LOCK TABLES `tape` WRITE;
/*!40000 ALTER TABLE `tape` DISABLE KEYS */;
/*!40000 ALTER TABLE `tape` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tapelibrary`
--

DROP TABLE IF EXISTS `tapelibrary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tapelibrary` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tapelibrary`
--

LOCK TABLES `tapelibrary` WRITE;
/*!40000 ALTER TABLE `tapelibrary` DISABLE KEYS */;
/*!40000 ALTER TABLE `tapelibrary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team`
--

DROP TABLE IF EXISTS `team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `team` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team`
--

LOCK TABLES `team` WRITE;
/*!40000 ALTER TABLE `team` DISABLE KEYS */;
/*!40000 ALTER TABLE `team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telephonyci`
--

DROP TABLE IF EXISTS `telephonyci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `telephonyci` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phonenumber` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telephonyci`
--

LOCK TABLES `telephonyci` WRITE;
/*!40000 ALTER TABLE `telephonyci` DISABLE KEYS */;
/*!40000 ALTER TABLE `telephonyci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket`
--

DROP TABLE IF EXISTS `ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `operational_status` enum('closed','ongoing','resolved') COLLATE utf8_unicode_ci DEFAULT 'ongoing',
  `ref` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `org_id` int(11) DEFAULT '0',
  `caller_id` int(11) DEFAULT '0',
  `team_id` int(11) DEFAULT '0',
  `agent_id` int(11) DEFAULT '0',
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` text COLLATE utf8_unicode_ci,
  `description_format` enum('text','html') COLLATE utf8_unicode_ci DEFAULT 'text',
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `last_update` datetime DEFAULT NULL,
  `close_date` datetime DEFAULT NULL,
  `private_log` longtext COLLATE utf8_unicode_ci,
  `private_log_index` blob,
  `finalclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Ticket',
  `id_instalador` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'NA',
  `san` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'NA',
  `nombre_instalador` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'NA',
  `pais_ticket` enum('RQ-HCL','RQ-HDC','RQ-HEC','RQ-HPE','RQ-LATAM','RQ-VAR PANAMÁ') COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `operational_status` (`operational_status`),
  KEY `org_id` (`org_id`),
  KEY `caller_id` (`caller_id`),
  KEY `team_id` (`team_id`),
  KEY `agent_id` (`agent_id`),
  KEY `finalclass` (`finalclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket`
--

LOCK TABLES `ticket` WRITE;
/*!40000 ALTER TABLE `ticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_incident`
--

DROP TABLE IF EXISTS `ticket_incident`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_incident` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` enum('assigned','closed','escalated_tto','escalated_ttr','new','pending','resolved') COLLATE utf8_unicode_ci DEFAULT 'new',
  `impact` enum('2') COLLATE utf8_unicode_ci DEFAULT '2',
  `priority` enum('1','2') COLLATE utf8_unicode_ci DEFAULT '2',
  `urgency` enum('1','2') COLLATE utf8_unicode_ci DEFAULT '2',
  `origin` enum('mail','monitoring','phone','portal') COLLATE utf8_unicode_ci DEFAULT 'phone',
  `service_id` int(11) DEFAULT '0',
  `servicesubcategory_id` int(11) DEFAULT '0',
  `escalation_flag` enum('no','yes') COLLATE utf8_unicode_ci DEFAULT 'no',
  `escalation_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `assignment_date` datetime DEFAULT NULL,
  `resolution_date` datetime DEFAULT NULL,
  `last_pending_date` datetime DEFAULT NULL,
  `cumulatedpending_timespent` int(11) unsigned DEFAULT NULL,
  `cumulatedpending_started` datetime DEFAULT NULL,
  `cumulatedpending_laststart` datetime DEFAULT NULL,
  `cumulatedpending_stopped` datetime DEFAULT NULL,
  `tto_timespent` int(11) unsigned DEFAULT NULL,
  `tto_started` datetime DEFAULT NULL,
  `tto_laststart` datetime DEFAULT NULL,
  `tto_stopped` datetime DEFAULT NULL,
  `tto_75_deadline` datetime DEFAULT NULL,
  `tto_75_passed` tinyint(1) unsigned DEFAULT NULL,
  `tto_75_triggered` tinyint(1) DEFAULT NULL,
  `tto_75_overrun` int(11) unsigned DEFAULT NULL,
  `tto_100_deadline` datetime DEFAULT NULL,
  `tto_100_passed` tinyint(1) unsigned DEFAULT NULL,
  `tto_100_triggered` tinyint(1) DEFAULT NULL,
  `tto_100_overrun` int(11) unsigned DEFAULT NULL,
  `ttr_timespent` int(11) unsigned DEFAULT NULL,
  `ttr_started` datetime DEFAULT NULL,
  `ttr_laststart` datetime DEFAULT NULL,
  `ttr_stopped` datetime DEFAULT NULL,
  `ttr_75_deadline` datetime DEFAULT NULL,
  `ttr_75_passed` tinyint(1) unsigned DEFAULT NULL,
  `ttr_75_triggered` tinyint(1) DEFAULT NULL,
  `ttr_75_overrun` int(11) unsigned DEFAULT NULL,
  `ttr_100_deadline` datetime DEFAULT NULL,
  `ttr_100_passed` tinyint(1) unsigned DEFAULT NULL,
  `ttr_100_triggered` tinyint(1) DEFAULT NULL,
  `ttr_100_overrun` int(11) unsigned DEFAULT NULL,
  `time_spent` int(11) unsigned DEFAULT NULL,
  `resolution_code` enum('assistance','bug fixed','data modified','documented','hardware repair','other','software patch','system update','test drills','training') COLLATE utf8_unicode_ci DEFAULT NULL,
  `solution` text COLLATE utf8_unicode_ci,
  `pending_reason` text COLLATE utf8_unicode_ci,
  `parent_incident_id` int(11) DEFAULT '0',
  `parent_problem_id` int(11) DEFAULT '0',
  `parent_change_id` int(11) DEFAULT '0',
  `public_log` longtext COLLATE utf8_unicode_ci,
  `public_log_index` blob,
  `user_satisfaction` enum('1','2','3','4','5') COLLATE utf8_unicode_ci DEFAULT '1',
  `user_commment` text COLLATE utf8_unicode_ci,
  `external_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  KEY `servicesubcategory_id` (`servicesubcategory_id`),
  KEY `parent_incident_id` (`parent_incident_id`),
  KEY `parent_problem_id` (`parent_problem_id`),
  KEY `parent_change_id` (`parent_change_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_incident`
--

LOCK TABLES `ticket_incident` WRITE;
/*!40000 ALTER TABLE `ticket_incident` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_incident` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_problem`
--

DROP TABLE IF EXISTS `ticket_problem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_problem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` enum('assigned','closed','new','resolved') COLLATE utf8_unicode_ci DEFAULT 'new',
  `service_id` int(11) DEFAULT '0',
  `servicesubcategory_id` int(11) DEFAULT '0',
  `product` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `impact` enum('1','2','3') COLLATE utf8_unicode_ci DEFAULT '1',
  `urgency` enum('1','2','3','4') COLLATE utf8_unicode_ci DEFAULT '1',
  `priority` enum('1','2','3','4') COLLATE utf8_unicode_ci DEFAULT '1',
  `related_change_id` int(11) DEFAULT '0',
  `assignment_date` datetime DEFAULT NULL,
  `resolution_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  KEY `servicesubcategory_id` (`servicesubcategory_id`),
  KEY `related_change_id` (`related_change_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_problem`
--

LOCK TABLES `ticket_problem` WRITE;
/*!40000 ALTER TABLE `ticket_problem` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_problem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_request`
--

DROP TABLE IF EXISTS `ticket_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_request` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` enum('approved','assigned','closed','escalated_tto','escalated_ttr','new','pending','rejected','resolved','waiting_for_approval') COLLATE utf8_unicode_ci DEFAULT 'new',
  `request_type` enum('service_request') COLLATE utf8_unicode_ci DEFAULT 'service_request',
  `impact` enum('2') COLLATE utf8_unicode_ci DEFAULT '2',
  `priority` enum('1','2','3','4') COLLATE utf8_unicode_ci DEFAULT '4',
  `urgency` enum('1','2','3','4') COLLATE utf8_unicode_ci DEFAULT '4',
  `origin` enum('mail','phone','portal') COLLATE utf8_unicode_ci DEFAULT 'phone',
  `approver_id` int(11) DEFAULT '0',
  `servicefamily_id` int(11) DEFAULT '0',
  `service_id` int(11) DEFAULT '0',
  `servicesubcategory_id` int(11) DEFAULT '0',
  `escalation_flag` enum('no','yes') COLLATE utf8_unicode_ci DEFAULT 'no',
  `escalation_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `assignment_date` datetime DEFAULT NULL,
  `resolution_date` datetime DEFAULT NULL,
  `last_pending_date` datetime DEFAULT NULL,
  `cumulatedpending_timespent` int(11) unsigned DEFAULT NULL,
  `cumulatedpending_started` datetime DEFAULT NULL,
  `cumulatedpending_laststart` datetime DEFAULT NULL,
  `cumulatedpending_stopped` datetime DEFAULT NULL,
  `tto_timespent` int(11) unsigned DEFAULT NULL,
  `tto_started` datetime DEFAULT NULL,
  `tto_laststart` datetime DEFAULT NULL,
  `tto_stopped` datetime DEFAULT NULL,
  `tto_75_deadline` datetime DEFAULT NULL,
  `tto_75_passed` tinyint(1) unsigned DEFAULT NULL,
  `tto_75_triggered` tinyint(1) DEFAULT NULL,
  `tto_75_overrun` int(11) unsigned DEFAULT NULL,
  `tto_100_deadline` datetime DEFAULT NULL,
  `tto_100_passed` tinyint(1) unsigned DEFAULT NULL,
  `tto_100_triggered` tinyint(1) DEFAULT NULL,
  `tto_100_overrun` int(11) unsigned DEFAULT NULL,
  `ttr_timespent` int(11) unsigned DEFAULT NULL,
  `ttr_started` datetime DEFAULT NULL,
  `ttr_laststart` datetime DEFAULT NULL,
  `ttr_stopped` datetime DEFAULT NULL,
  `ttr_75_deadline` datetime DEFAULT NULL,
  `ttr_75_passed` tinyint(1) unsigned DEFAULT NULL,
  `ttr_75_triggered` tinyint(1) DEFAULT NULL,
  `ttr_75_overrun` int(11) unsigned DEFAULT NULL,
  `ttr_100_deadline` datetime DEFAULT NULL,
  `ttr_100_passed` tinyint(1) unsigned DEFAULT NULL,
  `ttr_100_triggered` tinyint(1) DEFAULT NULL,
  `ttr_100_overrun` int(11) unsigned DEFAULT NULL,
  `time_spent` int(11) unsigned DEFAULT NULL,
  `resolution_code` enum('assistance','bug fixed','data modified','documented','hardware repair','other','software patch','system update','test drills','training') COLLATE utf8_unicode_ci DEFAULT NULL,
  `solution` text COLLATE utf8_unicode_ci,
  `pending_reason` text COLLATE utf8_unicode_ci,
  `parent_request_id` int(11) DEFAULT '0',
  `parent_incident_id` int(11) DEFAULT '0',
  `parent_problem_id` int(11) DEFAULT '0',
  `parent_change_id` int(11) DEFAULT '0',
  `public_log` longtext COLLATE utf8_unicode_ci,
  `public_log_index` blob,
  `user_satisfaction` enum('1','2','3','4','5') COLLATE utf8_unicode_ci DEFAULT '1',
  `user_commment` text COLLATE utf8_unicode_ci,
  `external_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `approver_id` (`approver_id`),
  KEY `servicefamily_id` (`servicefamily_id`),
  KEY `service_id` (`service_id`),
  KEY `servicesubcategory_id` (`servicesubcategory_id`),
  KEY `parent_request_id` (`parent_request_id`),
  KEY `parent_incident_id` (`parent_incident_id`),
  KEY `parent_problem_id` (`parent_problem_id`),
  KEY `parent_change_id` (`parent_change_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_request`
--

LOCK TABLES `ticket_request` WRITE;
/*!40000 ALTER TABLE `ticket_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `typology`
--

DROP TABLE IF EXISTS `typology`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `typology` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `finalclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Typology',
  PRIMARY KEY (`id`),
  KEY `finalclass` (`finalclass`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `typology`
--

LOCK TABLES `typology` WRITE;
/*!40000 ALTER TABLE `typology` DISABLE KEYS */;
INSERT INTO `typology` VALUES (1,'Centos 6.9','OSFamily'),(2,'6.9','OSVersion'),(3,'Windows','OSFamily'),(4,'Server 2012 R2','OSVersion'),(5,'Configuración','DocumentType');
/*!40000 ALTER TABLE `typology` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `view_ApplicationSolution`
--

DROP TABLE IF EXISTS `view_ApplicationSolution`;
/*!50001 DROP VIEW IF EXISTS `view_ApplicationSolution`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_ApplicationSolution` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `status`,
 1 AS `redundancy`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_ApprovedChange`
--

DROP TABLE IF EXISTS `view_ApprovedChange`;
/*!50001 DROP VIEW IF EXISTS `view_ApprovedChange`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_ApprovedChange` AS SELECT 
 1 AS `id`,
 1 AS `operational_status`,
 1 AS `ref`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `caller_id`,
 1 AS `caller_name`,
 1 AS `team_id`,
 1 AS `team_name`,
 1 AS `agent_id`,
 1 AS `agent_name`,
 1 AS `title`,
 1 AS `description`,
 1 AS `description_format`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `last_update`,
 1 AS `close_date`,
 1 AS `private_log`,
 1 AS `private_log_index`,
 1 AS `id_instalador`,
 1 AS `san`,
 1 AS `nombre_instalador`,
 1 AS `pais_ticket`,
 1 AS `status`,
 1 AS `reason`,
 1 AS `requestor_id`,
 1 AS `requestor_email`,
 1 AS `creation_date`,
 1 AS `impact`,
 1 AS `supervisor_group_id`,
 1 AS `supervisor_group_name`,
 1 AS `supervisor_id`,
 1 AS `supervisor_email`,
 1 AS `manager_group_id`,
 1 AS `manager_group_name`,
 1 AS `manager_id`,
 1 AS `manager_email`,
 1 AS `outage`,
 1 AS `fallback`,
 1 AS `parent_id`,
 1 AS `parent_name`,
 1 AS `external_id_cambios`,
 1 AS `servicefamily_key`,
 1 AS `servicefamily_n`,
 1 AS `service_key`,
 1 AS `service_n`,
 1 AS `servicesubcategory_key`,
 1 AS `servicesubcategory_n`,
 1 AS `approval_date`,
 1 AS `approval_comment`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `caller_id_friendlyname`,
 1 AS `team_id_friendlyname`,
 1 AS `agent_id_friendlyname`,
 1 AS `requestor_id_friendlyname`,
 1 AS `supervisor_group_id_friendlyname`,
 1 AS `supervisor_id_friendlyname`,
 1 AS `manager_group_id_friendlyname`,
 1 AS `manager_id_friendlyname`,
 1 AS `parent_id_friendlyname`,
 1 AS `parent_id_finalclass_recall`,
 1 AS `servicefamily_key_friendlyname`,
 1 AS `service_key_friendlyname`,
 1 AS `servicesubcategory_key_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Attachment`
--

DROP TABLE IF EXISTS `view_Attachment`;
/*!50001 DROP VIEW IF EXISTS `view_Attachment`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Attachment` AS SELECT 
 1 AS `id`,
 1 AS `expire`,
 1 AS `temp_id`,
 1 AS `item_class`,
 1 AS `item_id`,
 1 AS `item_org_id`,
 1 AS `contents`,
 1 AS `contents_data`,
 1 AS `contents_filename`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Brand`
--

DROP TABLE IF EXISTS `view_Brand`;
/*!50001 DROP VIEW IF EXISTS `view_Brand`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Brand` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `finalclass`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_BusinessProcess`
--

DROP TABLE IF EXISTS `view_BusinessProcess`;
/*!50001 DROP VIEW IF EXISTS `view_BusinessProcess`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_BusinessProcess` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `status`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Change`
--

DROP TABLE IF EXISTS `view_Change`;
/*!50001 DROP VIEW IF EXISTS `view_Change`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Change` AS SELECT 
 1 AS `id`,
 1 AS `operational_status`,
 1 AS `ref`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `caller_id`,
 1 AS `caller_name`,
 1 AS `team_id`,
 1 AS `team_name`,
 1 AS `agent_id`,
 1 AS `agent_name`,
 1 AS `title`,
 1 AS `description`,
 1 AS `description_format`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `last_update`,
 1 AS `close_date`,
 1 AS `private_log`,
 1 AS `private_log_index`,
 1 AS `id_instalador`,
 1 AS `san`,
 1 AS `nombre_instalador`,
 1 AS `pais_ticket`,
 1 AS `status`,
 1 AS `reason`,
 1 AS `requestor_id`,
 1 AS `requestor_email`,
 1 AS `creation_date`,
 1 AS `impact`,
 1 AS `supervisor_group_id`,
 1 AS `supervisor_group_name`,
 1 AS `supervisor_id`,
 1 AS `supervisor_email`,
 1 AS `manager_group_id`,
 1 AS `manager_group_name`,
 1 AS `manager_id`,
 1 AS `manager_email`,
 1 AS `outage`,
 1 AS `fallback`,
 1 AS `parent_id`,
 1 AS `parent_name`,
 1 AS `external_id_cambios`,
 1 AS `servicefamily_key`,
 1 AS `servicefamily_n`,
 1 AS `service_key`,
 1 AS `service_n`,
 1 AS `servicesubcategory_key`,
 1 AS `servicesubcategory_n`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `caller_id_friendlyname`,
 1 AS `team_id_friendlyname`,
 1 AS `agent_id_friendlyname`,
 1 AS `requestor_id_friendlyname`,
 1 AS `supervisor_group_id_friendlyname`,
 1 AS `supervisor_id_friendlyname`,
 1 AS `manager_group_id_friendlyname`,
 1 AS `manager_id_friendlyname`,
 1 AS `parent_id_friendlyname`,
 1 AS `parent_id_finalclass_recall`,
 1 AS `servicefamily_key_friendlyname`,
 1 AS `service_key_friendlyname`,
 1 AS `servicesubcategory_key_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_ConnectableCI`
--

DROP TABLE IF EXISTS `view_ConnectableCI`;
/*!50001 DROP VIEW IF EXISTS `view_ConnectableCI`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_ConnectableCI` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Contact`
--

DROP TABLE IF EXISTS `view_Contact`;
/*!50001 DROP VIEW IF EXISTS `view_Contact`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Contact` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `status`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `email`,
 1 AS `phone`,
 1 AS `notify`,
 1 AS `function`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_ContactType`
--

DROP TABLE IF EXISTS `view_ContactType`;
/*!50001 DROP VIEW IF EXISTS `view_ContactType`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_ContactType` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `finalclass`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Contract`
--

DROP TABLE IF EXISTS `view_Contract`;
/*!50001 DROP VIEW IF EXISTS `view_Contract`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Contract` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `description`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `cost`,
 1 AS `cost_currency`,
 1 AS `contracttype_id`,
 1 AS `contracttype_name`,
 1 AS `billing_frequency`,
 1 AS `cost_unit`,
 1 AS `provider_id`,
 1 AS `provider_name`,
 1 AS `status`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `contracttype_id_friendlyname`,
 1 AS `provider_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_ContractType`
--

DROP TABLE IF EXISTS `view_ContractType`;
/*!50001 DROP VIEW IF EXISTS `view_ContractType`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_ContractType` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `finalclass`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_CoverageWindow`
--

DROP TABLE IF EXISTS `view_CoverageWindow`;
/*!50001 DROP VIEW IF EXISTS `view_CoverageWindow`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_CoverageWindow` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `monday_start`,
 1 AS `monday_end`,
 1 AS `tuesday_start`,
 1 AS `tuesday_end`,
 1 AS `wednesday_start`,
 1 AS `wednesday_end`,
 1 AS `thursday_start`,
 1 AS `thursday_end`,
 1 AS `friday_start`,
 1 AS `friday_end`,
 1 AS `saturday_start`,
 1 AS `saturday_end`,
 1 AS `sunday_start`,
 1 AS `sunday_end`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_CustomerContract`
--

DROP TABLE IF EXISTS `view_CustomerContract`;
/*!50001 DROP VIEW IF EXISTS `view_CustomerContract`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_CustomerContract` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `description`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `cost`,
 1 AS `cost_currency`,
 1 AS `contracttype_id`,
 1 AS `contracttype_name`,
 1 AS `billing_frequency`,
 1 AS `cost_unit`,
 1 AS `provider_id`,
 1 AS `provider_name`,
 1 AS `status`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `contracttype_id_friendlyname`,
 1 AS `provider_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_DBServer`
--

DROP TABLE IF EXISTS `view_DBServer`;
/*!50001 DROP VIEW IF EXISTS `view_DBServer`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_DBServer` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `system_id`,
 1 AS `system_name`,
 1 AS `software_id`,
 1 AS `software_name`,
 1 AS `softwarelicence_id`,
 1 AS `softwarelicence_name`,
 1 AS `path`,
 1 AS `status`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `system_id_friendlyname`,
 1 AS `system_id_finalclass_recall`,
 1 AS `software_id_friendlyname`,
 1 AS `softwarelicence_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_DatabaseSchema`
--

DROP TABLE IF EXISTS `view_DatabaseSchema`;
/*!50001 DROP VIEW IF EXISTS `view_DatabaseSchema`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_DatabaseSchema` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `dbserver_id`,
 1 AS `dbserver_name`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `dbserver_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_DatacenterDevice`
--

DROP TABLE IF EXISTS `view_DatacenterDevice`;
/*!50001 DROP VIEW IF EXISTS `view_DatacenterDevice`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_DatacenterDevice` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `rack_id`,
 1 AS `rack_name`,
 1 AS `enclosure_id`,
 1 AS `enclosure_name`,
 1 AS `nb_u`,
 1 AS `managementip`,
 1 AS `powerA_id`,
 1 AS `powerA_name`,
 1 AS `powerB_id`,
 1 AS `powerB_name`,
 1 AS `redundancy`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`,
 1 AS `rack_id_friendlyname`,
 1 AS `enclosure_id_friendlyname`,
 1 AS `powerA_id_friendlyname`,
 1 AS `powerA_id_finalclass_recall`,
 1 AS `powerB_id_friendlyname`,
 1 AS `powerB_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_DeliveryModel`
--

DROP TABLE IF EXISTS `view_DeliveryModel`;
/*!50001 DROP VIEW IF EXISTS `view_DeliveryModel`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_DeliveryModel` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `description`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Document`
--

DROP TABLE IF EXISTS `view_Document`;
/*!50001 DROP VIEW IF EXISTS `view_Document`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Document` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `documenttype_id`,
 1 AS `documenttype_name`,
 1 AS `version`,
 1 AS `description`,
 1 AS `status`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `documenttype_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_DocumentFile`
--

DROP TABLE IF EXISTS `view_DocumentFile`;
/*!50001 DROP VIEW IF EXISTS `view_DocumentFile`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_DocumentFile` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `documenttype_id`,
 1 AS `documenttype_name`,
 1 AS `version`,
 1 AS `description`,
 1 AS `status`,
 1 AS `file`,
 1 AS `file_data`,
 1 AS `file_filename`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `documenttype_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_DocumentNote`
--

DROP TABLE IF EXISTS `view_DocumentNote`;
/*!50001 DROP VIEW IF EXISTS `view_DocumentNote`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_DocumentNote` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `documenttype_id`,
 1 AS `documenttype_name`,
 1 AS `version`,
 1 AS `description`,
 1 AS `status`,
 1 AS `text`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `documenttype_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_DocumentType`
--

DROP TABLE IF EXISTS `view_DocumentType`;
/*!50001 DROP VIEW IF EXISTS `view_DocumentType`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_DocumentType` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `finalclass`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_DocumentWeb`
--

DROP TABLE IF EXISTS `view_DocumentWeb`;
/*!50001 DROP VIEW IF EXISTS `view_DocumentWeb`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_DocumentWeb` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `documenttype_id`,
 1 AS `documenttype_name`,
 1 AS `version`,
 1 AS `description`,
 1 AS `status`,
 1 AS `url`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `documenttype_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_EmergencyChange`
--

DROP TABLE IF EXISTS `view_EmergencyChange`;
/*!50001 DROP VIEW IF EXISTS `view_EmergencyChange`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_EmergencyChange` AS SELECT 
 1 AS `id`,
 1 AS `operational_status`,
 1 AS `ref`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `caller_id`,
 1 AS `caller_name`,
 1 AS `team_id`,
 1 AS `team_name`,
 1 AS `agent_id`,
 1 AS `agent_name`,
 1 AS `title`,
 1 AS `description`,
 1 AS `description_format`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `last_update`,
 1 AS `close_date`,
 1 AS `private_log`,
 1 AS `private_log_index`,
 1 AS `id_instalador`,
 1 AS `san`,
 1 AS `nombre_instalador`,
 1 AS `pais_ticket`,
 1 AS `status`,
 1 AS `reason`,
 1 AS `requestor_id`,
 1 AS `requestor_email`,
 1 AS `creation_date`,
 1 AS `impact`,
 1 AS `supervisor_group_id`,
 1 AS `supervisor_group_name`,
 1 AS `supervisor_id`,
 1 AS `supervisor_email`,
 1 AS `manager_group_id`,
 1 AS `manager_group_name`,
 1 AS `manager_id`,
 1 AS `manager_email`,
 1 AS `outage`,
 1 AS `fallback`,
 1 AS `parent_id`,
 1 AS `parent_name`,
 1 AS `external_id_cambios`,
 1 AS `servicefamily_key`,
 1 AS `servicefamily_n`,
 1 AS `service_key`,
 1 AS `service_n`,
 1 AS `servicesubcategory_key`,
 1 AS `servicesubcategory_n`,
 1 AS `approval_date`,
 1 AS `approval_comment`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `caller_id_friendlyname`,
 1 AS `team_id_friendlyname`,
 1 AS `agent_id_friendlyname`,
 1 AS `requestor_id_friendlyname`,
 1 AS `supervisor_group_id_friendlyname`,
 1 AS `supervisor_id_friendlyname`,
 1 AS `manager_group_id_friendlyname`,
 1 AS `manager_id_friendlyname`,
 1 AS `parent_id_friendlyname`,
 1 AS `parent_id_finalclass_recall`,
 1 AS `servicefamily_key_friendlyname`,
 1 AS `service_key_friendlyname`,
 1 AS `servicesubcategory_key_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Enclosure`
--

DROP TABLE IF EXISTS `view_Enclosure`;
/*!50001 DROP VIEW IF EXISTS `view_Enclosure`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Enclosure` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `rack_id`,
 1 AS `rack_name`,
 1 AS `nb_u`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`,
 1 AS `rack_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_FAQ`
--

DROP TABLE IF EXISTS `view_FAQ`;
/*!50001 DROP VIEW IF EXISTS `view_FAQ`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_FAQ` AS SELECT 
 1 AS `id`,
 1 AS `title`,
 1 AS `summary`,
 1 AS `description`,
 1 AS `category_id`,
 1 AS `category_name`,
 1 AS `error_code`,
 1 AS `key_words`,
 1 AS `friendlyname`,
 1 AS `category_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_FAQCategory`
--

DROP TABLE IF EXISTS `view_FAQCategory`;
/*!50001 DROP VIEW IF EXISTS `view_FAQCategory`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_FAQCategory` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Farm`
--

DROP TABLE IF EXISTS `view_Farm`;
/*!50001 DROP VIEW IF EXISTS `view_Farm`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Farm` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `status`,
 1 AS `redundancy`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_FiberChannelInterface`
--

DROP TABLE IF EXISTS `view_FiberChannelInterface`;
/*!50001 DROP VIEW IF EXISTS `view_FiberChannelInterface`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_FiberChannelInterface` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `speed`,
 1 AS `topology`,
 1 AS `wwn`,
 1 AS `datacenterdevice_id`,
 1 AS `datacenterdevice_name`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `datacenterdevice_id_friendlyname`,
 1 AS `datacenterdevice_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_FunctionalCI`
--

DROP TABLE IF EXISTS `view_FunctionalCI`;
/*!50001 DROP VIEW IF EXISTS `view_FunctionalCI`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_FunctionalCI` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Group`
--

DROP TABLE IF EXISTS `view_Group`;
/*!50001 DROP VIEW IF EXISTS `view_Group`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Group` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `status`,
 1 AS `org_id`,
 1 AS `owner_name`,
 1 AS `description`,
 1 AS `type`,
 1 AS `parent_id`,
 1 AS `parent_name`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `parent_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Holiday`
--

DROP TABLE IF EXISTS `view_Holiday`;
/*!50001 DROP VIEW IF EXISTS `view_Holiday`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Holiday` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `date`,
 1 AS `calendar_id`,
 1 AS `calendar_name`,
 1 AS `friendlyname`,
 1 AS `calendar_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_HolidayCalendar`
--

DROP TABLE IF EXISTS `view_HolidayCalendar`;
/*!50001 DROP VIEW IF EXISTS `view_HolidayCalendar`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_HolidayCalendar` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Hypervisor`
--

DROP TABLE IF EXISTS `view_Hypervisor`;
/*!50001 DROP VIEW IF EXISTS `view_Hypervisor`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Hypervisor` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `status`,
 1 AS `farm_id`,
 1 AS `farm_name`,
 1 AS `server_id`,
 1 AS `server_name`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `farm_id_friendlyname`,
 1 AS `server_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_IOSVersion`
--

DROP TABLE IF EXISTS `view_IOSVersion`;
/*!50001 DROP VIEW IF EXISTS `view_IOSVersion`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_IOSVersion` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `brand_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_IPInterface`
--

DROP TABLE IF EXISTS `view_IPInterface`;
/*!50001 DROP VIEW IF EXISTS `view_IPInterface`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_IPInterface` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `ipaddress`,
 1 AS `macaddress`,
 1 AS `comment`,
 1 AS `ipgateway`,
 1 AS `ipmask`,
 1 AS `speed`,
 1 AS `finalclass`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_IPPhone`
--

DROP TABLE IF EXISTS `view_IPPhone`;
/*!50001 DROP VIEW IF EXISTS `view_IPPhone`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_IPPhone` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `phonenumber`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Incident`
--

DROP TABLE IF EXISTS `view_Incident`;
/*!50001 DROP VIEW IF EXISTS `view_Incident`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Incident` AS SELECT 
 1 AS `id`,
 1 AS `operational_status`,
 1 AS `ref`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `caller_id`,
 1 AS `caller_name`,
 1 AS `team_id`,
 1 AS `team_name`,
 1 AS `agent_id`,
 1 AS `agent_name`,
 1 AS `title`,
 1 AS `description`,
 1 AS `description_format`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `last_update`,
 1 AS `close_date`,
 1 AS `private_log`,
 1 AS `private_log_index`,
 1 AS `id_instalador`,
 1 AS `san`,
 1 AS `nombre_instalador`,
 1 AS `pais_ticket`,
 1 AS `status`,
 1 AS `impact`,
 1 AS `priority`,
 1 AS `urgency`,
 1 AS `origin`,
 1 AS `service_id`,
 1 AS `service_name`,
 1 AS `servicesubcategory_id`,
 1 AS `servicesubcategory_name`,
 1 AS `escalation_flag`,
 1 AS `escalation_reason`,
 1 AS `assignment_date`,
 1 AS `resolution_date`,
 1 AS `last_pending_date`,
 1 AS `cumulatedpending`,
 1 AS `cumulatedpending_started`,
 1 AS `cumulatedpending_laststart`,
 1 AS `cumulatedpending_stopped`,
 1 AS `tto`,
 1 AS `tto_started`,
 1 AS `tto_laststart`,
 1 AS `tto_stopped`,
 1 AS `tto_75_deadline`,
 1 AS `tto_75_passed`,
 1 AS `tto_75_triggered`,
 1 AS `tto_75_overrun`,
 1 AS `tto_100_deadline`,
 1 AS `tto_100_passed`,
 1 AS `tto_100_triggered`,
 1 AS `tto_100_overrun`,
 1 AS `ttr`,
 1 AS `ttr_started`,
 1 AS `ttr_laststart`,
 1 AS `ttr_stopped`,
 1 AS `ttr_75_deadline`,
 1 AS `ttr_75_passed`,
 1 AS `ttr_75_triggered`,
 1 AS `ttr_75_overrun`,
 1 AS `ttr_100_deadline`,
 1 AS `ttr_100_passed`,
 1 AS `ttr_100_triggered`,
 1 AS `ttr_100_overrun`,
 1 AS `tto_escalation_deadline`,
 1 AS `sla_tto_passed`,
 1 AS `sla_tto_over`,
 1 AS `ttr_escalation_deadline`,
 1 AS `sla_ttr_passed`,
 1 AS `sla_ttr_over`,
 1 AS `time_spent`,
 1 AS `resolution_code`,
 1 AS `solution`,
 1 AS `pending_reason`,
 1 AS `parent_incident_id`,
 1 AS `parent_incident_ref`,
 1 AS `parent_problem_id`,
 1 AS `parent_problem_ref`,
 1 AS `parent_change_id`,
 1 AS `parent_change_ref`,
 1 AS `public_log`,
 1 AS `public_log_index`,
 1 AS `user_satisfaction`,
 1 AS `user_comment`,
 1 AS `external_id`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `caller_id_friendlyname`,
 1 AS `team_id_friendlyname`,
 1 AS `agent_id_friendlyname`,
 1 AS `service_id_friendlyname`,
 1 AS `servicesubcategory_id_friendlyname`,
 1 AS `parent_incident_id_friendlyname`,
 1 AS `parent_problem_id_friendlyname`,
 1 AS `parent_change_id_friendlyname`,
 1 AS `parent_change_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_KnownError`
--

DROP TABLE IF EXISTS `view_KnownError`;
/*!50001 DROP VIEW IF EXISTS `view_KnownError`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_KnownError` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `org_id`,
 1 AS `cust_name`,
 1 AS `problem_id`,
 1 AS `problem_ref`,
 1 AS `symptom`,
 1 AS `root_cause`,
 1 AS `workaround`,
 1 AS `solution`,
 1 AS `error_code`,
 1 AS `domain`,
 1 AS `vendor`,
 1 AS `model`,
 1 AS `version`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `problem_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Licence`
--

DROP TABLE IF EXISTS `view_Licence`;
/*!50001 DROP VIEW IF EXISTS `view_Licence`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Licence` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `usage_limit`,
 1 AS `description`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `licence_key`,
 1 AS `perpetual`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Location`
--

DROP TABLE IF EXISTS `view_Location`;
/*!50001 DROP VIEW IF EXISTS `view_Location`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Location` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `status`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `address`,
 1 AS `postal_code`,
 1 AS `city`,
 1 AS `country`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_LogicalInterface`
--

DROP TABLE IF EXISTS `view_LogicalInterface`;
/*!50001 DROP VIEW IF EXISTS `view_LogicalInterface`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_LogicalInterface` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `ipaddress`,
 1 AS `macaddress`,
 1 AS `comment`,
 1 AS `ipgateway`,
 1 AS `ipmask`,
 1 AS `speed`,
 1 AS `virtualmachine_id`,
 1 AS `virtualmachine_name`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `virtualmachine_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_LogicalVolume`
--

DROP TABLE IF EXISTS `view_LogicalVolume`;
/*!50001 DROP VIEW IF EXISTS `view_LogicalVolume`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_LogicalVolume` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `lun_id`,
 1 AS `description`,
 1 AS `raid_level`,
 1 AS `size`,
 1 AS `storagesystem_id`,
 1 AS `storagesystem_name`,
 1 AS `friendlyname`,
 1 AS `storagesystem_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Middleware`
--

DROP TABLE IF EXISTS `view_Middleware`;
/*!50001 DROP VIEW IF EXISTS `view_Middleware`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Middleware` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `system_id`,
 1 AS `system_name`,
 1 AS `software_id`,
 1 AS `software_name`,
 1 AS `softwarelicence_id`,
 1 AS `softwarelicence_name`,
 1 AS `path`,
 1 AS `status`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `system_id_friendlyname`,
 1 AS `system_id_finalclass_recall`,
 1 AS `software_id_friendlyname`,
 1 AS `softwarelicence_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_MiddlewareInstance`
--

DROP TABLE IF EXISTS `view_MiddlewareInstance`;
/*!50001 DROP VIEW IF EXISTS `view_MiddlewareInstance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_MiddlewareInstance` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `middleware_id`,
 1 AS `middleware_name`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `middleware_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_MobilePhone`
--

DROP TABLE IF EXISTS `view_MobilePhone`;
/*!50001 DROP VIEW IF EXISTS `view_MobilePhone`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_MobilePhone` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `phonenumber`,
 1 AS `imei`,
 1 AS `hw_pin`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Model`
--

DROP TABLE IF EXISTS `view_Model`;
/*!50001 DROP VIEW IF EXISTS `view_Model`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Model` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `type`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `brand_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_NAS`
--

DROP TABLE IF EXISTS `view_NAS`;
/*!50001 DROP VIEW IF EXISTS `view_NAS`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_NAS` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `rack_id`,
 1 AS `rack_name`,
 1 AS `enclosure_id`,
 1 AS `enclosure_name`,
 1 AS `nb_u`,
 1 AS `managementip`,
 1 AS `powerA_id`,
 1 AS `powerA_name`,
 1 AS `powerB_id`,
 1 AS `powerB_name`,
 1 AS `redundancy`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`,
 1 AS `rack_id_friendlyname`,
 1 AS `enclosure_id_friendlyname`,
 1 AS `powerA_id_friendlyname`,
 1 AS `powerA_id_finalclass_recall`,
 1 AS `powerB_id_friendlyname`,
 1 AS `powerB_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_NASFileSystem`
--

DROP TABLE IF EXISTS `view_NASFileSystem`;
/*!50001 DROP VIEW IF EXISTS `view_NASFileSystem`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_NASFileSystem` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `raid_level`,
 1 AS `size`,
 1 AS `nas_id`,
 1 AS `nas_name`,
 1 AS `friendlyname`,
 1 AS `nas_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_NetworkDevice`
--

DROP TABLE IF EXISTS `view_NetworkDevice`;
/*!50001 DROP VIEW IF EXISTS `view_NetworkDevice`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_NetworkDevice` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `rack_id`,
 1 AS `rack_name`,
 1 AS `enclosure_id`,
 1 AS `enclosure_name`,
 1 AS `nb_u`,
 1 AS `managementip`,
 1 AS `powerA_id`,
 1 AS `powerA_name`,
 1 AS `powerB_id`,
 1 AS `powerB_name`,
 1 AS `redundancy`,
 1 AS `networkdevicetype_id`,
 1 AS `networkdevicetype_name`,
 1 AS `iosversion_id`,
 1 AS `iosversion_name`,
 1 AS `ram`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`,
 1 AS `rack_id_friendlyname`,
 1 AS `enclosure_id_friendlyname`,
 1 AS `powerA_id_friendlyname`,
 1 AS `powerA_id_finalclass_recall`,
 1 AS `powerB_id_friendlyname`,
 1 AS `powerB_id_finalclass_recall`,
 1 AS `networkdevicetype_id_friendlyname`,
 1 AS `iosversion_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_NetworkDeviceType`
--

DROP TABLE IF EXISTS `view_NetworkDeviceType`;
/*!50001 DROP VIEW IF EXISTS `view_NetworkDeviceType`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_NetworkDeviceType` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `finalclass`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_NetworkInterface`
--

DROP TABLE IF EXISTS `view_NetworkInterface`;
/*!50001 DROP VIEW IF EXISTS `view_NetworkInterface`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_NetworkInterface` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `finalclass`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_NormalChange`
--

DROP TABLE IF EXISTS `view_NormalChange`;
/*!50001 DROP VIEW IF EXISTS `view_NormalChange`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_NormalChange` AS SELECT 
 1 AS `id`,
 1 AS `operational_status`,
 1 AS `ref`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `caller_id`,
 1 AS `caller_name`,
 1 AS `team_id`,
 1 AS `team_name`,
 1 AS `agent_id`,
 1 AS `agent_name`,
 1 AS `title`,
 1 AS `description`,
 1 AS `description_format`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `last_update`,
 1 AS `close_date`,
 1 AS `private_log`,
 1 AS `private_log_index`,
 1 AS `id_instalador`,
 1 AS `san`,
 1 AS `nombre_instalador`,
 1 AS `pais_ticket`,
 1 AS `status`,
 1 AS `reason`,
 1 AS `requestor_id`,
 1 AS `requestor_email`,
 1 AS `creation_date`,
 1 AS `impact`,
 1 AS `supervisor_group_id`,
 1 AS `supervisor_group_name`,
 1 AS `supervisor_id`,
 1 AS `supervisor_email`,
 1 AS `manager_group_id`,
 1 AS `manager_group_name`,
 1 AS `manager_id`,
 1 AS `manager_email`,
 1 AS `outage`,
 1 AS `fallback`,
 1 AS `parent_id`,
 1 AS `parent_name`,
 1 AS `external_id_cambios`,
 1 AS `servicefamily_key`,
 1 AS `servicefamily_n`,
 1 AS `service_key`,
 1 AS `service_n`,
 1 AS `servicesubcategory_key`,
 1 AS `servicesubcategory_n`,
 1 AS `approval_date`,
 1 AS `approval_comment`,
 1 AS `acceptance_date`,
 1 AS `acceptance_comment`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `caller_id_friendlyname`,
 1 AS `team_id_friendlyname`,
 1 AS `agent_id_friendlyname`,
 1 AS `requestor_id_friendlyname`,
 1 AS `supervisor_group_id_friendlyname`,
 1 AS `supervisor_id_friendlyname`,
 1 AS `manager_group_id_friendlyname`,
 1 AS `manager_id_friendlyname`,
 1 AS `parent_id_friendlyname`,
 1 AS `parent_id_finalclass_recall`,
 1 AS `servicefamily_key_friendlyname`,
 1 AS `service_key_friendlyname`,
 1 AS `servicesubcategory_key_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_OSFamily`
--

DROP TABLE IF EXISTS `view_OSFamily`;
/*!50001 DROP VIEW IF EXISTS `view_OSFamily`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_OSFamily` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `finalclass`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_OSLicence`
--

DROP TABLE IF EXISTS `view_OSLicence`;
/*!50001 DROP VIEW IF EXISTS `view_OSLicence`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_OSLicence` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `usage_limit`,
 1 AS `description`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `licence_key`,
 1 AS `perpetual`,
 1 AS `osversion_id`,
 1 AS `osversion_name`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `osversion_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_OSPatch`
--

DROP TABLE IF EXISTS `view_OSPatch`;
/*!50001 DROP VIEW IF EXISTS `view_OSPatch`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_OSPatch` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `osversion_id`,
 1 AS `osversion_name`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `osversion_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_OSVersion`
--

DROP TABLE IF EXISTS `view_OSVersion`;
/*!50001 DROP VIEW IF EXISTS `view_OSVersion`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_OSVersion` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `osfamily_id`,
 1 AS `osfamily_name`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `osfamily_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Organization`
--

DROP TABLE IF EXISTS `view_Organization`;
/*!50001 DROP VIEW IF EXISTS `view_Organization`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Organization` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `code`,
 1 AS `status`,
 1 AS `parent_id`,
 1 AS `parent_name`,
 1 AS `deliverymodel_id`,
 1 AS `deliverymodel_name`,
 1 AS `friendlyname`,
 1 AS `parent_id_friendlyname`,
 1 AS `deliverymodel_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_OtherSoftware`
--

DROP TABLE IF EXISTS `view_OtherSoftware`;
/*!50001 DROP VIEW IF EXISTS `view_OtherSoftware`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_OtherSoftware` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `system_id`,
 1 AS `system_name`,
 1 AS `software_id`,
 1 AS `software_name`,
 1 AS `softwarelicence_id`,
 1 AS `softwarelicence_name`,
 1 AS `path`,
 1 AS `status`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `system_id_friendlyname`,
 1 AS `system_id_finalclass_recall`,
 1 AS `software_id_friendlyname`,
 1 AS `softwarelicence_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_PC`
--

DROP TABLE IF EXISTS `view_PC`;
/*!50001 DROP VIEW IF EXISTS `view_PC`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_PC` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `osfamily_id`,
 1 AS `osfamily_name`,
 1 AS `osversion_id`,
 1 AS `osversion_name`,
 1 AS `cpu`,
 1 AS `ram`,
 1 AS `type`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`,
 1 AS `osfamily_id_friendlyname`,
 1 AS `osversion_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_PCSoftware`
--

DROP TABLE IF EXISTS `view_PCSoftware`;
/*!50001 DROP VIEW IF EXISTS `view_PCSoftware`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_PCSoftware` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `system_id`,
 1 AS `system_name`,
 1 AS `software_id`,
 1 AS `software_name`,
 1 AS `softwarelicence_id`,
 1 AS `softwarelicence_name`,
 1 AS `path`,
 1 AS `status`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `system_id_friendlyname`,
 1 AS `system_id_finalclass_recall`,
 1 AS `software_id_friendlyname`,
 1 AS `softwarelicence_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_PDU`
--

DROP TABLE IF EXISTS `view_PDU`;
/*!50001 DROP VIEW IF EXISTS `view_PDU`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_PDU` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `rack_id`,
 1 AS `rack_name`,
 1 AS `powerstart_id`,
 1 AS `powerstart_name`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`,
 1 AS `rack_id_friendlyname`,
 1 AS `powerstart_id_friendlyname`,
 1 AS `powerstart_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Patch`
--

DROP TABLE IF EXISTS `view_Patch`;
/*!50001 DROP VIEW IF EXISTS `view_Patch`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Patch` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `finalclass`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Peripheral`
--

DROP TABLE IF EXISTS `view_Peripheral`;
/*!50001 DROP VIEW IF EXISTS `view_Peripheral`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Peripheral` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Person`
--

DROP TABLE IF EXISTS `view_Person`;
/*!50001 DROP VIEW IF EXISTS `view_Person`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Person` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `status`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `email`,
 1 AS `phone`,
 1 AS `notify`,
 1 AS `function`,
 1 AS `picture`,
 1 AS `picture_data`,
 1 AS `picture_filename`,
 1 AS `first_name`,
 1 AS `employee_number`,
 1 AS `mobile_phone`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `manager_id`,
 1 AS `manager_name`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `manager_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Phone`
--

DROP TABLE IF EXISTS `view_Phone`;
/*!50001 DROP VIEW IF EXISTS `view_Phone`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Phone` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `phonenumber`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_PhysicalDevice`
--

DROP TABLE IF EXISTS `view_PhysicalDevice`;
/*!50001 DROP VIEW IF EXISTS `view_PhysicalDevice`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_PhysicalDevice` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_PhysicalInterface`
--

DROP TABLE IF EXISTS `view_PhysicalInterface`;
/*!50001 DROP VIEW IF EXISTS `view_PhysicalInterface`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_PhysicalInterface` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `ipaddress`,
 1 AS `macaddress`,
 1 AS `comment`,
 1 AS `ipgateway`,
 1 AS `ipmask`,
 1 AS `speed`,
 1 AS `connectableci_id`,
 1 AS `connectableci_name`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `connectableci_id_friendlyname`,
 1 AS `connectableci_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_PowerConnection`
--

DROP TABLE IF EXISTS `view_PowerConnection`;
/*!50001 DROP VIEW IF EXISTS `view_PowerConnection`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_PowerConnection` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_PowerSource`
--

DROP TABLE IF EXISTS `view_PowerSource`;
/*!50001 DROP VIEW IF EXISTS `view_PowerSource`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_PowerSource` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Printer`
--

DROP TABLE IF EXISTS `view_Printer`;
/*!50001 DROP VIEW IF EXISTS `view_Printer`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Printer` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Problem`
--

DROP TABLE IF EXISTS `view_Problem`;
/*!50001 DROP VIEW IF EXISTS `view_Problem`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Problem` AS SELECT 
 1 AS `id`,
 1 AS `operational_status`,
 1 AS `ref`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `caller_id`,
 1 AS `caller_name`,
 1 AS `team_id`,
 1 AS `team_name`,
 1 AS `agent_id`,
 1 AS `agent_name`,
 1 AS `title`,
 1 AS `description`,
 1 AS `description_format`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `last_update`,
 1 AS `close_date`,
 1 AS `private_log`,
 1 AS `private_log_index`,
 1 AS `id_instalador`,
 1 AS `san`,
 1 AS `nombre_instalador`,
 1 AS `pais_ticket`,
 1 AS `status`,
 1 AS `service_id`,
 1 AS `service_name`,
 1 AS `servicesubcategory_id`,
 1 AS `servicesubcategory_name`,
 1 AS `product`,
 1 AS `impact`,
 1 AS `urgency`,
 1 AS `priority`,
 1 AS `related_change_id`,
 1 AS `related_change_ref`,
 1 AS `assignment_date`,
 1 AS `resolution_date`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `caller_id_friendlyname`,
 1 AS `team_id_friendlyname`,
 1 AS `agent_id_friendlyname`,
 1 AS `service_id_friendlyname`,
 1 AS `servicesubcategory_id_friendlyname`,
 1 AS `related_change_id_friendlyname`,
 1 AS `related_change_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_ProviderContract`
--

DROP TABLE IF EXISTS `view_ProviderContract`;
/*!50001 DROP VIEW IF EXISTS `view_ProviderContract`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_ProviderContract` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `description`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `cost`,
 1 AS `cost_currency`,
 1 AS `contracttype_id`,
 1 AS `contracttype_name`,
 1 AS `billing_frequency`,
 1 AS `cost_unit`,
 1 AS `provider_id`,
 1 AS `provider_name`,
 1 AS `status`,
 1 AS `sla`,
 1 AS `coverage`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `contracttype_id_friendlyname`,
 1 AS `provider_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Rack`
--

DROP TABLE IF EXISTS `view_Rack`;
/*!50001 DROP VIEW IF EXISTS `view_Rack`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Rack` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `nb_u`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_RoutineChange`
--

DROP TABLE IF EXISTS `view_RoutineChange`;
/*!50001 DROP VIEW IF EXISTS `view_RoutineChange`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_RoutineChange` AS SELECT 
 1 AS `id`,
 1 AS `operational_status`,
 1 AS `ref`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `caller_id`,
 1 AS `caller_name`,
 1 AS `team_id`,
 1 AS `team_name`,
 1 AS `agent_id`,
 1 AS `agent_name`,
 1 AS `title`,
 1 AS `description`,
 1 AS `description_format`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `last_update`,
 1 AS `close_date`,
 1 AS `private_log`,
 1 AS `private_log_index`,
 1 AS `id_instalador`,
 1 AS `san`,
 1 AS `nombre_instalador`,
 1 AS `pais_ticket`,
 1 AS `status`,
 1 AS `reason`,
 1 AS `requestor_id`,
 1 AS `requestor_email`,
 1 AS `creation_date`,
 1 AS `impact`,
 1 AS `supervisor_group_id`,
 1 AS `supervisor_group_name`,
 1 AS `supervisor_id`,
 1 AS `supervisor_email`,
 1 AS `manager_group_id`,
 1 AS `manager_group_name`,
 1 AS `manager_id`,
 1 AS `manager_email`,
 1 AS `outage`,
 1 AS `fallback`,
 1 AS `parent_id`,
 1 AS `parent_name`,
 1 AS `external_id_cambios`,
 1 AS `servicefamily_key`,
 1 AS `servicefamily_n`,
 1 AS `service_key`,
 1 AS `service_n`,
 1 AS `servicesubcategory_key`,
 1 AS `servicesubcategory_n`,
 1 AS `tipo_cambio`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `caller_id_friendlyname`,
 1 AS `team_id_friendlyname`,
 1 AS `agent_id_friendlyname`,
 1 AS `requestor_id_friendlyname`,
 1 AS `supervisor_group_id_friendlyname`,
 1 AS `supervisor_id_friendlyname`,
 1 AS `manager_group_id_friendlyname`,
 1 AS `manager_id_friendlyname`,
 1 AS `parent_id_friendlyname`,
 1 AS `parent_id_finalclass_recall`,
 1 AS `servicefamily_key_friendlyname`,
 1 AS `service_key_friendlyname`,
 1 AS `servicesubcategory_key_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_SANSwitch`
--

DROP TABLE IF EXISTS `view_SANSwitch`;
/*!50001 DROP VIEW IF EXISTS `view_SANSwitch`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_SANSwitch` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `rack_id`,
 1 AS `rack_name`,
 1 AS `enclosure_id`,
 1 AS `enclosure_name`,
 1 AS `nb_u`,
 1 AS `managementip`,
 1 AS `powerA_id`,
 1 AS `powerA_name`,
 1 AS `powerB_id`,
 1 AS `powerB_name`,
 1 AS `redundancy`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`,
 1 AS `rack_id_friendlyname`,
 1 AS `enclosure_id_friendlyname`,
 1 AS `powerA_id_friendlyname`,
 1 AS `powerA_id_finalclass_recall`,
 1 AS `powerB_id_friendlyname`,
 1 AS `powerB_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_SLA`
--

DROP TABLE IF EXISTS `view_SLA`;
/*!50001 DROP VIEW IF EXISTS `view_SLA`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_SLA` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_SLT`
--

DROP TABLE IF EXISTS `view_SLT`;
/*!50001 DROP VIEW IF EXISTS `view_SLT`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_SLT` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `priority`,
 1 AS `request_type`,
 1 AS `metric`,
 1 AS `value`,
 1 AS `unit`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Server`
--

DROP TABLE IF EXISTS `view_Server`;
/*!50001 DROP VIEW IF EXISTS `view_Server`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Server` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `rack_id`,
 1 AS `rack_name`,
 1 AS `enclosure_id`,
 1 AS `enclosure_name`,
 1 AS `nb_u`,
 1 AS `managementip`,
 1 AS `powerA_id`,
 1 AS `powerA_name`,
 1 AS `powerB_id`,
 1 AS `powerB_name`,
 1 AS `redundancy`,
 1 AS `osfamily_id`,
 1 AS `osfamily_name`,
 1 AS `osversion_id`,
 1 AS `osversion_name`,
 1 AS `oslicence_id`,
 1 AS `oslicence_name`,
 1 AS `cpu`,
 1 AS `ram`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`,
 1 AS `rack_id_friendlyname`,
 1 AS `enclosure_id_friendlyname`,
 1 AS `powerA_id_friendlyname`,
 1 AS `powerA_id_finalclass_recall`,
 1 AS `powerB_id_friendlyname`,
 1 AS `powerB_id_finalclass_recall`,
 1 AS `osfamily_id_friendlyname`,
 1 AS `osversion_id_friendlyname`,
 1 AS `oslicence_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Service`
--

DROP TABLE IF EXISTS `view_Service`;
/*!50001 DROP VIEW IF EXISTS `view_Service`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Service` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `servicefamily_id`,
 1 AS `servicefamily_name`,
 1 AS `description`,
 1 AS `status`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `servicefamily_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_ServiceFamily`
--

DROP TABLE IF EXISTS `view_ServiceFamily`;
/*!50001 DROP VIEW IF EXISTS `view_ServiceFamily`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_ServiceFamily` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_ServiceSubcategory`
--

DROP TABLE IF EXISTS `view_ServiceSubcategory`;
/*!50001 DROP VIEW IF EXISTS `view_ServiceSubcategory`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_ServiceSubcategory` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `service_id`,
 1 AS `service_org_id`,
 1 AS `service_name`,
 1 AS `service_provider`,
 1 AS `request_type`,
 1 AS `status`,
 1 AS `friendlyname`,
 1 AS `service_id_friendlyname`,
 1 AS `service_org_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Software`
--

DROP TABLE IF EXISTS `view_Software`;
/*!50001 DROP VIEW IF EXISTS `view_Software`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Software` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `vendor`,
 1 AS `version`,
 1 AS `type`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_SoftwareInstance`
--

DROP TABLE IF EXISTS `view_SoftwareInstance`;
/*!50001 DROP VIEW IF EXISTS `view_SoftwareInstance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_SoftwareInstance` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `system_id`,
 1 AS `system_name`,
 1 AS `software_id`,
 1 AS `software_name`,
 1 AS `softwarelicence_id`,
 1 AS `softwarelicence_name`,
 1 AS `path`,
 1 AS `status`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `system_id_friendlyname`,
 1 AS `system_id_finalclass_recall`,
 1 AS `software_id_friendlyname`,
 1 AS `softwarelicence_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_SoftwareLicence`
--

DROP TABLE IF EXISTS `view_SoftwareLicence`;
/*!50001 DROP VIEW IF EXISTS `view_SoftwareLicence`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_SoftwareLicence` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `usage_limit`,
 1 AS `description`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `licence_key`,
 1 AS `perpetual`,
 1 AS `software_id`,
 1 AS `software_name`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `software_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_SoftwarePatch`
--

DROP TABLE IF EXISTS `view_SoftwarePatch`;
/*!50001 DROP VIEW IF EXISTS `view_SoftwarePatch`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_SoftwarePatch` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `software_id`,
 1 AS `software_name`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `software_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_StorageSystem`
--

DROP TABLE IF EXISTS `view_StorageSystem`;
/*!50001 DROP VIEW IF EXISTS `view_StorageSystem`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_StorageSystem` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `rack_id`,
 1 AS `rack_name`,
 1 AS `enclosure_id`,
 1 AS `enclosure_name`,
 1 AS `nb_u`,
 1 AS `managementip`,
 1 AS `powerA_id`,
 1 AS `powerA_name`,
 1 AS `powerB_id`,
 1 AS `powerB_name`,
 1 AS `redundancy`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`,
 1 AS `rack_id_friendlyname`,
 1 AS `enclosure_id_friendlyname`,
 1 AS `powerA_id_friendlyname`,
 1 AS `powerA_id_finalclass_recall`,
 1 AS `powerB_id_friendlyname`,
 1 AS `powerB_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Subnet`
--

DROP TABLE IF EXISTS `view_Subnet`;
/*!50001 DROP VIEW IF EXISTS `view_Subnet`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Subnet` AS SELECT 
 1 AS `id`,
 1 AS `description`,
 1 AS `subnet_name`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `ip`,
 1 AS `ip_mask`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Tablet`
--

DROP TABLE IF EXISTS `view_Tablet`;
/*!50001 DROP VIEW IF EXISTS `view_Tablet`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Tablet` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Tape`
--

DROP TABLE IF EXISTS `view_Tape`;
/*!50001 DROP VIEW IF EXISTS `view_Tape`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Tape` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `size`,
 1 AS `tapelibrary_id`,
 1 AS `tapelibrary_name`,
 1 AS `friendlyname`,
 1 AS `tapelibrary_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_TapeLibrary`
--

DROP TABLE IF EXISTS `view_TapeLibrary`;
/*!50001 DROP VIEW IF EXISTS `view_TapeLibrary`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_TapeLibrary` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `rack_id`,
 1 AS `rack_name`,
 1 AS `enclosure_id`,
 1 AS `enclosure_name`,
 1 AS `nb_u`,
 1 AS `managementip`,
 1 AS `powerA_id`,
 1 AS `powerA_name`,
 1 AS `powerB_id`,
 1 AS `powerB_name`,
 1 AS `redundancy`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`,
 1 AS `rack_id_friendlyname`,
 1 AS `enclosure_id_friendlyname`,
 1 AS `powerA_id_friendlyname`,
 1 AS `powerA_id_finalclass_recall`,
 1 AS `powerB_id_friendlyname`,
 1 AS `powerB_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Team`
--

DROP TABLE IF EXISTS `view_Team`;
/*!50001 DROP VIEW IF EXISTS `view_Team`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Team` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `status`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `email`,
 1 AS `phone`,
 1 AS `notify`,
 1 AS `function`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_TelephonyCI`
--

DROP TABLE IF EXISTS `view_TelephonyCI`;
/*!50001 DROP VIEW IF EXISTS `view_TelephonyCI`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_TelephonyCI` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `phonenumber`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Ticket`
--

DROP TABLE IF EXISTS `view_Ticket`;
/*!50001 DROP VIEW IF EXISTS `view_Ticket`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Ticket` AS SELECT 
 1 AS `id`,
 1 AS `operational_status`,
 1 AS `ref`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `caller_id`,
 1 AS `caller_name`,
 1 AS `team_id`,
 1 AS `team_name`,
 1 AS `agent_id`,
 1 AS `agent_name`,
 1 AS `title`,
 1 AS `description`,
 1 AS `description_format`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `last_update`,
 1 AS `close_date`,
 1 AS `private_log`,
 1 AS `private_log_index`,
 1 AS `id_instalador`,
 1 AS `san`,
 1 AS `nombre_instalador`,
 1 AS `pais_ticket`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `caller_id_friendlyname`,
 1 AS `team_id_friendlyname`,
 1 AS `agent_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Typology`
--

DROP TABLE IF EXISTS `view_Typology`;
/*!50001 DROP VIEW IF EXISTS `view_Typology`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Typology` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `finalclass`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_UserRequest`
--

DROP TABLE IF EXISTS `view_UserRequest`;
/*!50001 DROP VIEW IF EXISTS `view_UserRequest`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_UserRequest` AS SELECT 
 1 AS `id`,
 1 AS `operational_status`,
 1 AS `ref`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `caller_id`,
 1 AS `caller_name`,
 1 AS `team_id`,
 1 AS `team_name`,
 1 AS `agent_id`,
 1 AS `agent_name`,
 1 AS `title`,
 1 AS `description`,
 1 AS `description_format`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `last_update`,
 1 AS `close_date`,
 1 AS `private_log`,
 1 AS `private_log_index`,
 1 AS `id_instalador`,
 1 AS `san`,
 1 AS `nombre_instalador`,
 1 AS `pais_ticket`,
 1 AS `status`,
 1 AS `request_type`,
 1 AS `impact`,
 1 AS `priority`,
 1 AS `urgency`,
 1 AS `origin`,
 1 AS `approver_id`,
 1 AS `approver_email`,
 1 AS `servicefamily_id`,
 1 AS `servicefamily_name`,
 1 AS `service_id`,
 1 AS `service_name`,
 1 AS `servicesubcategory_id`,
 1 AS `servicesubcategory_name`,
 1 AS `escalation_flag`,
 1 AS `escalation_reason`,
 1 AS `assignment_date`,
 1 AS `resolution_date`,
 1 AS `last_pending_date`,
 1 AS `cumulatedpending`,
 1 AS `cumulatedpending_started`,
 1 AS `cumulatedpending_laststart`,
 1 AS `cumulatedpending_stopped`,
 1 AS `tto`,
 1 AS `tto_started`,
 1 AS `tto_laststart`,
 1 AS `tto_stopped`,
 1 AS `tto_75_deadline`,
 1 AS `tto_75_passed`,
 1 AS `tto_75_triggered`,
 1 AS `tto_75_overrun`,
 1 AS `tto_100_deadline`,
 1 AS `tto_100_passed`,
 1 AS `tto_100_triggered`,
 1 AS `tto_100_overrun`,
 1 AS `ttr`,
 1 AS `ttr_started`,
 1 AS `ttr_laststart`,
 1 AS `ttr_stopped`,
 1 AS `ttr_75_deadline`,
 1 AS `ttr_75_passed`,
 1 AS `ttr_75_triggered`,
 1 AS `ttr_75_overrun`,
 1 AS `ttr_100_deadline`,
 1 AS `ttr_100_passed`,
 1 AS `ttr_100_triggered`,
 1 AS `ttr_100_overrun`,
 1 AS `tto_escalation_deadline`,
 1 AS `sla_tto_passed`,
 1 AS `sla_tto_over`,
 1 AS `ttr_escalation_deadline`,
 1 AS `sla_ttr_passed`,
 1 AS `sla_ttr_over`,
 1 AS `time_spent`,
 1 AS `resolution_code`,
 1 AS `solution`,
 1 AS `pending_reason`,
 1 AS `parent_request_id`,
 1 AS `parent_request_ref`,
 1 AS `parent_incident_id`,
 1 AS `parent_incident_ref`,
 1 AS `parent_problem_id`,
 1 AS `parent_problem_ref`,
 1 AS `parent_change_id`,
 1 AS `parent_change_ref`,
 1 AS `public_log`,
 1 AS `public_log_index`,
 1 AS `user_satisfaction`,
 1 AS `user_comment`,
 1 AS `external_id`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `caller_id_friendlyname`,
 1 AS `team_id_friendlyname`,
 1 AS `agent_id_friendlyname`,
 1 AS `approver_id_friendlyname`,
 1 AS `servicefamily_id_friendlyname`,
 1 AS `service_id_friendlyname`,
 1 AS `servicesubcategory_id_friendlyname`,
 1 AS `parent_request_id_friendlyname`,
 1 AS `parent_incident_id_friendlyname`,
 1 AS `parent_problem_id_friendlyname`,
 1 AS `parent_change_id_friendlyname`,
 1 AS `parent_change_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_VLAN`
--

DROP TABLE IF EXISTS `view_VLAN`;
/*!50001 DROP VIEW IF EXISTS `view_VLAN`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_VLAN` AS SELECT 
 1 AS `id`,
 1 AS `vlan_tag`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_VirtualDevice`
--

DROP TABLE IF EXISTS `view_VirtualDevice`;
/*!50001 DROP VIEW IF EXISTS `view_VirtualDevice`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_VirtualDevice` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `status`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_VirtualHost`
--

DROP TABLE IF EXISTS `view_VirtualHost`;
/*!50001 DROP VIEW IF EXISTS `view_VirtualHost`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_VirtualHost` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `status`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_VirtualMachine`
--

DROP TABLE IF EXISTS `view_VirtualMachine`;
/*!50001 DROP VIEW IF EXISTS `view_VirtualMachine`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_VirtualMachine` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `status`,
 1 AS `virtualhost_id`,
 1 AS `virtualhost_name`,
 1 AS `osfamily_id`,
 1 AS `osfamily_name`,
 1 AS `osversion_id`,
 1 AS `osversion_name`,
 1 AS `oslicence_id`,
 1 AS `oslicence_name`,
 1 AS `cpu`,
 1 AS `ram`,
 1 AS `managementip`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `virtualhost_id_friendlyname`,
 1 AS `virtualhost_id_finalclass_recall`,
 1 AS `osfamily_id_friendlyname`,
 1 AS `osversion_id_friendlyname`,
 1 AS `oslicence_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_WebApplication`
--

DROP TABLE IF EXISTS `view_WebApplication`;
/*!50001 DROP VIEW IF EXISTS `view_WebApplication`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_WebApplication` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `webserver_id`,
 1 AS `webserver_name`,
 1 AS `url`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `webserver_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_WebServer`
--

DROP TABLE IF EXISTS `view_WebServer`;
/*!50001 DROP VIEW IF EXISTS `view_WebServer`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_WebServer` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `system_id`,
 1 AS `system_name`,
 1 AS `software_id`,
 1 AS `software_name`,
 1 AS `softwarelicence_id`,
 1 AS `softwarelicence_name`,
 1 AS `path`,
 1 AS `status`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `system_id_friendlyname`,
 1 AS `system_id_finalclass_recall`,
 1 AS `software_id_friendlyname`,
 1 AS `softwarelicence_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_WorkOrder`
--

DROP TABLE IF EXISTS `view_WorkOrder`;
/*!50001 DROP VIEW IF EXISTS `view_WorkOrder`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_WorkOrder` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `status`,
 1 AS `description`,
 1 AS `ticket_id`,
 1 AS `ticket_ref`,
 1 AS `team_id`,
 1 AS `team_name`,
 1 AS `agent_id`,
 1 AS `agent_email`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `log`,
 1 AS `log_index`,
 1 AS `friendlyname`,
 1 AS `ticket_id_friendlyname`,
 1 AS `ticket_id_finalclass_recall`,
 1 AS `team_id_friendlyname`,
 1 AS `agent_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkApplicationSolutionToBusinessProcess`
--

DROP TABLE IF EXISTS `view_lnkApplicationSolutionToBusinessProcess`;
/*!50001 DROP VIEW IF EXISTS `view_lnkApplicationSolutionToBusinessProcess`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkApplicationSolutionToBusinessProcess` AS SELECT 
 1 AS `id`,
 1 AS `businessprocess_id`,
 1 AS `businessprocess_name`,
 1 AS `applicationsolution_id`,
 1 AS `applicationsolution_name`,
 1 AS `friendlyname`,
 1 AS `businessprocess_id_friendlyname`,
 1 AS `applicationsolution_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkApplicationSolutionToFunctionalCI`
--

DROP TABLE IF EXISTS `view_lnkApplicationSolutionToFunctionalCI`;
/*!50001 DROP VIEW IF EXISTS `view_lnkApplicationSolutionToFunctionalCI`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkApplicationSolutionToFunctionalCI` AS SELECT 
 1 AS `id`,
 1 AS `applicationsolution_id`,
 1 AS `applicationsolution_name`,
 1 AS `functionalci_id`,
 1 AS `functionalci_name`,
 1 AS `friendlyname`,
 1 AS `applicationsolution_id_friendlyname`,
 1 AS `functionalci_id_friendlyname`,
 1 AS `functionalci_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkConnectableCIToNetworkDevice`
--

DROP TABLE IF EXISTS `view_lnkConnectableCIToNetworkDevice`;
/*!50001 DROP VIEW IF EXISTS `view_lnkConnectableCIToNetworkDevice`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkConnectableCIToNetworkDevice` AS SELECT 
 1 AS `id`,
 1 AS `networkdevice_id`,
 1 AS `networkdevice_name`,
 1 AS `connectableci_id`,
 1 AS `connectableci_name`,
 1 AS `network_port`,
 1 AS `device_port`,
 1 AS `connection_type`,
 1 AS `friendlyname`,
 1 AS `networkdevice_id_friendlyname`,
 1 AS `connectableci_id_friendlyname`,
 1 AS `connectableci_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkContactToContract`
--

DROP TABLE IF EXISTS `view_lnkContactToContract`;
/*!50001 DROP VIEW IF EXISTS `view_lnkContactToContract`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkContactToContract` AS SELECT 
 1 AS `id`,
 1 AS `contract_id`,
 1 AS `contract_name`,
 1 AS `contact_id`,
 1 AS `contact_name`,
 1 AS `friendlyname`,
 1 AS `contract_id_friendlyname`,
 1 AS `contract_id_finalclass_recall`,
 1 AS `contact_id_friendlyname`,
 1 AS `contact_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkContactToFunctionalCI`
--

DROP TABLE IF EXISTS `view_lnkContactToFunctionalCI`;
/*!50001 DROP VIEW IF EXISTS `view_lnkContactToFunctionalCI`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkContactToFunctionalCI` AS SELECT 
 1 AS `id`,
 1 AS `functionalci_id`,
 1 AS `functionalci_name`,
 1 AS `contact_id`,
 1 AS `contact_name`,
 1 AS `friendlyname`,
 1 AS `functionalci_id_friendlyname`,
 1 AS `functionalci_id_finalclass_recall`,
 1 AS `contact_id_friendlyname`,
 1 AS `contact_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkContactToService`
--

DROP TABLE IF EXISTS `view_lnkContactToService`;
/*!50001 DROP VIEW IF EXISTS `view_lnkContactToService`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkContactToService` AS SELECT 
 1 AS `id`,
 1 AS `service_id`,
 1 AS `service_name`,
 1 AS `contact_id`,
 1 AS `contact_name`,
 1 AS `friendlyname`,
 1 AS `service_id_friendlyname`,
 1 AS `contact_id_friendlyname`,
 1 AS `contact_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkContactToTicket`
--

DROP TABLE IF EXISTS `view_lnkContactToTicket`;
/*!50001 DROP VIEW IF EXISTS `view_lnkContactToTicket`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkContactToTicket` AS SELECT 
 1 AS `id`,
 1 AS `ticket_id`,
 1 AS `ticket_ref`,
 1 AS `contact_id`,
 1 AS `contact_email`,
 1 AS `role`,
 1 AS `role_code`,
 1 AS `friendlyname`,
 1 AS `ticket_id_friendlyname`,
 1 AS `ticket_id_finalclass_recall`,
 1 AS `contact_id_friendlyname`,
 1 AS `contact_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkContractToDocument`
--

DROP TABLE IF EXISTS `view_lnkContractToDocument`;
/*!50001 DROP VIEW IF EXISTS `view_lnkContractToDocument`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkContractToDocument` AS SELECT 
 1 AS `id`,
 1 AS `contract_id`,
 1 AS `contract_name`,
 1 AS `document_id`,
 1 AS `document_name`,
 1 AS `friendlyname`,
 1 AS `contract_id_friendlyname`,
 1 AS `contract_id_finalclass_recall`,
 1 AS `document_id_friendlyname`,
 1 AS `document_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkCustomerContractToService`
--

DROP TABLE IF EXISTS `view_lnkCustomerContractToService`;
/*!50001 DROP VIEW IF EXISTS `view_lnkCustomerContractToService`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkCustomerContractToService` AS SELECT 
 1 AS `id`,
 1 AS `customercontract_id`,
 1 AS `customercontract_name`,
 1 AS `service_id`,
 1 AS `service_name`,
 1 AS `sla_id`,
 1 AS `sla_name`,
 1 AS `coveragewindow_id`,
 1 AS `coveragewindow_name`,
 1 AS `friendlyname`,
 1 AS `customercontract_id_friendlyname`,
 1 AS `service_id_friendlyname`,
 1 AS `sla_id_friendlyname`,
 1 AS `coveragewindow_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkDeliveryModelToContact`
--

DROP TABLE IF EXISTS `view_lnkDeliveryModelToContact`;
/*!50001 DROP VIEW IF EXISTS `view_lnkDeliveryModelToContact`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkDeliveryModelToContact` AS SELECT 
 1 AS `id`,
 1 AS `deliverymodel_id`,
 1 AS `deliverymodel_name`,
 1 AS `contact_id`,
 1 AS `contact_name`,
 1 AS `role_id`,
 1 AS `role_name`,
 1 AS `friendlyname`,
 1 AS `deliverymodel_id_friendlyname`,
 1 AS `contact_id_friendlyname`,
 1 AS `contact_id_finalclass_recall`,
 1 AS `role_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkDocumentToError`
--

DROP TABLE IF EXISTS `view_lnkDocumentToError`;
/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToError`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkDocumentToError` AS SELECT 
 1 AS `id`,
 1 AS `document_id`,
 1 AS `document_name`,
 1 AS `error_id`,
 1 AS `error_name`,
 1 AS `link_type`,
 1 AS `friendlyname`,
 1 AS `document_id_friendlyname`,
 1 AS `document_id_finalclass_recall`,
 1 AS `error_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkDocumentToFunctionalCI`
--

DROP TABLE IF EXISTS `view_lnkDocumentToFunctionalCI`;
/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToFunctionalCI`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkDocumentToFunctionalCI` AS SELECT 
 1 AS `id`,
 1 AS `functionalci_id`,
 1 AS `functionalci_name`,
 1 AS `document_id`,
 1 AS `document_name`,
 1 AS `friendlyname`,
 1 AS `functionalci_id_friendlyname`,
 1 AS `functionalci_id_finalclass_recall`,
 1 AS `document_id_friendlyname`,
 1 AS `document_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkDocumentToLicence`
--

DROP TABLE IF EXISTS `view_lnkDocumentToLicence`;
/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToLicence`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkDocumentToLicence` AS SELECT 
 1 AS `id`,
 1 AS `licence_id`,
 1 AS `licence_name`,
 1 AS `document_id`,
 1 AS `document_name`,
 1 AS `friendlyname`,
 1 AS `licence_id_friendlyname`,
 1 AS `licence_id_finalclass_recall`,
 1 AS `document_id_friendlyname`,
 1 AS `document_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkDocumentToPatch`
--

DROP TABLE IF EXISTS `view_lnkDocumentToPatch`;
/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToPatch`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkDocumentToPatch` AS SELECT 
 1 AS `id`,
 1 AS `patch_id`,
 1 AS `patch_name`,
 1 AS `document_id`,
 1 AS `document_name`,
 1 AS `friendlyname`,
 1 AS `patch_id_friendlyname`,
 1 AS `patch_id_finalclass_recall`,
 1 AS `document_id_friendlyname`,
 1 AS `document_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkDocumentToService`
--

DROP TABLE IF EXISTS `view_lnkDocumentToService`;
/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToService`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkDocumentToService` AS SELECT 
 1 AS `id`,
 1 AS `service_id`,
 1 AS `service_name`,
 1 AS `document_id`,
 1 AS `document_name`,
 1 AS `friendlyname`,
 1 AS `service_id_friendlyname`,
 1 AS `document_id_friendlyname`,
 1 AS `document_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkDocumentToSoftware`
--

DROP TABLE IF EXISTS `view_lnkDocumentToSoftware`;
/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToSoftware`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkDocumentToSoftware` AS SELECT 
 1 AS `id`,
 1 AS `software_id`,
 1 AS `software_name`,
 1 AS `document_id`,
 1 AS `document_name`,
 1 AS `friendlyname`,
 1 AS `software_id_friendlyname`,
 1 AS `document_id_friendlyname`,
 1 AS `document_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkErrorToFunctionalCI`
--

DROP TABLE IF EXISTS `view_lnkErrorToFunctionalCI`;
/*!50001 DROP VIEW IF EXISTS `view_lnkErrorToFunctionalCI`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkErrorToFunctionalCI` AS SELECT 
 1 AS `id`,
 1 AS `functionalci_id`,
 1 AS `functionalci_name`,
 1 AS `error_id`,
 1 AS `error_name`,
 1 AS `reason`,
 1 AS `friendlyname`,
 1 AS `functionalci_id_friendlyname`,
 1 AS `functionalci_id_finalclass_recall`,
 1 AS `error_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkFunctionalCIToOSPatch`
--

DROP TABLE IF EXISTS `view_lnkFunctionalCIToOSPatch`;
/*!50001 DROP VIEW IF EXISTS `view_lnkFunctionalCIToOSPatch`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkFunctionalCIToOSPatch` AS SELECT 
 1 AS `id`,
 1 AS `ospatch_id`,
 1 AS `ospatch_name`,
 1 AS `functionalci_id`,
 1 AS `functionalci_name`,
 1 AS `friendlyname`,
 1 AS `ospatch_id_friendlyname`,
 1 AS `functionalci_id_friendlyname`,
 1 AS `functionalci_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkFunctionalCIToProviderContract`
--

DROP TABLE IF EXISTS `view_lnkFunctionalCIToProviderContract`;
/*!50001 DROP VIEW IF EXISTS `view_lnkFunctionalCIToProviderContract`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkFunctionalCIToProviderContract` AS SELECT 
 1 AS `id`,
 1 AS `providercontract_id`,
 1 AS `providercontract_name`,
 1 AS `functionalci_id`,
 1 AS `functionalci_name`,
 1 AS `friendlyname`,
 1 AS `providercontract_id_friendlyname`,
 1 AS `functionalci_id_friendlyname`,
 1 AS `functionalci_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkFunctionalCIToService`
--

DROP TABLE IF EXISTS `view_lnkFunctionalCIToService`;
/*!50001 DROP VIEW IF EXISTS `view_lnkFunctionalCIToService`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkFunctionalCIToService` AS SELECT 
 1 AS `id`,
 1 AS `service_id`,
 1 AS `service_name`,
 1 AS `functionalci_id`,
 1 AS `functionalci_name`,
 1 AS `friendlyname`,
 1 AS `service_id_friendlyname`,
 1 AS `functionalci_id_friendlyname`,
 1 AS `functionalci_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkFunctionalCIToTicket`
--

DROP TABLE IF EXISTS `view_lnkFunctionalCIToTicket`;
/*!50001 DROP VIEW IF EXISTS `view_lnkFunctionalCIToTicket`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkFunctionalCIToTicket` AS SELECT 
 1 AS `id`,
 1 AS `ticket_id`,
 1 AS `ticket_ref`,
 1 AS `ticket_title`,
 1 AS `functionalci_id`,
 1 AS `functionalci_name`,
 1 AS `impact`,
 1 AS `impact_code`,
 1 AS `friendlyname`,
 1 AS `ticket_id_friendlyname`,
 1 AS `ticket_id_finalclass_recall`,
 1 AS `functionalci_id_friendlyname`,
 1 AS `functionalci_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkGroupToCI`
--

DROP TABLE IF EXISTS `view_lnkGroupToCI`;
/*!50001 DROP VIEW IF EXISTS `view_lnkGroupToCI`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkGroupToCI` AS SELECT 
 1 AS `id`,
 1 AS `group_id`,
 1 AS `group_name`,
 1 AS `ci_id`,
 1 AS `ci_name`,
 1 AS `reason`,
 1 AS `friendlyname`,
 1 AS `group_id_friendlyname`,
 1 AS `ci_id_friendlyname`,
 1 AS `ci_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkPersonToTeam`
--

DROP TABLE IF EXISTS `view_lnkPersonToTeam`;
/*!50001 DROP VIEW IF EXISTS `view_lnkPersonToTeam`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkPersonToTeam` AS SELECT 
 1 AS `id`,
 1 AS `team_id`,
 1 AS `team_name`,
 1 AS `person_id`,
 1 AS `person_name`,
 1 AS `role_id`,
 1 AS `role_name`,
 1 AS `friendlyname`,
 1 AS `team_id_friendlyname`,
 1 AS `person_id_friendlyname`,
 1 AS `role_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkPhysicalInterfaceToVLAN`
--

DROP TABLE IF EXISTS `view_lnkPhysicalInterfaceToVLAN`;
/*!50001 DROP VIEW IF EXISTS `view_lnkPhysicalInterfaceToVLAN`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkPhysicalInterfaceToVLAN` AS SELECT 
 1 AS `id`,
 1 AS `physicalinterface_id`,
 1 AS `physicalinterface_name`,
 1 AS `physicalinterface_device_id`,
 1 AS `physicalinterface_device_name`,
 1 AS `vlan_id`,
 1 AS `vlan_tag`,
 1 AS `friendlyname`,
 1 AS `physicalinterface_id_friendlyname`,
 1 AS `physicalinterface_device_id_friendlyname`,
 1 AS `vlan_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkProviderContractToService`
--

DROP TABLE IF EXISTS `view_lnkProviderContractToService`;
/*!50001 DROP VIEW IF EXISTS `view_lnkProviderContractToService`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkProviderContractToService` AS SELECT 
 1 AS `id`,
 1 AS `service_id`,
 1 AS `service_name`,
 1 AS `providercontract_id`,
 1 AS `providercontract_name`,
 1 AS `friendlyname`,
 1 AS `service_id_friendlyname`,
 1 AS `providercontract_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkSLAToSLT`
--

DROP TABLE IF EXISTS `view_lnkSLAToSLT`;
/*!50001 DROP VIEW IF EXISTS `view_lnkSLAToSLT`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkSLAToSLT` AS SELECT 
 1 AS `id`,
 1 AS `sla_id`,
 1 AS `sla_name`,
 1 AS `slt_id`,
 1 AS `slt_name`,
 1 AS `slt_metric`,
 1 AS `slt_request_type`,
 1 AS `slt_ticket_priority`,
 1 AS `slt_value`,
 1 AS `slt_value_unit`,
 1 AS `friendlyname`,
 1 AS `sla_id_friendlyname`,
 1 AS `slt_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkSanToDatacenterDevice`
--

DROP TABLE IF EXISTS `view_lnkSanToDatacenterDevice`;
/*!50001 DROP VIEW IF EXISTS `view_lnkSanToDatacenterDevice`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkSanToDatacenterDevice` AS SELECT 
 1 AS `id`,
 1 AS `san_id`,
 1 AS `san_name`,
 1 AS `datacenterdevice_id`,
 1 AS `datacenterdevice_name`,
 1 AS `san_port`,
 1 AS `datacenterdevice_port`,
 1 AS `friendlyname`,
 1 AS `san_id_friendlyname`,
 1 AS `datacenterdevice_id_friendlyname`,
 1 AS `datacenterdevice_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkServerToVolume`
--

DROP TABLE IF EXISTS `view_lnkServerToVolume`;
/*!50001 DROP VIEW IF EXISTS `view_lnkServerToVolume`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkServerToVolume` AS SELECT 
 1 AS `id`,
 1 AS `volume_id`,
 1 AS `volume_name`,
 1 AS `server_id`,
 1 AS `server_name`,
 1 AS `size_used`,
 1 AS `friendlyname`,
 1 AS `volume_id_friendlyname`,
 1 AS `server_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkSoftwareInstanceToSoftwarePatch`
--

DROP TABLE IF EXISTS `view_lnkSoftwareInstanceToSoftwarePatch`;
/*!50001 DROP VIEW IF EXISTS `view_lnkSoftwareInstanceToSoftwarePatch`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkSoftwareInstanceToSoftwarePatch` AS SELECT 
 1 AS `id`,
 1 AS `softwarepatch_id`,
 1 AS `softwarepatch_name`,
 1 AS `softwareinstance_id`,
 1 AS `softwareinstance_name`,
 1 AS `friendlyname`,
 1 AS `softwarepatch_id_friendlyname`,
 1 AS `softwareinstance_id_friendlyname`,
 1 AS `softwareinstance_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkSubnetToVLAN`
--

DROP TABLE IF EXISTS `view_lnkSubnetToVLAN`;
/*!50001 DROP VIEW IF EXISTS `view_lnkSubnetToVLAN`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkSubnetToVLAN` AS SELECT 
 1 AS `id`,
 1 AS `subnet_id`,
 1 AS `subnet_ip`,
 1 AS `subnet_name`,
 1 AS `vlan_id`,
 1 AS `vlan_tag`,
 1 AS `friendlyname`,
 1 AS `subnet_id_friendlyname`,
 1 AS `vlan_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkVirtualDeviceToVolume`
--

DROP TABLE IF EXISTS `view_lnkVirtualDeviceToVolume`;
/*!50001 DROP VIEW IF EXISTS `view_lnkVirtualDeviceToVolume`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkVirtualDeviceToVolume` AS SELECT 
 1 AS `id`,
 1 AS `volume_id`,
 1 AS `volume_name`,
 1 AS `virtualdevice_id`,
 1 AS `virtualdevice_name`,
 1 AS `size_used`,
 1 AS `friendlyname`,
 1 AS `volume_id_friendlyname`,
 1 AS `virtualdevice_id_friendlyname`,
 1 AS `virtualdevice_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `virtualdevice`
--

DROP TABLE IF EXISTS `virtualdevice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `virtualdevice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` enum('implementation','obsolete','production','stock') COLLATE utf8_unicode_ci DEFAULT 'production',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `virtualdevice`
--

LOCK TABLES `virtualdevice` WRITE;
/*!40000 ALTER TABLE `virtualdevice` DISABLE KEYS */;
INSERT INTO `virtualdevice` VALUES (11,'production'),(12,'production'),(13,'production'),(14,'production'),(15,'production'),(16,'production');
/*!40000 ALTER TABLE `virtualdevice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `virtualhost`
--

DROP TABLE IF EXISTS `virtualhost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `virtualhost` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `virtualhost`
--

LOCK TABLES `virtualhost` WRITE;
/*!40000 ALTER TABLE `virtualhost` DISABLE KEYS */;
INSERT INTO `virtualhost` VALUES (11),(12),(13);
/*!40000 ALTER TABLE `virtualhost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `virtualmachine`
--

DROP TABLE IF EXISTS `virtualmachine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `virtualmachine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `virtualhost_id` int(11) DEFAULT '0',
  `osfamily_id` int(11) DEFAULT '0',
  `osversion_id` int(11) DEFAULT '0',
  `oslicence_id` int(11) DEFAULT '0',
  `cpu` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `ram` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `managementip` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `virtualhost_id` (`virtualhost_id`),
  KEY `osfamily_id` (`osfamily_id`),
  KEY `osversion_id` (`osversion_id`),
  KEY `oslicence_id` (`oslicence_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `virtualmachine`
--

LOCK TABLES `virtualmachine` WRITE;
/*!40000 ALTER TABLE `virtualmachine` DISABLE KEYS */;
INSERT INTO `virtualmachine` VALUES (14,12,1,2,1,'','8 Gb','50.63.161.27'),(15,13,3,4,2,'','','18.216.179.61'),(16,13,3,4,2,'Xcon(r) 2.4 Ghz','1 Gb','18.217.220.111');
/*!40000 ALTER TABLE `virtualmachine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vlan`
--

DROP TABLE IF EXISTS `vlan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vlan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vlan_tag` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` text COLLATE utf8_unicode_ci,
  `org_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vlan`
--

LOCK TABLES `vlan` WRITE;
/*!40000 ALTER TABLE `vlan` DISABLE KEYS */;
/*!40000 ALTER TABLE `vlan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webapplication`
--

DROP TABLE IF EXISTS `webapplication`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webapplication` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `webserver_id` int(11) DEFAULT '0',
  `url` varchar(2048) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `webserver_id` (`webserver_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webapplication`
--

LOCK TABLES `webapplication` WRITE;
/*!40000 ALTER TABLE `webapplication` DISABLE KEYS */;
INSERT INTO `webapplication` VALUES (18,17,''),(28,27,'https://alltic.co/itop/'),(29,27,'https://alltic.co/BT/'),(30,27,'https://alltic.co/testlink/'),(31,27,'https://alltic.co/time/');
/*!40000 ALTER TABLE `webapplication` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webserver`
--

DROP TABLE IF EXISTS `webserver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webserver` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webserver`
--

LOCK TABLES `webserver` WRITE;
/*!40000 ALTER TABLE `webserver` DISABLE KEYS */;
INSERT INTO `webserver` VALUES (17),(27);
/*!40000 ALTER TABLE `webserver` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workorder`
--

DROP TABLE IF EXISTS `workorder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `status` enum('closed','open') COLLATE utf8_unicode_ci DEFAULT 'open',
  `description` text COLLATE utf8_unicode_ci,
  `ticket_id` int(11) DEFAULT '0',
  `team_id` int(11) DEFAULT '0',
  `owner_id` int(11) DEFAULT '0',
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `log` longtext COLLATE utf8_unicode_ci,
  `log_index` blob,
  PRIMARY KEY (`id`),
  KEY `ticket_id` (`ticket_id`),
  KEY `team_id` (`team_id`),
  KEY `owner_id` (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workorder`
--

LOCK TABLES `workorder` WRITE;
/*!40000 ALTER TABLE `workorder` DISABLE KEYS */;
/*!40000 ALTER TABLE `workorder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `view_ApplicationSolution`
--

/*!50001 DROP VIEW IF EXISTS `view_ApplicationSolution`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_ApplicationSolution` AS select distinct `_applicationsolution`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_applicationsolution`.`status` AS `status`,`_applicationsolution`.`redundancy` AS `redundancy`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from (`applicationsolution` `_applicationsolution` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_applicationsolution`.`id` = `_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_ApprovedChange`
--

/*!50001 DROP VIEW IF EXISTS `view_ApprovedChange`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_ApprovedChange` AS select distinct `_change_approved`.`id` AS `id`,`_ticket`.`operational_status` AS `operational_status`,`_ticket`.`ref` AS `ref`,`_ticket`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ticket`.`caller_id` AS `caller_id`,`Person_caller_id_contact`.`name` AS `caller_name`,`_ticket`.`team_id` AS `team_id`,`Team_team_id_contact`.`email` AS `team_name`,`_ticket`.`agent_id` AS `agent_id`,`Person_agent_id_contact`.`name` AS `agent_name`,`_ticket`.`title` AS `title`,`_ticket`.`description` AS `description`,`_ticket`.`description_format` AS `description_format`,`_ticket`.`start_date` AS `start_date`,`_ticket`.`end_date` AS `end_date`,`_ticket`.`last_update` AS `last_update`,`_ticket`.`close_date` AS `close_date`,`_ticket`.`private_log` AS `private_log`,`_ticket`.`private_log_index` AS `private_log_index`,`_ticket`.`id_instalador` AS `id_instalador`,`_ticket`.`san` AS `san`,`_ticket`.`nombre_instalador` AS `nombre_instalador`,`_ticket`.`pais_ticket` AS `pais_ticket`,`_change`.`status` AS `status`,`_change`.`reason` AS `reason`,`_change`.`requestor_id` AS `requestor_id`,`Person_requestor_id_contact`.`email` AS `requestor_email`,`_change`.`creation_date` AS `creation_date`,`_change`.`impact` AS `impact`,`_change`.`supervisor_group_id` AS `supervisor_group_id`,`Team_supervisor_group_id_contact`.`name` AS `supervisor_group_name`,`_change`.`supervisor_id` AS `supervisor_id`,`Person_supervisor_id_contact`.`email` AS `supervisor_email`,`_change`.`manager_group_id` AS `manager_group_id`,`Team_manager_group_id_contact`.`name` AS `manager_group_name`,`_change`.`manager_id` AS `manager_id`,`Person_manager_id_contact`.`email` AS `manager_email`,`_change`.`outage` AS `outage`,`_change`.`fallback` AS `fallback`,`_change`.`parent_id` AS `parent_id`,`Change_parent_id_ticket`.`ref` AS `parent_name`,`_change`.`external_id_cambios` AS `external_id_cambios`,`_change`.`servicefamily_key` AS `servicefamily_key`,`ServiceFamily_servicefamily_key_servicefamily`.`name` AS `servicefamily_n`,`_change`.`service_key` AS `service_key`,`Service_service_key_service`.`name` AS `service_n`,`_change`.`servicesubcategory_key` AS `servicesubcategory_key`,`ServiceSubcategory_servicesubcategory_key_servicesubcategory`.`name` AS `servicesubcategory_n`,`_change_approved`.`approval_date` AS `approval_date`,`_change_approved`.`approval_comment` AS `approval_comment`,`_ticket`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_ticket`.`ref`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_caller_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_caller_id_contact`.`name`,'')) as char charset utf8) AS `caller_id_friendlyname`,cast(concat(coalesce(`Team_team_id_contact`.`name`,'')) as char charset utf8) AS `team_id_friendlyname`,cast(concat(coalesce(`Person_agent_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_agent_id_contact`.`name`,'')) as char charset utf8) AS `agent_id_friendlyname`,cast(concat(coalesce(`Person_requestor_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_requestor_id_contact`.`name`,'')) as char charset utf8) AS `requestor_id_friendlyname`,cast(concat(coalesce(`Team_supervisor_group_id_contact`.`name`,'')) as char charset utf8) AS `supervisor_group_id_friendlyname`,cast(concat(coalesce(`Person_supervisor_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_supervisor_id_contact`.`name`,'')) as char charset utf8) AS `supervisor_id_friendlyname`,cast(concat(coalesce(`Team_manager_group_id_contact`.`name`,'')) as char charset utf8) AS `manager_group_id_friendlyname`,cast(concat(coalesce(`Person_manager_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_manager_id_contact`.`name`,'')) as char charset utf8) AS `manager_id_friendlyname`,cast(concat(coalesce(`Change_parent_id_ticket`.`ref`,'')) as char charset utf8) AS `parent_id_friendlyname`,`Change_parent_id_ticket`.`finalclass` AS `parent_id_finalclass_recall`,cast(concat(coalesce(`ServiceFamily_servicefamily_key_servicefamily`.`name`,'')) as char charset utf8) AS `servicefamily_key_friendlyname`,cast(concat(coalesce(`Service_service_key_service`.`name`,'')) as char charset utf8) AS `service_key_friendlyname`,cast(concat(coalesce(`ServiceSubcategory_servicesubcategory_key_servicesubcategory`.`name`,'')) as char charset utf8) AS `servicesubcategory_key_friendlyname` from ((`change_approved` `_change_approved` join ((((`ticket` `_ticket` join `organization` `Organization_org_id_organization` on((`_ticket`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_caller_id_person` join `contact` `Person_caller_id_contact` on((`Person_caller_id_person`.`id` = `Person_caller_id_contact`.`id`))) on((`_ticket`.`caller_id` = `Person_caller_id_person`.`id`))) left join (`team` `Team_team_id_team` join `contact` `Team_team_id_contact` on((`Team_team_id_team`.`id` = `Team_team_id_contact`.`id`))) on((`_ticket`.`team_id` = `Team_team_id_team`.`id`))) left join (`person` `Person_agent_id_person` join `contact` `Person_agent_id_contact` on((`Person_agent_id_person`.`id` = `Person_agent_id_contact`.`id`))) on((`_ticket`.`agent_id` = `Person_agent_id_person`.`id`))) on((`_change_approved`.`id` = `_ticket`.`id`))) join (((((((((`change` `_change` left join (`person` `Person_requestor_id_person` join `contact` `Person_requestor_id_contact` on((`Person_requestor_id_person`.`id` = `Person_requestor_id_contact`.`id`))) on((`_change`.`requestor_id` = `Person_requestor_id_person`.`id`))) left join (`team` `Team_supervisor_group_id_team` join `contact` `Team_supervisor_group_id_contact` on((`Team_supervisor_group_id_team`.`id` = `Team_supervisor_group_id_contact`.`id`))) on((`_change`.`supervisor_group_id` = `Team_supervisor_group_id_team`.`id`))) left join (`person` `Person_supervisor_id_person` join `contact` `Person_supervisor_id_contact` on((`Person_supervisor_id_person`.`id` = `Person_supervisor_id_contact`.`id`))) on((`_change`.`supervisor_id` = `Person_supervisor_id_person`.`id`))) left join (`team` `Team_manager_group_id_team` join `contact` `Team_manager_group_id_contact` on((`Team_manager_group_id_team`.`id` = `Team_manager_group_id_contact`.`id`))) on((`_change`.`manager_group_id` = `Team_manager_group_id_team`.`id`))) left join (`person` `Person_manager_id_person` join `contact` `Person_manager_id_contact` on((`Person_manager_id_person`.`id` = `Person_manager_id_contact`.`id`))) on((`_change`.`manager_id` = `Person_manager_id_person`.`id`))) left join (`change` `Change_parent_id_change` join `ticket` `Change_parent_id_ticket` on((`Change_parent_id_change`.`id` = `Change_parent_id_ticket`.`id`))) on((`_change`.`parent_id` = `Change_parent_id_change`.`id`))) left join `servicefamily` `ServiceFamily_servicefamily_key_servicefamily` on((`_change`.`servicefamily_key` = `ServiceFamily_servicefamily_key_servicefamily`.`id`))) left join `service` `Service_service_key_service` on((`_change`.`service_key` = `Service_service_key_service`.`id`))) left join `servicesubcategory` `ServiceSubcategory_servicesubcategory_key_servicesubcategory` on((`_change`.`servicesubcategory_key` = `ServiceSubcategory_servicesubcategory_key_servicesubcategory`.`id`))) on((`_change_approved`.`id` = `_change`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Attachment`
--

/*!50001 DROP VIEW IF EXISTS `view_Attachment`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Attachment` AS select distinct `_attachment`.`id` AS `id`,`_attachment`.`expire` AS `expire`,`_attachment`.`temp_id` AS `temp_id`,`_attachment`.`item_class` AS `item_class`,`_attachment`.`item_id` AS `item_id`,`_attachment`.`item_org_id` AS `item_org_id`,`_attachment`.`contents_mimetype` AS `contents`,`_attachment`.`contents_data` AS `contents_data`,`_attachment`.`contents_filename` AS `contents_filename`,cast(concat(coalesce(`_attachment`.`item_class`,''),coalesce(' ',''),coalesce(`_attachment`.`temp_id`,'')) as char charset utf8) AS `friendlyname` from `attachment` `_attachment` where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Brand`
--

/*!50001 DROP VIEW IF EXISTS `view_Brand`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Brand` AS select distinct `_brand`.`id` AS `id`,`_typology`.`name` AS `name`,`_typology`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_typology`.`name`,'')) as char charset utf8) AS `friendlyname` from (`brand` `_brand` join `typology` `_typology` on((`_brand`.`id` = `_typology`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_BusinessProcess`
--

/*!50001 DROP VIEW IF EXISTS `view_BusinessProcess`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_BusinessProcess` AS select distinct `_businessprocess`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_businessprocess`.`status` AS `status`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from (`businessprocess` `_businessprocess` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_businessprocess`.`id` = `_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Change`
--

/*!50001 DROP VIEW IF EXISTS `view_Change`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Change` AS select distinct `_change`.`id` AS `id`,`_ticket`.`operational_status` AS `operational_status`,`_ticket`.`ref` AS `ref`,`_ticket`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ticket`.`caller_id` AS `caller_id`,`Person_caller_id_contact`.`name` AS `caller_name`,`_ticket`.`team_id` AS `team_id`,`Team_team_id_contact`.`email` AS `team_name`,`_ticket`.`agent_id` AS `agent_id`,`Person_agent_id_contact`.`name` AS `agent_name`,`_ticket`.`title` AS `title`,`_ticket`.`description` AS `description`,`_ticket`.`description_format` AS `description_format`,`_ticket`.`start_date` AS `start_date`,`_ticket`.`end_date` AS `end_date`,`_ticket`.`last_update` AS `last_update`,`_ticket`.`close_date` AS `close_date`,`_ticket`.`private_log` AS `private_log`,`_ticket`.`private_log_index` AS `private_log_index`,`_ticket`.`id_instalador` AS `id_instalador`,`_ticket`.`san` AS `san`,`_ticket`.`nombre_instalador` AS `nombre_instalador`,`_ticket`.`pais_ticket` AS `pais_ticket`,`_change`.`status` AS `status`,`_change`.`reason` AS `reason`,`_change`.`requestor_id` AS `requestor_id`,`Person_requestor_id_contact`.`email` AS `requestor_email`,`_change`.`creation_date` AS `creation_date`,`_change`.`impact` AS `impact`,`_change`.`supervisor_group_id` AS `supervisor_group_id`,`Team_supervisor_group_id_contact`.`name` AS `supervisor_group_name`,`_change`.`supervisor_id` AS `supervisor_id`,`Person_supervisor_id_contact`.`email` AS `supervisor_email`,`_change`.`manager_group_id` AS `manager_group_id`,`Team_manager_group_id_contact`.`name` AS `manager_group_name`,`_change`.`manager_id` AS `manager_id`,`Person_manager_id_contact`.`email` AS `manager_email`,`_change`.`outage` AS `outage`,`_change`.`fallback` AS `fallback`,`_change`.`parent_id` AS `parent_id`,`Change_parent_id_ticket`.`ref` AS `parent_name`,`_change`.`external_id_cambios` AS `external_id_cambios`,`_change`.`servicefamily_key` AS `servicefamily_key`,`ServiceFamily_servicefamily_key_servicefamily`.`name` AS `servicefamily_n`,`_change`.`service_key` AS `service_key`,`Service_service_key_service`.`name` AS `service_n`,`_change`.`servicesubcategory_key` AS `servicesubcategory_key`,`ServiceSubcategory_servicesubcategory_key_servicesubcategory`.`name` AS `servicesubcategory_n`,`_ticket`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_ticket`.`ref`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_caller_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_caller_id_contact`.`name`,'')) as char charset utf8) AS `caller_id_friendlyname`,cast(concat(coalesce(`Team_team_id_contact`.`name`,'')) as char charset utf8) AS `team_id_friendlyname`,cast(concat(coalesce(`Person_agent_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_agent_id_contact`.`name`,'')) as char charset utf8) AS `agent_id_friendlyname`,cast(concat(coalesce(`Person_requestor_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_requestor_id_contact`.`name`,'')) as char charset utf8) AS `requestor_id_friendlyname`,cast(concat(coalesce(`Team_supervisor_group_id_contact`.`name`,'')) as char charset utf8) AS `supervisor_group_id_friendlyname`,cast(concat(coalesce(`Person_supervisor_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_supervisor_id_contact`.`name`,'')) as char charset utf8) AS `supervisor_id_friendlyname`,cast(concat(coalesce(`Team_manager_group_id_contact`.`name`,'')) as char charset utf8) AS `manager_group_id_friendlyname`,cast(concat(coalesce(`Person_manager_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_manager_id_contact`.`name`,'')) as char charset utf8) AS `manager_id_friendlyname`,cast(concat(coalesce(`Change_parent_id_ticket`.`ref`,'')) as char charset utf8) AS `parent_id_friendlyname`,`Change_parent_id_ticket`.`finalclass` AS `parent_id_finalclass_recall`,cast(concat(coalesce(`ServiceFamily_servicefamily_key_servicefamily`.`name`,'')) as char charset utf8) AS `servicefamily_key_friendlyname`,cast(concat(coalesce(`Service_service_key_service`.`name`,'')) as char charset utf8) AS `service_key_friendlyname`,cast(concat(coalesce(`ServiceSubcategory_servicesubcategory_key_servicesubcategory`.`name`,'')) as char charset utf8) AS `servicesubcategory_key_friendlyname` from ((((((((((`change` `_change` left join (`person` `Person_requestor_id_person` join `contact` `Person_requestor_id_contact` on((`Person_requestor_id_person`.`id` = `Person_requestor_id_contact`.`id`))) on((`_change`.`requestor_id` = `Person_requestor_id_person`.`id`))) left join (`team` `Team_supervisor_group_id_team` join `contact` `Team_supervisor_group_id_contact` on((`Team_supervisor_group_id_team`.`id` = `Team_supervisor_group_id_contact`.`id`))) on((`_change`.`supervisor_group_id` = `Team_supervisor_group_id_team`.`id`))) left join (`person` `Person_supervisor_id_person` join `contact` `Person_supervisor_id_contact` on((`Person_supervisor_id_person`.`id` = `Person_supervisor_id_contact`.`id`))) on((`_change`.`supervisor_id` = `Person_supervisor_id_person`.`id`))) left join (`team` `Team_manager_group_id_team` join `contact` `Team_manager_group_id_contact` on((`Team_manager_group_id_team`.`id` = `Team_manager_group_id_contact`.`id`))) on((`_change`.`manager_group_id` = `Team_manager_group_id_team`.`id`))) left join (`person` `Person_manager_id_person` join `contact` `Person_manager_id_contact` on((`Person_manager_id_person`.`id` = `Person_manager_id_contact`.`id`))) on((`_change`.`manager_id` = `Person_manager_id_person`.`id`))) left join (`change` `Change_parent_id_change` join `ticket` `Change_parent_id_ticket` on((`Change_parent_id_change`.`id` = `Change_parent_id_ticket`.`id`))) on((`_change`.`parent_id` = `Change_parent_id_change`.`id`))) left join `servicefamily` `ServiceFamily_servicefamily_key_servicefamily` on((`_change`.`servicefamily_key` = `ServiceFamily_servicefamily_key_servicefamily`.`id`))) left join `service` `Service_service_key_service` on((`_change`.`service_key` = `Service_service_key_service`.`id`))) left join `servicesubcategory` `ServiceSubcategory_servicesubcategory_key_servicesubcategory` on((`_change`.`servicesubcategory_key` = `ServiceSubcategory_servicesubcategory_key_servicesubcategory`.`id`))) join ((((`ticket` `_ticket` join `organization` `Organization_org_id_organization` on((`_ticket`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_caller_id_person` join `contact` `Person_caller_id_contact` on((`Person_caller_id_person`.`id` = `Person_caller_id_contact`.`id`))) on((`_ticket`.`caller_id` = `Person_caller_id_person`.`id`))) left join (`team` `Team_team_id_team` join `contact` `Team_team_id_contact` on((`Team_team_id_team`.`id` = `Team_team_id_contact`.`id`))) on((`_ticket`.`team_id` = `Team_team_id_team`.`id`))) left join (`person` `Person_agent_id_person` join `contact` `Person_agent_id_contact` on((`Person_agent_id_person`.`id` = `Person_agent_id_contact`.`id`))) on((`_ticket`.`agent_id` = `Person_agent_id_person`.`id`))) on((`_change`.`id` = `_ticket`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_ConnectableCI`
--

/*!50001 DROP VIEW IF EXISTS `view_ConnectableCI`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_ConnectableCI` AS select distinct `_connectableci`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname` from ((`connectableci` `_connectableci` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_connectableci`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_connectableci`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Contact`
--

/*!50001 DROP VIEW IF EXISTS `view_Contact`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Contact` AS select distinct `_contact`.`id` AS `id`,`_contact`.`name` AS `name`,`_contact`.`status` AS `status`,`_contact`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_contact`.`email` AS `email`,`_contact`.`phone` AS `phone`,`_contact`.`notify` AS `notify`,`_contact`.`function` AS `function`,`_contact`.`finalclass` AS `finalclass`,if((`_contact`.`finalclass` in ('Team','Contact')),cast(concat(coalesce(`_contact`.`name`,'')) as char charset utf8),cast(concat(coalesce(`_fn_Person_person`.`first_name`,''),coalesce(' ',''),coalesce(`_contact`.`name`,'')) as char charset utf8)) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from ((`contact` `_contact` join `organization` `Organization_org_id_organization` on((`_contact`.`org_id` = `Organization_org_id_organization`.`id`))) left join `person` `_fn_Person_person` on((`_contact`.`id` = `_fn_Person_person`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_ContactType`
--

/*!50001 DROP VIEW IF EXISTS `view_ContactType`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_ContactType` AS select distinct `_contacttype`.`id` AS `id`,`_typology`.`name` AS `name`,`_typology`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_typology`.`name`,'')) as char charset utf8) AS `friendlyname` from (`contacttype` `_contacttype` join `typology` `_typology` on((`_contacttype`.`id` = `_typology`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Contract`
--

/*!50001 DROP VIEW IF EXISTS `view_Contract`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Contract` AS select distinct `_contract`.`id` AS `id`,`_contract`.`name` AS `name`,`_contract`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_contract`.`description` AS `description`,`_contract`.`start_date` AS `start_date`,`_contract`.`end_date` AS `end_date`,`_contract`.`cost` AS `cost`,`_contract`.`cost_currency` AS `cost_currency`,`_contract`.`contracttype_id` AS `contracttype_id`,`ContractType_contracttype_id_typology`.`name` AS `contracttype_name`,`_contract`.`billing_frequency` AS `billing_frequency`,`_contract`.`cost_unit` AS `cost_unit`,`_contract`.`provider_id` AS `provider_id`,`Organization_provider_id_organization`.`name` AS `provider_name`,`_contract`.`status` AS `status`,`_contract`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_contract`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`ContractType_contracttype_id_typology`.`name`,'')) as char charset utf8) AS `contracttype_id_friendlyname`,cast(concat(coalesce(`Organization_provider_id_organization`.`name`,'')) as char charset utf8) AS `provider_id_friendlyname` from (((`contract` `_contract` join `organization` `Organization_org_id_organization` on((`_contract`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`contracttype` `ContractType_contracttype_id_contracttype` join `typology` `ContractType_contracttype_id_typology` on((`ContractType_contracttype_id_contracttype`.`id` = `ContractType_contracttype_id_typology`.`id`))) on((`_contract`.`contracttype_id` = `ContractType_contracttype_id_contracttype`.`id`))) join `organization` `Organization_provider_id_organization` on((`_contract`.`provider_id` = `Organization_provider_id_organization`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_ContractType`
--

/*!50001 DROP VIEW IF EXISTS `view_ContractType`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_ContractType` AS select distinct `_contracttype`.`id` AS `id`,`_typology`.`name` AS `name`,`_typology`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_typology`.`name`,'')) as char charset utf8) AS `friendlyname` from (`contracttype` `_contracttype` join `typology` `_typology` on((`_contracttype`.`id` = `_typology`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_CoverageWindow`
--

/*!50001 DROP VIEW IF EXISTS `view_CoverageWindow`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_CoverageWindow` AS select distinct `_coverage_windows`.`id` AS `id`,`_coverage_windows`.`name` AS `name`,`_coverage_windows`.`description` AS `description`,`_coverage_windows`.`monday_start` AS `monday_start`,`_coverage_windows`.`monday_end` AS `monday_end`,`_coverage_windows`.`tuesday_start` AS `tuesday_start`,`_coverage_windows`.`tuesday_end` AS `tuesday_end`,`_coverage_windows`.`wendnesday_start` AS `wednesday_start`,`_coverage_windows`.`wednesday_end` AS `wednesday_end`,`_coverage_windows`.`thursday_start` AS `thursday_start`,`_coverage_windows`.`thursday_end` AS `thursday_end`,`_coverage_windows`.`friday_start` AS `friday_start`,`_coverage_windows`.`friday_end` AS `friday_end`,`_coverage_windows`.`saturday_start` AS `saturday_start`,`_coverage_windows`.`saturday_end` AS `saturday_end`,`_coverage_windows`.`sunday_start` AS `sunday_start`,`_coverage_windows`.`sunday_end` AS `sunday_end`,cast(concat(coalesce(`_coverage_windows`.`name`,'')) as char charset utf8) AS `friendlyname` from `coverage_windows` `_coverage_windows` where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_CustomerContract`
--

/*!50001 DROP VIEW IF EXISTS `view_CustomerContract`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_CustomerContract` AS select distinct `_customercontract`.`id` AS `id`,`_contract`.`name` AS `name`,`_contract`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_contract`.`description` AS `description`,`_contract`.`start_date` AS `start_date`,`_contract`.`end_date` AS `end_date`,`_contract`.`cost` AS `cost`,`_contract`.`cost_currency` AS `cost_currency`,`_contract`.`contracttype_id` AS `contracttype_id`,`ContractType_contracttype_id_typology`.`name` AS `contracttype_name`,`_contract`.`billing_frequency` AS `billing_frequency`,`_contract`.`cost_unit` AS `cost_unit`,`_contract`.`provider_id` AS `provider_id`,`Organization_provider_id_organization`.`name` AS `provider_name`,`_contract`.`status` AS `status`,`_contract`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_contract`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`ContractType_contracttype_id_typology`.`name`,'')) as char charset utf8) AS `contracttype_id_friendlyname`,cast(concat(coalesce(`Organization_provider_id_organization`.`name`,'')) as char charset utf8) AS `provider_id_friendlyname` from (`customercontract` `_customercontract` join (((`contract` `_contract` join `organization` `Organization_org_id_organization` on((`_contract`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`contracttype` `ContractType_contracttype_id_contracttype` join `typology` `ContractType_contracttype_id_typology` on((`ContractType_contracttype_id_contracttype`.`id` = `ContractType_contracttype_id_typology`.`id`))) on((`_contract`.`contracttype_id` = `ContractType_contracttype_id_contracttype`.`id`))) join `organization` `Organization_provider_id_organization` on((`_contract`.`provider_id` = `Organization_provider_id_organization`.`id`))) on((`_customercontract`.`id` = `_contract`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_DBServer`
--

/*!50001 DROP VIEW IF EXISTS `view_DBServer`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_DBServer` AS select distinct `_dbserver`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_softwareinstance`.`functionalci_id` AS `system_id`,`FunctionalCI_system_id_functionalci`.`name` AS `system_name`,`_softwareinstance`.`software_id` AS `software_id`,`Software_software_id_software`.`name` AS `software_name`,`_softwareinstance`.`softwarelicence_id` AS `softwarelicence_id`,`SoftwareLicence_softwarelicence_id_licence`.`name` AS `softwarelicence_name`,`_softwareinstance`.`path` AS `path`,`_softwareinstance`.`status` AS `status`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,if((`FunctionalCI_system_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id1_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8)) AS `system_id_friendlyname`,`FunctionalCI_system_id_functionalci`.`finalclass` AS `system_id_finalclass_recall`,cast(concat(coalesce(`Software_software_id_software`.`name`,''),coalesce(' ',''),coalesce(`Software_software_id_software`.`version`,'')) as char charset utf8) AS `software_id_friendlyname`,cast(concat(coalesce(`SoftwareLicence_softwarelicence_id_licence`.`name`,'')) as char charset utf8) AS `softwarelicence_id_friendlyname` from ((`dbserver` `_dbserver` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_dbserver`.`id` = `_functionalci`.`id`))) join (((`softwareinstance` `_softwareinstance` join (`functionalci` `FunctionalCI_system_id_functionalci` left join (`softwareinstance` `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id1_functionalci` on((`FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id1_functionalci`.`id`))) on((`FunctionalCI_system_id_functionalci`.`id` = `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) left join `software` `Software_software_id_software` on((`_softwareinstance`.`software_id` = `Software_software_id_software`.`id`))) left join (`softwarelicence` `SoftwareLicence_softwarelicence_id_softwarelicence` join `licence` `SoftwareLicence_softwarelicence_id_licence` on((`SoftwareLicence_softwarelicence_id_softwarelicence`.`id` = `SoftwareLicence_softwarelicence_id_licence`.`id`))) on((`_softwareinstance`.`softwarelicence_id` = `SoftwareLicence_softwarelicence_id_softwarelicence`.`id`))) on((`_dbserver`.`id` = `_softwareinstance`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_DatabaseSchema`
--

/*!50001 DROP VIEW IF EXISTS `view_DatabaseSchema`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_DatabaseSchema` AS select distinct `_databaseschema`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_databaseschema`.`dbserver_id` AS `dbserver_id`,`DBServer_dbserver_id_functionalci`.`name` AS `dbserver_name`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`DBServer_dbserver_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8) AS `dbserver_id_friendlyname` from ((`databaseschema` `_databaseschema` join ((`dbserver` `DBServer_dbserver_id_dbserver` join `functionalci` `DBServer_dbserver_id_functionalci` on((`DBServer_dbserver_id_dbserver`.`id` = `DBServer_dbserver_id_functionalci`.`id`))) join (`softwareinstance` `DBServer_dbserver_id_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`DBServer_dbserver_id_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`DBServer_dbserver_id_dbserver`.`id` = `DBServer_dbserver_id_softwareinstance`.`id`))) on((`_databaseschema`.`dbserver_id` = `DBServer_dbserver_id_dbserver`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_databaseschema`.`id` = `_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_DatacenterDevice`
--

/*!50001 DROP VIEW IF EXISTS `view_DatacenterDevice`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_DatacenterDevice` AS select distinct `_datacenterdevice`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_datacenterdevice`.`rack_id` AS `rack_id`,`Rack_rack_id_functionalci`.`name` AS `rack_name`,`_datacenterdevice`.`enclosure_id` AS `enclosure_id`,`Enclosure_enclosure_id_functionalci`.`name` AS `enclosure_name`,`_datacenterdevice`.`nb_u` AS `nb_u`,`_datacenterdevice`.`managementip` AS `managementip`,`_datacenterdevice`.`powera_id` AS `powerA_id`,`PowerConnection_powerA_id_functionalci`.`name` AS `powerA_name`,`_datacenterdevice`.`powerB_id` AS `powerB_id`,`PowerConnection_powerB_id_functionalci`.`name` AS `powerB_name`,`_datacenterdevice`.`redundancy` AS `redundancy`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname`,cast(concat(coalesce(`Rack_rack_id_functionalci`.`name`,'')) as char charset utf8) AS `rack_id_friendlyname`,cast(concat(coalesce(`Enclosure_enclosure_id_functionalci`.`name`,'')) as char charset utf8) AS `enclosure_id_friendlyname`,cast(concat(coalesce(`PowerConnection_powerA_id_functionalci`.`name`,'')) as char charset utf8) AS `powerA_id_friendlyname`,`PowerConnection_powerA_id_functionalci`.`finalclass` AS `powerA_id_finalclass_recall`,cast(concat(coalesce(`PowerConnection_powerB_id_functionalci`.`name`,'')) as char charset utf8) AS `powerB_id_friendlyname`,`PowerConnection_powerB_id_functionalci`.`finalclass` AS `powerB_id_finalclass_recall` from ((((((`datacenterdevice` `_datacenterdevice` left join (`rack` `Rack_rack_id_rack` join `functionalci` `Rack_rack_id_functionalci` on((`Rack_rack_id_rack`.`id` = `Rack_rack_id_functionalci`.`id`))) on((`_datacenterdevice`.`rack_id` = `Rack_rack_id_rack`.`id`))) left join (`enclosure` `Enclosure_enclosure_id_enclosure` join `functionalci` `Enclosure_enclosure_id_functionalci` on((`Enclosure_enclosure_id_enclosure`.`id` = `Enclosure_enclosure_id_functionalci`.`id`))) on((`_datacenterdevice`.`enclosure_id` = `Enclosure_enclosure_id_enclosure`.`id`))) left join (`powerconnection` `PowerConnection_powerA_id_powerconnection` join `functionalci` `PowerConnection_powerA_id_functionalci` on((`PowerConnection_powerA_id_powerconnection`.`id` = `PowerConnection_powerA_id_functionalci`.`id`))) on((`_datacenterdevice`.`powera_id` = `PowerConnection_powerA_id_powerconnection`.`id`))) left join (`powerconnection` `PowerConnection_powerB_id_powerconnection` join `functionalci` `PowerConnection_powerB_id_functionalci` on((`PowerConnection_powerB_id_powerconnection`.`id` = `PowerConnection_powerB_id_functionalci`.`id`))) on((`_datacenterdevice`.`powerB_id` = `PowerConnection_powerB_id_powerconnection`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_datacenterdevice`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_datacenterdevice`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_DeliveryModel`
--

/*!50001 DROP VIEW IF EXISTS `view_DeliveryModel`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_DeliveryModel` AS select distinct `_deliverymodel`.`id` AS `id`,`_deliverymodel`.`name` AS `name`,`_deliverymodel`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_deliverymodel`.`description` AS `description`,cast(concat(coalesce(`_deliverymodel`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from (`deliverymodel` `_deliverymodel` join `organization` `Organization_org_id_organization` on((`_deliverymodel`.`org_id` = `Organization_org_id_organization`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Document`
--

/*!50001 DROP VIEW IF EXISTS `view_Document`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Document` AS select distinct `_document`.`id` AS `id`,`_document`.`name` AS `name`,`_document`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_document`.`documenttype_id` AS `documenttype_id`,`DocumentType_documenttype_id_typology`.`name` AS `documenttype_name`,`_document`.`version` AS `version`,`_document`.`description` AS `description`,`_document`.`status` AS `status`,`_document`.`finalclass` AS `finalclass`,if((`_document`.`finalclass` = 'Document'),cast(concat(coalesce('Document','')) as char charset utf8),cast(concat(coalesce(`_document`.`name`,'')) as char charset utf8)) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`DocumentType_documenttype_id_typology`.`name`,'')) as char charset utf8) AS `documenttype_id_friendlyname` from ((`document` `_document` join `organization` `Organization_org_id_organization` on((`_document`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`documenttype` `DocumentType_documenttype_id_documenttype` join `typology` `DocumentType_documenttype_id_typology` on((`DocumentType_documenttype_id_documenttype`.`id` = `DocumentType_documenttype_id_typology`.`id`))) on((`_document`.`documenttype_id` = `DocumentType_documenttype_id_documenttype`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_DocumentFile`
--

/*!50001 DROP VIEW IF EXISTS `view_DocumentFile`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_DocumentFile` AS select distinct `_documentfile`.`id` AS `id`,`_document`.`name` AS `name`,`_document`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_document`.`documenttype_id` AS `documenttype_id`,`DocumentType_documenttype_id_typology`.`name` AS `documenttype_name`,`_document`.`version` AS `version`,`_document`.`description` AS `description`,`_document`.`status` AS `status`,`_documentfile`.`file_mimetype` AS `file`,`_documentfile`.`file_data` AS `file_data`,`_documentfile`.`file_filename` AS `file_filename`,`_document`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_document`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`DocumentType_documenttype_id_typology`.`name`,'')) as char charset utf8) AS `documenttype_id_friendlyname` from (`documentfile` `_documentfile` join ((`document` `_document` join `organization` `Organization_org_id_organization` on((`_document`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`documenttype` `DocumentType_documenttype_id_documenttype` join `typology` `DocumentType_documenttype_id_typology` on((`DocumentType_documenttype_id_documenttype`.`id` = `DocumentType_documenttype_id_typology`.`id`))) on((`_document`.`documenttype_id` = `DocumentType_documenttype_id_documenttype`.`id`))) on((`_documentfile`.`id` = `_document`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_DocumentNote`
--

/*!50001 DROP VIEW IF EXISTS `view_DocumentNote`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_DocumentNote` AS select distinct `_documentnote`.`id` AS `id`,`_document`.`name` AS `name`,`_document`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_document`.`documenttype_id` AS `documenttype_id`,`DocumentType_documenttype_id_typology`.`name` AS `documenttype_name`,`_document`.`version` AS `version`,`_document`.`description` AS `description`,`_document`.`status` AS `status`,`_documentnote`.`text` AS `text`,`_document`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_document`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`DocumentType_documenttype_id_typology`.`name`,'')) as char charset utf8) AS `documenttype_id_friendlyname` from (`documentnote` `_documentnote` join ((`document` `_document` join `organization` `Organization_org_id_organization` on((`_document`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`documenttype` `DocumentType_documenttype_id_documenttype` join `typology` `DocumentType_documenttype_id_typology` on((`DocumentType_documenttype_id_documenttype`.`id` = `DocumentType_documenttype_id_typology`.`id`))) on((`_document`.`documenttype_id` = `DocumentType_documenttype_id_documenttype`.`id`))) on((`_documentnote`.`id` = `_document`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_DocumentType`
--

/*!50001 DROP VIEW IF EXISTS `view_DocumentType`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_DocumentType` AS select distinct `_documenttype`.`id` AS `id`,`_typology`.`name` AS `name`,`_typology`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_typology`.`name`,'')) as char charset utf8) AS `friendlyname` from (`documenttype` `_documenttype` join `typology` `_typology` on((`_documenttype`.`id` = `_typology`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_DocumentWeb`
--

/*!50001 DROP VIEW IF EXISTS `view_DocumentWeb`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_DocumentWeb` AS select distinct `_documentweb`.`id` AS `id`,`_document`.`name` AS `name`,`_document`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_document`.`documenttype_id` AS `documenttype_id`,`DocumentType_documenttype_id_typology`.`name` AS `documenttype_name`,`_document`.`version` AS `version`,`_document`.`description` AS `description`,`_document`.`status` AS `status`,`_documentweb`.`url` AS `url`,`_document`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_document`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`DocumentType_documenttype_id_typology`.`name`,'')) as char charset utf8) AS `documenttype_id_friendlyname` from (`documentweb` `_documentweb` join ((`document` `_document` join `organization` `Organization_org_id_organization` on((`_document`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`documenttype` `DocumentType_documenttype_id_documenttype` join `typology` `DocumentType_documenttype_id_typology` on((`DocumentType_documenttype_id_documenttype`.`id` = `DocumentType_documenttype_id_typology`.`id`))) on((`_document`.`documenttype_id` = `DocumentType_documenttype_id_documenttype`.`id`))) on((`_documentweb`.`id` = `_document`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_EmergencyChange`
--

/*!50001 DROP VIEW IF EXISTS `view_EmergencyChange`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_EmergencyChange` AS select distinct `_change_emergency`.`id` AS `id`,`_ticket`.`operational_status` AS `operational_status`,`_ticket`.`ref` AS `ref`,`_ticket`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ticket`.`caller_id` AS `caller_id`,`Person_caller_id_contact`.`name` AS `caller_name`,`_ticket`.`team_id` AS `team_id`,`Team_team_id_contact`.`email` AS `team_name`,`_ticket`.`agent_id` AS `agent_id`,`Person_agent_id_contact`.`name` AS `agent_name`,`_ticket`.`title` AS `title`,`_ticket`.`description` AS `description`,`_ticket`.`description_format` AS `description_format`,`_ticket`.`start_date` AS `start_date`,`_ticket`.`end_date` AS `end_date`,`_ticket`.`last_update` AS `last_update`,`_ticket`.`close_date` AS `close_date`,`_ticket`.`private_log` AS `private_log`,`_ticket`.`private_log_index` AS `private_log_index`,`_ticket`.`id_instalador` AS `id_instalador`,`_ticket`.`san` AS `san`,`_ticket`.`nombre_instalador` AS `nombre_instalador`,`_ticket`.`pais_ticket` AS `pais_ticket`,`_change`.`status` AS `status`,`_change`.`reason` AS `reason`,`_change`.`requestor_id` AS `requestor_id`,`Person_requestor_id_contact`.`email` AS `requestor_email`,`_change`.`creation_date` AS `creation_date`,`_change`.`impact` AS `impact`,`_change`.`supervisor_group_id` AS `supervisor_group_id`,`Team_supervisor_group_id_contact`.`name` AS `supervisor_group_name`,`_change`.`supervisor_id` AS `supervisor_id`,`Person_supervisor_id_contact`.`email` AS `supervisor_email`,`_change`.`manager_group_id` AS `manager_group_id`,`Team_manager_group_id_contact`.`name` AS `manager_group_name`,`_change`.`manager_id` AS `manager_id`,`Person_manager_id_contact`.`email` AS `manager_email`,`_change`.`outage` AS `outage`,`_change`.`fallback` AS `fallback`,`_change`.`parent_id` AS `parent_id`,`Change_parent_id_ticket`.`ref` AS `parent_name`,`_change`.`external_id_cambios` AS `external_id_cambios`,`_change`.`servicefamily_key` AS `servicefamily_key`,`ServiceFamily_servicefamily_key_servicefamily`.`name` AS `servicefamily_n`,`_change`.`service_key` AS `service_key`,`Service_service_key_service`.`name` AS `service_n`,`_change`.`servicesubcategory_key` AS `servicesubcategory_key`,`ServiceSubcategory_servicesubcategory_key_servicesubcategory`.`name` AS `servicesubcategory_n`,`_change_approved`.`approval_date` AS `approval_date`,`_change_approved`.`approval_comment` AS `approval_comment`,`_ticket`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_ticket`.`ref`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_caller_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_caller_id_contact`.`name`,'')) as char charset utf8) AS `caller_id_friendlyname`,cast(concat(coalesce(`Team_team_id_contact`.`name`,'')) as char charset utf8) AS `team_id_friendlyname`,cast(concat(coalesce(`Person_agent_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_agent_id_contact`.`name`,'')) as char charset utf8) AS `agent_id_friendlyname`,cast(concat(coalesce(`Person_requestor_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_requestor_id_contact`.`name`,'')) as char charset utf8) AS `requestor_id_friendlyname`,cast(concat(coalesce(`Team_supervisor_group_id_contact`.`name`,'')) as char charset utf8) AS `supervisor_group_id_friendlyname`,cast(concat(coalesce(`Person_supervisor_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_supervisor_id_contact`.`name`,'')) as char charset utf8) AS `supervisor_id_friendlyname`,cast(concat(coalesce(`Team_manager_group_id_contact`.`name`,'')) as char charset utf8) AS `manager_group_id_friendlyname`,cast(concat(coalesce(`Person_manager_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_manager_id_contact`.`name`,'')) as char charset utf8) AS `manager_id_friendlyname`,cast(concat(coalesce(`Change_parent_id_ticket`.`ref`,'')) as char charset utf8) AS `parent_id_friendlyname`,`Change_parent_id_ticket`.`finalclass` AS `parent_id_finalclass_recall`,cast(concat(coalesce(`ServiceFamily_servicefamily_key_servicefamily`.`name`,'')) as char charset utf8) AS `servicefamily_key_friendlyname`,cast(concat(coalesce(`Service_service_key_service`.`name`,'')) as char charset utf8) AS `service_key_friendlyname`,cast(concat(coalesce(`ServiceSubcategory_servicesubcategory_key_servicesubcategory`.`name`,'')) as char charset utf8) AS `servicesubcategory_key_friendlyname` from (((`change_emergency` `_change_emergency` join ((((`ticket` `_ticket` join `organization` `Organization_org_id_organization` on((`_ticket`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_caller_id_person` join `contact` `Person_caller_id_contact` on((`Person_caller_id_person`.`id` = `Person_caller_id_contact`.`id`))) on((`_ticket`.`caller_id` = `Person_caller_id_person`.`id`))) left join (`team` `Team_team_id_team` join `contact` `Team_team_id_contact` on((`Team_team_id_team`.`id` = `Team_team_id_contact`.`id`))) on((`_ticket`.`team_id` = `Team_team_id_team`.`id`))) left join (`person` `Person_agent_id_person` join `contact` `Person_agent_id_contact` on((`Person_agent_id_person`.`id` = `Person_agent_id_contact`.`id`))) on((`_ticket`.`agent_id` = `Person_agent_id_person`.`id`))) on((`_change_emergency`.`id` = `_ticket`.`id`))) join (((((((((`change` `_change` left join (`person` `Person_requestor_id_person` join `contact` `Person_requestor_id_contact` on((`Person_requestor_id_person`.`id` = `Person_requestor_id_contact`.`id`))) on((`_change`.`requestor_id` = `Person_requestor_id_person`.`id`))) left join (`team` `Team_supervisor_group_id_team` join `contact` `Team_supervisor_group_id_contact` on((`Team_supervisor_group_id_team`.`id` = `Team_supervisor_group_id_contact`.`id`))) on((`_change`.`supervisor_group_id` = `Team_supervisor_group_id_team`.`id`))) left join (`person` `Person_supervisor_id_person` join `contact` `Person_supervisor_id_contact` on((`Person_supervisor_id_person`.`id` = `Person_supervisor_id_contact`.`id`))) on((`_change`.`supervisor_id` = `Person_supervisor_id_person`.`id`))) left join (`team` `Team_manager_group_id_team` join `contact` `Team_manager_group_id_contact` on((`Team_manager_group_id_team`.`id` = `Team_manager_group_id_contact`.`id`))) on((`_change`.`manager_group_id` = `Team_manager_group_id_team`.`id`))) left join (`person` `Person_manager_id_person` join `contact` `Person_manager_id_contact` on((`Person_manager_id_person`.`id` = `Person_manager_id_contact`.`id`))) on((`_change`.`manager_id` = `Person_manager_id_person`.`id`))) left join (`change` `Change_parent_id_change` join `ticket` `Change_parent_id_ticket` on((`Change_parent_id_change`.`id` = `Change_parent_id_ticket`.`id`))) on((`_change`.`parent_id` = `Change_parent_id_change`.`id`))) left join `servicefamily` `ServiceFamily_servicefamily_key_servicefamily` on((`_change`.`servicefamily_key` = `ServiceFamily_servicefamily_key_servicefamily`.`id`))) left join `service` `Service_service_key_service` on((`_change`.`service_key` = `Service_service_key_service`.`id`))) left join `servicesubcategory` `ServiceSubcategory_servicesubcategory_key_servicesubcategory` on((`_change`.`servicesubcategory_key` = `ServiceSubcategory_servicesubcategory_key_servicesubcategory`.`id`))) on((`_change_emergency`.`id` = `_change`.`id`))) join `change_approved` `_change_approved` on((`_change_emergency`.`id` = `_change_approved`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Enclosure`
--

/*!50001 DROP VIEW IF EXISTS `view_Enclosure`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Enclosure` AS select distinct `_enclosure`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_enclosure`.`rack_id` AS `rack_id`,`Rack_rack_id_functionalci`.`name` AS `rack_name`,`_enclosure`.`nb_u` AS `nb_u`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname`,cast(concat(coalesce(`Rack_rack_id_functionalci`.`name`,'')) as char charset utf8) AS `rack_id_friendlyname` from (((`enclosure` `_enclosure` join (`rack` `Rack_rack_id_rack` join `functionalci` `Rack_rack_id_functionalci` on((`Rack_rack_id_rack`.`id` = `Rack_rack_id_functionalci`.`id`))) on((`_enclosure`.`rack_id` = `Rack_rack_id_rack`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_enclosure`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_enclosure`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_FAQ`
--

/*!50001 DROP VIEW IF EXISTS `view_FAQ`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_FAQ` AS select distinct `_faq`.`id` AS `id`,`_faq`.`title` AS `title`,`_faq`.`summary` AS `summary`,`_faq`.`description` AS `description`,`_faq`.`category_id` AS `category_id`,`FAQCategory_category_id_faqcategory`.`nam` AS `category_name`,`_faq`.`error_code` AS `error_code`,`_faq`.`key_words` AS `key_words`,cast(concat(coalesce(`_faq`.`title`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`FAQCategory_category_id_faqcategory`.`nam`,'')) as char charset utf8) AS `category_id_friendlyname` from (`faq` `_faq` join `faqcategory` `FAQCategory_category_id_faqcategory` on((`_faq`.`category_id` = `FAQCategory_category_id_faqcategory`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_FAQCategory`
--

/*!50001 DROP VIEW IF EXISTS `view_FAQCategory`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_FAQCategory` AS select distinct `_faqcategory`.`id` AS `id`,`_faqcategory`.`nam` AS `name`,cast(concat(coalesce(`_faqcategory`.`nam`,'')) as char charset utf8) AS `friendlyname` from `faqcategory` `_faqcategory` where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Farm`
--

/*!50001 DROP VIEW IF EXISTS `view_Farm`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Farm` AS select distinct `_farm`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_virtualdevice`.`status` AS `status`,`_farm`.`redundancy` AS `redundancy`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from ((`farm` `_farm` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_farm`.`id` = `_functionalci`.`id`))) join `virtualdevice` `_virtualdevice` on((`_farm`.`id` = `_virtualdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_FiberChannelInterface`
--

/*!50001 DROP VIEW IF EXISTS `view_FiberChannelInterface`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_FiberChannelInterface` AS select distinct `_fiberchannelinterface`.`id` AS `id`,`_networkinterface`.`name` AS `name`,`_fiberchannelinterface`.`speed` AS `speed`,`_fiberchannelinterface`.`topology` AS `topology`,`_fiberchannelinterface`.`wwn` AS `wwn`,`_fiberchannelinterface`.`datacenterdevice_id` AS `datacenterdevice_id`,`DatacenterDevice_datacenterdevice_id_functionalci`.`name` AS `datacenterdevice_name`,`_networkinterface`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`DatacenterDevice_datacenterdevice_id_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`DatacenterDevice_datacenterdevice_id_functionalci`.`name`,'')) as char charset utf8) AS `datacenterdevice_id_friendlyname`,`DatacenterDevice_datacenterdevice_id_functionalci`.`finalclass` AS `datacenterdevice_id_finalclass_recall` from ((`fiberchannelinterface` `_fiberchannelinterface` join (`datacenterdevice` `DatacenterDevice_datacenterdevice_id_datacenterdevice` join `functionalci` `DatacenterDevice_datacenterdevice_id_functionalci` on((`DatacenterDevice_datacenterdevice_id_datacenterdevice`.`id` = `DatacenterDevice_datacenterdevice_id_functionalci`.`id`))) on((`_fiberchannelinterface`.`datacenterdevice_id` = `DatacenterDevice_datacenterdevice_id_datacenterdevice`.`id`))) join `networkinterface` `_networkinterface` on((`_fiberchannelinterface`.`id` = `_networkinterface`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_FunctionalCI`
--

/*!50001 DROP VIEW IF EXISTS `view_FunctionalCI`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_FunctionalCI` AS select distinct `_functionalci`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_functionalci`.`finalclass` AS `finalclass`,if((`_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8)) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from ((`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`softwareinstance` `_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`_functionalci`.`id` = `_fn_SoftwareInstance_softwareinstance`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Group`
--

/*!50001 DROP VIEW IF EXISTS `view_Group`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Group` AS select distinct `_group`.`id` AS `id`,`_group`.`name` AS `name`,`_group`.`status` AS `status`,`_group`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `owner_name`,`_group`.`description` AS `description`,`_group`.`type` AS `type`,`_group`.`parent_id` AS `parent_id`,`Group_parent_id_group`.`name` AS `parent_name`,cast(concat(coalesce(`_group`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Group_parent_id_group`.`name`,'')) as char charset utf8) AS `parent_id_friendlyname` from ((`group` `_group` join `organization` `Organization_org_id_organization` on((`_group`.`org_id` = `Organization_org_id_organization`.`id`))) left join `group` `Group_parent_id_group` on((`_group`.`parent_id` = `Group_parent_id_group`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Holiday`
--

/*!50001 DROP VIEW IF EXISTS `view_Holiday`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Holiday` AS select distinct `_holidays`.`id` AS `id`,`_holidays`.`name` AS `name`,`_holidays`.`date` AS `date`,`_holidays`.`calendar_id` AS `calendar_id`,`HolidayCalendar_calendar_id_holiday_calendar`.`name` AS `calendar_name`,cast(concat(coalesce(`_holidays`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`HolidayCalendar_calendar_id_holiday_calendar`.`name`,'')) as char charset utf8) AS `calendar_id_friendlyname` from (`holidays` `_holidays` left join `holiday_calendar` `HolidayCalendar_calendar_id_holiday_calendar` on((`_holidays`.`calendar_id` = `HolidayCalendar_calendar_id_holiday_calendar`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_HolidayCalendar`
--

/*!50001 DROP VIEW IF EXISTS `view_HolidayCalendar`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_HolidayCalendar` AS select distinct `_holiday_calendar`.`id` AS `id`,`_holiday_calendar`.`name` AS `name`,cast(concat(coalesce(`_holiday_calendar`.`name`,'')) as char charset utf8) AS `friendlyname` from `holiday_calendar` `_holiday_calendar` where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Hypervisor`
--

/*!50001 DROP VIEW IF EXISTS `view_Hypervisor`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Hypervisor` AS select distinct `_hypervisor`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_virtualdevice`.`status` AS `status`,`_hypervisor`.`farm_id` AS `farm_id`,`Farm_farm_id_functionalci`.`name` AS `farm_name`,`_hypervisor`.`server_id` AS `server_id`,`Server_server_id_functionalci`.`name` AS `server_name`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Farm_farm_id_functionalci`.`name`,'')) as char charset utf8) AS `farm_id_friendlyname`,cast(concat(coalesce(`Server_server_id_functionalci`.`name`,'')) as char charset utf8) AS `server_id_friendlyname` from ((((`hypervisor` `_hypervisor` left join (`farm` `Farm_farm_id_farm` join `functionalci` `Farm_farm_id_functionalci` on((`Farm_farm_id_farm`.`id` = `Farm_farm_id_functionalci`.`id`))) on((`_hypervisor`.`farm_id` = `Farm_farm_id_farm`.`id`))) left join (`server` `Server_server_id_server` join `functionalci` `Server_server_id_functionalci` on((`Server_server_id_server`.`id` = `Server_server_id_functionalci`.`id`))) on((`_hypervisor`.`server_id` = `Server_server_id_server`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_hypervisor`.`id` = `_functionalci`.`id`))) join `virtualdevice` `_virtualdevice` on((`_hypervisor`.`id` = `_virtualdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_IOSVersion`
--

/*!50001 DROP VIEW IF EXISTS `view_IOSVersion`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_IOSVersion` AS select distinct `_iosversion`.`id` AS `id`,`_typology`.`name` AS `name`,`_iosversion`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_typology`.`finalclass` AS `finalclass`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,''),coalesce(' ',''),coalesce(`_typology`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname` from ((`iosversion` `_iosversion` join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_iosversion`.`brand_id` = `Brand_brand_id_brand`.`id`))) join `typology` `_typology` on((`_iosversion`.`id` = `_typology`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_IPInterface`
--

/*!50001 DROP VIEW IF EXISTS `view_IPInterface`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_IPInterface` AS select distinct `_ipinterface`.`id` AS `id`,`_networkinterface`.`name` AS `name`,`_ipinterface`.`ipaddress` AS `ipaddress`,`_ipinterface`.`macaddress` AS `macaddress`,`_ipinterface`.`comment` AS `comment`,`_ipinterface`.`ipgateway` AS `ipgateway`,`_ipinterface`.`ipmask` AS `ipmask`,`_ipinterface`.`speed` AS `speed`,`_networkinterface`.`finalclass` AS `finalclass`,if((`_networkinterface`.`finalclass` = 'IPInterface'),cast(concat(coalesce(`_networkinterface`.`name`,'')) as char charset utf8),if((`_networkinterface`.`finalclass` = 'LogicalInterface'),cast(concat(coalesce(`_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`VirtualMachine_virtualmachine_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`ConnectableCI_connectableci_id_functionalci`.`name`,'')) as char charset utf8))) AS `friendlyname` from (((`ipinterface` `_ipinterface` join `networkinterface` `_networkinterface` on((`_ipinterface`.`id` = `_networkinterface`.`id`))) left join (`logicalinterface` `_fn_LogicalInterface_logicalinterface` join (`virtualmachine` `VirtualMachine_virtualmachine_id_virtualmachine` join `functionalci` `VirtualMachine_virtualmachine_id_functionalci` on((`VirtualMachine_virtualmachine_id_virtualmachine`.`id` = `VirtualMachine_virtualmachine_id_functionalci`.`id`))) on((`_fn_LogicalInterface_logicalinterface`.`virtualmachine_id` = `VirtualMachine_virtualmachine_id_virtualmachine`.`id`))) on((`_ipinterface`.`id` = `_fn_LogicalInterface_logicalinterface`.`id`))) left join (`physicalinterface` `_fn_PhysicalInterface_physicalinterface` join (`connectableci` `ConnectableCI_connectableci_id_connectableci` join `functionalci` `ConnectableCI_connectableci_id_functionalci` on((`ConnectableCI_connectableci_id_connectableci`.`id` = `ConnectableCI_connectableci_id_functionalci`.`id`))) on((`_fn_PhysicalInterface_physicalinterface`.`connectableci_id` = `ConnectableCI_connectableci_id_connectableci`.`id`))) on((`_ipinterface`.`id` = `_fn_PhysicalInterface_physicalinterface`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_IPPhone`
--

/*!50001 DROP VIEW IF EXISTS `view_IPPhone`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_IPPhone` AS select distinct `_ipphone`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_telephonyci`.`phonenumber` AS `phonenumber`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname` from (((`ipphone` `_ipphone` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_ipphone`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_ipphone`.`id` = `_physicaldevice`.`id`))) join `telephonyci` `_telephonyci` on((`_ipphone`.`id` = `_telephonyci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Incident`
--

/*!50001 DROP VIEW IF EXISTS `view_Incident`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Incident` AS select distinct `_ticket_incident`.`id` AS `id`,`_ticket`.`operational_status` AS `operational_status`,`_ticket`.`ref` AS `ref`,`_ticket`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ticket`.`caller_id` AS `caller_id`,`Person_caller_id_contact`.`name` AS `caller_name`,`_ticket`.`team_id` AS `team_id`,`Team_team_id_contact`.`email` AS `team_name`,`_ticket`.`agent_id` AS `agent_id`,`Person_agent_id_contact`.`name` AS `agent_name`,`_ticket`.`title` AS `title`,`_ticket`.`description` AS `description`,`_ticket`.`description_format` AS `description_format`,`_ticket`.`start_date` AS `start_date`,`_ticket`.`end_date` AS `end_date`,`_ticket`.`last_update` AS `last_update`,`_ticket`.`close_date` AS `close_date`,`_ticket`.`private_log` AS `private_log`,`_ticket`.`private_log_index` AS `private_log_index`,`_ticket`.`id_instalador` AS `id_instalador`,`_ticket`.`san` AS `san`,`_ticket`.`nombre_instalador` AS `nombre_instalador`,`_ticket`.`pais_ticket` AS `pais_ticket`,`_ticket_incident`.`status` AS `status`,`_ticket_incident`.`impact` AS `impact`,`_ticket_incident`.`priority` AS `priority`,`_ticket_incident`.`urgency` AS `urgency`,`_ticket_incident`.`origin` AS `origin`,`_ticket_incident`.`service_id` AS `service_id`,`Service_service_id_service`.`name` AS `service_name`,`_ticket_incident`.`servicesubcategory_id` AS `servicesubcategory_id`,`ServiceSubcategory_servicesubcategory_id_servicesubcategory`.`name` AS `servicesubcategory_name`,`_ticket_incident`.`escalation_flag` AS `escalation_flag`,`_ticket_incident`.`escalation_reason` AS `escalation_reason`,`_ticket_incident`.`assignment_date` AS `assignment_date`,`_ticket_incident`.`resolution_date` AS `resolution_date`,`_ticket_incident`.`last_pending_date` AS `last_pending_date`,`_ticket_incident`.`cumulatedpending_timespent` AS `cumulatedpending`,`_ticket_incident`.`cumulatedpending_started` AS `cumulatedpending_started`,`_ticket_incident`.`cumulatedpending_laststart` AS `cumulatedpending_laststart`,`_ticket_incident`.`cumulatedpending_stopped` AS `cumulatedpending_stopped`,`_ticket_incident`.`tto_timespent` AS `tto`,`_ticket_incident`.`tto_started` AS `tto_started`,`_ticket_incident`.`tto_laststart` AS `tto_laststart`,`_ticket_incident`.`tto_stopped` AS `tto_stopped`,`_ticket_incident`.`tto_75_deadline` AS `tto_75_deadline`,`_ticket_incident`.`tto_75_passed` AS `tto_75_passed`,`_ticket_incident`.`tto_75_triggered` AS `tto_75_triggered`,`_ticket_incident`.`tto_75_overrun` AS `tto_75_overrun`,`_ticket_incident`.`tto_100_deadline` AS `tto_100_deadline`,`_ticket_incident`.`tto_100_passed` AS `tto_100_passed`,`_ticket_incident`.`tto_100_triggered` AS `tto_100_triggered`,`_ticket_incident`.`tto_100_overrun` AS `tto_100_overrun`,`_ticket_incident`.`ttr_timespent` AS `ttr`,`_ticket_incident`.`ttr_started` AS `ttr_started`,`_ticket_incident`.`ttr_laststart` AS `ttr_laststart`,`_ticket_incident`.`ttr_stopped` AS `ttr_stopped`,`_ticket_incident`.`ttr_75_deadline` AS `ttr_75_deadline`,`_ticket_incident`.`ttr_75_passed` AS `ttr_75_passed`,`_ticket_incident`.`ttr_75_triggered` AS `ttr_75_triggered`,`_ticket_incident`.`ttr_75_overrun` AS `ttr_75_overrun`,`_ticket_incident`.`ttr_100_deadline` AS `ttr_100_deadline`,`_ticket_incident`.`ttr_100_passed` AS `ttr_100_passed`,`_ticket_incident`.`ttr_100_triggered` AS `ttr_100_triggered`,`_ticket_incident`.`ttr_100_overrun` AS `ttr_100_overrun`,`_ticket_incident`.`tto_100_deadline` AS `tto_escalation_deadline`,`_ticket_incident`.`tto_100_passed` AS `sla_tto_passed`,`_ticket_incident`.`tto_100_overrun` AS `sla_tto_over`,`_ticket_incident`.`ttr_100_deadline` AS `ttr_escalation_deadline`,`_ticket_incident`.`ttr_100_passed` AS `sla_ttr_passed`,`_ticket_incident`.`ttr_100_overrun` AS `sla_ttr_over`,`_ticket_incident`.`time_spent` AS `time_spent`,`_ticket_incident`.`resolution_code` AS `resolution_code`,`_ticket_incident`.`solution` AS `solution`,`_ticket_incident`.`pending_reason` AS `pending_reason`,`_ticket_incident`.`parent_incident_id` AS `parent_incident_id`,`Incident_parent_incident_id_ticket`.`ref` AS `parent_incident_ref`,`_ticket_incident`.`parent_problem_id` AS `parent_problem_id`,`Problem_parent_problem_id_ticket`.`ref` AS `parent_problem_ref`,`_ticket_incident`.`parent_change_id` AS `parent_change_id`,`Change_parent_change_id_ticket`.`ref` AS `parent_change_ref`,`_ticket_incident`.`public_log` AS `public_log`,`_ticket_incident`.`public_log_index` AS `public_log_index`,`_ticket_incident`.`user_satisfaction` AS `user_satisfaction`,`_ticket_incident`.`user_commment` AS `user_comment`,`_ticket_incident`.`external_id` AS `external_id`,`_ticket`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_ticket`.`ref`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_caller_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_caller_id_contact`.`name`,'')) as char charset utf8) AS `caller_id_friendlyname`,cast(concat(coalesce(`Team_team_id_contact`.`name`,'')) as char charset utf8) AS `team_id_friendlyname`,cast(concat(coalesce(`Person_agent_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_agent_id_contact`.`name`,'')) as char charset utf8) AS `agent_id_friendlyname`,cast(concat(coalesce(`Service_service_id_service`.`name`,'')) as char charset utf8) AS `service_id_friendlyname`,cast(concat(coalesce(`ServiceSubcategory_servicesubcategory_id_servicesubcategory`.`name`,'')) as char charset utf8) AS `servicesubcategory_id_friendlyname`,cast(concat(coalesce(`Incident_parent_incident_id_ticket`.`ref`,'')) as char charset utf8) AS `parent_incident_id_friendlyname`,cast(concat(coalesce(`Problem_parent_problem_id_ticket`.`ref`,'')) as char charset utf8) AS `parent_problem_id_friendlyname`,cast(concat(coalesce(`Change_parent_change_id_ticket`.`ref`,'')) as char charset utf8) AS `parent_change_id_friendlyname`,`Change_parent_change_id_ticket`.`finalclass` AS `parent_change_id_finalclass_recall` from ((((((`ticket_incident` `_ticket_incident` left join `service` `Service_service_id_service` on((`_ticket_incident`.`service_id` = `Service_service_id_service`.`id`))) left join `servicesubcategory` `ServiceSubcategory_servicesubcategory_id_servicesubcategory` on((`_ticket_incident`.`servicesubcategory_id` = `ServiceSubcategory_servicesubcategory_id_servicesubcategory`.`id`))) left join (`ticket_incident` `Incident_parent_incident_id_ticket_incident` join `ticket` `Incident_parent_incident_id_ticket` on((`Incident_parent_incident_id_ticket_incident`.`id` = `Incident_parent_incident_id_ticket`.`id`))) on((`_ticket_incident`.`parent_incident_id` = `Incident_parent_incident_id_ticket_incident`.`id`))) left join (`ticket_problem` `Problem_parent_problem_id_ticket_problem` join `ticket` `Problem_parent_problem_id_ticket` on((`Problem_parent_problem_id_ticket_problem`.`id` = `Problem_parent_problem_id_ticket`.`id`))) on((`_ticket_incident`.`parent_problem_id` = `Problem_parent_problem_id_ticket_problem`.`id`))) left join (`change` `Change_parent_change_id_change` join `ticket` `Change_parent_change_id_ticket` on((`Change_parent_change_id_change`.`id` = `Change_parent_change_id_ticket`.`id`))) on((`_ticket_incident`.`parent_change_id` = `Change_parent_change_id_change`.`id`))) join ((((`ticket` `_ticket` join `organization` `Organization_org_id_organization` on((`_ticket`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_caller_id_person` join `contact` `Person_caller_id_contact` on((`Person_caller_id_person`.`id` = `Person_caller_id_contact`.`id`))) on((`_ticket`.`caller_id` = `Person_caller_id_person`.`id`))) left join (`team` `Team_team_id_team` join `contact` `Team_team_id_contact` on((`Team_team_id_team`.`id` = `Team_team_id_contact`.`id`))) on((`_ticket`.`team_id` = `Team_team_id_team`.`id`))) left join (`person` `Person_agent_id_person` join `contact` `Person_agent_id_contact` on((`Person_agent_id_person`.`id` = `Person_agent_id_contact`.`id`))) on((`_ticket`.`agent_id` = `Person_agent_id_person`.`id`))) on((`_ticket_incident`.`id` = `_ticket`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_KnownError`
--

/*!50001 DROP VIEW IF EXISTS `view_KnownError`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_KnownError` AS select distinct `_knownerror`.`id` AS `id`,`_knownerror`.`name` AS `name`,`_knownerror`.`cust_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `cust_name`,`_knownerror`.`problem_id` AS `problem_id`,`Problem_problem_id_ticket`.`ref` AS `problem_ref`,`_knownerror`.`symptom` AS `symptom`,`_knownerror`.`rootcause` AS `root_cause`,`_knownerror`.`workaround` AS `workaround`,`_knownerror`.`solution` AS `solution`,`_knownerror`.`error_code` AS `error_code`,`_knownerror`.`domain` AS `domain`,`_knownerror`.`vendor` AS `vendor`,`_knownerror`.`model` AS `model`,`_knownerror`.`version` AS `version`,cast(concat(coalesce(`_knownerror`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Problem_problem_id_ticket`.`ref`,'')) as char charset utf8) AS `problem_id_friendlyname` from ((`knownerror` `_knownerror` join `organization` `Organization_org_id_organization` on((`_knownerror`.`cust_id` = `Organization_org_id_organization`.`id`))) left join (`ticket_problem` `Problem_problem_id_ticket_problem` join `ticket` `Problem_problem_id_ticket` on((`Problem_problem_id_ticket_problem`.`id` = `Problem_problem_id_ticket`.`id`))) on((`_knownerror`.`problem_id` = `Problem_problem_id_ticket_problem`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Licence`
--

/*!50001 DROP VIEW IF EXISTS `view_Licence`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Licence` AS select distinct `_licence`.`id` AS `id`,`_licence`.`name` AS `name`,`_licence`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_licence`.`usage_limit` AS `usage_limit`,`_licence`.`description` AS `description`,`_licence`.`start_date` AS `start_date`,`_licence`.`end_date` AS `end_date`,`_licence`.`licence_key` AS `licence_key`,`_licence`.`perpetual` AS `perpetual`,`_licence`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_licence`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from (`licence` `_licence` join `organization` `Organization_org_id_organization` on((`_licence`.`org_id` = `Organization_org_id_organization`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Location`
--

/*!50001 DROP VIEW IF EXISTS `view_Location`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Location` AS select distinct `_location`.`id` AS `id`,`_location`.`name` AS `name`,`_location`.`status` AS `status`,`_location`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_location`.`address` AS `address`,`_location`.`postal_code` AS `postal_code`,`_location`.`city` AS `city`,`_location`.`country` AS `country`,cast(concat(coalesce(`_location`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from (`location` `_location` join `organization` `Organization_org_id_organization` on((`_location`.`org_id` = `Organization_org_id_organization`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_LogicalInterface`
--

/*!50001 DROP VIEW IF EXISTS `view_LogicalInterface`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_LogicalInterface` AS select distinct `_logicalinterface`.`id` AS `id`,`_networkinterface`.`name` AS `name`,`_ipinterface`.`ipaddress` AS `ipaddress`,`_ipinterface`.`macaddress` AS `macaddress`,`_ipinterface`.`comment` AS `comment`,`_ipinterface`.`ipgateway` AS `ipgateway`,`_ipinterface`.`ipmask` AS `ipmask`,`_ipinterface`.`speed` AS `speed`,`_logicalinterface`.`virtualmachine_id` AS `virtualmachine_id`,`VirtualMachine_virtualmachine_id_functionalci`.`name` AS `virtualmachine_name`,`_networkinterface`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`VirtualMachine_virtualmachine_id_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`VirtualMachine_virtualmachine_id_functionalci`.`name`,'')) as char charset utf8) AS `virtualmachine_id_friendlyname` from (((`logicalinterface` `_logicalinterface` join (`virtualmachine` `VirtualMachine_virtualmachine_id_virtualmachine` join `functionalci` `VirtualMachine_virtualmachine_id_functionalci` on((`VirtualMachine_virtualmachine_id_virtualmachine`.`id` = `VirtualMachine_virtualmachine_id_functionalci`.`id`))) on((`_logicalinterface`.`virtualmachine_id` = `VirtualMachine_virtualmachine_id_virtualmachine`.`id`))) join `networkinterface` `_networkinterface` on((`_logicalinterface`.`id` = `_networkinterface`.`id`))) join `ipinterface` `_ipinterface` on((`_logicalinterface`.`id` = `_ipinterface`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_LogicalVolume`
--

/*!50001 DROP VIEW IF EXISTS `view_LogicalVolume`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_LogicalVolume` AS select distinct `_logicalvolume`.`id` AS `id`,`_logicalvolume`.`name` AS `name`,`_logicalvolume`.`lun_id` AS `lun_id`,`_logicalvolume`.`description` AS `description`,`_logicalvolume`.`raid_level` AS `raid_level`,`_logicalvolume`.`size` AS `size`,`_logicalvolume`.`storagesystem_id` AS `storagesystem_id`,`StorageSystem_storagesystem_id_functionalci`.`name` AS `storagesystem_name`,cast(concat(coalesce(`StorageSystem_storagesystem_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`_logicalvolume`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`StorageSystem_storagesystem_id_functionalci`.`name`,'')) as char charset utf8) AS `storagesystem_id_friendlyname` from (`logicalvolume` `_logicalvolume` join (`storagesystem` `StorageSystem_storagesystem_id_storagesystem` join `functionalci` `StorageSystem_storagesystem_id_functionalci` on((`StorageSystem_storagesystem_id_storagesystem`.`id` = `StorageSystem_storagesystem_id_functionalci`.`id`))) on((`_logicalvolume`.`storagesystem_id` = `StorageSystem_storagesystem_id_storagesystem`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Middleware`
--

/*!50001 DROP VIEW IF EXISTS `view_Middleware`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Middleware` AS select distinct `_middleware`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_softwareinstance`.`functionalci_id` AS `system_id`,`FunctionalCI_system_id_functionalci`.`name` AS `system_name`,`_softwareinstance`.`software_id` AS `software_id`,`Software_software_id_software`.`name` AS `software_name`,`_softwareinstance`.`softwarelicence_id` AS `softwarelicence_id`,`SoftwareLicence_softwarelicence_id_licence`.`name` AS `softwarelicence_name`,`_softwareinstance`.`path` AS `path`,`_softwareinstance`.`status` AS `status`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,if((`FunctionalCI_system_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id1_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8)) AS `system_id_friendlyname`,`FunctionalCI_system_id_functionalci`.`finalclass` AS `system_id_finalclass_recall`,cast(concat(coalesce(`Software_software_id_software`.`name`,''),coalesce(' ',''),coalesce(`Software_software_id_software`.`version`,'')) as char charset utf8) AS `software_id_friendlyname`,cast(concat(coalesce(`SoftwareLicence_softwarelicence_id_licence`.`name`,'')) as char charset utf8) AS `softwarelicence_id_friendlyname` from ((`middleware` `_middleware` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_middleware`.`id` = `_functionalci`.`id`))) join (((`softwareinstance` `_softwareinstance` join (`functionalci` `FunctionalCI_system_id_functionalci` left join (`softwareinstance` `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id1_functionalci` on((`FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id1_functionalci`.`id`))) on((`FunctionalCI_system_id_functionalci`.`id` = `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) left join `software` `Software_software_id_software` on((`_softwareinstance`.`software_id` = `Software_software_id_software`.`id`))) left join (`softwarelicence` `SoftwareLicence_softwarelicence_id_softwarelicence` join `licence` `SoftwareLicence_softwarelicence_id_licence` on((`SoftwareLicence_softwarelicence_id_softwarelicence`.`id` = `SoftwareLicence_softwarelicence_id_licence`.`id`))) on((`_softwareinstance`.`softwarelicence_id` = `SoftwareLicence_softwarelicence_id_softwarelicence`.`id`))) on((`_middleware`.`id` = `_softwareinstance`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_MiddlewareInstance`
--

/*!50001 DROP VIEW IF EXISTS `view_MiddlewareInstance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_MiddlewareInstance` AS select distinct `_middlewareinstance`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_middlewareinstance`.`middleware_id` AS `middleware_id`,`Middleware_middleware_id_functionalci`.`name` AS `middleware_name`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Middleware_middleware_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8) AS `middleware_id_friendlyname` from ((`middlewareinstance` `_middlewareinstance` join ((`middleware` `Middleware_middleware_id_middleware` join `functionalci` `Middleware_middleware_id_functionalci` on((`Middleware_middleware_id_middleware`.`id` = `Middleware_middleware_id_functionalci`.`id`))) join (`softwareinstance` `Middleware_middleware_id_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`Middleware_middleware_id_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`Middleware_middleware_id_middleware`.`id` = `Middleware_middleware_id_softwareinstance`.`id`))) on((`_middlewareinstance`.`middleware_id` = `Middleware_middleware_id_middleware`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_middlewareinstance`.`id` = `_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_MobilePhone`
--

/*!50001 DROP VIEW IF EXISTS `view_MobilePhone`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_MobilePhone` AS select distinct `_mobilephone`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_telephonyci`.`phonenumber` AS `phonenumber`,`_mobilephone`.`imei` AS `imei`,`_mobilephone`.`hw_pin` AS `hw_pin`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname` from (((`mobilephone` `_mobilephone` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_mobilephone`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_mobilephone`.`id` = `_physicaldevice`.`id`))) join `telephonyci` `_telephonyci` on((`_mobilephone`.`id` = `_telephonyci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Model`
--

/*!50001 DROP VIEW IF EXISTS `view_Model`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Model` AS select distinct `_model`.`id` AS `id`,`_typology`.`name` AS `name`,`_model`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_model`.`type` AS `type`,`_typology`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_typology`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname` from ((`model` `_model` join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_model`.`brand_id` = `Brand_brand_id_brand`.`id`))) join `typology` `_typology` on((`_model`.`id` = `_typology`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_NAS`
--

/*!50001 DROP VIEW IF EXISTS `view_NAS`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_NAS` AS select distinct `_nas`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_datacenterdevice`.`rack_id` AS `rack_id`,`Rack_rack_id_functionalci`.`name` AS `rack_name`,`_datacenterdevice`.`enclosure_id` AS `enclosure_id`,`Enclosure_enclosure_id_functionalci`.`name` AS `enclosure_name`,`_datacenterdevice`.`nb_u` AS `nb_u`,`_datacenterdevice`.`managementip` AS `managementip`,`_datacenterdevice`.`powera_id` AS `powerA_id`,`PowerConnection_powerA_id_functionalci`.`name` AS `powerA_name`,`_datacenterdevice`.`powerB_id` AS `powerB_id`,`PowerConnection_powerB_id_functionalci`.`name` AS `powerB_name`,`_datacenterdevice`.`redundancy` AS `redundancy`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname`,cast(concat(coalesce(`Rack_rack_id_functionalci`.`name`,'')) as char charset utf8) AS `rack_id_friendlyname`,cast(concat(coalesce(`Enclosure_enclosure_id_functionalci`.`name`,'')) as char charset utf8) AS `enclosure_id_friendlyname`,cast(concat(coalesce(`PowerConnection_powerA_id_functionalci`.`name`,'')) as char charset utf8) AS `powerA_id_friendlyname`,`PowerConnection_powerA_id_functionalci`.`finalclass` AS `powerA_id_finalclass_recall`,cast(concat(coalesce(`PowerConnection_powerB_id_functionalci`.`name`,'')) as char charset utf8) AS `powerB_id_friendlyname`,`PowerConnection_powerB_id_functionalci`.`finalclass` AS `powerB_id_finalclass_recall` from (((`nas` `_nas` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_nas`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_nas`.`id` = `_physicaldevice`.`id`))) join ((((`datacenterdevice` `_datacenterdevice` left join (`rack` `Rack_rack_id_rack` join `functionalci` `Rack_rack_id_functionalci` on((`Rack_rack_id_rack`.`id` = `Rack_rack_id_functionalci`.`id`))) on((`_datacenterdevice`.`rack_id` = `Rack_rack_id_rack`.`id`))) left join (`enclosure` `Enclosure_enclosure_id_enclosure` join `functionalci` `Enclosure_enclosure_id_functionalci` on((`Enclosure_enclosure_id_enclosure`.`id` = `Enclosure_enclosure_id_functionalci`.`id`))) on((`_datacenterdevice`.`enclosure_id` = `Enclosure_enclosure_id_enclosure`.`id`))) left join (`powerconnection` `PowerConnection_powerA_id_powerconnection` join `functionalci` `PowerConnection_powerA_id_functionalci` on((`PowerConnection_powerA_id_powerconnection`.`id` = `PowerConnection_powerA_id_functionalci`.`id`))) on((`_datacenterdevice`.`powera_id` = `PowerConnection_powerA_id_powerconnection`.`id`))) left join (`powerconnection` `PowerConnection_powerB_id_powerconnection` join `functionalci` `PowerConnection_powerB_id_functionalci` on((`PowerConnection_powerB_id_powerconnection`.`id` = `PowerConnection_powerB_id_functionalci`.`id`))) on((`_datacenterdevice`.`powerB_id` = `PowerConnection_powerB_id_powerconnection`.`id`))) on((`_nas`.`id` = `_datacenterdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_NASFileSystem`
--

/*!50001 DROP VIEW IF EXISTS `view_NASFileSystem`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_NASFileSystem` AS select distinct `_nasfilesystem`.`id` AS `id`,`_nasfilesystem`.`name` AS `name`,`_nasfilesystem`.`description` AS `description`,`_nasfilesystem`.`raid_level` AS `raid_level`,`_nasfilesystem`.`size` AS `size`,`_nasfilesystem`.`nas_id` AS `nas_id`,`NAS_nas_id_functionalci`.`name` AS `nas_name`,cast(concat(coalesce(`_nasfilesystem`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`NAS_nas_id_functionalci`.`name`,'')) as char charset utf8) AS `nas_id_friendlyname` from (`nasfilesystem` `_nasfilesystem` join (`nas` `NAS_nas_id_nas` join `functionalci` `NAS_nas_id_functionalci` on((`NAS_nas_id_nas`.`id` = `NAS_nas_id_functionalci`.`id`))) on((`_nasfilesystem`.`nas_id` = `NAS_nas_id_nas`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_NetworkDevice`
--

/*!50001 DROP VIEW IF EXISTS `view_NetworkDevice`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_NetworkDevice` AS select distinct `_networkdevice`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id1_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_datacenterdevice`.`rack_id` AS `rack_id`,`Rack_rack_id_functionalci`.`name` AS `rack_name`,`_datacenterdevice`.`enclosure_id` AS `enclosure_id`,`Enclosure_enclosure_id_functionalci`.`name` AS `enclosure_name`,`_datacenterdevice`.`nb_u` AS `nb_u`,`_datacenterdevice`.`managementip` AS `managementip`,`_datacenterdevice`.`powera_id` AS `powerA_id`,`PowerConnection_powerA_id_functionalci`.`name` AS `powerA_name`,`_datacenterdevice`.`powerB_id` AS `powerB_id`,`PowerConnection_powerB_id_functionalci`.`name` AS `powerB_name`,`_datacenterdevice`.`redundancy` AS `redundancy`,`_networkdevice`.`networkdevicetype_id` AS `networkdevicetype_id`,`NetworkDeviceType_networkdevicetype_id_typology`.`name` AS `networkdevicetype_name`,`_networkdevice`.`iosversion_id` AS `iosversion_id`,`IOSVersion_iosversion_id_typology`.`name` AS `iosversion_name`,`_networkdevice`.`ram` AS `ram`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id1_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname`,cast(concat(coalesce(`Rack_rack_id_functionalci`.`name`,'')) as char charset utf8) AS `rack_id_friendlyname`,cast(concat(coalesce(`Enclosure_enclosure_id_functionalci`.`name`,'')) as char charset utf8) AS `enclosure_id_friendlyname`,cast(concat(coalesce(`PowerConnection_powerA_id_functionalci`.`name`,'')) as char charset utf8) AS `powerA_id_friendlyname`,`PowerConnection_powerA_id_functionalci`.`finalclass` AS `powerA_id_finalclass_recall`,cast(concat(coalesce(`PowerConnection_powerB_id_functionalci`.`name`,'')) as char charset utf8) AS `powerB_id_friendlyname`,`PowerConnection_powerB_id_functionalci`.`finalclass` AS `powerB_id_finalclass_recall`,cast(concat(coalesce(`NetworkDeviceType_networkdevicetype_id_typology`.`name`,'')) as char charset utf8) AS `networkdevicetype_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,''),coalesce(' ',''),coalesce(`IOSVersion_iosversion_id_typology`.`name`,'')) as char charset utf8) AS `iosversion_id_friendlyname` from (((((`networkdevice` `_networkdevice` join (`networkdevicetype` `NetworkDeviceType_networkdevicetype_id_networkdevicetype` join `typology` `NetworkDeviceType_networkdevicetype_id_typology` on((`NetworkDeviceType_networkdevicetype_id_networkdevicetype`.`id` = `NetworkDeviceType_networkdevicetype_id_typology`.`id`))) on((`_networkdevice`.`networkdevicetype_id` = `NetworkDeviceType_networkdevicetype_id_networkdevicetype`.`id`))) left join ((`iosversion` `IOSVersion_iosversion_id_iosversion` join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`IOSVersion_iosversion_id_iosversion`.`brand_id` = `Brand_brand_id_brand`.`id`))) join `typology` `IOSVersion_iosversion_id_typology` on((`IOSVersion_iosversion_id_iosversion`.`id` = `IOSVersion_iosversion_id_typology`.`id`))) on((`_networkdevice`.`iosversion_id` = `IOSVersion_iosversion_id_iosversion`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_networkdevice`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id1_brand` join `typology` `Brand_brand_id1_typology` on((`Brand_brand_id1_brand`.`id` = `Brand_brand_id1_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id1_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_networkdevice`.`id` = `_physicaldevice`.`id`))) join ((((`datacenterdevice` `_datacenterdevice` left join (`rack` `Rack_rack_id_rack` join `functionalci` `Rack_rack_id_functionalci` on((`Rack_rack_id_rack`.`id` = `Rack_rack_id_functionalci`.`id`))) on((`_datacenterdevice`.`rack_id` = `Rack_rack_id_rack`.`id`))) left join (`enclosure` `Enclosure_enclosure_id_enclosure` join `functionalci` `Enclosure_enclosure_id_functionalci` on((`Enclosure_enclosure_id_enclosure`.`id` = `Enclosure_enclosure_id_functionalci`.`id`))) on((`_datacenterdevice`.`enclosure_id` = `Enclosure_enclosure_id_enclosure`.`id`))) left join (`powerconnection` `PowerConnection_powerA_id_powerconnection` join `functionalci` `PowerConnection_powerA_id_functionalci` on((`PowerConnection_powerA_id_powerconnection`.`id` = `PowerConnection_powerA_id_functionalci`.`id`))) on((`_datacenterdevice`.`powera_id` = `PowerConnection_powerA_id_powerconnection`.`id`))) left join (`powerconnection` `PowerConnection_powerB_id_powerconnection` join `functionalci` `PowerConnection_powerB_id_functionalci` on((`PowerConnection_powerB_id_powerconnection`.`id` = `PowerConnection_powerB_id_functionalci`.`id`))) on((`_datacenterdevice`.`powerB_id` = `PowerConnection_powerB_id_powerconnection`.`id`))) on((`_networkdevice`.`id` = `_datacenterdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_NetworkDeviceType`
--

/*!50001 DROP VIEW IF EXISTS `view_NetworkDeviceType`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_NetworkDeviceType` AS select distinct `_networkdevicetype`.`id` AS `id`,`_typology`.`name` AS `name`,`_typology`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_typology`.`name`,'')) as char charset utf8) AS `friendlyname` from (`networkdevicetype` `_networkdevicetype` join `typology` `_typology` on((`_networkdevicetype`.`id` = `_typology`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_NetworkInterface`
--

/*!50001 DROP VIEW IF EXISTS `view_NetworkInterface`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_NetworkInterface` AS select distinct `_networkinterface`.`id` AS `id`,`_networkinterface`.`name` AS `name`,`_networkinterface`.`finalclass` AS `finalclass`,if((`_networkinterface`.`finalclass` = 'NetworkInterface'),cast(concat(coalesce(`_networkinterface`.`name`,'')) as char charset utf8),if((`_networkinterface`.`finalclass` = 'LogicalInterface'),cast(concat(coalesce(`_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`VirtualMachine_virtualmachine_id_functionalci`.`name`,'')) as char charset utf8),if((`_networkinterface`.`finalclass` = 'FiberChannelInterface'),cast(concat(coalesce(`_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`DatacenterDevice_datacenterdevice_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`ConnectableCI_connectableci_id_functionalci`.`name`,'')) as char charset utf8)))) AS `friendlyname` from (((`networkinterface` `_networkinterface` left join (`logicalinterface` `_fn_LogicalInterface_logicalinterface` join (`virtualmachine` `VirtualMachine_virtualmachine_id_virtualmachine` join `functionalci` `VirtualMachine_virtualmachine_id_functionalci` on((`VirtualMachine_virtualmachine_id_virtualmachine`.`id` = `VirtualMachine_virtualmachine_id_functionalci`.`id`))) on((`_fn_LogicalInterface_logicalinterface`.`virtualmachine_id` = `VirtualMachine_virtualmachine_id_virtualmachine`.`id`))) on((`_networkinterface`.`id` = `_fn_LogicalInterface_logicalinterface`.`id`))) left join (`fiberchannelinterface` `_fn_FiberChannelInterface_fiberchannelinterface` join (`datacenterdevice` `DatacenterDevice_datacenterdevice_id_datacenterdevice` join `functionalci` `DatacenterDevice_datacenterdevice_id_functionalci` on((`DatacenterDevice_datacenterdevice_id_datacenterdevice`.`id` = `DatacenterDevice_datacenterdevice_id_functionalci`.`id`))) on((`_fn_FiberChannelInterface_fiberchannelinterface`.`datacenterdevice_id` = `DatacenterDevice_datacenterdevice_id_datacenterdevice`.`id`))) on((`_networkinterface`.`id` = `_fn_FiberChannelInterface_fiberchannelinterface`.`id`))) left join (`physicalinterface` `_fn_PhysicalInterface_physicalinterface` join (`connectableci` `ConnectableCI_connectableci_id_connectableci` join `functionalci` `ConnectableCI_connectableci_id_functionalci` on((`ConnectableCI_connectableci_id_connectableci`.`id` = `ConnectableCI_connectableci_id_functionalci`.`id`))) on((`_fn_PhysicalInterface_physicalinterface`.`connectableci_id` = `ConnectableCI_connectableci_id_connectableci`.`id`))) on((`_networkinterface`.`id` = `_fn_PhysicalInterface_physicalinterface`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_NormalChange`
--

/*!50001 DROP VIEW IF EXISTS `view_NormalChange`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_NormalChange` AS select distinct `_change_normal`.`id` AS `id`,`_ticket`.`operational_status` AS `operational_status`,`_ticket`.`ref` AS `ref`,`_ticket`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ticket`.`caller_id` AS `caller_id`,`Person_caller_id_contact`.`name` AS `caller_name`,`_ticket`.`team_id` AS `team_id`,`Team_team_id_contact`.`email` AS `team_name`,`_ticket`.`agent_id` AS `agent_id`,`Person_agent_id_contact`.`name` AS `agent_name`,`_ticket`.`title` AS `title`,`_ticket`.`description` AS `description`,`_ticket`.`description_format` AS `description_format`,`_ticket`.`start_date` AS `start_date`,`_ticket`.`end_date` AS `end_date`,`_ticket`.`last_update` AS `last_update`,`_ticket`.`close_date` AS `close_date`,`_ticket`.`private_log` AS `private_log`,`_ticket`.`private_log_index` AS `private_log_index`,`_ticket`.`id_instalador` AS `id_instalador`,`_ticket`.`san` AS `san`,`_ticket`.`nombre_instalador` AS `nombre_instalador`,`_ticket`.`pais_ticket` AS `pais_ticket`,`_change`.`status` AS `status`,`_change`.`reason` AS `reason`,`_change`.`requestor_id` AS `requestor_id`,`Person_requestor_id_contact`.`email` AS `requestor_email`,`_change`.`creation_date` AS `creation_date`,`_change`.`impact` AS `impact`,`_change`.`supervisor_group_id` AS `supervisor_group_id`,`Team_supervisor_group_id_contact`.`name` AS `supervisor_group_name`,`_change`.`supervisor_id` AS `supervisor_id`,`Person_supervisor_id_contact`.`email` AS `supervisor_email`,`_change`.`manager_group_id` AS `manager_group_id`,`Team_manager_group_id_contact`.`name` AS `manager_group_name`,`_change`.`manager_id` AS `manager_id`,`Person_manager_id_contact`.`email` AS `manager_email`,`_change`.`outage` AS `outage`,`_change`.`fallback` AS `fallback`,`_change`.`parent_id` AS `parent_id`,`Change_parent_id_ticket`.`ref` AS `parent_name`,`_change`.`external_id_cambios` AS `external_id_cambios`,`_change`.`servicefamily_key` AS `servicefamily_key`,`ServiceFamily_servicefamily_key_servicefamily`.`name` AS `servicefamily_n`,`_change`.`service_key` AS `service_key`,`Service_service_key_service`.`name` AS `service_n`,`_change`.`servicesubcategory_key` AS `servicesubcategory_key`,`ServiceSubcategory_servicesubcategory_key_servicesubcategory`.`name` AS `servicesubcategory_n`,`_change_approved`.`approval_date` AS `approval_date`,`_change_approved`.`approval_comment` AS `approval_comment`,`_change_normal`.`acceptance_date` AS `acceptance_date`,`_change_normal`.`acceptance_comment` AS `acceptance_comment`,`_ticket`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_ticket`.`ref`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_caller_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_caller_id_contact`.`name`,'')) as char charset utf8) AS `caller_id_friendlyname`,cast(concat(coalesce(`Team_team_id_contact`.`name`,'')) as char charset utf8) AS `team_id_friendlyname`,cast(concat(coalesce(`Person_agent_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_agent_id_contact`.`name`,'')) as char charset utf8) AS `agent_id_friendlyname`,cast(concat(coalesce(`Person_requestor_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_requestor_id_contact`.`name`,'')) as char charset utf8) AS `requestor_id_friendlyname`,cast(concat(coalesce(`Team_supervisor_group_id_contact`.`name`,'')) as char charset utf8) AS `supervisor_group_id_friendlyname`,cast(concat(coalesce(`Person_supervisor_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_supervisor_id_contact`.`name`,'')) as char charset utf8) AS `supervisor_id_friendlyname`,cast(concat(coalesce(`Team_manager_group_id_contact`.`name`,'')) as char charset utf8) AS `manager_group_id_friendlyname`,cast(concat(coalesce(`Person_manager_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_manager_id_contact`.`name`,'')) as char charset utf8) AS `manager_id_friendlyname`,cast(concat(coalesce(`Change_parent_id_ticket`.`ref`,'')) as char charset utf8) AS `parent_id_friendlyname`,`Change_parent_id_ticket`.`finalclass` AS `parent_id_finalclass_recall`,cast(concat(coalesce(`ServiceFamily_servicefamily_key_servicefamily`.`name`,'')) as char charset utf8) AS `servicefamily_key_friendlyname`,cast(concat(coalesce(`Service_service_key_service`.`name`,'')) as char charset utf8) AS `service_key_friendlyname`,cast(concat(coalesce(`ServiceSubcategory_servicesubcategory_key_servicesubcategory`.`name`,'')) as char charset utf8) AS `servicesubcategory_key_friendlyname` from (((`change_normal` `_change_normal` join ((((`ticket` `_ticket` join `organization` `Organization_org_id_organization` on((`_ticket`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_caller_id_person` join `contact` `Person_caller_id_contact` on((`Person_caller_id_person`.`id` = `Person_caller_id_contact`.`id`))) on((`_ticket`.`caller_id` = `Person_caller_id_person`.`id`))) left join (`team` `Team_team_id_team` join `contact` `Team_team_id_contact` on((`Team_team_id_team`.`id` = `Team_team_id_contact`.`id`))) on((`_ticket`.`team_id` = `Team_team_id_team`.`id`))) left join (`person` `Person_agent_id_person` join `contact` `Person_agent_id_contact` on((`Person_agent_id_person`.`id` = `Person_agent_id_contact`.`id`))) on((`_ticket`.`agent_id` = `Person_agent_id_person`.`id`))) on((`_change_normal`.`id` = `_ticket`.`id`))) join (((((((((`change` `_change` left join (`person` `Person_requestor_id_person` join `contact` `Person_requestor_id_contact` on((`Person_requestor_id_person`.`id` = `Person_requestor_id_contact`.`id`))) on((`_change`.`requestor_id` = `Person_requestor_id_person`.`id`))) left join (`team` `Team_supervisor_group_id_team` join `contact` `Team_supervisor_group_id_contact` on((`Team_supervisor_group_id_team`.`id` = `Team_supervisor_group_id_contact`.`id`))) on((`_change`.`supervisor_group_id` = `Team_supervisor_group_id_team`.`id`))) left join (`person` `Person_supervisor_id_person` join `contact` `Person_supervisor_id_contact` on((`Person_supervisor_id_person`.`id` = `Person_supervisor_id_contact`.`id`))) on((`_change`.`supervisor_id` = `Person_supervisor_id_person`.`id`))) left join (`team` `Team_manager_group_id_team` join `contact` `Team_manager_group_id_contact` on((`Team_manager_group_id_team`.`id` = `Team_manager_group_id_contact`.`id`))) on((`_change`.`manager_group_id` = `Team_manager_group_id_team`.`id`))) left join (`person` `Person_manager_id_person` join `contact` `Person_manager_id_contact` on((`Person_manager_id_person`.`id` = `Person_manager_id_contact`.`id`))) on((`_change`.`manager_id` = `Person_manager_id_person`.`id`))) left join (`change` `Change_parent_id_change` join `ticket` `Change_parent_id_ticket` on((`Change_parent_id_change`.`id` = `Change_parent_id_ticket`.`id`))) on((`_change`.`parent_id` = `Change_parent_id_change`.`id`))) left join `servicefamily` `ServiceFamily_servicefamily_key_servicefamily` on((`_change`.`servicefamily_key` = `ServiceFamily_servicefamily_key_servicefamily`.`id`))) left join `service` `Service_service_key_service` on((`_change`.`service_key` = `Service_service_key_service`.`id`))) left join `servicesubcategory` `ServiceSubcategory_servicesubcategory_key_servicesubcategory` on((`_change`.`servicesubcategory_key` = `ServiceSubcategory_servicesubcategory_key_servicesubcategory`.`id`))) on((`_change_normal`.`id` = `_change`.`id`))) join `change_approved` `_change_approved` on((`_change_normal`.`id` = `_change_approved`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_OSFamily`
--

/*!50001 DROP VIEW IF EXISTS `view_OSFamily`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_OSFamily` AS select distinct `_osfamily`.`id` AS `id`,`_typology`.`name` AS `name`,`_typology`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_typology`.`name`,'')) as char charset utf8) AS `friendlyname` from (`osfamily` `_osfamily` join `typology` `_typology` on((`_osfamily`.`id` = `_typology`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_OSLicence`
--

/*!50001 DROP VIEW IF EXISTS `view_OSLicence`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_OSLicence` AS select distinct `_oslicence`.`id` AS `id`,`_licence`.`name` AS `name`,`_licence`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_licence`.`usage_limit` AS `usage_limit`,`_licence`.`description` AS `description`,`_licence`.`start_date` AS `start_date`,`_licence`.`end_date` AS `end_date`,`_licence`.`licence_key` AS `licence_key`,`_licence`.`perpetual` AS `perpetual`,`_oslicence`.`osversion_id` AS `osversion_id`,`OSVersion_osversion_id_typology`.`name` AS `osversion_name`,`_licence`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_licence`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`OSVersion_osversion_id_typology`.`name`,'')) as char charset utf8) AS `osversion_id_friendlyname` from ((`oslicence` `_oslicence` join (`osversion` `OSVersion_osversion_id_osversion` join `typology` `OSVersion_osversion_id_typology` on((`OSVersion_osversion_id_osversion`.`id` = `OSVersion_osversion_id_typology`.`id`))) on((`_oslicence`.`osversion_id` = `OSVersion_osversion_id_osversion`.`id`))) join (`licence` `_licence` join `organization` `Organization_org_id_organization` on((`_licence`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_oslicence`.`id` = `_licence`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_OSPatch`
--

/*!50001 DROP VIEW IF EXISTS `view_OSPatch`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_OSPatch` AS select distinct `_ospatch`.`id` AS `id`,`_patch`.`name` AS `name`,`_patch`.`description` AS `description`,`_ospatch`.`osversion_id` AS `osversion_id`,`OSVersion_osversion_id_typology`.`name` AS `osversion_name`,`_patch`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_patch`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`OSVersion_osversion_id_typology`.`name`,'')) as char charset utf8) AS `osversion_id_friendlyname` from ((`ospatch` `_ospatch` join (`osversion` `OSVersion_osversion_id_osversion` join `typology` `OSVersion_osversion_id_typology` on((`OSVersion_osversion_id_osversion`.`id` = `OSVersion_osversion_id_typology`.`id`))) on((`_ospatch`.`osversion_id` = `OSVersion_osversion_id_osversion`.`id`))) join `patch` `_patch` on((`_ospatch`.`id` = `_patch`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_OSVersion`
--

/*!50001 DROP VIEW IF EXISTS `view_OSVersion`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_OSVersion` AS select distinct `_osversion`.`id` AS `id`,`_typology`.`name` AS `name`,`_osversion`.`osfamily_id` AS `osfamily_id`,`OSFamily_osfamily_id_typology`.`name` AS `osfamily_name`,`_typology`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_typology`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`OSFamily_osfamily_id_typology`.`name`,'')) as char charset utf8) AS `osfamily_id_friendlyname` from ((`osversion` `_osversion` join (`osfamily` `OSFamily_osfamily_id_osfamily` join `typology` `OSFamily_osfamily_id_typology` on((`OSFamily_osfamily_id_osfamily`.`id` = `OSFamily_osfamily_id_typology`.`id`))) on((`_osversion`.`osfamily_id` = `OSFamily_osfamily_id_osfamily`.`id`))) join `typology` `_typology` on((`_osversion`.`id` = `_typology`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Organization`
--

/*!50001 DROP VIEW IF EXISTS `view_Organization`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Organization` AS select distinct `_organization`.`id` AS `id`,`_organization`.`name` AS `name`,`_organization`.`code` AS `code`,`_organization`.`status` AS `status`,`_organization`.`parent_id` AS `parent_id`,`Organization_parent_id_organization`.`name` AS `parent_name`,`_organization`.`deliverymodel_id` AS `deliverymodel_id`,`DeliveryModel_deliverymodel_id_deliverymodel`.`name` AS `deliverymodel_name`,cast(concat(coalesce(`_organization`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_parent_id_organization`.`name`,'')) as char charset utf8) AS `parent_id_friendlyname`,cast(concat(coalesce(`DeliveryModel_deliverymodel_id_deliverymodel`.`name`,'')) as char charset utf8) AS `deliverymodel_id_friendlyname` from ((`organization` `_organization` left join `organization` `Organization_parent_id_organization` on((`_organization`.`parent_id` = `Organization_parent_id_organization`.`id`))) left join `deliverymodel` `DeliveryModel_deliverymodel_id_deliverymodel` on((`_organization`.`deliverymodel_id` = `DeliveryModel_deliverymodel_id_deliverymodel`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_OtherSoftware`
--

/*!50001 DROP VIEW IF EXISTS `view_OtherSoftware`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_OtherSoftware` AS select distinct `_othersoftware`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_softwareinstance`.`functionalci_id` AS `system_id`,`FunctionalCI_system_id_functionalci`.`name` AS `system_name`,`_softwareinstance`.`software_id` AS `software_id`,`Software_software_id_software`.`name` AS `software_name`,`_softwareinstance`.`softwarelicence_id` AS `softwarelicence_id`,`SoftwareLicence_softwarelicence_id_licence`.`name` AS `softwarelicence_name`,`_softwareinstance`.`path` AS `path`,`_softwareinstance`.`status` AS `status`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,if((`FunctionalCI_system_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id1_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8)) AS `system_id_friendlyname`,`FunctionalCI_system_id_functionalci`.`finalclass` AS `system_id_finalclass_recall`,cast(concat(coalesce(`Software_software_id_software`.`name`,''),coalesce(' ',''),coalesce(`Software_software_id_software`.`version`,'')) as char charset utf8) AS `software_id_friendlyname`,cast(concat(coalesce(`SoftwareLicence_softwarelicence_id_licence`.`name`,'')) as char charset utf8) AS `softwarelicence_id_friendlyname` from ((`othersoftware` `_othersoftware` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_othersoftware`.`id` = `_functionalci`.`id`))) join (((`softwareinstance` `_softwareinstance` join (`functionalci` `FunctionalCI_system_id_functionalci` left join (`softwareinstance` `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id1_functionalci` on((`FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id1_functionalci`.`id`))) on((`FunctionalCI_system_id_functionalci`.`id` = `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) left join `software` `Software_software_id_software` on((`_softwareinstance`.`software_id` = `Software_software_id_software`.`id`))) left join (`softwarelicence` `SoftwareLicence_softwarelicence_id_softwarelicence` join `licence` `SoftwareLicence_softwarelicence_id_licence` on((`SoftwareLicence_softwarelicence_id_softwarelicence`.`id` = `SoftwareLicence_softwarelicence_id_licence`.`id`))) on((`_softwareinstance`.`softwarelicence_id` = `SoftwareLicence_softwarelicence_id_softwarelicence`.`id`))) on((`_othersoftware`.`id` = `_softwareinstance`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_PC`
--

/*!50001 DROP VIEW IF EXISTS `view_PC`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_PC` AS select distinct `_pc`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_pc`.`osfamily_id` AS `osfamily_id`,`OSFamily_osfamily_id_typology`.`name` AS `osfamily_name`,`_pc`.`osversion_id` AS `osversion_id`,`OSVersion_osversion_id_typology`.`name` AS `osversion_name`,`_pc`.`cpu` AS `cpu`,`_pc`.`ram` AS `ram`,`_pc`.`type` AS `type`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname`,cast(concat(coalesce(`OSFamily_osfamily_id_typology`.`name`,'')) as char charset utf8) AS `osfamily_id_friendlyname`,cast(concat(coalesce(`OSVersion_osversion_id_typology`.`name`,'')) as char charset utf8) AS `osversion_id_friendlyname` from ((((`pc` `_pc` left join (`osfamily` `OSFamily_osfamily_id_osfamily` join `typology` `OSFamily_osfamily_id_typology` on((`OSFamily_osfamily_id_osfamily`.`id` = `OSFamily_osfamily_id_typology`.`id`))) on((`_pc`.`osfamily_id` = `OSFamily_osfamily_id_osfamily`.`id`))) left join (`osversion` `OSVersion_osversion_id_osversion` join `typology` `OSVersion_osversion_id_typology` on((`OSVersion_osversion_id_osversion`.`id` = `OSVersion_osversion_id_typology`.`id`))) on((`_pc`.`osversion_id` = `OSVersion_osversion_id_osversion`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_pc`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_pc`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_PCSoftware`
--

/*!50001 DROP VIEW IF EXISTS `view_PCSoftware`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_PCSoftware` AS select distinct `_pcsoftware`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_softwareinstance`.`functionalci_id` AS `system_id`,`FunctionalCI_system_id_functionalci`.`name` AS `system_name`,`_softwareinstance`.`software_id` AS `software_id`,`Software_software_id_software`.`name` AS `software_name`,`_softwareinstance`.`softwarelicence_id` AS `softwarelicence_id`,`SoftwareLicence_softwarelicence_id_licence`.`name` AS `softwarelicence_name`,`_softwareinstance`.`path` AS `path`,`_softwareinstance`.`status` AS `status`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,if((`FunctionalCI_system_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id1_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8)) AS `system_id_friendlyname`,`FunctionalCI_system_id_functionalci`.`finalclass` AS `system_id_finalclass_recall`,cast(concat(coalesce(`Software_software_id_software`.`name`,''),coalesce(' ',''),coalesce(`Software_software_id_software`.`version`,'')) as char charset utf8) AS `software_id_friendlyname`,cast(concat(coalesce(`SoftwareLicence_softwarelicence_id_licence`.`name`,'')) as char charset utf8) AS `softwarelicence_id_friendlyname` from ((`pcsoftware` `_pcsoftware` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_pcsoftware`.`id` = `_functionalci`.`id`))) join (((`softwareinstance` `_softwareinstance` join (`functionalci` `FunctionalCI_system_id_functionalci` left join (`softwareinstance` `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id1_functionalci` on((`FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id1_functionalci`.`id`))) on((`FunctionalCI_system_id_functionalci`.`id` = `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) left join `software` `Software_software_id_software` on((`_softwareinstance`.`software_id` = `Software_software_id_software`.`id`))) left join (`softwarelicence` `SoftwareLicence_softwarelicence_id_softwarelicence` join `licence` `SoftwareLicence_softwarelicence_id_licence` on((`SoftwareLicence_softwarelicence_id_softwarelicence`.`id` = `SoftwareLicence_softwarelicence_id_licence`.`id`))) on((`_softwareinstance`.`softwarelicence_id` = `SoftwareLicence_softwarelicence_id_softwarelicence`.`id`))) on((`_pcsoftware`.`id` = `_softwareinstance`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_PDU`
--

/*!50001 DROP VIEW IF EXISTS `view_PDU`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_PDU` AS select distinct `_pdu`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_pdu`.`rack_id` AS `rack_id`,`Rack_rack_id_functionalci`.`name` AS `rack_name`,`_pdu`.`powerstart_id` AS `powerstart_id`,`PowerConnection_powerstart_id_functionalci`.`name` AS `powerstart_name`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname`,cast(concat(coalesce(`Rack_rack_id_functionalci`.`name`,'')) as char charset utf8) AS `rack_id_friendlyname`,cast(concat(coalesce(`PowerConnection_powerstart_id_functionalci`.`name`,'')) as char charset utf8) AS `powerstart_id_friendlyname`,`PowerConnection_powerstart_id_functionalci`.`finalclass` AS `powerstart_id_finalclass_recall` from ((((`pdu` `_pdu` join (`rack` `Rack_rack_id_rack` join `functionalci` `Rack_rack_id_functionalci` on((`Rack_rack_id_rack`.`id` = `Rack_rack_id_functionalci`.`id`))) on((`_pdu`.`rack_id` = `Rack_rack_id_rack`.`id`))) left join (`powerconnection` `PowerConnection_powerstart_id_powerconnection` join `functionalci` `PowerConnection_powerstart_id_functionalci` on((`PowerConnection_powerstart_id_powerconnection`.`id` = `PowerConnection_powerstart_id_functionalci`.`id`))) on((`_pdu`.`powerstart_id` = `PowerConnection_powerstart_id_powerconnection`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_pdu`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_pdu`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Patch`
--

/*!50001 DROP VIEW IF EXISTS `view_Patch`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Patch` AS select distinct `_patch`.`id` AS `id`,`_patch`.`name` AS `name`,`_patch`.`description` AS `description`,`_patch`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_patch`.`name`,'')) as char charset utf8) AS `friendlyname` from `patch` `_patch` where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Peripheral`
--

/*!50001 DROP VIEW IF EXISTS `view_Peripheral`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Peripheral` AS select distinct `_peripheral`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname` from ((`peripheral` `_peripheral` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_peripheral`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_peripheral`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Person`
--

/*!50001 DROP VIEW IF EXISTS `view_Person`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Person` AS select distinct `_person`.`id` AS `id`,`_contact`.`name` AS `name`,`_contact`.`status` AS `status`,`_contact`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_contact`.`email` AS `email`,`_contact`.`phone` AS `phone`,`_contact`.`notify` AS `notify`,`_contact`.`function` AS `function`,`_person`.`picture_mimetype` AS `picture`,`_person`.`picture_data` AS `picture_data`,`_person`.`picture_filename` AS `picture_filename`,`_person`.`first_name` AS `first_name`,`_person`.`employee_number` AS `employee_number`,`_person`.`mobile_phone` AS `mobile_phone`,`_person`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_person`.`manager_id` AS `manager_id`,`Person_manager_id_contact`.`name` AS `manager_name`,`_contact`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_person`.`first_name`,''),coalesce(' ',''),coalesce(`_contact`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Person_manager_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_manager_id_contact`.`name`,'')) as char charset utf8) AS `manager_id_friendlyname` from (((`person` `_person` left join `location` `Location_location_id_location` on((`_person`.`location_id` = `Location_location_id_location`.`id`))) left join (`person` `Person_manager_id_person` join `contact` `Person_manager_id_contact` on((`Person_manager_id_person`.`id` = `Person_manager_id_contact`.`id`))) on((`_person`.`manager_id` = `Person_manager_id_person`.`id`))) join (`contact` `_contact` join `organization` `Organization_org_id_organization` on((`_contact`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_person`.`id` = `_contact`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Phone`
--

/*!50001 DROP VIEW IF EXISTS `view_Phone`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Phone` AS select distinct `_phone`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_telephonyci`.`phonenumber` AS `phonenumber`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname` from (((`phone` `_phone` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_phone`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_phone`.`id` = `_physicaldevice`.`id`))) join `telephonyci` `_telephonyci` on((`_phone`.`id` = `_telephonyci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_PhysicalDevice`
--

/*!50001 DROP VIEW IF EXISTS `view_PhysicalDevice`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_PhysicalDevice` AS select distinct `_physicaldevice`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname` from ((((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_physicaldevice`.`id` = `_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_PhysicalInterface`
--

/*!50001 DROP VIEW IF EXISTS `view_PhysicalInterface`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_PhysicalInterface` AS select distinct `_physicalinterface`.`id` AS `id`,`_networkinterface`.`name` AS `name`,`_ipinterface`.`ipaddress` AS `ipaddress`,`_ipinterface`.`macaddress` AS `macaddress`,`_ipinterface`.`comment` AS `comment`,`_ipinterface`.`ipgateway` AS `ipgateway`,`_ipinterface`.`ipmask` AS `ipmask`,`_ipinterface`.`speed` AS `speed`,`_physicalinterface`.`connectableci_id` AS `connectableci_id`,`ConnectableCI_connectableci_id_functionalci`.`name` AS `connectableci_name`,`_networkinterface`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`ConnectableCI_connectableci_id_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`ConnectableCI_connectableci_id_functionalci`.`name`,'')) as char charset utf8) AS `connectableci_id_friendlyname`,`ConnectableCI_connectableci_id_functionalci`.`finalclass` AS `connectableci_id_finalclass_recall` from (((`physicalinterface` `_physicalinterface` join (`connectableci` `ConnectableCI_connectableci_id_connectableci` join `functionalci` `ConnectableCI_connectableci_id_functionalci` on((`ConnectableCI_connectableci_id_connectableci`.`id` = `ConnectableCI_connectableci_id_functionalci`.`id`))) on((`_physicalinterface`.`connectableci_id` = `ConnectableCI_connectableci_id_connectableci`.`id`))) join `networkinterface` `_networkinterface` on((`_physicalinterface`.`id` = `_networkinterface`.`id`))) join `ipinterface` `_ipinterface` on((`_physicalinterface`.`id` = `_ipinterface`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_PowerConnection`
--

/*!50001 DROP VIEW IF EXISTS `view_PowerConnection`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_PowerConnection` AS select distinct `_powerconnection`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname` from ((`powerconnection` `_powerconnection` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_powerconnection`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_powerconnection`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_PowerSource`
--

/*!50001 DROP VIEW IF EXISTS `view_PowerSource`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_PowerSource` AS select distinct `_powersource`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname` from ((`powersource` `_powersource` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_powersource`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_powersource`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Printer`
--

/*!50001 DROP VIEW IF EXISTS `view_Printer`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Printer` AS select distinct `_printer`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname` from ((`printer` `_printer` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_printer`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_printer`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Problem`
--

/*!50001 DROP VIEW IF EXISTS `view_Problem`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Problem` AS select distinct `_ticket_problem`.`id` AS `id`,`_ticket`.`operational_status` AS `operational_status`,`_ticket`.`ref` AS `ref`,`_ticket`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ticket`.`caller_id` AS `caller_id`,`Person_caller_id_contact`.`name` AS `caller_name`,`_ticket`.`team_id` AS `team_id`,`Team_team_id_contact`.`email` AS `team_name`,`_ticket`.`agent_id` AS `agent_id`,`Person_agent_id_contact`.`name` AS `agent_name`,`_ticket`.`title` AS `title`,`_ticket`.`description` AS `description`,`_ticket`.`description_format` AS `description_format`,`_ticket`.`start_date` AS `start_date`,`_ticket`.`end_date` AS `end_date`,`_ticket`.`last_update` AS `last_update`,`_ticket`.`close_date` AS `close_date`,`_ticket`.`private_log` AS `private_log`,`_ticket`.`private_log_index` AS `private_log_index`,`_ticket`.`id_instalador` AS `id_instalador`,`_ticket`.`san` AS `san`,`_ticket`.`nombre_instalador` AS `nombre_instalador`,`_ticket`.`pais_ticket` AS `pais_ticket`,`_ticket_problem`.`status` AS `status`,`_ticket_problem`.`service_id` AS `service_id`,`Service_service_id_service`.`name` AS `service_name`,`_ticket_problem`.`servicesubcategory_id` AS `servicesubcategory_id`,`ServiceSubcategory_servicesubcategory_id_servicesubcategory`.`name` AS `servicesubcategory_name`,`_ticket_problem`.`product` AS `product`,`_ticket_problem`.`impact` AS `impact`,`_ticket_problem`.`urgency` AS `urgency`,`_ticket_problem`.`priority` AS `priority`,`_ticket_problem`.`related_change_id` AS `related_change_id`,`Change_related_change_id_ticket`.`ref` AS `related_change_ref`,`_ticket_problem`.`assignment_date` AS `assignment_date`,`_ticket_problem`.`resolution_date` AS `resolution_date`,`_ticket`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_ticket`.`ref`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_caller_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_caller_id_contact`.`name`,'')) as char charset utf8) AS `caller_id_friendlyname`,cast(concat(coalesce(`Team_team_id_contact`.`name`,'')) as char charset utf8) AS `team_id_friendlyname`,cast(concat(coalesce(`Person_agent_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_agent_id_contact`.`name`,'')) as char charset utf8) AS `agent_id_friendlyname`,cast(concat(coalesce(`Service_service_id_service`.`name`,'')) as char charset utf8) AS `service_id_friendlyname`,cast(concat(coalesce(`ServiceSubcategory_servicesubcategory_id_servicesubcategory`.`name`,'')) as char charset utf8) AS `servicesubcategory_id_friendlyname`,cast(concat(coalesce(`Change_related_change_id_ticket`.`ref`,'')) as char charset utf8) AS `related_change_id_friendlyname`,`Change_related_change_id_ticket`.`finalclass` AS `related_change_id_finalclass_recall` from ((((`ticket_problem` `_ticket_problem` left join `service` `Service_service_id_service` on((`_ticket_problem`.`service_id` = `Service_service_id_service`.`id`))) left join `servicesubcategory` `ServiceSubcategory_servicesubcategory_id_servicesubcategory` on((`_ticket_problem`.`servicesubcategory_id` = `ServiceSubcategory_servicesubcategory_id_servicesubcategory`.`id`))) left join (`change` `Change_related_change_id_change` join `ticket` `Change_related_change_id_ticket` on((`Change_related_change_id_change`.`id` = `Change_related_change_id_ticket`.`id`))) on((`_ticket_problem`.`related_change_id` = `Change_related_change_id_change`.`id`))) join ((((`ticket` `_ticket` join `organization` `Organization_org_id_organization` on((`_ticket`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_caller_id_person` join `contact` `Person_caller_id_contact` on((`Person_caller_id_person`.`id` = `Person_caller_id_contact`.`id`))) on((`_ticket`.`caller_id` = `Person_caller_id_person`.`id`))) left join (`team` `Team_team_id_team` join `contact` `Team_team_id_contact` on((`Team_team_id_team`.`id` = `Team_team_id_contact`.`id`))) on((`_ticket`.`team_id` = `Team_team_id_team`.`id`))) left join (`person` `Person_agent_id_person` join `contact` `Person_agent_id_contact` on((`Person_agent_id_person`.`id` = `Person_agent_id_contact`.`id`))) on((`_ticket`.`agent_id` = `Person_agent_id_person`.`id`))) on((`_ticket_problem`.`id` = `_ticket`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_ProviderContract`
--

/*!50001 DROP VIEW IF EXISTS `view_ProviderContract`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_ProviderContract` AS select distinct `_providercontract`.`id` AS `id`,`_contract`.`name` AS `name`,`_contract`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_contract`.`description` AS `description`,`_contract`.`start_date` AS `start_date`,`_contract`.`end_date` AS `end_date`,`_contract`.`cost` AS `cost`,`_contract`.`cost_currency` AS `cost_currency`,`_contract`.`contracttype_id` AS `contracttype_id`,`ContractType_contracttype_id_typology`.`name` AS `contracttype_name`,`_contract`.`billing_frequency` AS `billing_frequency`,`_contract`.`cost_unit` AS `cost_unit`,`_contract`.`provider_id` AS `provider_id`,`Organization_provider_id_organization`.`name` AS `provider_name`,`_contract`.`status` AS `status`,`_providercontract`.`sla` AS `sla`,`_providercontract`.`coverage` AS `coverage`,`_contract`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_contract`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`ContractType_contracttype_id_typology`.`name`,'')) as char charset utf8) AS `contracttype_id_friendlyname`,cast(concat(coalesce(`Organization_provider_id_organization`.`name`,'')) as char charset utf8) AS `provider_id_friendlyname` from (`providercontract` `_providercontract` join (((`contract` `_contract` join `organization` `Organization_org_id_organization` on((`_contract`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`contracttype` `ContractType_contracttype_id_contracttype` join `typology` `ContractType_contracttype_id_typology` on((`ContractType_contracttype_id_contracttype`.`id` = `ContractType_contracttype_id_typology`.`id`))) on((`_contract`.`contracttype_id` = `ContractType_contracttype_id_contracttype`.`id`))) join `organization` `Organization_provider_id_organization` on((`_contract`.`provider_id` = `Organization_provider_id_organization`.`id`))) on((`_providercontract`.`id` = `_contract`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Rack`
--

/*!50001 DROP VIEW IF EXISTS `view_Rack`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Rack` AS select distinct `_rack`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_rack`.`nb_u` AS `nb_u`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname` from ((`rack` `_rack` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_rack`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_rack`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_RoutineChange`
--

/*!50001 DROP VIEW IF EXISTS `view_RoutineChange`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_RoutineChange` AS select distinct `_change_routine`.`id` AS `id`,`_ticket`.`operational_status` AS `operational_status`,`_ticket`.`ref` AS `ref`,`_ticket`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ticket`.`caller_id` AS `caller_id`,`Person_caller_id_contact`.`name` AS `caller_name`,`_ticket`.`team_id` AS `team_id`,`Team_team_id_contact`.`email` AS `team_name`,`_ticket`.`agent_id` AS `agent_id`,`Person_agent_id_contact`.`name` AS `agent_name`,`_ticket`.`title` AS `title`,`_ticket`.`description` AS `description`,`_ticket`.`description_format` AS `description_format`,`_ticket`.`start_date` AS `start_date`,`_ticket`.`end_date` AS `end_date`,`_ticket`.`last_update` AS `last_update`,`_ticket`.`close_date` AS `close_date`,`_ticket`.`private_log` AS `private_log`,`_ticket`.`private_log_index` AS `private_log_index`,`_ticket`.`id_instalador` AS `id_instalador`,`_ticket`.`san` AS `san`,`_ticket`.`nombre_instalador` AS `nombre_instalador`,`_ticket`.`pais_ticket` AS `pais_ticket`,`_change`.`status` AS `status`,`_change`.`reason` AS `reason`,`_change`.`requestor_id` AS `requestor_id`,`Person_requestor_id_contact`.`email` AS `requestor_email`,`_change`.`creation_date` AS `creation_date`,`_change`.`impact` AS `impact`,`_change`.`supervisor_group_id` AS `supervisor_group_id`,`Team_supervisor_group_id_contact`.`name` AS `supervisor_group_name`,`_change`.`supervisor_id` AS `supervisor_id`,`Person_supervisor_id_contact`.`email` AS `supervisor_email`,`_change`.`manager_group_id` AS `manager_group_id`,`Team_manager_group_id_contact`.`name` AS `manager_group_name`,`_change`.`manager_id` AS `manager_id`,`Person_manager_id_contact`.`email` AS `manager_email`,`_change`.`outage` AS `outage`,`_change`.`fallback` AS `fallback`,`_change`.`parent_id` AS `parent_id`,`Change_parent_id_ticket`.`ref` AS `parent_name`,`_change`.`external_id_cambios` AS `external_id_cambios`,`_change`.`servicefamily_key` AS `servicefamily_key`,`ServiceFamily_servicefamily_key_servicefamily`.`name` AS `servicefamily_n`,`_change`.`service_key` AS `service_key`,`Service_service_key_service`.`name` AS `service_n`,`_change`.`servicesubcategory_key` AS `servicesubcategory_key`,`ServiceSubcategory_servicesubcategory_key_servicesubcategory`.`name` AS `servicesubcategory_n`,`_change_routine`.`tipo_cambio` AS `tipo_cambio`,`_ticket`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_ticket`.`ref`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_caller_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_caller_id_contact`.`name`,'')) as char charset utf8) AS `caller_id_friendlyname`,cast(concat(coalesce(`Team_team_id_contact`.`name`,'')) as char charset utf8) AS `team_id_friendlyname`,cast(concat(coalesce(`Person_agent_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_agent_id_contact`.`name`,'')) as char charset utf8) AS `agent_id_friendlyname`,cast(concat(coalesce(`Person_requestor_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_requestor_id_contact`.`name`,'')) as char charset utf8) AS `requestor_id_friendlyname`,cast(concat(coalesce(`Team_supervisor_group_id_contact`.`name`,'')) as char charset utf8) AS `supervisor_group_id_friendlyname`,cast(concat(coalesce(`Person_supervisor_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_supervisor_id_contact`.`name`,'')) as char charset utf8) AS `supervisor_id_friendlyname`,cast(concat(coalesce(`Team_manager_group_id_contact`.`name`,'')) as char charset utf8) AS `manager_group_id_friendlyname`,cast(concat(coalesce(`Person_manager_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_manager_id_contact`.`name`,'')) as char charset utf8) AS `manager_id_friendlyname`,cast(concat(coalesce(`Change_parent_id_ticket`.`ref`,'')) as char charset utf8) AS `parent_id_friendlyname`,`Change_parent_id_ticket`.`finalclass` AS `parent_id_finalclass_recall`,cast(concat(coalesce(`ServiceFamily_servicefamily_key_servicefamily`.`name`,'')) as char charset utf8) AS `servicefamily_key_friendlyname`,cast(concat(coalesce(`Service_service_key_service`.`name`,'')) as char charset utf8) AS `service_key_friendlyname`,cast(concat(coalesce(`ServiceSubcategory_servicesubcategory_key_servicesubcategory`.`name`,'')) as char charset utf8) AS `servicesubcategory_key_friendlyname` from ((`change_routine` `_change_routine` join ((((`ticket` `_ticket` join `organization` `Organization_org_id_organization` on((`_ticket`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_caller_id_person` join `contact` `Person_caller_id_contact` on((`Person_caller_id_person`.`id` = `Person_caller_id_contact`.`id`))) on((`_ticket`.`caller_id` = `Person_caller_id_person`.`id`))) left join (`team` `Team_team_id_team` join `contact` `Team_team_id_contact` on((`Team_team_id_team`.`id` = `Team_team_id_contact`.`id`))) on((`_ticket`.`team_id` = `Team_team_id_team`.`id`))) left join (`person` `Person_agent_id_person` join `contact` `Person_agent_id_contact` on((`Person_agent_id_person`.`id` = `Person_agent_id_contact`.`id`))) on((`_ticket`.`agent_id` = `Person_agent_id_person`.`id`))) on((`_change_routine`.`id` = `_ticket`.`id`))) join (((((((((`change` `_change` left join (`person` `Person_requestor_id_person` join `contact` `Person_requestor_id_contact` on((`Person_requestor_id_person`.`id` = `Person_requestor_id_contact`.`id`))) on((`_change`.`requestor_id` = `Person_requestor_id_person`.`id`))) left join (`team` `Team_supervisor_group_id_team` join `contact` `Team_supervisor_group_id_contact` on((`Team_supervisor_group_id_team`.`id` = `Team_supervisor_group_id_contact`.`id`))) on((`_change`.`supervisor_group_id` = `Team_supervisor_group_id_team`.`id`))) left join (`person` `Person_supervisor_id_person` join `contact` `Person_supervisor_id_contact` on((`Person_supervisor_id_person`.`id` = `Person_supervisor_id_contact`.`id`))) on((`_change`.`supervisor_id` = `Person_supervisor_id_person`.`id`))) left join (`team` `Team_manager_group_id_team` join `contact` `Team_manager_group_id_contact` on((`Team_manager_group_id_team`.`id` = `Team_manager_group_id_contact`.`id`))) on((`_change`.`manager_group_id` = `Team_manager_group_id_team`.`id`))) left join (`person` `Person_manager_id_person` join `contact` `Person_manager_id_contact` on((`Person_manager_id_person`.`id` = `Person_manager_id_contact`.`id`))) on((`_change`.`manager_id` = `Person_manager_id_person`.`id`))) left join (`change` `Change_parent_id_change` join `ticket` `Change_parent_id_ticket` on((`Change_parent_id_change`.`id` = `Change_parent_id_ticket`.`id`))) on((`_change`.`parent_id` = `Change_parent_id_change`.`id`))) left join `servicefamily` `ServiceFamily_servicefamily_key_servicefamily` on((`_change`.`servicefamily_key` = `ServiceFamily_servicefamily_key_servicefamily`.`id`))) left join `service` `Service_service_key_service` on((`_change`.`service_key` = `Service_service_key_service`.`id`))) left join `servicesubcategory` `ServiceSubcategory_servicesubcategory_key_servicesubcategory` on((`_change`.`servicesubcategory_key` = `ServiceSubcategory_servicesubcategory_key_servicesubcategory`.`id`))) on((`_change_routine`.`id` = `_change`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_SANSwitch`
--

/*!50001 DROP VIEW IF EXISTS `view_SANSwitch`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_SANSwitch` AS select distinct `_sanswitch`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_datacenterdevice`.`rack_id` AS `rack_id`,`Rack_rack_id_functionalci`.`name` AS `rack_name`,`_datacenterdevice`.`enclosure_id` AS `enclosure_id`,`Enclosure_enclosure_id_functionalci`.`name` AS `enclosure_name`,`_datacenterdevice`.`nb_u` AS `nb_u`,`_datacenterdevice`.`managementip` AS `managementip`,`_datacenterdevice`.`powera_id` AS `powerA_id`,`PowerConnection_powerA_id_functionalci`.`name` AS `powerA_name`,`_datacenterdevice`.`powerB_id` AS `powerB_id`,`PowerConnection_powerB_id_functionalci`.`name` AS `powerB_name`,`_datacenterdevice`.`redundancy` AS `redundancy`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname`,cast(concat(coalesce(`Rack_rack_id_functionalci`.`name`,'')) as char charset utf8) AS `rack_id_friendlyname`,cast(concat(coalesce(`Enclosure_enclosure_id_functionalci`.`name`,'')) as char charset utf8) AS `enclosure_id_friendlyname`,cast(concat(coalesce(`PowerConnection_powerA_id_functionalci`.`name`,'')) as char charset utf8) AS `powerA_id_friendlyname`,`PowerConnection_powerA_id_functionalci`.`finalclass` AS `powerA_id_finalclass_recall`,cast(concat(coalesce(`PowerConnection_powerB_id_functionalci`.`name`,'')) as char charset utf8) AS `powerB_id_friendlyname`,`PowerConnection_powerB_id_functionalci`.`finalclass` AS `powerB_id_finalclass_recall` from (((`sanswitch` `_sanswitch` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_sanswitch`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_sanswitch`.`id` = `_physicaldevice`.`id`))) join ((((`datacenterdevice` `_datacenterdevice` left join (`rack` `Rack_rack_id_rack` join `functionalci` `Rack_rack_id_functionalci` on((`Rack_rack_id_rack`.`id` = `Rack_rack_id_functionalci`.`id`))) on((`_datacenterdevice`.`rack_id` = `Rack_rack_id_rack`.`id`))) left join (`enclosure` `Enclosure_enclosure_id_enclosure` join `functionalci` `Enclosure_enclosure_id_functionalci` on((`Enclosure_enclosure_id_enclosure`.`id` = `Enclosure_enclosure_id_functionalci`.`id`))) on((`_datacenterdevice`.`enclosure_id` = `Enclosure_enclosure_id_enclosure`.`id`))) left join (`powerconnection` `PowerConnection_powerA_id_powerconnection` join `functionalci` `PowerConnection_powerA_id_functionalci` on((`PowerConnection_powerA_id_powerconnection`.`id` = `PowerConnection_powerA_id_functionalci`.`id`))) on((`_datacenterdevice`.`powera_id` = `PowerConnection_powerA_id_powerconnection`.`id`))) left join (`powerconnection` `PowerConnection_powerB_id_powerconnection` join `functionalci` `PowerConnection_powerB_id_functionalci` on((`PowerConnection_powerB_id_powerconnection`.`id` = `PowerConnection_powerB_id_functionalci`.`id`))) on((`_datacenterdevice`.`powerB_id` = `PowerConnection_powerB_id_powerconnection`.`id`))) on((`_sanswitch`.`id` = `_datacenterdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_SLA`
--

/*!50001 DROP VIEW IF EXISTS `view_SLA`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_SLA` AS select distinct `_sla`.`id` AS `id`,`_sla`.`name` AS `name`,`_sla`.`description` AS `description`,`_sla`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,cast(concat(coalesce(`_sla`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from (`sla` `_sla` join `organization` `Organization_org_id_organization` on((`_sla`.`org_id` = `Organization_org_id_organization`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_SLT`
--

/*!50001 DROP VIEW IF EXISTS `view_SLT`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_SLT` AS select distinct `_slt`.`id` AS `id`,`_slt`.`name` AS `name`,`_slt`.`priority` AS `priority`,`_slt`.`request_type` AS `request_type`,`_slt`.`metric` AS `metric`,`_slt`.`value` AS `value`,`_slt`.`unit` AS `unit`,cast(concat(coalesce(`_slt`.`name`,'')) as char charset utf8) AS `friendlyname` from `slt` `_slt` where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Server`
--

/*!50001 DROP VIEW IF EXISTS `view_Server`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Server` AS select distinct `_server`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_datacenterdevice`.`rack_id` AS `rack_id`,`Rack_rack_id_functionalci`.`name` AS `rack_name`,`_datacenterdevice`.`enclosure_id` AS `enclosure_id`,`Enclosure_enclosure_id_functionalci`.`name` AS `enclosure_name`,`_datacenterdevice`.`nb_u` AS `nb_u`,`_datacenterdevice`.`managementip` AS `managementip`,`_datacenterdevice`.`powera_id` AS `powerA_id`,`PowerConnection_powerA_id_functionalci`.`name` AS `powerA_name`,`_datacenterdevice`.`powerB_id` AS `powerB_id`,`PowerConnection_powerB_id_functionalci`.`name` AS `powerB_name`,`_datacenterdevice`.`redundancy` AS `redundancy`,`_server`.`osfamily_id` AS `osfamily_id`,`OSFamily_osfamily_id_typology`.`name` AS `osfamily_name`,`_server`.`osversion_id` AS `osversion_id`,`OSVersion_osversion_id_typology`.`name` AS `osversion_name`,`_server`.`oslicence_id` AS `oslicence_id`,`OSLicence_oslicence_id_licence`.`name` AS `oslicence_name`,`_server`.`cpu` AS `cpu`,`_server`.`ram` AS `ram`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname`,cast(concat(coalesce(`Rack_rack_id_functionalci`.`name`,'')) as char charset utf8) AS `rack_id_friendlyname`,cast(concat(coalesce(`Enclosure_enclosure_id_functionalci`.`name`,'')) as char charset utf8) AS `enclosure_id_friendlyname`,cast(concat(coalesce(`PowerConnection_powerA_id_functionalci`.`name`,'')) as char charset utf8) AS `powerA_id_friendlyname`,`PowerConnection_powerA_id_functionalci`.`finalclass` AS `powerA_id_finalclass_recall`,cast(concat(coalesce(`PowerConnection_powerB_id_functionalci`.`name`,'')) as char charset utf8) AS `powerB_id_friendlyname`,`PowerConnection_powerB_id_functionalci`.`finalclass` AS `powerB_id_finalclass_recall`,cast(concat(coalesce(`OSFamily_osfamily_id_typology`.`name`,'')) as char charset utf8) AS `osfamily_id_friendlyname`,cast(concat(coalesce(`OSVersion_osversion_id_typology`.`name`,'')) as char charset utf8) AS `osversion_id_friendlyname`,cast(concat(coalesce(`OSLicence_oslicence_id_licence`.`name`,'')) as char charset utf8) AS `oslicence_id_friendlyname` from ((((((`server` `_server` left join (`osfamily` `OSFamily_osfamily_id_osfamily` join `typology` `OSFamily_osfamily_id_typology` on((`OSFamily_osfamily_id_osfamily`.`id` = `OSFamily_osfamily_id_typology`.`id`))) on((`_server`.`osfamily_id` = `OSFamily_osfamily_id_osfamily`.`id`))) left join (`osversion` `OSVersion_osversion_id_osversion` join `typology` `OSVersion_osversion_id_typology` on((`OSVersion_osversion_id_osversion`.`id` = `OSVersion_osversion_id_typology`.`id`))) on((`_server`.`osversion_id` = `OSVersion_osversion_id_osversion`.`id`))) left join (`oslicence` `OSLicence_oslicence_id_oslicence` join `licence` `OSLicence_oslicence_id_licence` on((`OSLicence_oslicence_id_oslicence`.`id` = `OSLicence_oslicence_id_licence`.`id`))) on((`_server`.`oslicence_id` = `OSLicence_oslicence_id_oslicence`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_server`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_server`.`id` = `_physicaldevice`.`id`))) join ((((`datacenterdevice` `_datacenterdevice` left join (`rack` `Rack_rack_id_rack` join `functionalci` `Rack_rack_id_functionalci` on((`Rack_rack_id_rack`.`id` = `Rack_rack_id_functionalci`.`id`))) on((`_datacenterdevice`.`rack_id` = `Rack_rack_id_rack`.`id`))) left join (`enclosure` `Enclosure_enclosure_id_enclosure` join `functionalci` `Enclosure_enclosure_id_functionalci` on((`Enclosure_enclosure_id_enclosure`.`id` = `Enclosure_enclosure_id_functionalci`.`id`))) on((`_datacenterdevice`.`enclosure_id` = `Enclosure_enclosure_id_enclosure`.`id`))) left join (`powerconnection` `PowerConnection_powerA_id_powerconnection` join `functionalci` `PowerConnection_powerA_id_functionalci` on((`PowerConnection_powerA_id_powerconnection`.`id` = `PowerConnection_powerA_id_functionalci`.`id`))) on((`_datacenterdevice`.`powera_id` = `PowerConnection_powerA_id_powerconnection`.`id`))) left join (`powerconnection` `PowerConnection_powerB_id_powerconnection` join `functionalci` `PowerConnection_powerB_id_functionalci` on((`PowerConnection_powerB_id_powerconnection`.`id` = `PowerConnection_powerB_id_functionalci`.`id`))) on((`_datacenterdevice`.`powerB_id` = `PowerConnection_powerB_id_powerconnection`.`id`))) on((`_server`.`id` = `_datacenterdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Service`
--

/*!50001 DROP VIEW IF EXISTS `view_Service`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Service` AS select distinct `_service`.`id` AS `id`,`_service`.`name` AS `name`,`_service`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_service`.`servicefamily_id` AS `servicefamily_id`,`ServiceFamily_servicefamily_id_servicefamily`.`name` AS `servicefamily_name`,`_service`.`description` AS `description`,`_service`.`status` AS `status`,cast(concat(coalesce(`_service`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`ServiceFamily_servicefamily_id_servicefamily`.`name`,'')) as char charset utf8) AS `servicefamily_id_friendlyname` from ((`service` `_service` join `organization` `Organization_org_id_organization` on((`_service`.`org_id` = `Organization_org_id_organization`.`id`))) left join `servicefamily` `ServiceFamily_servicefamily_id_servicefamily` on((`_service`.`servicefamily_id` = `ServiceFamily_servicefamily_id_servicefamily`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_ServiceFamily`
--

/*!50001 DROP VIEW IF EXISTS `view_ServiceFamily`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_ServiceFamily` AS select distinct `_servicefamily`.`id` AS `id`,`_servicefamily`.`name` AS `name`,cast(concat(coalesce(`_servicefamily`.`name`,'')) as char charset utf8) AS `friendlyname` from `servicefamily` `_servicefamily` where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_ServiceSubcategory`
--

/*!50001 DROP VIEW IF EXISTS `view_ServiceSubcategory`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_ServiceSubcategory` AS select distinct `_servicesubcategory`.`id` AS `id`,`_servicesubcategory`.`name` AS `name`,`_servicesubcategory`.`description` AS `description`,`_servicesubcategory`.`service_id` AS `service_id`,`Service_service_id_service`.`org_id` AS `service_org_id`,`Service_service_id_service`.`name` AS `service_name`,`Organization_org_id_organization`.`name` AS `service_provider`,`_servicesubcategory`.`request_type` AS `request_type`,`_servicesubcategory`.`status` AS `status`,cast(concat(coalesce(`_servicesubcategory`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Service_service_id_service`.`name`,'')) as char charset utf8) AS `service_id_friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `service_org_id_friendlyname` from (`servicesubcategory` `_servicesubcategory` join (`service` `Service_service_id_service` join `organization` `Organization_org_id_organization` on((`Service_service_id_service`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_servicesubcategory`.`service_id` = `Service_service_id_service`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Software`
--

/*!50001 DROP VIEW IF EXISTS `view_Software`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Software` AS select distinct `_software`.`id` AS `id`,`_software`.`name` AS `name`,`_software`.`vendor` AS `vendor`,`_software`.`version` AS `version`,`_software`.`type` AS `type`,cast(concat(coalesce(`_software`.`name`,''),coalesce(' ',''),coalesce(`_software`.`version`,'')) as char charset utf8) AS `friendlyname` from `software` `_software` where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_SoftwareInstance`
--

/*!50001 DROP VIEW IF EXISTS `view_SoftwareInstance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_SoftwareInstance` AS select distinct `_softwareinstance`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_softwareinstance`.`functionalci_id` AS `system_id`,`FunctionalCI_system_id_functionalci`.`name` AS `system_name`,`_softwareinstance`.`software_id` AS `software_id`,`Software_software_id_software`.`name` AS `software_name`,`_softwareinstance`.`softwarelicence_id` AS `softwarelicence_id`,`SoftwareLicence_softwarelicence_id_licence`.`name` AS `softwarelicence_name`,`_softwareinstance`.`path` AS `path`,`_softwareinstance`.`status` AS `status`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,if((`FunctionalCI_system_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id1_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8)) AS `system_id_friendlyname`,`FunctionalCI_system_id_functionalci`.`finalclass` AS `system_id_finalclass_recall`,cast(concat(coalesce(`Software_software_id_software`.`name`,''),coalesce(' ',''),coalesce(`Software_software_id_software`.`version`,'')) as char charset utf8) AS `software_id_friendlyname`,cast(concat(coalesce(`SoftwareLicence_softwarelicence_id_licence`.`name`,'')) as char charset utf8) AS `softwarelicence_id_friendlyname` from ((((`softwareinstance` `_softwareinstance` join (`functionalci` `FunctionalCI_system_id_functionalci` left join (`softwareinstance` `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id1_functionalci` on((`FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id1_functionalci`.`id`))) on((`FunctionalCI_system_id_functionalci`.`id` = `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) left join `software` `Software_software_id_software` on((`_softwareinstance`.`software_id` = `Software_software_id_software`.`id`))) left join (`softwarelicence` `SoftwareLicence_softwarelicence_id_softwarelicence` join `licence` `SoftwareLicence_softwarelicence_id_licence` on((`SoftwareLicence_softwarelicence_id_softwarelicence`.`id` = `SoftwareLicence_softwarelicence_id_licence`.`id`))) on((`_softwareinstance`.`softwarelicence_id` = `SoftwareLicence_softwarelicence_id_softwarelicence`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_softwareinstance`.`id` = `_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_SoftwareLicence`
--

/*!50001 DROP VIEW IF EXISTS `view_SoftwareLicence`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_SoftwareLicence` AS select distinct `_softwarelicence`.`id` AS `id`,`_licence`.`name` AS `name`,`_licence`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_licence`.`usage_limit` AS `usage_limit`,`_licence`.`description` AS `description`,`_licence`.`start_date` AS `start_date`,`_licence`.`end_date` AS `end_date`,`_licence`.`licence_key` AS `licence_key`,`_licence`.`perpetual` AS `perpetual`,`_softwarelicence`.`software_id` AS `software_id`,`Software_software_id_software`.`name` AS `software_name`,`_licence`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_licence`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Software_software_id_software`.`name`,''),coalesce(' ',''),coalesce(`Software_software_id_software`.`version`,'')) as char charset utf8) AS `software_id_friendlyname` from ((`softwarelicence` `_softwarelicence` join `software` `Software_software_id_software` on((`_softwarelicence`.`software_id` = `Software_software_id_software`.`id`))) join (`licence` `_licence` join `organization` `Organization_org_id_organization` on((`_licence`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_softwarelicence`.`id` = `_licence`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_SoftwarePatch`
--

/*!50001 DROP VIEW IF EXISTS `view_SoftwarePatch`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_SoftwarePatch` AS select distinct `_softwarepatch`.`id` AS `id`,`_patch`.`name` AS `name`,`_patch`.`description` AS `description`,`_softwarepatch`.`software_id` AS `software_id`,`Software_software_id_software`.`name` AS `software_name`,`_patch`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_patch`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Software_software_id_software`.`name`,''),coalesce(' ',''),coalesce(`Software_software_id_software`.`version`,'')) as char charset utf8) AS `software_id_friendlyname` from ((`softwarepatch` `_softwarepatch` join `software` `Software_software_id_software` on((`_softwarepatch`.`software_id` = `Software_software_id_software`.`id`))) join `patch` `_patch` on((`_softwarepatch`.`id` = `_patch`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_StorageSystem`
--

/*!50001 DROP VIEW IF EXISTS `view_StorageSystem`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_StorageSystem` AS select distinct `_storagesystem`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_datacenterdevice`.`rack_id` AS `rack_id`,`Rack_rack_id_functionalci`.`name` AS `rack_name`,`_datacenterdevice`.`enclosure_id` AS `enclosure_id`,`Enclosure_enclosure_id_functionalci`.`name` AS `enclosure_name`,`_datacenterdevice`.`nb_u` AS `nb_u`,`_datacenterdevice`.`managementip` AS `managementip`,`_datacenterdevice`.`powera_id` AS `powerA_id`,`PowerConnection_powerA_id_functionalci`.`name` AS `powerA_name`,`_datacenterdevice`.`powerB_id` AS `powerB_id`,`PowerConnection_powerB_id_functionalci`.`name` AS `powerB_name`,`_datacenterdevice`.`redundancy` AS `redundancy`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname`,cast(concat(coalesce(`Rack_rack_id_functionalci`.`name`,'')) as char charset utf8) AS `rack_id_friendlyname`,cast(concat(coalesce(`Enclosure_enclosure_id_functionalci`.`name`,'')) as char charset utf8) AS `enclosure_id_friendlyname`,cast(concat(coalesce(`PowerConnection_powerA_id_functionalci`.`name`,'')) as char charset utf8) AS `powerA_id_friendlyname`,`PowerConnection_powerA_id_functionalci`.`finalclass` AS `powerA_id_finalclass_recall`,cast(concat(coalesce(`PowerConnection_powerB_id_functionalci`.`name`,'')) as char charset utf8) AS `powerB_id_friendlyname`,`PowerConnection_powerB_id_functionalci`.`finalclass` AS `powerB_id_finalclass_recall` from (((`storagesystem` `_storagesystem` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_storagesystem`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_storagesystem`.`id` = `_physicaldevice`.`id`))) join ((((`datacenterdevice` `_datacenterdevice` left join (`rack` `Rack_rack_id_rack` join `functionalci` `Rack_rack_id_functionalci` on((`Rack_rack_id_rack`.`id` = `Rack_rack_id_functionalci`.`id`))) on((`_datacenterdevice`.`rack_id` = `Rack_rack_id_rack`.`id`))) left join (`enclosure` `Enclosure_enclosure_id_enclosure` join `functionalci` `Enclosure_enclosure_id_functionalci` on((`Enclosure_enclosure_id_enclosure`.`id` = `Enclosure_enclosure_id_functionalci`.`id`))) on((`_datacenterdevice`.`enclosure_id` = `Enclosure_enclosure_id_enclosure`.`id`))) left join (`powerconnection` `PowerConnection_powerA_id_powerconnection` join `functionalci` `PowerConnection_powerA_id_functionalci` on((`PowerConnection_powerA_id_powerconnection`.`id` = `PowerConnection_powerA_id_functionalci`.`id`))) on((`_datacenterdevice`.`powera_id` = `PowerConnection_powerA_id_powerconnection`.`id`))) left join (`powerconnection` `PowerConnection_powerB_id_powerconnection` join `functionalci` `PowerConnection_powerB_id_functionalci` on((`PowerConnection_powerB_id_powerconnection`.`id` = `PowerConnection_powerB_id_functionalci`.`id`))) on((`_datacenterdevice`.`powerB_id` = `PowerConnection_powerB_id_powerconnection`.`id`))) on((`_storagesystem`.`id` = `_datacenterdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Subnet`
--

/*!50001 DROP VIEW IF EXISTS `view_Subnet`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Subnet` AS select distinct `_subnet`.`id` AS `id`,`_subnet`.`description` AS `description`,`_subnet`.`subnet_name` AS `subnet_name`,`_subnet`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_subnet`.`ip` AS `ip`,`_subnet`.`ip_mask` AS `ip_mask`,cast(concat(coalesce(`_subnet`.`ip`,''),coalesce(' ',''),coalesce(`_subnet`.`ip_mask`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from (`subnet` `_subnet` join `organization` `Organization_org_id_organization` on((`_subnet`.`org_id` = `Organization_org_id_organization`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Tablet`
--

/*!50001 DROP VIEW IF EXISTS `view_Tablet`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Tablet` AS select distinct `_tablet`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname` from ((`tablet` `_tablet` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_tablet`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_tablet`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Tape`
--

/*!50001 DROP VIEW IF EXISTS `view_Tape`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Tape` AS select distinct `_tape`.`id` AS `id`,`_tape`.`name` AS `name`,`_tape`.`description` AS `description`,`_tape`.`size` AS `size`,`_tape`.`tapelibrary_id` AS `tapelibrary_id`,`TapeLibrary_tapelibrary_id_functionalci`.`name` AS `tapelibrary_name`,cast(concat(coalesce(`_tape`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`TapeLibrary_tapelibrary_id_functionalci`.`name`,'')) as char charset utf8) AS `tapelibrary_id_friendlyname` from (`tape` `_tape` join (`tapelibrary` `TapeLibrary_tapelibrary_id_tapelibrary` join `functionalci` `TapeLibrary_tapelibrary_id_functionalci` on((`TapeLibrary_tapelibrary_id_tapelibrary`.`id` = `TapeLibrary_tapelibrary_id_functionalci`.`id`))) on((`_tape`.`tapelibrary_id` = `TapeLibrary_tapelibrary_id_tapelibrary`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_TapeLibrary`
--

/*!50001 DROP VIEW IF EXISTS `view_TapeLibrary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_TapeLibrary` AS select distinct `_tapelibrary`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_datacenterdevice`.`rack_id` AS `rack_id`,`Rack_rack_id_functionalci`.`name` AS `rack_name`,`_datacenterdevice`.`enclosure_id` AS `enclosure_id`,`Enclosure_enclosure_id_functionalci`.`name` AS `enclosure_name`,`_datacenterdevice`.`nb_u` AS `nb_u`,`_datacenterdevice`.`managementip` AS `managementip`,`_datacenterdevice`.`powera_id` AS `powerA_id`,`PowerConnection_powerA_id_functionalci`.`name` AS `powerA_name`,`_datacenterdevice`.`powerB_id` AS `powerB_id`,`PowerConnection_powerB_id_functionalci`.`name` AS `powerB_name`,`_datacenterdevice`.`redundancy` AS `redundancy`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname`,cast(concat(coalesce(`Rack_rack_id_functionalci`.`name`,'')) as char charset utf8) AS `rack_id_friendlyname`,cast(concat(coalesce(`Enclosure_enclosure_id_functionalci`.`name`,'')) as char charset utf8) AS `enclosure_id_friendlyname`,cast(concat(coalesce(`PowerConnection_powerA_id_functionalci`.`name`,'')) as char charset utf8) AS `powerA_id_friendlyname`,`PowerConnection_powerA_id_functionalci`.`finalclass` AS `powerA_id_finalclass_recall`,cast(concat(coalesce(`PowerConnection_powerB_id_functionalci`.`name`,'')) as char charset utf8) AS `powerB_id_friendlyname`,`PowerConnection_powerB_id_functionalci`.`finalclass` AS `powerB_id_finalclass_recall` from (((`tapelibrary` `_tapelibrary` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_tapelibrary`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_tapelibrary`.`id` = `_physicaldevice`.`id`))) join ((((`datacenterdevice` `_datacenterdevice` left join (`rack` `Rack_rack_id_rack` join `functionalci` `Rack_rack_id_functionalci` on((`Rack_rack_id_rack`.`id` = `Rack_rack_id_functionalci`.`id`))) on((`_datacenterdevice`.`rack_id` = `Rack_rack_id_rack`.`id`))) left join (`enclosure` `Enclosure_enclosure_id_enclosure` join `functionalci` `Enclosure_enclosure_id_functionalci` on((`Enclosure_enclosure_id_enclosure`.`id` = `Enclosure_enclosure_id_functionalci`.`id`))) on((`_datacenterdevice`.`enclosure_id` = `Enclosure_enclosure_id_enclosure`.`id`))) left join (`powerconnection` `PowerConnection_powerA_id_powerconnection` join `functionalci` `PowerConnection_powerA_id_functionalci` on((`PowerConnection_powerA_id_powerconnection`.`id` = `PowerConnection_powerA_id_functionalci`.`id`))) on((`_datacenterdevice`.`powera_id` = `PowerConnection_powerA_id_powerconnection`.`id`))) left join (`powerconnection` `PowerConnection_powerB_id_powerconnection` join `functionalci` `PowerConnection_powerB_id_functionalci` on((`PowerConnection_powerB_id_powerconnection`.`id` = `PowerConnection_powerB_id_functionalci`.`id`))) on((`_datacenterdevice`.`powerB_id` = `PowerConnection_powerB_id_powerconnection`.`id`))) on((`_tapelibrary`.`id` = `_datacenterdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Team`
--

/*!50001 DROP VIEW IF EXISTS `view_Team`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Team` AS select distinct `_team`.`id` AS `id`,`_contact`.`name` AS `name`,`_contact`.`status` AS `status`,`_contact`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_contact`.`email` AS `email`,`_contact`.`phone` AS `phone`,`_contact`.`notify` AS `notify`,`_contact`.`function` AS `function`,`_contact`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_contact`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from (`team` `_team` join (`contact` `_contact` join `organization` `Organization_org_id_organization` on((`_contact`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_team`.`id` = `_contact`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_TelephonyCI`
--

/*!50001 DROP VIEW IF EXISTS `view_TelephonyCI`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_TelephonyCI` AS select distinct `_telephonyci`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_telephonyci`.`phonenumber` AS `phonenumber`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname` from ((`telephonyci` `_telephonyci` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_telephonyci`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_telephonyci`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Ticket`
--

/*!50001 DROP VIEW IF EXISTS `view_Ticket`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Ticket` AS select distinct `_ticket`.`id` AS `id`,`_ticket`.`operational_status` AS `operational_status`,`_ticket`.`ref` AS `ref`,`_ticket`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ticket`.`caller_id` AS `caller_id`,`Person_caller_id_contact`.`name` AS `caller_name`,`_ticket`.`team_id` AS `team_id`,`Team_team_id_contact`.`email` AS `team_name`,`_ticket`.`agent_id` AS `agent_id`,`Person_agent_id_contact`.`name` AS `agent_name`,`_ticket`.`title` AS `title`,`_ticket`.`description` AS `description`,`_ticket`.`description_format` AS `description_format`,`_ticket`.`start_date` AS `start_date`,`_ticket`.`end_date` AS `end_date`,`_ticket`.`last_update` AS `last_update`,`_ticket`.`close_date` AS `close_date`,`_ticket`.`private_log` AS `private_log`,`_ticket`.`private_log_index` AS `private_log_index`,`_ticket`.`id_instalador` AS `id_instalador`,`_ticket`.`san` AS `san`,`_ticket`.`nombre_instalador` AS `nombre_instalador`,`_ticket`.`pais_ticket` AS `pais_ticket`,`_ticket`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_ticket`.`ref`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_caller_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_caller_id_contact`.`name`,'')) as char charset utf8) AS `caller_id_friendlyname`,cast(concat(coalesce(`Team_team_id_contact`.`name`,'')) as char charset utf8) AS `team_id_friendlyname`,cast(concat(coalesce(`Person_agent_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_agent_id_contact`.`name`,'')) as char charset utf8) AS `agent_id_friendlyname` from ((((`ticket` `_ticket` join `organization` `Organization_org_id_organization` on((`_ticket`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_caller_id_person` join `contact` `Person_caller_id_contact` on((`Person_caller_id_person`.`id` = `Person_caller_id_contact`.`id`))) on((`_ticket`.`caller_id` = `Person_caller_id_person`.`id`))) left join (`team` `Team_team_id_team` join `contact` `Team_team_id_contact` on((`Team_team_id_team`.`id` = `Team_team_id_contact`.`id`))) on((`_ticket`.`team_id` = `Team_team_id_team`.`id`))) left join (`person` `Person_agent_id_person` join `contact` `Person_agent_id_contact` on((`Person_agent_id_person`.`id` = `Person_agent_id_contact`.`id`))) on((`_ticket`.`agent_id` = `Person_agent_id_person`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Typology`
--

/*!50001 DROP VIEW IF EXISTS `view_Typology`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Typology` AS select distinct `_typology`.`id` AS `id`,`_typology`.`name` AS `name`,`_typology`.`finalclass` AS `finalclass`,if((`_typology`.`finalclass` = 'IOSVersion'),cast(concat(coalesce(`Brand_brand_id_typology`.`name`,''),coalesce(' ',''),coalesce(`_typology`.`name`,'')) as char charset utf8),cast(concat(coalesce(`_typology`.`name`,'')) as char charset utf8)) AS `friendlyname` from (`typology` `_typology` left join (`iosversion` `_fn_IOSVersion_iosversion` join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_fn_IOSVersion_iosversion`.`brand_id` = `Brand_brand_id_brand`.`id`))) on((`_typology`.`id` = `_fn_IOSVersion_iosversion`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_UserRequest`
--

/*!50001 DROP VIEW IF EXISTS `view_UserRequest`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_UserRequest` AS select distinct `_ticket_request`.`id` AS `id`,`_ticket`.`operational_status` AS `operational_status`,`_ticket`.`ref` AS `ref`,`_ticket`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ticket`.`caller_id` AS `caller_id`,`Person_caller_id_contact`.`name` AS `caller_name`,`_ticket`.`team_id` AS `team_id`,`Team_team_id_contact`.`email` AS `team_name`,`_ticket`.`agent_id` AS `agent_id`,`Person_agent_id_contact`.`name` AS `agent_name`,`_ticket`.`title` AS `title`,`_ticket`.`description` AS `description`,`_ticket`.`description_format` AS `description_format`,`_ticket`.`start_date` AS `start_date`,`_ticket`.`end_date` AS `end_date`,`_ticket`.`last_update` AS `last_update`,`_ticket`.`close_date` AS `close_date`,`_ticket`.`private_log` AS `private_log`,`_ticket`.`private_log_index` AS `private_log_index`,`_ticket`.`id_instalador` AS `id_instalador`,`_ticket`.`san` AS `san`,`_ticket`.`nombre_instalador` AS `nombre_instalador`,`_ticket`.`pais_ticket` AS `pais_ticket`,`_ticket_request`.`status` AS `status`,`_ticket_request`.`request_type` AS `request_type`,`_ticket_request`.`impact` AS `impact`,`_ticket_request`.`priority` AS `priority`,`_ticket_request`.`urgency` AS `urgency`,`_ticket_request`.`origin` AS `origin`,`_ticket_request`.`approver_id` AS `approver_id`,`Person_approver_id_contact`.`email` AS `approver_email`,`_ticket_request`.`servicefamily_id` AS `servicefamily_id`,`ServiceFamily_servicefamily_id_servicefamily`.`name` AS `servicefamily_name`,`_ticket_request`.`service_id` AS `service_id`,`Service_service_id_service`.`name` AS `service_name`,`_ticket_request`.`servicesubcategory_id` AS `servicesubcategory_id`,`ServiceSubcategory_servicesubcategory_id_servicesubcategory`.`name` AS `servicesubcategory_name`,`_ticket_request`.`escalation_flag` AS `escalation_flag`,`_ticket_request`.`escalation_reason` AS `escalation_reason`,`_ticket_request`.`assignment_date` AS `assignment_date`,`_ticket_request`.`resolution_date` AS `resolution_date`,`_ticket_request`.`last_pending_date` AS `last_pending_date`,`_ticket_request`.`cumulatedpending_timespent` AS `cumulatedpending`,`_ticket_request`.`cumulatedpending_started` AS `cumulatedpending_started`,`_ticket_request`.`cumulatedpending_laststart` AS `cumulatedpending_laststart`,`_ticket_request`.`cumulatedpending_stopped` AS `cumulatedpending_stopped`,`_ticket_request`.`tto_timespent` AS `tto`,`_ticket_request`.`tto_started` AS `tto_started`,`_ticket_request`.`tto_laststart` AS `tto_laststart`,`_ticket_request`.`tto_stopped` AS `tto_stopped`,`_ticket_request`.`tto_75_deadline` AS `tto_75_deadline`,`_ticket_request`.`tto_75_passed` AS `tto_75_passed`,`_ticket_request`.`tto_75_triggered` AS `tto_75_triggered`,`_ticket_request`.`tto_75_overrun` AS `tto_75_overrun`,`_ticket_request`.`tto_100_deadline` AS `tto_100_deadline`,`_ticket_request`.`tto_100_passed` AS `tto_100_passed`,`_ticket_request`.`tto_100_triggered` AS `tto_100_triggered`,`_ticket_request`.`tto_100_overrun` AS `tto_100_overrun`,`_ticket_request`.`ttr_timespent` AS `ttr`,`_ticket_request`.`ttr_started` AS `ttr_started`,`_ticket_request`.`ttr_laststart` AS `ttr_laststart`,`_ticket_request`.`ttr_stopped` AS `ttr_stopped`,`_ticket_request`.`ttr_75_deadline` AS `ttr_75_deadline`,`_ticket_request`.`ttr_75_passed` AS `ttr_75_passed`,`_ticket_request`.`ttr_75_triggered` AS `ttr_75_triggered`,`_ticket_request`.`ttr_75_overrun` AS `ttr_75_overrun`,`_ticket_request`.`ttr_100_deadline` AS `ttr_100_deadline`,`_ticket_request`.`ttr_100_passed` AS `ttr_100_passed`,`_ticket_request`.`ttr_100_triggered` AS `ttr_100_triggered`,`_ticket_request`.`ttr_100_overrun` AS `ttr_100_overrun`,`_ticket_request`.`tto_100_deadline` AS `tto_escalation_deadline`,`_ticket_request`.`tto_100_passed` AS `sla_tto_passed`,`_ticket_request`.`tto_100_overrun` AS `sla_tto_over`,`_ticket_request`.`ttr_100_deadline` AS `ttr_escalation_deadline`,`_ticket_request`.`ttr_100_passed` AS `sla_ttr_passed`,`_ticket_request`.`ttr_100_overrun` AS `sla_ttr_over`,`_ticket_request`.`time_spent` AS `time_spent`,`_ticket_request`.`resolution_code` AS `resolution_code`,`_ticket_request`.`solution` AS `solution`,`_ticket_request`.`pending_reason` AS `pending_reason`,`_ticket_request`.`parent_request_id` AS `parent_request_id`,`UserRequest_parent_request_id_ticket`.`ref` AS `parent_request_ref`,`_ticket_request`.`parent_incident_id` AS `parent_incident_id`,`Incident_parent_incident_id_ticket`.`ref` AS `parent_incident_ref`,`_ticket_request`.`parent_problem_id` AS `parent_problem_id`,`Problem_parent_problem_id_ticket`.`ref` AS `parent_problem_ref`,`_ticket_request`.`parent_change_id` AS `parent_change_id`,`Change_parent_change_id_ticket`.`ref` AS `parent_change_ref`,`_ticket_request`.`public_log` AS `public_log`,`_ticket_request`.`public_log_index` AS `public_log_index`,`_ticket_request`.`user_satisfaction` AS `user_satisfaction`,`_ticket_request`.`user_commment` AS `user_comment`,`_ticket_request`.`external_id` AS `external_id`,`_ticket`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_ticket`.`ref`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_caller_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_caller_id_contact`.`name`,'')) as char charset utf8) AS `caller_id_friendlyname`,cast(concat(coalesce(`Team_team_id_contact`.`name`,'')) as char charset utf8) AS `team_id_friendlyname`,cast(concat(coalesce(`Person_agent_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_agent_id_contact`.`name`,'')) as char charset utf8) AS `agent_id_friendlyname`,cast(concat(coalesce(`Person_approver_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_approver_id_contact`.`name`,'')) as char charset utf8) AS `approver_id_friendlyname`,cast(concat(coalesce(`ServiceFamily_servicefamily_id_servicefamily`.`name`,'')) as char charset utf8) AS `servicefamily_id_friendlyname`,cast(concat(coalesce(`Service_service_id_service`.`name`,'')) as char charset utf8) AS `service_id_friendlyname`,cast(concat(coalesce(`ServiceSubcategory_servicesubcategory_id_servicesubcategory`.`name`,'')) as char charset utf8) AS `servicesubcategory_id_friendlyname`,cast(concat(coalesce(`UserRequest_parent_request_id_ticket`.`ref`,'')) as char charset utf8) AS `parent_request_id_friendlyname`,cast(concat(coalesce(`Incident_parent_incident_id_ticket`.`ref`,'')) as char charset utf8) AS `parent_incident_id_friendlyname`,cast(concat(coalesce(`Problem_parent_problem_id_ticket`.`ref`,'')) as char charset utf8) AS `parent_problem_id_friendlyname`,cast(concat(coalesce(`Change_parent_change_id_ticket`.`ref`,'')) as char charset utf8) AS `parent_change_id_friendlyname`,`Change_parent_change_id_ticket`.`finalclass` AS `parent_change_id_finalclass_recall` from (((((((((`ticket_request` `_ticket_request` left join (`person` `Person_approver_id_person` join `contact` `Person_approver_id_contact` on((`Person_approver_id_person`.`id` = `Person_approver_id_contact`.`id`))) on((`_ticket_request`.`approver_id` = `Person_approver_id_person`.`id`))) left join `servicefamily` `ServiceFamily_servicefamily_id_servicefamily` on((`_ticket_request`.`servicefamily_id` = `ServiceFamily_servicefamily_id_servicefamily`.`id`))) left join `service` `Service_service_id_service` on((`_ticket_request`.`service_id` = `Service_service_id_service`.`id`))) left join `servicesubcategory` `ServiceSubcategory_servicesubcategory_id_servicesubcategory` on((`_ticket_request`.`servicesubcategory_id` = `ServiceSubcategory_servicesubcategory_id_servicesubcategory`.`id`))) left join (`ticket_request` `UserRequest_parent_request_id_ticket_request` join `ticket` `UserRequest_parent_request_id_ticket` on((`UserRequest_parent_request_id_ticket_request`.`id` = `UserRequest_parent_request_id_ticket`.`id`))) on((`_ticket_request`.`parent_request_id` = `UserRequest_parent_request_id_ticket_request`.`id`))) left join (`ticket_incident` `Incident_parent_incident_id_ticket_incident` join `ticket` `Incident_parent_incident_id_ticket` on((`Incident_parent_incident_id_ticket_incident`.`id` = `Incident_parent_incident_id_ticket`.`id`))) on((`_ticket_request`.`parent_incident_id` = `Incident_parent_incident_id_ticket_incident`.`id`))) left join (`ticket_problem` `Problem_parent_problem_id_ticket_problem` join `ticket` `Problem_parent_problem_id_ticket` on((`Problem_parent_problem_id_ticket_problem`.`id` = `Problem_parent_problem_id_ticket`.`id`))) on((`_ticket_request`.`parent_problem_id` = `Problem_parent_problem_id_ticket_problem`.`id`))) left join (`change` `Change_parent_change_id_change` join `ticket` `Change_parent_change_id_ticket` on((`Change_parent_change_id_change`.`id` = `Change_parent_change_id_ticket`.`id`))) on((`_ticket_request`.`parent_change_id` = `Change_parent_change_id_change`.`id`))) join ((((`ticket` `_ticket` join `organization` `Organization_org_id_organization` on((`_ticket`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_caller_id_person` join `contact` `Person_caller_id_contact` on((`Person_caller_id_person`.`id` = `Person_caller_id_contact`.`id`))) on((`_ticket`.`caller_id` = `Person_caller_id_person`.`id`))) left join (`team` `Team_team_id_team` join `contact` `Team_team_id_contact` on((`Team_team_id_team`.`id` = `Team_team_id_contact`.`id`))) on((`_ticket`.`team_id` = `Team_team_id_team`.`id`))) left join (`person` `Person_agent_id_person` join `contact` `Person_agent_id_contact` on((`Person_agent_id_person`.`id` = `Person_agent_id_contact`.`id`))) on((`_ticket`.`agent_id` = `Person_agent_id_person`.`id`))) on((`_ticket_request`.`id` = `_ticket`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_VLAN`
--

/*!50001 DROP VIEW IF EXISTS `view_VLAN`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_VLAN` AS select distinct `_vlan`.`id` AS `id`,`_vlan`.`vlan_tag` AS `vlan_tag`,`_vlan`.`description` AS `description`,`_vlan`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,cast(concat(coalesce(`_vlan`.`vlan_tag`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from (`vlan` `_vlan` join `organization` `Organization_org_id_organization` on((`_vlan`.`org_id` = `Organization_org_id_organization`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_VirtualDevice`
--

/*!50001 DROP VIEW IF EXISTS `view_VirtualDevice`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_VirtualDevice` AS select distinct `_virtualdevice`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_virtualdevice`.`status` AS `status`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from (`virtualdevice` `_virtualdevice` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_virtualdevice`.`id` = `_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_VirtualHost`
--

/*!50001 DROP VIEW IF EXISTS `view_VirtualHost`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_VirtualHost` AS select distinct `_virtualhost`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_virtualdevice`.`status` AS `status`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from ((`virtualhost` `_virtualhost` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_virtualhost`.`id` = `_functionalci`.`id`))) join `virtualdevice` `_virtualdevice` on((`_virtualhost`.`id` = `_virtualdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_VirtualMachine`
--

/*!50001 DROP VIEW IF EXISTS `view_VirtualMachine`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_VirtualMachine` AS select distinct `_virtualmachine`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_virtualdevice`.`status` AS `status`,`_virtualmachine`.`virtualhost_id` AS `virtualhost_id`,`VirtualHost_virtualhost_id_functionalci`.`name` AS `virtualhost_name`,`_virtualmachine`.`osfamily_id` AS `osfamily_id`,`OSFamily_osfamily_id_typology`.`name` AS `osfamily_name`,`_virtualmachine`.`osversion_id` AS `osversion_id`,`OSVersion_osversion_id_typology`.`name` AS `osversion_name`,`_virtualmachine`.`oslicence_id` AS `oslicence_id`,`OSLicence_oslicence_id_licence`.`name` AS `oslicence_name`,`_virtualmachine`.`cpu` AS `cpu`,`_virtualmachine`.`ram` AS `ram`,`_virtualmachine`.`managementip` AS `managementip`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`VirtualHost_virtualhost_id_functionalci`.`name`,'')) as char charset utf8) AS `virtualhost_id_friendlyname`,`VirtualHost_virtualhost_id_functionalci`.`finalclass` AS `virtualhost_id_finalclass_recall`,cast(concat(coalesce(`OSFamily_osfamily_id_typology`.`name`,'')) as char charset utf8) AS `osfamily_id_friendlyname`,cast(concat(coalesce(`OSVersion_osversion_id_typology`.`name`,'')) as char charset utf8) AS `osversion_id_friendlyname`,cast(concat(coalesce(`OSLicence_oslicence_id_licence`.`name`,'')) as char charset utf8) AS `oslicence_id_friendlyname` from ((((((`virtualmachine` `_virtualmachine` join (`virtualhost` `VirtualHost_virtualhost_id_virtualhost` join `functionalci` `VirtualHost_virtualhost_id_functionalci` on((`VirtualHost_virtualhost_id_virtualhost`.`id` = `VirtualHost_virtualhost_id_functionalci`.`id`))) on((`_virtualmachine`.`virtualhost_id` = `VirtualHost_virtualhost_id_virtualhost`.`id`))) left join (`osfamily` `OSFamily_osfamily_id_osfamily` join `typology` `OSFamily_osfamily_id_typology` on((`OSFamily_osfamily_id_osfamily`.`id` = `OSFamily_osfamily_id_typology`.`id`))) on((`_virtualmachine`.`osfamily_id` = `OSFamily_osfamily_id_osfamily`.`id`))) left join (`osversion` `OSVersion_osversion_id_osversion` join `typology` `OSVersion_osversion_id_typology` on((`OSVersion_osversion_id_osversion`.`id` = `OSVersion_osversion_id_typology`.`id`))) on((`_virtualmachine`.`osversion_id` = `OSVersion_osversion_id_osversion`.`id`))) left join (`oslicence` `OSLicence_oslicence_id_oslicence` join `licence` `OSLicence_oslicence_id_licence` on((`OSLicence_oslicence_id_oslicence`.`id` = `OSLicence_oslicence_id_licence`.`id`))) on((`_virtualmachine`.`oslicence_id` = `OSLicence_oslicence_id_oslicence`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_virtualmachine`.`id` = `_functionalci`.`id`))) join `virtualdevice` `_virtualdevice` on((`_virtualmachine`.`id` = `_virtualdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_WebApplication`
--

/*!50001 DROP VIEW IF EXISTS `view_WebApplication`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_WebApplication` AS select distinct `_webapplication`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_webapplication`.`webserver_id` AS `webserver_id`,`WebServer_webserver_id_functionalci`.`name` AS `webserver_name`,`_webapplication`.`url` AS `url`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`WebServer_webserver_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8) AS `webserver_id_friendlyname` from ((`webapplication` `_webapplication` join ((`webserver` `WebServer_webserver_id_webserver` join `functionalci` `WebServer_webserver_id_functionalci` on((`WebServer_webserver_id_webserver`.`id` = `WebServer_webserver_id_functionalci`.`id`))) join (`softwareinstance` `WebServer_webserver_id_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`WebServer_webserver_id_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`WebServer_webserver_id_webserver`.`id` = `WebServer_webserver_id_softwareinstance`.`id`))) on((`_webapplication`.`webserver_id` = `WebServer_webserver_id_webserver`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_webapplication`.`id` = `_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_WebServer`
--

/*!50001 DROP VIEW IF EXISTS `view_WebServer`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_WebServer` AS select distinct `_webserver`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_softwareinstance`.`functionalci_id` AS `system_id`,`FunctionalCI_system_id_functionalci`.`name` AS `system_name`,`_softwareinstance`.`software_id` AS `software_id`,`Software_software_id_software`.`name` AS `software_name`,`_softwareinstance`.`softwarelicence_id` AS `softwarelicence_id`,`SoftwareLicence_softwarelicence_id_licence`.`name` AS `softwarelicence_name`,`_softwareinstance`.`path` AS `path`,`_softwareinstance`.`status` AS `status`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,if((`FunctionalCI_system_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id1_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8)) AS `system_id_friendlyname`,`FunctionalCI_system_id_functionalci`.`finalclass` AS `system_id_finalclass_recall`,cast(concat(coalesce(`Software_software_id_software`.`name`,''),coalesce(' ',''),coalesce(`Software_software_id_software`.`version`,'')) as char charset utf8) AS `software_id_friendlyname`,cast(concat(coalesce(`SoftwareLicence_softwarelicence_id_licence`.`name`,'')) as char charset utf8) AS `softwarelicence_id_friendlyname` from ((`webserver` `_webserver` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_webserver`.`id` = `_functionalci`.`id`))) join (((`softwareinstance` `_softwareinstance` join (`functionalci` `FunctionalCI_system_id_functionalci` left join (`softwareinstance` `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id1_functionalci` on((`FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id1_functionalci`.`id`))) on((`FunctionalCI_system_id_functionalci`.`id` = `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) left join `software` `Software_software_id_software` on((`_softwareinstance`.`software_id` = `Software_software_id_software`.`id`))) left join (`softwarelicence` `SoftwareLicence_softwarelicence_id_softwarelicence` join `licence` `SoftwareLicence_softwarelicence_id_licence` on((`SoftwareLicence_softwarelicence_id_softwarelicence`.`id` = `SoftwareLicence_softwarelicence_id_licence`.`id`))) on((`_softwareinstance`.`softwarelicence_id` = `SoftwareLicence_softwarelicence_id_softwarelicence`.`id`))) on((`_webserver`.`id` = `_softwareinstance`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_WorkOrder`
--

/*!50001 DROP VIEW IF EXISTS `view_WorkOrder`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_WorkOrder` AS select distinct `_workorder`.`id` AS `id`,`_workorder`.`name` AS `name`,`_workorder`.`status` AS `status`,`_workorder`.`description` AS `description`,`_workorder`.`ticket_id` AS `ticket_id`,`Ticket_ticket_id_ticket`.`ref` AS `ticket_ref`,`_workorder`.`team_id` AS `team_id`,`Team_team_id_contact`.`email` AS `team_name`,`_workorder`.`owner_id` AS `agent_id`,`Person_agent_id_contact`.`email` AS `agent_email`,`_workorder`.`start_date` AS `start_date`,`_workorder`.`end_date` AS `end_date`,`_workorder`.`log` AS `log`,`_workorder`.`log_index` AS `log_index`,cast(concat(coalesce(`_workorder`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Ticket_ticket_id_ticket`.`ref`,'')) as char charset utf8) AS `ticket_id_friendlyname`,`Ticket_ticket_id_ticket`.`finalclass` AS `ticket_id_finalclass_recall`,cast(concat(coalesce(`Team_team_id_contact`.`name`,'')) as char charset utf8) AS `team_id_friendlyname`,cast(concat(coalesce(`Person_agent_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_agent_id_contact`.`name`,'')) as char charset utf8) AS `agent_id_friendlyname` from (((`workorder` `_workorder` join `ticket` `Ticket_ticket_id_ticket` on((`_workorder`.`ticket_id` = `Ticket_ticket_id_ticket`.`id`))) join (`team` `Team_team_id_team` join `contact` `Team_team_id_contact` on((`Team_team_id_team`.`id` = `Team_team_id_contact`.`id`))) on((`_workorder`.`team_id` = `Team_team_id_team`.`id`))) left join (`person` `Person_agent_id_person` join `contact` `Person_agent_id_contact` on((`Person_agent_id_person`.`id` = `Person_agent_id_contact`.`id`))) on((`_workorder`.`owner_id` = `Person_agent_id_person`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkApplicationSolutionToBusinessProcess`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkApplicationSolutionToBusinessProcess`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkApplicationSolutionToBusinessProcess` AS select distinct `_lnkapplicationsolutiontobusinessprocess`.`id` AS `id`,`_lnkapplicationsolutiontobusinessprocess`.`businessprocess_id` AS `businessprocess_id`,`BusinessProcess_businessprocess_id_functionalci`.`name` AS `businessprocess_name`,`_lnkapplicationsolutiontobusinessprocess`.`applicationsolution_id` AS `applicationsolution_id`,`ApplicationSolution_applicationsolution_id_functionalci`.`name` AS `applicationsolution_name`,cast(concat(coalesce(`_lnkapplicationsolutiontobusinessprocess`.`businessprocess_id`,''),coalesce(' ',''),coalesce(`_lnkapplicationsolutiontobusinessprocess`.`applicationsolution_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`BusinessProcess_businessprocess_id_functionalci`.`name`,'')) as char charset utf8) AS `businessprocess_id_friendlyname`,cast(concat(coalesce(`ApplicationSolution_applicationsolution_id_functionalci`.`name`,'')) as char charset utf8) AS `applicationsolution_id_friendlyname` from ((`lnkapplicationsolutiontobusinessprocess` `_lnkapplicationsolutiontobusinessprocess` join (`businessprocess` `BusinessProcess_businessprocess_id_businessprocess` join `functionalci` `BusinessProcess_businessprocess_id_functionalci` on((`BusinessProcess_businessprocess_id_businessprocess`.`id` = `BusinessProcess_businessprocess_id_functionalci`.`id`))) on((`_lnkapplicationsolutiontobusinessprocess`.`businessprocess_id` = `BusinessProcess_businessprocess_id_businessprocess`.`id`))) join (`applicationsolution` `ApplicationSolution_applicationsolution_id_applicationsolution` join `functionalci` `ApplicationSolution_applicationsolution_id_functionalci` on((`ApplicationSolution_applicationsolution_id_applicationsolution`.`id` = `ApplicationSolution_applicationsolution_id_functionalci`.`id`))) on((`_lnkapplicationsolutiontobusinessprocess`.`applicationsolution_id` = `ApplicationSolution_applicationsolution_id_applicationsolution`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkApplicationSolutionToFunctionalCI`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkApplicationSolutionToFunctionalCI`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkApplicationSolutionToFunctionalCI` AS select distinct `_lnkapplicationsolutiontofunctionalci`.`id` AS `id`,`_lnkapplicationsolutiontofunctionalci`.`applicationsolution_id` AS `applicationsolution_id`,`ApplicationSolution_applicationsolution_id_functionalci`.`name` AS `applicationsolution_name`,`_lnkapplicationsolutiontofunctionalci`.`functionalci_id` AS `functionalci_id`,`FunctionalCI_functionalci_id_functionalci`.`name` AS `functionalci_name`,cast(concat(coalesce(`_lnkapplicationsolutiontofunctionalci`.`applicationsolution_id`,''),coalesce(' ',''),coalesce(`_lnkapplicationsolutiontofunctionalci`.`functionalci_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`ApplicationSolution_applicationsolution_id_functionalci`.`name`,'')) as char charset utf8) AS `applicationsolution_id_friendlyname`,if((`FunctionalCI_functionalci_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,'')) as char charset utf8)) AS `functionalci_id_friendlyname`,`FunctionalCI_functionalci_id_functionalci`.`finalclass` AS `functionalci_id_finalclass_recall` from ((`lnkapplicationsolutiontofunctionalci` `_lnkapplicationsolutiontofunctionalci` join (`applicationsolution` `ApplicationSolution_applicationsolution_id_applicationsolution` join `functionalci` `ApplicationSolution_applicationsolution_id_functionalci` on((`ApplicationSolution_applicationsolution_id_applicationsolution`.`id` = `ApplicationSolution_applicationsolution_id_functionalci`.`id`))) on((`_lnkapplicationsolutiontofunctionalci`.`applicationsolution_id` = `ApplicationSolution_applicationsolution_id_applicationsolution`.`id`))) join (`functionalci` `FunctionalCI_functionalci_id_functionalci` left join (`softwareinstance` `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`FunctionalCI_functionalci_id_functionalci`.`id` = `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_lnkapplicationsolutiontofunctionalci`.`functionalci_id` = `FunctionalCI_functionalci_id_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkConnectableCIToNetworkDevice`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkConnectableCIToNetworkDevice`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkConnectableCIToNetworkDevice` AS select distinct `_lnkconnectablecitonetworkdevice`.`id` AS `id`,`_lnkconnectablecitonetworkdevice`.`networkdevice_id` AS `networkdevice_id`,`NetworkDevice_networkdevice_id_functionalci`.`name` AS `networkdevice_name`,`_lnkconnectablecitonetworkdevice`.`connectableci_id` AS `connectableci_id`,`ConnectableCI_connectableci_id_functionalci`.`name` AS `connectableci_name`,`_lnkconnectablecitonetworkdevice`.`network_port` AS `network_port`,`_lnkconnectablecitonetworkdevice`.`device_port` AS `device_port`,`_lnkconnectablecitonetworkdevice`.`type` AS `connection_type`,cast(concat(coalesce(`_lnkconnectablecitonetworkdevice`.`networkdevice_id`,''),coalesce(' ',''),coalesce(`_lnkconnectablecitonetworkdevice`.`connectableci_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`NetworkDevice_networkdevice_id_functionalci`.`name`,'')) as char charset utf8) AS `networkdevice_id_friendlyname`,cast(concat(coalesce(`ConnectableCI_connectableci_id_functionalci`.`name`,'')) as char charset utf8) AS `connectableci_id_friendlyname`,`ConnectableCI_connectableci_id_functionalci`.`finalclass` AS `connectableci_id_finalclass_recall` from ((`lnkconnectablecitonetworkdevice` `_lnkconnectablecitonetworkdevice` join (`networkdevice` `NetworkDevice_networkdevice_id_networkdevice` join `functionalci` `NetworkDevice_networkdevice_id_functionalci` on((`NetworkDevice_networkdevice_id_networkdevice`.`id` = `NetworkDevice_networkdevice_id_functionalci`.`id`))) on((`_lnkconnectablecitonetworkdevice`.`networkdevice_id` = `NetworkDevice_networkdevice_id_networkdevice`.`id`))) join (`connectableci` `ConnectableCI_connectableci_id_connectableci` join `functionalci` `ConnectableCI_connectableci_id_functionalci` on((`ConnectableCI_connectableci_id_connectableci`.`id` = `ConnectableCI_connectableci_id_functionalci`.`id`))) on((`_lnkconnectablecitonetworkdevice`.`connectableci_id` = `ConnectableCI_connectableci_id_connectableci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkContactToContract`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkContactToContract`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkContactToContract` AS select distinct `_lnkcontacttocontract`.`id` AS `id`,`_lnkcontacttocontract`.`contract_id` AS `contract_id`,`Contract_contract_id_contract`.`name` AS `contract_name`,`_lnkcontacttocontract`.`contact_id` AS `contact_id`,`Contact_contact_id_contact`.`name` AS `contact_name`,cast(concat(coalesce(`_lnkcontacttocontract`.`contract_id`,''),coalesce(' ',''),coalesce(`_lnkcontacttocontract`.`contact_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Contract_contract_id_contract`.`name`,'')) as char charset utf8) AS `contract_id_friendlyname`,`Contract_contract_id_contract`.`finalclass` AS `contract_id_finalclass_recall`,if((`Contact_contact_id_contact`.`finalclass` in ('Team','Contact')),cast(concat(coalesce(`Contact_contact_id_contact`.`name`,'')) as char charset utf8),cast(concat(coalesce(`Contact_contact_id_fn_Person_person`.`first_name`,''),coalesce(' ',''),coalesce(`Contact_contact_id_contact`.`name`,'')) as char charset utf8)) AS `contact_id_friendlyname`,`Contact_contact_id_contact`.`finalclass` AS `contact_id_finalclass_recall` from ((`lnkcontacttocontract` `_lnkcontacttocontract` join `contract` `Contract_contract_id_contract` on((`_lnkcontacttocontract`.`contract_id` = `Contract_contract_id_contract`.`id`))) join (`contact` `Contact_contact_id_contact` left join `person` `Contact_contact_id_fn_Person_person` on((`Contact_contact_id_contact`.`id` = `Contact_contact_id_fn_Person_person`.`id`))) on((`_lnkcontacttocontract`.`contact_id` = `Contact_contact_id_contact`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkContactToFunctionalCI`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkContactToFunctionalCI`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkContactToFunctionalCI` AS select distinct `_lnkcontacttofunctionalci`.`id` AS `id`,`_lnkcontacttofunctionalci`.`functionalci_id` AS `functionalci_id`,`FunctionalCI_functionalci_id_functionalci`.`name` AS `functionalci_name`,`_lnkcontacttofunctionalci`.`contact_id` AS `contact_id`,`Contact_contact_id_contact`.`name` AS `contact_name`,cast(concat(coalesce(`_lnkcontacttofunctionalci`.`functionalci_id`,''),coalesce(' ',''),coalesce(`_lnkcontacttofunctionalci`.`contact_id`,'')) as char charset utf8) AS `friendlyname`,if((`FunctionalCI_functionalci_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,'')) as char charset utf8)) AS `functionalci_id_friendlyname`,`FunctionalCI_functionalci_id_functionalci`.`finalclass` AS `functionalci_id_finalclass_recall`,if((`Contact_contact_id_contact`.`finalclass` in ('Team','Contact')),cast(concat(coalesce(`Contact_contact_id_contact`.`name`,'')) as char charset utf8),cast(concat(coalesce(`Contact_contact_id_fn_Person_person`.`first_name`,''),coalesce(' ',''),coalesce(`Contact_contact_id_contact`.`name`,'')) as char charset utf8)) AS `contact_id_friendlyname`,`Contact_contact_id_contact`.`finalclass` AS `contact_id_finalclass_recall` from ((`lnkcontacttofunctionalci` `_lnkcontacttofunctionalci` join (`functionalci` `FunctionalCI_functionalci_id_functionalci` left join (`softwareinstance` `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`FunctionalCI_functionalci_id_functionalci`.`id` = `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_lnkcontacttofunctionalci`.`functionalci_id` = `FunctionalCI_functionalci_id_functionalci`.`id`))) join (`contact` `Contact_contact_id_contact` left join `person` `Contact_contact_id_fn_Person_person` on((`Contact_contact_id_contact`.`id` = `Contact_contact_id_fn_Person_person`.`id`))) on((`_lnkcontacttofunctionalci`.`contact_id` = `Contact_contact_id_contact`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkContactToService`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkContactToService`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkContactToService` AS select distinct `_lnkcontacttoservice`.`id` AS `id`,`_lnkcontacttoservice`.`service_id` AS `service_id`,`Service_service_id_service`.`name` AS `service_name`,`_lnkcontacttoservice`.`contact_id` AS `contact_id`,`Contact_contact_id_contact`.`name` AS `contact_name`,cast(concat(coalesce(`_lnkcontacttoservice`.`service_id`,''),coalesce(' ',''),coalesce(`_lnkcontacttoservice`.`contact_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Service_service_id_service`.`name`,'')) as char charset utf8) AS `service_id_friendlyname`,if((`Contact_contact_id_contact`.`finalclass` in ('Team','Contact')),cast(concat(coalesce(`Contact_contact_id_contact`.`name`,'')) as char charset utf8),cast(concat(coalesce(`Contact_contact_id_fn_Person_person`.`first_name`,''),coalesce(' ',''),coalesce(`Contact_contact_id_contact`.`name`,'')) as char charset utf8)) AS `contact_id_friendlyname`,`Contact_contact_id_contact`.`finalclass` AS `contact_id_finalclass_recall` from ((`lnkcontacttoservice` `_lnkcontacttoservice` join `service` `Service_service_id_service` on((`_lnkcontacttoservice`.`service_id` = `Service_service_id_service`.`id`))) join (`contact` `Contact_contact_id_contact` left join `person` `Contact_contact_id_fn_Person_person` on((`Contact_contact_id_contact`.`id` = `Contact_contact_id_fn_Person_person`.`id`))) on((`_lnkcontacttoservice`.`contact_id` = `Contact_contact_id_contact`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkContactToTicket`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkContactToTicket`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkContactToTicket` AS select distinct `_lnkcontacttoticket`.`id` AS `id`,`_lnkcontacttoticket`.`ticket_id` AS `ticket_id`,`Ticket_ticket_id_ticket`.`ref` AS `ticket_ref`,`_lnkcontacttoticket`.`contact_id` AS `contact_id`,`Contact_contact_id_contact`.`email` AS `contact_email`,`_lnkcontacttoticket`.`role` AS `role`,`_lnkcontacttoticket`.`impact_code` AS `role_code`,cast(concat(coalesce(`_lnkcontacttoticket`.`ticket_id`,''),coalesce(' ',''),coalesce(`_lnkcontacttoticket`.`contact_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Ticket_ticket_id_ticket`.`ref`,'')) as char charset utf8) AS `ticket_id_friendlyname`,`Ticket_ticket_id_ticket`.`finalclass` AS `ticket_id_finalclass_recall`,if((`Contact_contact_id_contact`.`finalclass` in ('Team','Contact')),cast(concat(coalesce(`Contact_contact_id_contact`.`name`,'')) as char charset utf8),cast(concat(coalesce(`Contact_contact_id_fn_Person_person`.`first_name`,''),coalesce(' ',''),coalesce(`Contact_contact_id_contact`.`name`,'')) as char charset utf8)) AS `contact_id_friendlyname`,`Contact_contact_id_contact`.`finalclass` AS `contact_id_finalclass_recall` from ((`lnkcontacttoticket` `_lnkcontacttoticket` join `ticket` `Ticket_ticket_id_ticket` on((`_lnkcontacttoticket`.`ticket_id` = `Ticket_ticket_id_ticket`.`id`))) join (`contact` `Contact_contact_id_contact` left join `person` `Contact_contact_id_fn_Person_person` on((`Contact_contact_id_contact`.`id` = `Contact_contact_id_fn_Person_person`.`id`))) on((`_lnkcontacttoticket`.`contact_id` = `Contact_contact_id_contact`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkContractToDocument`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkContractToDocument`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkContractToDocument` AS select distinct `_lnkcontracttodocument`.`id` AS `id`,`_lnkcontracttodocument`.`contract_id` AS `contract_id`,`Contract_contract_id_contract`.`name` AS `contract_name`,`_lnkcontracttodocument`.`document_id` AS `document_id`,`Document_document_id_document`.`name` AS `document_name`,cast(concat(coalesce(`_lnkcontracttodocument`.`contract_id`,''),coalesce(' ',''),coalesce(`_lnkcontracttodocument`.`document_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Contract_contract_id_contract`.`name`,'')) as char charset utf8) AS `contract_id_friendlyname`,`Contract_contract_id_contract`.`finalclass` AS `contract_id_finalclass_recall`,if((`Document_document_id_document`.`finalclass` = 'Document'),cast(concat(coalesce('Document','')) as char charset utf8),cast(concat(coalesce(`Document_document_id_document`.`name`,'')) as char charset utf8)) AS `document_id_friendlyname`,`Document_document_id_document`.`finalclass` AS `document_id_finalclass_recall` from ((`lnkcontracttodocument` `_lnkcontracttodocument` join `contract` `Contract_contract_id_contract` on((`_lnkcontracttodocument`.`contract_id` = `Contract_contract_id_contract`.`id`))) join `document` `Document_document_id_document` on((`_lnkcontracttodocument`.`document_id` = `Document_document_id_document`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkCustomerContractToService`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkCustomerContractToService`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkCustomerContractToService` AS select distinct `_lnkcustomercontracttoservice`.`id` AS `id`,`_lnkcustomercontracttoservice`.`customercontract_id` AS `customercontract_id`,`CustomerContract_customercontract_id_contract`.`name` AS `customercontract_name`,`_lnkcustomercontracttoservice`.`service_id` AS `service_id`,`Service_service_id_service`.`name` AS `service_name`,`_lnkcustomercontracttoservice`.`sla_id` AS `sla_id`,`SLA_sla_id_sla`.`name` AS `sla_name`,`_lnkcustomercontracttoservice`.`coveragewindow_id` AS `coveragewindow_id`,`CoverageWindow_coveragewindow_id_coverage_windows`.`name` AS `coveragewindow_name`,cast(concat(coalesce(`_lnkcustomercontracttoservice`.`customercontract_id`,''),coalesce(' ',''),coalesce(`_lnkcustomercontracttoservice`.`service_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`CustomerContract_customercontract_id_contract`.`name`,'')) as char charset utf8) AS `customercontract_id_friendlyname`,cast(concat(coalesce(`Service_service_id_service`.`name`,'')) as char charset utf8) AS `service_id_friendlyname`,cast(concat(coalesce(`SLA_sla_id_sla`.`name`,'')) as char charset utf8) AS `sla_id_friendlyname`,cast(concat(coalesce(`CoverageWindow_coveragewindow_id_coverage_windows`.`name`,'')) as char charset utf8) AS `coveragewindow_id_friendlyname` from ((((`lnkcustomercontracttoservice` `_lnkcustomercontracttoservice` join (`customercontract` `CustomerContract_customercontract_id_customercontract` join `contract` `CustomerContract_customercontract_id_contract` on((`CustomerContract_customercontract_id_customercontract`.`id` = `CustomerContract_customercontract_id_contract`.`id`))) on((`_lnkcustomercontracttoservice`.`customercontract_id` = `CustomerContract_customercontract_id_customercontract`.`id`))) join `service` `Service_service_id_service` on((`_lnkcustomercontracttoservice`.`service_id` = `Service_service_id_service`.`id`))) left join `sla` `SLA_sla_id_sla` on((`_lnkcustomercontracttoservice`.`sla_id` = `SLA_sla_id_sla`.`id`))) left join `coverage_windows` `CoverageWindow_coveragewindow_id_coverage_windows` on((`_lnkcustomercontracttoservice`.`coveragewindow_id` = `CoverageWindow_coveragewindow_id_coverage_windows`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkDeliveryModelToContact`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkDeliveryModelToContact`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkDeliveryModelToContact` AS select distinct `_lnkdeliverymodeltocontact`.`id` AS `id`,`_lnkdeliverymodeltocontact`.`deliverymodel_id` AS `deliverymodel_id`,`DeliveryModel_deliverymodel_id_deliverymodel`.`name` AS `deliverymodel_name`,`_lnkdeliverymodeltocontact`.`contact_id` AS `contact_id`,`Contact_contact_id_contact`.`name` AS `contact_name`,`_lnkdeliverymodeltocontact`.`role_id` AS `role_id`,`ContactType_role_id_typology`.`name` AS `role_name`,cast(concat(coalesce(`_lnkdeliverymodeltocontact`.`deliverymodel_id`,''),coalesce(' ',''),coalesce(`_lnkdeliverymodeltocontact`.`contact_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`DeliveryModel_deliverymodel_id_deliverymodel`.`name`,'')) as char charset utf8) AS `deliverymodel_id_friendlyname`,if((`Contact_contact_id_contact`.`finalclass` in ('Team','Contact')),cast(concat(coalesce(`Contact_contact_id_contact`.`name`,'')) as char charset utf8),cast(concat(coalesce(`Contact_contact_id_fn_Person_person`.`first_name`,''),coalesce(' ',''),coalesce(`Contact_contact_id_contact`.`name`,'')) as char charset utf8)) AS `contact_id_friendlyname`,`Contact_contact_id_contact`.`finalclass` AS `contact_id_finalclass_recall`,cast(concat(coalesce(`ContactType_role_id_typology`.`name`,'')) as char charset utf8) AS `role_id_friendlyname` from (((`lnkdeliverymodeltocontact` `_lnkdeliverymodeltocontact` join `deliverymodel` `DeliveryModel_deliverymodel_id_deliverymodel` on((`_lnkdeliverymodeltocontact`.`deliverymodel_id` = `DeliveryModel_deliverymodel_id_deliverymodel`.`id`))) join (`contact` `Contact_contact_id_contact` left join `person` `Contact_contact_id_fn_Person_person` on((`Contact_contact_id_contact`.`id` = `Contact_contact_id_fn_Person_person`.`id`))) on((`_lnkdeliverymodeltocontact`.`contact_id` = `Contact_contact_id_contact`.`id`))) left join (`contacttype` `ContactType_role_id_contacttype` join `typology` `ContactType_role_id_typology` on((`ContactType_role_id_contacttype`.`id` = `ContactType_role_id_typology`.`id`))) on((`_lnkdeliverymodeltocontact`.`role_id` = `ContactType_role_id_contacttype`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkDocumentToError`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToError`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkDocumentToError` AS select distinct `_lnkdocumenttoerror`.`link_id` AS `id`,`_lnkdocumenttoerror`.`document_id` AS `document_id`,`Document_document_id_document`.`name` AS `document_name`,`_lnkdocumenttoerror`.`error_id` AS `error_id`,`KnownError_error_id_knownerror`.`name` AS `error_name`,`_lnkdocumenttoerror`.`link_type` AS `link_type`,cast(concat(coalesce(`_lnkdocumenttoerror`.`link_type`,'')) as char charset utf8) AS `friendlyname`,if((`Document_document_id_document`.`finalclass` = 'Document'),cast(concat(coalesce('Document','')) as char charset utf8),cast(concat(coalesce(`Document_document_id_document`.`name`,'')) as char charset utf8)) AS `document_id_friendlyname`,`Document_document_id_document`.`finalclass` AS `document_id_finalclass_recall`,cast(concat(coalesce(`KnownError_error_id_knownerror`.`name`,'')) as char charset utf8) AS `error_id_friendlyname` from ((`lnkdocumenttoerror` `_lnkdocumenttoerror` join `document` `Document_document_id_document` on((`_lnkdocumenttoerror`.`document_id` = `Document_document_id_document`.`id`))) join `knownerror` `KnownError_error_id_knownerror` on((`_lnkdocumenttoerror`.`error_id` = `KnownError_error_id_knownerror`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkDocumentToFunctionalCI`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToFunctionalCI`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkDocumentToFunctionalCI` AS select distinct `_lnkdocumenttofunctionalci`.`id` AS `id`,`_lnkdocumenttofunctionalci`.`functionalci_id` AS `functionalci_id`,`FunctionalCI_functionalci_id_functionalci`.`name` AS `functionalci_name`,`_lnkdocumenttofunctionalci`.`document_id` AS `document_id`,`Document_document_id_document`.`name` AS `document_name`,cast(concat(coalesce(`_lnkdocumenttofunctionalci`.`functionalci_id`,''),coalesce(' ',''),coalesce(`_lnkdocumenttofunctionalci`.`document_id`,'')) as char charset utf8) AS `friendlyname`,if((`FunctionalCI_functionalci_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,'')) as char charset utf8)) AS `functionalci_id_friendlyname`,`FunctionalCI_functionalci_id_functionalci`.`finalclass` AS `functionalci_id_finalclass_recall`,if((`Document_document_id_document`.`finalclass` = 'Document'),cast(concat(coalesce('Document','')) as char charset utf8),cast(concat(coalesce(`Document_document_id_document`.`name`,'')) as char charset utf8)) AS `document_id_friendlyname`,`Document_document_id_document`.`finalclass` AS `document_id_finalclass_recall` from ((`lnkdocumenttofunctionalci` `_lnkdocumenttofunctionalci` join (`functionalci` `FunctionalCI_functionalci_id_functionalci` left join (`softwareinstance` `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`FunctionalCI_functionalci_id_functionalci`.`id` = `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_lnkdocumenttofunctionalci`.`functionalci_id` = `FunctionalCI_functionalci_id_functionalci`.`id`))) join `document` `Document_document_id_document` on((`_lnkdocumenttofunctionalci`.`document_id` = `Document_document_id_document`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkDocumentToLicence`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToLicence`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkDocumentToLicence` AS select distinct `_lnkdocumenttolicence`.`id` AS `id`,`_lnkdocumenttolicence`.`licence_id` AS `licence_id`,`Licence_licence_id_licence`.`name` AS `licence_name`,`_lnkdocumenttolicence`.`document_id` AS `document_id`,`Document_document_id_document`.`name` AS `document_name`,cast(concat(coalesce(`_lnkdocumenttolicence`.`licence_id`,''),coalesce(' ',''),coalesce(`_lnkdocumenttolicence`.`document_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Licence_licence_id_licence`.`name`,'')) as char charset utf8) AS `licence_id_friendlyname`,`Licence_licence_id_licence`.`finalclass` AS `licence_id_finalclass_recall`,if((`Document_document_id_document`.`finalclass` = 'Document'),cast(concat(coalesce('Document','')) as char charset utf8),cast(concat(coalesce(`Document_document_id_document`.`name`,'')) as char charset utf8)) AS `document_id_friendlyname`,`Document_document_id_document`.`finalclass` AS `document_id_finalclass_recall` from ((`lnkdocumenttolicence` `_lnkdocumenttolicence` join `licence` `Licence_licence_id_licence` on((`_lnkdocumenttolicence`.`licence_id` = `Licence_licence_id_licence`.`id`))) join `document` `Document_document_id_document` on((`_lnkdocumenttolicence`.`document_id` = `Document_document_id_document`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkDocumentToPatch`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToPatch`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkDocumentToPatch` AS select distinct `_lnkdocumenttopatch`.`id` AS `id`,`_lnkdocumenttopatch`.`patch_id` AS `patch_id`,`Patch_patch_id_patch`.`name` AS `patch_name`,`_lnkdocumenttopatch`.`document_id` AS `document_id`,`Document_document_id_document`.`name` AS `document_name`,cast(concat(coalesce(`_lnkdocumenttopatch`.`patch_id`,''),coalesce(' ',''),coalesce(`_lnkdocumenttopatch`.`document_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Patch_patch_id_patch`.`name`,'')) as char charset utf8) AS `patch_id_friendlyname`,`Patch_patch_id_patch`.`finalclass` AS `patch_id_finalclass_recall`,if((`Document_document_id_document`.`finalclass` = 'Document'),cast(concat(coalesce('Document','')) as char charset utf8),cast(concat(coalesce(`Document_document_id_document`.`name`,'')) as char charset utf8)) AS `document_id_friendlyname`,`Document_document_id_document`.`finalclass` AS `document_id_finalclass_recall` from ((`lnkdocumenttopatch` `_lnkdocumenttopatch` join `patch` `Patch_patch_id_patch` on((`_lnkdocumenttopatch`.`patch_id` = `Patch_patch_id_patch`.`id`))) join `document` `Document_document_id_document` on((`_lnkdocumenttopatch`.`document_id` = `Document_document_id_document`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkDocumentToService`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToService`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkDocumentToService` AS select distinct `_lnkdocumenttoservice`.`id` AS `id`,`_lnkdocumenttoservice`.`service_id` AS `service_id`,`Service_service_id_service`.`name` AS `service_name`,`_lnkdocumenttoservice`.`document_id` AS `document_id`,`Document_document_id_document`.`name` AS `document_name`,cast(concat(coalesce(`_lnkdocumenttoservice`.`service_id`,''),coalesce(' ',''),coalesce(`_lnkdocumenttoservice`.`document_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Service_service_id_service`.`name`,'')) as char charset utf8) AS `service_id_friendlyname`,if((`Document_document_id_document`.`finalclass` = 'Document'),cast(concat(coalesce('Document','')) as char charset utf8),cast(concat(coalesce(`Document_document_id_document`.`name`,'')) as char charset utf8)) AS `document_id_friendlyname`,`Document_document_id_document`.`finalclass` AS `document_id_finalclass_recall` from ((`lnkdocumenttoservice` `_lnkdocumenttoservice` join `service` `Service_service_id_service` on((`_lnkdocumenttoservice`.`service_id` = `Service_service_id_service`.`id`))) join `document` `Document_document_id_document` on((`_lnkdocumenttoservice`.`document_id` = `Document_document_id_document`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkDocumentToSoftware`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToSoftware`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkDocumentToSoftware` AS select distinct `_lnkdocumenttosoftware`.`id` AS `id`,`_lnkdocumenttosoftware`.`software_id` AS `software_id`,`Software_software_id_software`.`name` AS `software_name`,`_lnkdocumenttosoftware`.`document_id` AS `document_id`,`Document_document_id_document`.`name` AS `document_name`,cast(concat(coalesce(`_lnkdocumenttosoftware`.`software_id`,''),coalesce(' ',''),coalesce(`_lnkdocumenttosoftware`.`document_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Software_software_id_software`.`name`,''),coalesce(' ',''),coalesce(`Software_software_id_software`.`version`,'')) as char charset utf8) AS `software_id_friendlyname`,if((`Document_document_id_document`.`finalclass` = 'Document'),cast(concat(coalesce('Document','')) as char charset utf8),cast(concat(coalesce(`Document_document_id_document`.`name`,'')) as char charset utf8)) AS `document_id_friendlyname`,`Document_document_id_document`.`finalclass` AS `document_id_finalclass_recall` from ((`lnkdocumenttosoftware` `_lnkdocumenttosoftware` join `software` `Software_software_id_software` on((`_lnkdocumenttosoftware`.`software_id` = `Software_software_id_software`.`id`))) join `document` `Document_document_id_document` on((`_lnkdocumenttosoftware`.`document_id` = `Document_document_id_document`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkErrorToFunctionalCI`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkErrorToFunctionalCI`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkErrorToFunctionalCI` AS select distinct `_lnkerrortofunctionalci`.`link_id` AS `id`,`_lnkerrortofunctionalci`.`functionalci_id` AS `functionalci_id`,`FunctionalCI_functionalci_id_functionalci`.`name` AS `functionalci_name`,`_lnkerrortofunctionalci`.`error_id` AS `error_id`,`KnownError_error_id_knownerror`.`name` AS `error_name`,`_lnkerrortofunctionalci`.`dummy` AS `reason`,cast(concat(coalesce('lnkErrorToFunctionalCI','')) as char charset utf8) AS `friendlyname`,if((`FunctionalCI_functionalci_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,'')) as char charset utf8)) AS `functionalci_id_friendlyname`,`FunctionalCI_functionalci_id_functionalci`.`finalclass` AS `functionalci_id_finalclass_recall`,cast(concat(coalesce(`KnownError_error_id_knownerror`.`name`,'')) as char charset utf8) AS `error_id_friendlyname` from ((`lnkerrortofunctionalci` `_lnkerrortofunctionalci` join (`functionalci` `FunctionalCI_functionalci_id_functionalci` left join (`softwareinstance` `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`FunctionalCI_functionalci_id_functionalci`.`id` = `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_lnkerrortofunctionalci`.`functionalci_id` = `FunctionalCI_functionalci_id_functionalci`.`id`))) join `knownerror` `KnownError_error_id_knownerror` on((`_lnkerrortofunctionalci`.`error_id` = `KnownError_error_id_knownerror`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkFunctionalCIToOSPatch`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkFunctionalCIToOSPatch`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkFunctionalCIToOSPatch` AS select distinct `_lnkfunctionalcitoospatch`.`id` AS `id`,`_lnkfunctionalcitoospatch`.`ospatch_id` AS `ospatch_id`,`OSPatch_ospatch_id_patch`.`name` AS `ospatch_name`,`_lnkfunctionalcitoospatch`.`functionalci_id` AS `functionalci_id`,`FunctionalCI_functionalci_id_functionalci`.`name` AS `functionalci_name`,cast(concat(coalesce(`_lnkfunctionalcitoospatch`.`ospatch_id`,''),coalesce(' ',''),coalesce(`_lnkfunctionalcitoospatch`.`functionalci_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`OSPatch_ospatch_id_patch`.`name`,'')) as char charset utf8) AS `ospatch_id_friendlyname`,if((`FunctionalCI_functionalci_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,'')) as char charset utf8)) AS `functionalci_id_friendlyname`,`FunctionalCI_functionalci_id_functionalci`.`finalclass` AS `functionalci_id_finalclass_recall` from ((`lnkfunctionalcitoospatch` `_lnkfunctionalcitoospatch` join (`ospatch` `OSPatch_ospatch_id_ospatch` join `patch` `OSPatch_ospatch_id_patch` on((`OSPatch_ospatch_id_ospatch`.`id` = `OSPatch_ospatch_id_patch`.`id`))) on((`_lnkfunctionalcitoospatch`.`ospatch_id` = `OSPatch_ospatch_id_ospatch`.`id`))) join (`functionalci` `FunctionalCI_functionalci_id_functionalci` left join (`softwareinstance` `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`FunctionalCI_functionalci_id_functionalci`.`id` = `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_lnkfunctionalcitoospatch`.`functionalci_id` = `FunctionalCI_functionalci_id_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkFunctionalCIToProviderContract`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkFunctionalCIToProviderContract`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkFunctionalCIToProviderContract` AS select distinct `_lnkfunctionalcitoprovidercontract`.`id` AS `id`,`_lnkfunctionalcitoprovidercontract`.`providercontract_id` AS `providercontract_id`,`ProviderContract_providercontract_id_contract`.`name` AS `providercontract_name`,`_lnkfunctionalcitoprovidercontract`.`functionalci_id` AS `functionalci_id`,`FunctionalCI_functionalci_id_functionalci`.`name` AS `functionalci_name`,cast(concat(coalesce(`_lnkfunctionalcitoprovidercontract`.`providercontract_id`,''),coalesce(' ',''),coalesce(`_lnkfunctionalcitoprovidercontract`.`functionalci_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`ProviderContract_providercontract_id_contract`.`name`,'')) as char charset utf8) AS `providercontract_id_friendlyname`,if((`FunctionalCI_functionalci_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,'')) as char charset utf8)) AS `functionalci_id_friendlyname`,`FunctionalCI_functionalci_id_functionalci`.`finalclass` AS `functionalci_id_finalclass_recall` from ((`lnkfunctionalcitoprovidercontract` `_lnkfunctionalcitoprovidercontract` join (`providercontract` `ProviderContract_providercontract_id_providercontract` join `contract` `ProviderContract_providercontract_id_contract` on((`ProviderContract_providercontract_id_providercontract`.`id` = `ProviderContract_providercontract_id_contract`.`id`))) on((`_lnkfunctionalcitoprovidercontract`.`providercontract_id` = `ProviderContract_providercontract_id_providercontract`.`id`))) join (`functionalci` `FunctionalCI_functionalci_id_functionalci` left join (`softwareinstance` `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`FunctionalCI_functionalci_id_functionalci`.`id` = `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_lnkfunctionalcitoprovidercontract`.`functionalci_id` = `FunctionalCI_functionalci_id_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkFunctionalCIToService`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkFunctionalCIToService`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkFunctionalCIToService` AS select distinct `_lnkfunctionalcitoservice`.`id` AS `id`,`_lnkfunctionalcitoservice`.`service_id` AS `service_id`,`Service_service_id_service`.`name` AS `service_name`,`_lnkfunctionalcitoservice`.`functionalci_id` AS `functionalci_id`,`FunctionalCI_functionalci_id_functionalci`.`name` AS `functionalci_name`,cast(concat(coalesce(`_lnkfunctionalcitoservice`.`service_id`,''),coalesce(' ',''),coalesce(`_lnkfunctionalcitoservice`.`functionalci_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Service_service_id_service`.`name`,'')) as char charset utf8) AS `service_id_friendlyname`,if((`FunctionalCI_functionalci_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,'')) as char charset utf8)) AS `functionalci_id_friendlyname`,`FunctionalCI_functionalci_id_functionalci`.`finalclass` AS `functionalci_id_finalclass_recall` from ((`lnkfunctionalcitoservice` `_lnkfunctionalcitoservice` join `service` `Service_service_id_service` on((`_lnkfunctionalcitoservice`.`service_id` = `Service_service_id_service`.`id`))) join (`functionalci` `FunctionalCI_functionalci_id_functionalci` left join (`softwareinstance` `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`FunctionalCI_functionalci_id_functionalci`.`id` = `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_lnkfunctionalcitoservice`.`functionalci_id` = `FunctionalCI_functionalci_id_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkFunctionalCIToTicket`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkFunctionalCIToTicket`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkFunctionalCIToTicket` AS select distinct `_lnkfunctionalcitoticket`.`id` AS `id`,`_lnkfunctionalcitoticket`.`ticket_id` AS `ticket_id`,`Ticket_ticket_id_ticket`.`ref` AS `ticket_ref`,`Ticket_ticket_id_ticket`.`title` AS `ticket_title`,`_lnkfunctionalcitoticket`.`functionalci_id` AS `functionalci_id`,`FunctionalCI_functionalci_id_functionalci`.`name` AS `functionalci_name`,`_lnkfunctionalcitoticket`.`impact` AS `impact`,`_lnkfunctionalcitoticket`.`impact_code` AS `impact_code`,cast(concat(coalesce(`_lnkfunctionalcitoticket`.`ticket_id`,''),coalesce(' ',''),coalesce(`_lnkfunctionalcitoticket`.`functionalci_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Ticket_ticket_id_ticket`.`ref`,'')) as char charset utf8) AS `ticket_id_friendlyname`,`Ticket_ticket_id_ticket`.`finalclass` AS `ticket_id_finalclass_recall`,if((`FunctionalCI_functionalci_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,'')) as char charset utf8)) AS `functionalci_id_friendlyname`,`FunctionalCI_functionalci_id_functionalci`.`finalclass` AS `functionalci_id_finalclass_recall` from ((`lnkfunctionalcitoticket` `_lnkfunctionalcitoticket` join `ticket` `Ticket_ticket_id_ticket` on((`_lnkfunctionalcitoticket`.`ticket_id` = `Ticket_ticket_id_ticket`.`id`))) join (`functionalci` `FunctionalCI_functionalci_id_functionalci` left join (`softwareinstance` `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`FunctionalCI_functionalci_id_functionalci`.`id` = `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_lnkfunctionalcitoticket`.`functionalci_id` = `FunctionalCI_functionalci_id_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkGroupToCI`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkGroupToCI`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkGroupToCI` AS select distinct `_lnkgrouptoci`.`id` AS `id`,`_lnkgrouptoci`.`group_id` AS `group_id`,`Group_group_id_group`.`name` AS `group_name`,`_lnkgrouptoci`.`ci_id` AS `ci_id`,`FunctionalCI_ci_id_functionalci`.`name` AS `ci_name`,`_lnkgrouptoci`.`reason` AS `reason`,cast(concat(coalesce(`_lnkgrouptoci`.`group_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Group_group_id_group`.`name`,'')) as char charset utf8) AS `group_id_friendlyname`,if((`FunctionalCI_ci_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_ci_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_ci_id_functionalci`.`name`,'')) as char charset utf8)) AS `ci_id_friendlyname`,`FunctionalCI_ci_id_functionalci`.`finalclass` AS `ci_id_finalclass_recall` from ((`lnkgrouptoci` `_lnkgrouptoci` join `group` `Group_group_id_group` on((`_lnkgrouptoci`.`group_id` = `Group_group_id_group`.`id`))) join (`functionalci` `FunctionalCI_ci_id_functionalci` left join (`softwareinstance` `FunctionalCI_ci_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`FunctionalCI_ci_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`FunctionalCI_ci_id_functionalci`.`id` = `FunctionalCI_ci_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_lnkgrouptoci`.`ci_id` = `FunctionalCI_ci_id_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkPersonToTeam`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkPersonToTeam`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkPersonToTeam` AS select distinct `_lnkpersontoteam`.`id` AS `id`,`_lnkpersontoteam`.`team_id` AS `team_id`,`Team_team_id_contact`.`name` AS `team_name`,`_lnkpersontoteam`.`person_id` AS `person_id`,`Person_person_id_contact`.`name` AS `person_name`,`_lnkpersontoteam`.`role_id` AS `role_id`,`ContactType_role_id_typology`.`name` AS `role_name`,cast(concat(coalesce(`_lnkpersontoteam`.`team_id`,''),coalesce(' ',''),coalesce(`_lnkpersontoteam`.`person_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Team_team_id_contact`.`name`,'')) as char charset utf8) AS `team_id_friendlyname`,cast(concat(coalesce(`Person_person_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_person_id_contact`.`name`,'')) as char charset utf8) AS `person_id_friendlyname`,cast(concat(coalesce(`ContactType_role_id_typology`.`name`,'')) as char charset utf8) AS `role_id_friendlyname` from (((`lnkpersontoteam` `_lnkpersontoteam` join (`team` `Team_team_id_team` join `contact` `Team_team_id_contact` on((`Team_team_id_team`.`id` = `Team_team_id_contact`.`id`))) on((`_lnkpersontoteam`.`team_id` = `Team_team_id_team`.`id`))) join (`person` `Person_person_id_person` join `contact` `Person_person_id_contact` on((`Person_person_id_person`.`id` = `Person_person_id_contact`.`id`))) on((`_lnkpersontoteam`.`person_id` = `Person_person_id_person`.`id`))) left join (`contacttype` `ContactType_role_id_contacttype` join `typology` `ContactType_role_id_typology` on((`ContactType_role_id_contacttype`.`id` = `ContactType_role_id_typology`.`id`))) on((`_lnkpersontoteam`.`role_id` = `ContactType_role_id_contacttype`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkPhysicalInterfaceToVLAN`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkPhysicalInterfaceToVLAN`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkPhysicalInterfaceToVLAN` AS select distinct `_lnkphysicalinterfacetovlan`.`id` AS `id`,`_lnkphysicalinterfacetovlan`.`physicalinterface_id` AS `physicalinterface_id`,`PhysicalInterface_physicalinterface_id_networkinterface`.`name` AS `physicalinterface_name`,`PhysicalInterface_physicalinterface_id_physicalinterface`.`connectableci_id` AS `physicalinterface_device_id`,`ConnectableCI_connectableci_id_functionalci`.`name` AS `physicalinterface_device_name`,`_lnkphysicalinterfacetovlan`.`vlan_id` AS `vlan_id`,`VLAN_vlan_id_vlan`.`vlan_tag` AS `vlan_tag`,cast(concat(coalesce(`_lnkphysicalinterfacetovlan`.`physicalinterface_id`,''),coalesce(' ',''),coalesce(`_lnkphysicalinterfacetovlan`.`vlan_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`PhysicalInterface_physicalinterface_id_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`ConnectableCI_connectableci_id_functionalci`.`name`,'')) as char charset utf8) AS `physicalinterface_id_friendlyname`,cast(concat(coalesce(`ConnectableCI_connectableci_id_functionalci`.`name`,'')) as char charset utf8) AS `physicalinterface_device_id_friendlyname`,cast(concat(coalesce(`VLAN_vlan_id_vlan`.`vlan_tag`,'')) as char charset utf8) AS `vlan_id_friendlyname` from ((`lnkphysicalinterfacetovlan` `_lnkphysicalinterfacetovlan` join ((`physicalinterface` `PhysicalInterface_physicalinterface_id_physicalinterface` join (`connectableci` `ConnectableCI_connectableci_id_connectableci` join `functionalci` `ConnectableCI_connectableci_id_functionalci` on((`ConnectableCI_connectableci_id_connectableci`.`id` = `ConnectableCI_connectableci_id_functionalci`.`id`))) on((`PhysicalInterface_physicalinterface_id_physicalinterface`.`connectableci_id` = `ConnectableCI_connectableci_id_connectableci`.`id`))) join `networkinterface` `PhysicalInterface_physicalinterface_id_networkinterface` on((`PhysicalInterface_physicalinterface_id_physicalinterface`.`id` = `PhysicalInterface_physicalinterface_id_networkinterface`.`id`))) on((`_lnkphysicalinterfacetovlan`.`physicalinterface_id` = `PhysicalInterface_physicalinterface_id_physicalinterface`.`id`))) join `vlan` `VLAN_vlan_id_vlan` on((`_lnkphysicalinterfacetovlan`.`vlan_id` = `VLAN_vlan_id_vlan`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkProviderContractToService`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkProviderContractToService`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkProviderContractToService` AS select distinct `_lnkprovidercontracttoservice`.`id` AS `id`,`_lnkprovidercontracttoservice`.`service_id` AS `service_id`,`Service_service_id_service`.`name` AS `service_name`,`_lnkprovidercontracttoservice`.`providercontract_id` AS `providercontract_id`,`ProviderContract_providercontract_id_contract`.`name` AS `providercontract_name`,cast(concat(coalesce(`_lnkprovidercontracttoservice`.`service_id`,''),coalesce(' ',''),coalesce(`_lnkprovidercontracttoservice`.`providercontract_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Service_service_id_service`.`name`,'')) as char charset utf8) AS `service_id_friendlyname`,cast(concat(coalesce(`ProviderContract_providercontract_id_contract`.`name`,'')) as char charset utf8) AS `providercontract_id_friendlyname` from ((`lnkprovidercontracttoservice` `_lnkprovidercontracttoservice` join `service` `Service_service_id_service` on((`_lnkprovidercontracttoservice`.`service_id` = `Service_service_id_service`.`id`))) join (`providercontract` `ProviderContract_providercontract_id_providercontract` join `contract` `ProviderContract_providercontract_id_contract` on((`ProviderContract_providercontract_id_providercontract`.`id` = `ProviderContract_providercontract_id_contract`.`id`))) on((`_lnkprovidercontracttoservice`.`providercontract_id` = `ProviderContract_providercontract_id_providercontract`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkSLAToSLT`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkSLAToSLT`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkSLAToSLT` AS select distinct `_lnkslatoslt`.`id` AS `id`,`_lnkslatoslt`.`sla_id` AS `sla_id`,`SLA_sla_id_sla`.`name` AS `sla_name`,`_lnkslatoslt`.`slt_id` AS `slt_id`,`SLT_slt_id_slt`.`name` AS `slt_name`,`SLT_slt_id_slt`.`metric` AS `slt_metric`,`SLT_slt_id_slt`.`request_type` AS `slt_request_type`,`SLT_slt_id_slt`.`priority` AS `slt_ticket_priority`,`SLT_slt_id_slt`.`value` AS `slt_value`,`SLT_slt_id_slt`.`unit` AS `slt_value_unit`,cast(concat(coalesce(`_lnkslatoslt`.`sla_id`,''),coalesce(' ',''),coalesce(`_lnkslatoslt`.`slt_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`SLA_sla_id_sla`.`name`,'')) as char charset utf8) AS `sla_id_friendlyname`,cast(concat(coalesce(`SLT_slt_id_slt`.`name`,'')) as char charset utf8) AS `slt_id_friendlyname` from ((`lnkslatoslt` `_lnkslatoslt` join `sla` `SLA_sla_id_sla` on((`_lnkslatoslt`.`sla_id` = `SLA_sla_id_sla`.`id`))) join `slt` `SLT_slt_id_slt` on((`_lnkslatoslt`.`slt_id` = `SLT_slt_id_slt`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkSanToDatacenterDevice`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkSanToDatacenterDevice`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkSanToDatacenterDevice` AS select distinct `_lnkdatacenterdevicetosan`.`id` AS `id`,`_lnkdatacenterdevicetosan`.`san_id` AS `san_id`,`SANSwitch_san_id_functionalci`.`name` AS `san_name`,`_lnkdatacenterdevicetosan`.`datacenterdevice_id` AS `datacenterdevice_id`,`DatacenterDevice_datacenterdevice_id_functionalci`.`name` AS `datacenterdevice_name`,`_lnkdatacenterdevicetosan`.`san_port` AS `san_port`,`_lnkdatacenterdevicetosan`.`datacenterdevice_port` AS `datacenterdevice_port`,cast(concat(coalesce(`_lnkdatacenterdevicetosan`.`san_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`SANSwitch_san_id_functionalci`.`name`,'')) as char charset utf8) AS `san_id_friendlyname`,cast(concat(coalesce(`DatacenterDevice_datacenterdevice_id_functionalci`.`name`,'')) as char charset utf8) AS `datacenterdevice_id_friendlyname`,`DatacenterDevice_datacenterdevice_id_functionalci`.`finalclass` AS `datacenterdevice_id_finalclass_recall` from ((`lnkdatacenterdevicetosan` `_lnkdatacenterdevicetosan` join (`sanswitch` `SANSwitch_san_id_sanswitch` join `functionalci` `SANSwitch_san_id_functionalci` on((`SANSwitch_san_id_sanswitch`.`id` = `SANSwitch_san_id_functionalci`.`id`))) on((`_lnkdatacenterdevicetosan`.`san_id` = `SANSwitch_san_id_sanswitch`.`id`))) join (`datacenterdevice` `DatacenterDevice_datacenterdevice_id_datacenterdevice` join `functionalci` `DatacenterDevice_datacenterdevice_id_functionalci` on((`DatacenterDevice_datacenterdevice_id_datacenterdevice`.`id` = `DatacenterDevice_datacenterdevice_id_functionalci`.`id`))) on((`_lnkdatacenterdevicetosan`.`datacenterdevice_id` = `DatacenterDevice_datacenterdevice_id_datacenterdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkServerToVolume`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkServerToVolume`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkServerToVolume` AS select distinct `_lnkservertovolume`.`id` AS `id`,`_lnkservertovolume`.`volume_id` AS `volume_id`,`LogicalVolume_volume_id_logicalvolume`.`name` AS `volume_name`,`_lnkservertovolume`.`server_id` AS `server_id`,`Server_server_id_functionalci`.`name` AS `server_name`,`_lnkservertovolume`.`size_used` AS `size_used`,cast(concat(coalesce(`_lnkservertovolume`.`volume_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`StorageSystem_storagesystem_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`LogicalVolume_volume_id_logicalvolume`.`name`,'')) as char charset utf8) AS `volume_id_friendlyname`,cast(concat(coalesce(`Server_server_id_functionalci`.`name`,'')) as char charset utf8) AS `server_id_friendlyname` from ((`lnkservertovolume` `_lnkservertovolume` join (`logicalvolume` `LogicalVolume_volume_id_logicalvolume` join (`storagesystem` `StorageSystem_storagesystem_id_storagesystem` join `functionalci` `StorageSystem_storagesystem_id_functionalci` on((`StorageSystem_storagesystem_id_storagesystem`.`id` = `StorageSystem_storagesystem_id_functionalci`.`id`))) on((`LogicalVolume_volume_id_logicalvolume`.`storagesystem_id` = `StorageSystem_storagesystem_id_storagesystem`.`id`))) on((`_lnkservertovolume`.`volume_id` = `LogicalVolume_volume_id_logicalvolume`.`id`))) join (`server` `Server_server_id_server` join `functionalci` `Server_server_id_functionalci` on((`Server_server_id_server`.`id` = `Server_server_id_functionalci`.`id`))) on((`_lnkservertovolume`.`server_id` = `Server_server_id_server`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkSoftwareInstanceToSoftwarePatch`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkSoftwareInstanceToSoftwarePatch`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkSoftwareInstanceToSoftwarePatch` AS select distinct `_lnksoftwareinstancetosoftwarepatch`.`id` AS `id`,`_lnksoftwareinstancetosoftwarepatch`.`softwarepatch_id` AS `softwarepatch_id`,`SoftwarePatch_softwarepatch_id_patch`.`name` AS `softwarepatch_name`,`_lnksoftwareinstancetosoftwarepatch`.`softwareinstance_id` AS `softwareinstance_id`,`SoftwareInstance_softwareinstance_id_functionalci`.`name` AS `softwareinstance_name`,cast(concat(coalesce(`_lnksoftwareinstancetosoftwarepatch`.`softwarepatch_id`,''),coalesce(' ',''),coalesce(`_lnksoftwareinstancetosoftwarepatch`.`softwareinstance_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`SoftwarePatch_softwarepatch_id_patch`.`name`,'')) as char charset utf8) AS `softwarepatch_id_friendlyname`,cast(concat(coalesce(`SoftwareInstance_softwareinstance_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8) AS `softwareinstance_id_friendlyname`,`SoftwareInstance_softwareinstance_id_functionalci`.`finalclass` AS `softwareinstance_id_finalclass_recall` from ((`lnksoftwareinstancetosoftwarepatch` `_lnksoftwareinstancetosoftwarepatch` join (`softwarepatch` `SoftwarePatch_softwarepatch_id_softwarepatch` join `patch` `SoftwarePatch_softwarepatch_id_patch` on((`SoftwarePatch_softwarepatch_id_softwarepatch`.`id` = `SoftwarePatch_softwarepatch_id_patch`.`id`))) on((`_lnksoftwareinstancetosoftwarepatch`.`softwarepatch_id` = `SoftwarePatch_softwarepatch_id_softwarepatch`.`id`))) join ((`softwareinstance` `SoftwareInstance_softwareinstance_id_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`SoftwareInstance_softwareinstance_id_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) join `functionalci` `SoftwareInstance_softwareinstance_id_functionalci` on((`SoftwareInstance_softwareinstance_id_softwareinstance`.`id` = `SoftwareInstance_softwareinstance_id_functionalci`.`id`))) on((`_lnksoftwareinstancetosoftwarepatch`.`softwareinstance_id` = `SoftwareInstance_softwareinstance_id_softwareinstance`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkSubnetToVLAN`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkSubnetToVLAN`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkSubnetToVLAN` AS select distinct `_lnksubnettovlan`.`id` AS `id`,`_lnksubnettovlan`.`subnet_id` AS `subnet_id`,`Subnet_subnet_id_subnet`.`ip` AS `subnet_ip`,`Subnet_subnet_id_subnet`.`subnet_name` AS `subnet_name`,`_lnksubnettovlan`.`vlan_id` AS `vlan_id`,`VLAN_vlan_id_vlan`.`vlan_tag` AS `vlan_tag`,cast(concat(coalesce(`_lnksubnettovlan`.`subnet_id`,''),coalesce(' ',''),coalesce(`_lnksubnettovlan`.`vlan_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Subnet_subnet_id_subnet`.`ip`,''),coalesce(' ',''),coalesce(`Subnet_subnet_id_subnet`.`ip_mask`,'')) as char charset utf8) AS `subnet_id_friendlyname`,cast(concat(coalesce(`VLAN_vlan_id_vlan`.`vlan_tag`,'')) as char charset utf8) AS `vlan_id_friendlyname` from ((`lnksubnettovlan` `_lnksubnettovlan` join `subnet` `Subnet_subnet_id_subnet` on((`_lnksubnettovlan`.`subnet_id` = `Subnet_subnet_id_subnet`.`id`))) join `vlan` `VLAN_vlan_id_vlan` on((`_lnksubnettovlan`.`vlan_id` = `VLAN_vlan_id_vlan`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkVirtualDeviceToVolume`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkVirtualDeviceToVolume`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`aws_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkVirtualDeviceToVolume` AS select distinct `_lnkvirtualdevicetovolume`.`id` AS `id`,`_lnkvirtualdevicetovolume`.`volume_id` AS `volume_id`,`LogicalVolume_volume_id_logicalvolume`.`name` AS `volume_name`,`_lnkvirtualdevicetovolume`.`virtualdevice_id` AS `virtualdevice_id`,`VirtualDevice_virtualdevice_id_functionalci`.`name` AS `virtualdevice_name`,`_lnkvirtualdevicetovolume`.`size_used` AS `size_used`,cast(concat(coalesce(`_lnkvirtualdevicetovolume`.`volume_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`StorageSystem_storagesystem_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`LogicalVolume_volume_id_logicalvolume`.`name`,'')) as char charset utf8) AS `volume_id_friendlyname`,cast(concat(coalesce(`VirtualDevice_virtualdevice_id_functionalci`.`name`,'')) as char charset utf8) AS `virtualdevice_id_friendlyname`,`VirtualDevice_virtualdevice_id_functionalci`.`finalclass` AS `virtualdevice_id_finalclass_recall` from ((`lnkvirtualdevicetovolume` `_lnkvirtualdevicetovolume` join (`logicalvolume` `LogicalVolume_volume_id_logicalvolume` join (`storagesystem` `StorageSystem_storagesystem_id_storagesystem` join `functionalci` `StorageSystem_storagesystem_id_functionalci` on((`StorageSystem_storagesystem_id_storagesystem`.`id` = `StorageSystem_storagesystem_id_functionalci`.`id`))) on((`LogicalVolume_volume_id_logicalvolume`.`storagesystem_id` = `StorageSystem_storagesystem_id_storagesystem`.`id`))) on((`_lnkvirtualdevicetovolume`.`volume_id` = `LogicalVolume_volume_id_logicalvolume`.`id`))) join (`virtualdevice` `VirtualDevice_virtualdevice_id_virtualdevice` join `functionalci` `VirtualDevice_virtualdevice_id_functionalci` on((`VirtualDevice_virtualdevice_id_virtualdevice`.`id` = `VirtualDevice_virtualdevice_id_functionalci`.`id`))) on((`_lnkvirtualdevicetovolume`.`virtualdevice_id` = `VirtualDevice_virtualdevice_id_virtualdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-11-26 10:37:03
